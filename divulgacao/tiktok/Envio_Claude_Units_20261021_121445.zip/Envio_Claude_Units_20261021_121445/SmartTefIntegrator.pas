unit SmartTefIntegrator;

interface

uses
  System.SysUtils, System.Classes, System.JSON, System.Generics.Collections, RestRequest4D;

type
  // Model para operador
  TOperador = class
  public
    Email: string;
    Name: string;
    Password: string;
    constructor CreateFromJSON(const AJSON: TJSONObject);
  end;

  // Retorno cria��o loja
  TCreateStoreResponse = class
  public
    Token: string;
    ActivationToken: string;
    OcpApimSubscriptionKey: string;
    Operador: TOperador;
    constructor CreateFromJSON(const AJSON: TJSONObject);
    destructor Destroy; override;
  end;

  // Interface para integra��o Smart TEF
  ISmartTefIntegrator = interface
    ['{A1B2C3D4-E5F6-47A8-9B0C-123456789ABC}']
    function CreateStore(const CNPJ, Email, Password, Name, StoreName: string)
      : TCreateStoreResponse;
  end;

  // Implementa��o da interface
  TSmartTefIntegrator = class(TInterfacedObject, ISmartTefIntegrator)
  private
    FBaseUrl: string;
    FIntegratorToken: string;
    FSubscriptionKeyInt: string;

    function PostRequest(const Endpoint: string; const Body: TJSONObject): string;
  public
    class function New: ISmartTefIntegrator;

    constructor Create;

    function CreateStore(const CNPJ, Email, Password, Name, StoreName: string)
      : TCreateStoreResponse;
  end;

implementation

{ TOperador }

constructor TOperador.CreateFromJSON(const AJSON: TJSONObject);
begin
  Email := AJSON.GetValue<string>('email', '');
  Name := AJSON.GetValue<string>('name', '');
  Password := AJSON.GetValue<string>('password', '');
end;

{ TCreateStoreResponse }

constructor TCreateStoreResponse.CreateFromJSON(const AJSON: TJSONObject);
var
  OpJSON: TJSONObject;
begin
  Token := AJSON.GetValue<string>('token', '');
  ActivationToken := AJSON.GetValue<string>('activationToken', '');
  OcpApimSubscriptionKey := AJSON.GetValue<string>('OcpApiSubscriptionKey', '');

  OpJSON := AJSON.GetValue<TJSONObject>('operador');

  if Assigned(OpJSON) then
    Operador := TOperador.CreateFromJSON(OpJSON)
  else
    Operador := nil;
end;

destructor TCreateStoreResponse.Destroy;
begin
  Operador.Free;
  inherited;
end;

{ TSmartTefIntegrator }

constructor TSmartTefIntegrator.Create;
begin
  FBaseUrl := 'https://api.smarttef.mobi';
  FIntegratorToken := '<TOKEN_REMOVIDO>';
  FSubscriptionKeyInt := '<CHAVE_REMOVIDA>';
end;

function TSmartTefIntegrator.PostRequest(const Endpoint: string; const Body: TJSONObject): string;
var
  Response: IResponse;
begin
  Response := TRequest.New //
    .BaseURL(FBaseUrl) //
    .Resource(Endpoint) //
    .TokenBearer(FIntegratorToken) //
    .AddHeader('Ocp-Apim-Subscription-Key', FSubscriptionKeyInt, [poDoNotEncode]) //
    .AddBody(Body.ToString) //
    .Post;

  if Trim(Copy(Response.StatusCode.ToString, 1, 1)) = '2' then
    Result := Response.Content
  else
    raise Exception.CreateFmt('HTTP Error %d: %s', [Response.StatusCode, Response.Content]);
end;

function TSmartTefIntegrator.CreateStore(const CNPJ, Email, Password, Name, StoreName: string)
  : TCreateStoreResponse;
var
  Body, RespJSON: TJSONObject;
  RespStr: string;
begin
  Body := TJSONObject.Create;

  try
    Body.AddPair('cnpj', CNPJ);
    Body.AddPair('cnpj_integrador', '40581011000127');
    Body.AddPair('email', Email.ToLower);
    Body.AddPair('password', Password);
    Body.AddPair('name', Name.ToUpper);
    Body.AddPair('store_name', StoreName.ToUpper);

    RespStr := PostRequest('/integrator/store/active', Body);
    RespJSON := TJSONObject.ParseJSONValue(RespStr) as TJSONObject;

    try
      Result := TCreateStoreResponse.CreateFromJSON(RespJSON);
    finally
      RespJSON.Free;
    end;
  finally
    Body.Free;
  end;
end;

class function TSmartTefIntegrator.New: ISmartTefIntegrator;
begin
  Result := Self.Create;
end;

end.
