object FrmContatoCliente: TFrmContatoCliente
  Left = 0
  Top = 0
  Caption = 'Contatos do cliente'
  ClientHeight = 531
  ClientWidth = 858
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  OnKeyDown = FormKeyDown
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Panel9: TPanel
    Left = 0
    Top = 490
    Width = 858
    Height = 41
    Align = alBottom
    TabOrder = 0
    object AdvGlowButton4: TAdvGlowButton
      Left = 316
      Top = 3
      Width = 217
      Height = 34
      HelpType = htKeyword
      Caption = '&Sair (Alt+C)'
      ImageIndex = 2
      NotesFont.Charset = DEFAULT_CHARSET
      NotesFont.Color = clWindowText
      NotesFont.Height = -11
      NotesFont.Name = 'Tahoma'
      NotesFont.Style = []
      Picture.Data = {
        89504E470D0A1A0A0000000D49484452000000180000001808040000004A7EF5
        730000000467414D410000B18F0BFC6105000000206348524D00007A26000080
        840000FA00000080E8000075300000EA6000003A98000017709CBA513C000000
        02624B47440000AA8D2332000000097048597300000EC400000EC401952B0E1B
        0000000774494D4507E30604122F1FDC90E3FD000001614944415438CB8D94BD
        2F044118C67F7B8E427C457909B73EB6950D9A2B2844C18556215121A1E124FE
        06D1E9F90B8448AE106E43E2A3BA4E240805A771711A5C7C6C7276356B6EF676
        77E29D6667DEE79967E679DF598D60B49022491B258AE479451993E4A8E08A61
        633111054E604950799CD01546188980BBB8BC301C46D953503E1900D07C840E
        AE69E29E6D2EB1D119639498C83E62062D98624182403F5792CAFA9F82CE2AF5
        80C3067701934F31BDEF2F748018E7DE0E1F7487DCAC876FA1310FB022A6CB11
        866F0A4456C3E082462F51C091603F1CB1440548B3EFADDDC299C24A9769007A
        C5BC1C431D2E7EF39D38B38A2359EC006088B522404608662274B6AA97FE8FAD
        06B620CCC501871951B8BA00BC955D1A44E1B2C1D658F49106B9913C5B0B6FBE
        075FF35511054CDEFCFBABDABB4C5FED71540FA8C450D08D04B908F831C9A8CA
        A639A8F9091C322E03B4105233293A69E79927F2BCFB93BF93F1E1F260B5E89E
        0000002574455874646174653A63726561746500323031392D30362D30345431
        363A34373A33312B30323A303070E1C8170000002574455874646174653A6D6F
        6469667900323031392D30362D30345431363A34373A33312B30323A303001BC
        70AB0000001974455874536F667477617265007777772E696E6B73636170652E
        6F72679BEE3C1A0000000049454E44AE426082}
      Rounded = True
      TabOrder = 0
      TabStop = True
      OnClick = AdvGlowButton4Click
      Appearance.BorderColor = 11382963
      Appearance.BorderColorHot = 11565130
      Appearance.BorderColorCheckedHot = 11565130
      Appearance.BorderColorDown = 11565130
      Appearance.BorderColorChecked = 13744549
      Appearance.BorderColorDisabled = 13948116
      Appearance.Color = clWhite
      Appearance.ColorTo = clWhite
      Appearance.ColorChecked = 13744549
      Appearance.ColorCheckedTo = 13744549
      Appearance.ColorDisabled = clWhite
      Appearance.ColorDisabledTo = clNone
      Appearance.ColorDown = 11565130
      Appearance.ColorDownTo = 11565130
      Appearance.ColorHot = 16444643
      Appearance.ColorHotTo = 16444643
      Appearance.ColorMirror = clWhite
      Appearance.ColorMirrorTo = clWhite
      Appearance.ColorMirrorHot = 16444643
      Appearance.ColorMirrorHotTo = 16444643
      Appearance.ColorMirrorDown = 11565130
      Appearance.ColorMirrorDownTo = 11565130
      Appearance.ColorMirrorChecked = 13744549
      Appearance.ColorMirrorCheckedTo = 13744549
      Appearance.ColorMirrorDisabled = clWhite
      Appearance.ColorMirrorDisabledTo = clNone
      Appearance.GradientHot = ggVertical
      Appearance.GradientMirrorHot = ggVertical
      Appearance.GradientDown = ggVertical
      Appearance.GradientMirrorDown = ggVertical
      Appearance.GradientChecked = ggVertical
      Appearance.TextColorChecked = 3750459
      Appearance.TextColorDown = 2303013
      Appearance.TextColorHot = 2303013
      Appearance.TextColorDisabled = 13948116
    end
  end
  object pgDadoscli: TPageControl
    Left = 0
    Top = 0
    Width = 858
    Height = 490
    ActivePage = TabSheet2
    Align = alClient
    TabOrder = 1
    object TabSheet2: TTabSheet
      Caption = 'Consulta'
      object GroupBox22: TGroupBox
        Left = 0
        Top = 373
        Width = 850
        Height = 89
        Align = alBottom
        Caption = 'Contato Principal'
        TabOrder = 0
        object Telefone: TLabel
          Left = 3
          Top = 24
          Width = 51
          Height = 16
          Caption = 'Telefone:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object Label11: TLabel
          Left = 262
          Top = 24
          Width = 44
          Height = 16
          Caption = 'Celular:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object Label14: TLabel
          Left = 3
          Top = 54
          Width = 37
          Height = 16
          Caption = 'Email:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object edtTelefonePrincip: TAlignEdit
          Left = 60
          Top = 18
          Width = 127
          Height = 23
          CharCase = ecUpperCase
          Color = 16775142
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          ReadOnly = True
          TabOrder = 0
        end
        object EdtCelPrincip: TAlignEdit
          Left = 312
          Top = 17
          Width = 127
          Height = 23
          CharCase = ecUpperCase
          Color = 16775142
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          ReadOnly = True
          TabOrder = 1
        end
        object edtemailPrincp: TAlignEdit
          Left = 46
          Top = 46
          Width = 583
          Height = 23
          CharCase = ecUpperCase
          Color = 16775142
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          ReadOnly = True
          TabOrder = 2
        end
      end
      object GroupBox2: TGroupBox
        Left = 0
        Top = 0
        Width = 850
        Height = 373
        Align = alClient
        TabOrder = 1
        object Label27: TLabel
          Left = 11
          Top = 14
          Width = 40
          Height = 16
          Caption = 'Cliente'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object edtnomecliContato: TAlignEdit
          Left = 3
          Top = 30
          Width = 844
          Height = 23
          CharCase = ecUpperCase
          Color = 16775142
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          TabOrder = 0
          OnChange = edtnomecliContatoChange
          OnEnter = edtnomecliContatoEnter
          OnExit = edtnomecliContatoExit
        end
        object edtCodcliContato: TAlignEdit
          Left = 605
          Top = 5
          Width = 32
          Height = 23
          TabStop = False
          CharCase = ecUpperCase
          Color = 16775142
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          TabOrder = 1
          Visible = False
        end
        object DBGPesqClienteContato: TDBGrid
          Left = 3
          Top = 53
          Width = 844
          Height = 314
          BiDiMode = bdLeftToRight
          Ctl3D = False
          DataSource = dsConsCli
          Enabled = False
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -11
          Font.Name = 'Arial'
          Font.Style = []
          Options = [dgColumnResize, dgColLines, dgTabs, dgConfirmDelete, dgCancelOnExit]
          ParentBiDiMode = False
          ParentCtl3D = False
          ParentFont = False
          TabOrder = 2
          TitleFont.Charset = DEFAULT_CHARSET
          TitleFont.Color = clWindowText
          TitleFont.Height = -16
          TitleFont.Name = 'MS Sans Serif'
          TitleFont.Style = [fsBold]
          OnDrawColumnCell = DBGPesqClienteContatoDrawColumnCell
          OnDblClick = DBGPesqClienteContatoDblClick
          OnExit = DBGPesqClienteContatoExit
          OnKeyDown = DBGPesqClienteContatoKeyDown
          OnKeyPress = DBGPesqClienteContatoKeyPress
          Columns = <
            item
              Expanded = False
              FieldName = 'cod_cli'
              Title.Alignment = taCenter
              Title.Caption = 'C'#211'D'
              Width = 50
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'NOME_FANTASIA'
              Title.Alignment = taCenter
              Title.Caption = 'FANTASIA'
              Width = 320
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'NOME_CLI'
              Title.Alignment = taCenter
              Title.Caption = 'RAZ'#195'O'
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'CNPJ_CLI'
              Title.Alignment = taCenter
              Title.Caption = 'CNPJ'
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'CIDRES_CLI'
              Title.Alignment = taCenter
              Title.Caption = 'CIDADE'
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'ATIVO'
              Visible = True
            end
            item
              Expanded = False
              FieldName = 'BLOQUEADO_CLI'
              Visible = True
            end>
        end
      end
    end
    object TabSheet5: TTabSheet
      Caption = 'Cadastrar Contato'
      ImageIndex = 1
      object Panel12: TPanel
        Left = 0
        Top = 0
        Width = 850
        Height = 66
        Align = alTop
        TabOrder = 0
        object Label17: TLabel
          Left = 0
          Top = 8
          Width = 38
          Height = 16
          Caption = 'Nome:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object Label18: TLabel
          Left = 423
          Top = 8
          Width = 49
          Height = 16
          Caption = 'Numero:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object Label20: TLabel
          Left = 217
          Top = 44
          Width = 37
          Height = 16
          Caption = 'Email:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object Label21: TLabel
          Left = 0
          Top = 44
          Width = 35
          Height = 16
          Caption = 'Setor:'
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -13
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
        end
        object edtNomeContato: TAlignEdit
          Left = 44
          Top = 1
          Width = 348
          Height = 23
          CharCase = ecUpperCase
          Color = clWhite
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          TabOrder = 0
        end
        object edtTelefoneContato: TAlignEdit
          Left = 476
          Top = 1
          Width = 149
          Height = 23
          CharCase = ecUpperCase
          Color = clWhite
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          MaxLength = 20
          ParentFont = False
          TabOrder = 1
        end
        object btnSalvarContato: TAdvGlowButton
          Left = 495
          Top = 31
          Width = 130
          Height = 29
          HelpType = htKeyword
          Caption = '&Salvar Contato'
          ImageIndex = 2
          NotesFont.Charset = DEFAULT_CHARSET
          NotesFont.Color = clWindowText
          NotesFont.Height = -11
          NotesFont.Name = 'Tahoma'
          NotesFont.Style = []
          Picture.Data = {
            89504E470D0A1A0A0000000D49484452000000180000001808040000004A7EF5
            730000000467414D410000B18F0BFC6105000000206348524D00007A26000080
            840000FA00000080E8000075300000EA6000003A98000017709CBA513C000000
            02624B47440000AA8D2332000000097048597300000DD700000DD70142289B78
            0000000774494D4507E30604123128B06C792D000001274944415438CBB5D43B
            2F44411887F1DF39C765ED4A54225121342E59AD44224BA254A8151A54BE874F
            207C08892F40E152D2BB848AD0109720AC1CC55AF672CE0A89FF34F366E67993
            676632815D6322C41EBC4B4A9336A716EC95CA5D45B1D89D71D9C431E942D1B1
            C9125D4EECC55345DF565366DCDB712316E9B36EC976282D4D46CC9995FFAC23
            BDD614D2019AE5E4B47CD5911ECB8D80FA843A7F075449D7E6C58623CFCE7524
            032DA60D54218150ABBC7ED96460BEEA58BF93D39E044435FD53BDFF281DDB74
            9BBA2B6BC4502DB0EA2815E8B2580F5CB934A15BA0E8D0B1B80278F7582F4D64
            D4B0C8AB1B67DE1A3B94FAEC3B112223EFCE938BC640A46050000E5CBBFE0978
            B5F20FF7F0FF40D92190A97C933569FB762D4F425B299F4C6935539E7E002A27
            41845902379D0000002574455874646174653A63726561746500323031392D30
            362D30345431363A34393A34302B30323A3030C29AFA09000000257445587464
            6174653A6D6F6469667900323031392D30362D30345431363A34393A34302B30
            323A3030B3C742B50000001974455874536F667477617265007777772E696E6B
            73636170652E6F72679BEE3C1A0000000049454E44AE426082}
          Rounded = True
          TabOrder = 4
          TabStop = True
          OnClick = btnSalvarContatoClick
          Appearance.BorderColor = 11382963
          Appearance.BorderColorHot = 11565130
          Appearance.BorderColorCheckedHot = 11565130
          Appearance.BorderColorDown = 11565130
          Appearance.BorderColorChecked = 13744549
          Appearance.BorderColorDisabled = 13948116
          Appearance.Color = clWhite
          Appearance.ColorTo = clWhite
          Appearance.ColorChecked = 13744549
          Appearance.ColorCheckedTo = 13744549
          Appearance.ColorDisabled = clWhite
          Appearance.ColorDisabledTo = clNone
          Appearance.ColorDown = 11565130
          Appearance.ColorDownTo = 11565130
          Appearance.ColorHot = 16444643
          Appearance.ColorHotTo = 16444643
          Appearance.ColorMirror = clWhite
          Appearance.ColorMirrorTo = clWhite
          Appearance.ColorMirrorHot = 16444643
          Appearance.ColorMirrorHotTo = 16444643
          Appearance.ColorMirrorDown = 11565130
          Appearance.ColorMirrorDownTo = 11565130
          Appearance.ColorMirrorChecked = 13744549
          Appearance.ColorMirrorCheckedTo = 13744549
          Appearance.ColorMirrorDisabled = clWhite
          Appearance.ColorMirrorDisabledTo = clNone
          Appearance.GradientHot = ggVertical
          Appearance.GradientMirrorHot = ggVertical
          Appearance.GradientDown = ggVertical
          Appearance.GradientMirrorDown = ggVertical
          Appearance.GradientChecked = ggVertical
          Appearance.TextColorChecked = 3750459
          Appearance.TextColorDown = 2303013
          Appearance.TextColorHot = 2303013
          Appearance.TextColorDisabled = 13948116
        end
        object EdtEmailContato: TAlignEdit
          Left = 260
          Top = 37
          Width = 229
          Height = 23
          CharCase = ecUpperCase
          Color = clWhite
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          TabOrder = 3
        end
        object edtSetor: TAlignEdit
          Left = 41
          Top = 37
          Width = 163
          Height = 23
          CharCase = ecUpperCase
          Color = clWhite
          Font.Charset = ANSI_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Arial'
          Font.Style = []
          ParentFont = False
          TabOrder = 2
        end
      end
      object DBGrid3: TDBGrid
        Left = 0
        Top = 66
        Width = 850
        Height = 396
        Align = alClient
        DataSource = dsContatoCli
        Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
        PopupMenu = PopDeletaContato
        TabOrder = 1
        TitleFont.Charset = DEFAULT_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'Tahoma'
        TitleFont.Style = []
        OnDrawColumnCell = DBGrid3DrawColumnCell
        Columns = <
          item
            Expanded = False
            FieldName = 'DESCRICAO'
            Title.Alignment = taCenter
            Title.Caption = 'NOME CONTATO'
            Width = 209
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'SETOR'
            Title.Alignment = taCenter
            Width = 174
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'NUMERO'
            Title.Alignment = taCenter
            Width = 152
            Visible = True
          end
          item
            Expanded = False
            FieldName = 'EMAIL'
            Title.Alignment = taCenter
            Width = 265
            Visible = True
          end>
      end
    end
    object TabSheet8: TTabSheet
      Caption = 'Observa'#231#245'es'
      ImageIndex = 2
      object MObsCliente: TMemo
        Left = 0
        Top = 0
        Width = 850
        Height = 462
        Align = alClient
        CharCase = ecUpperCase
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
        ReadOnly = True
        ScrollBars = ssVertical
        TabOrder = 0
      end
    end
    object TabSheet1: TTabSheet
      Caption = 'Endere'#231'o do cliente'
      ImageIndex = 3
      object MEndereco: TMemo
        Left = 0
        Top = 0
        Width = 850
        Height = 462
        Align = alClient
        CharCase = ecUpperCase
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
        ReadOnly = True
        ScrollBars = ssVertical
        TabOrder = 0
      end
    end
  end
  object FDQConsCli: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      
        'SELECT cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI,CIDRES_CLI,c.ATIV' +
        'O,c.BLOQUEADO_CLI,'
      
        'EMAIL_CLI,CELULAR_CLI,TELRES_CLI,c.CATEGORIA_CLI,c.OBS_VENDA,c.O' +
        'BS_CLI,'
      
        'c.ENDRES_CLI,c.BAIRES_CLI,c.NUMERORES_CLI,c.ESTRES_CLI,c.CEPRES_' +
        'CLI,c.PONTO_REFERENCIA'
      ' FROM cliente c '
      '')
    Left = 694
    Top = 137
    object FDQConsClicod_cli: TIntegerField
      FieldName = 'cod_cli'
      Origin = 'cod_cli'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Required = True
    end
    object FDQConsCliNOME_FANTASIA: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_FANTASIA'
      Origin = 'NOME_FANTASIA'
      Size = 60
    end
    object FDQConsCliNOME_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_CLI'
      Origin = 'NOME_CLI'
      Size = 60
    end
    object FDQConsCliCNPJ_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CNPJ_CLI'
      Origin = 'CNPJ_CLI'
      Size = 18
    end
    object FDQConsCliCIDRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CIDRES_CLI'
      Origin = 'CIDRES_CLI'
      Size = 30
    end
    object FDQConsCliATIVO: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'ATIVO'
      Origin = 'ATIVO'
      FixedChar = True
      Size = 1
    end
    object FDQConsCliBLOQUEADO_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'BLOQUEADO_CLI'
      Origin = 'BLOQUEADO_CLI'
      FixedChar = True
      Size = 1
    end
    object FDQConsCliEMAIL_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'EMAIL_CLI'
      Origin = 'EMAIL_CLI'
      Size = 100
    end
    object FDQConsCliCELULAR_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CELULAR_CLI'
      Origin = 'CELULAR_CLI'
      Size = 13
    end
    object FDQConsCliCATEGORIA_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CATEGORIA_CLI'
      Origin = 'CATEGORIA_CLI'
      Size = 50
    end
    object FDQConsCliTELRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'TELRES_CLI'
      Origin = 'TELRES_CLI'
      Size = 13
    end
    object FDQConsCliENDRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'ENDRES_CLI'
      Origin = 'ENDRES_CLI'
      Size = 50
    end
    object FDQConsCliBAIRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'BAIRES_CLI'
      Origin = 'BAIRES_CLI'
      Size = 30
    end
    object FDQConsCliNUMERORES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NUMERORES_CLI'
      Origin = 'NUMERORES_CLI'
      Size = 10
    end
    object FDQConsCliESTRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'ESTRES_CLI'
      Origin = 'ESTRES_CLI'
      FixedChar = True
      Size = 2
    end
    object FDQConsCliCEPRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CEPRES_CLI'
      Origin = 'CEPRES_CLI'
      Size = 9
    end
    object FDQConsCliPONTO_REFERENCIA: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'PONTO_REFERENCIA'
      Origin = 'PONTO_REFERENCIA'
      Size = 80
    end
    object FDQConsCliOBS_VENDA: TMemoField
      AutoGenerateValue = arDefault
      FieldName = 'OBS_VENDA'
      Origin = 'OBS_VENDA'
      BlobType = ftMemo
    end
    object FDQConsCliOBS_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'OBS_CLI'
      Origin = 'OBS_CLI'
      Size = 20000
    end
  end
  object dsConsCli: TDataSource
    DataSet = FDQConsCli
    Left = 694
    Top = 192
  end
  object PopDeletaContato: TPopupMenu
    Left = 768
    Top = 432
    object MenuItem1: TMenuItem
      Caption = 'Remover Contato'
      OnClick = MenuItem1Click
    end
  end
  object dsContatoCli: TDataSource
    DataSet = Dm.FDQContatoCli
    Left = 710
    Top = 290
  end
end
