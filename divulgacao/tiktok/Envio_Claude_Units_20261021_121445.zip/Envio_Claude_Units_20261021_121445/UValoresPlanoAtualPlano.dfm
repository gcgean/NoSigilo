object FrmValoresPlanoAtualPlano: TFrmValoresPlanoAtualPlano
  Left = 0
  Top = 0
  Caption = 'FrmValoresPlanoAtualPlano'
  ClientHeight = 507
  ClientWidth = 1014
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  OnCreate = FormCreate
  OnKeyDown = FormKeyDown
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object DBGFuncionalidades: TDBGrid
    Left = 0
    Top = 0
    Width = 1014
    Height = 507
    Align = alClient
    DataSource = DSValores
    DrawingStyle = gdsGradient
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
    ParentFont = False
    TabOrder = 0
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Color = clBtnFace
        Expanded = False
        FieldName = 'id_plano_atual'
        Title.Font.Charset = DEFAULT_CHARSET
        Title.Font.Color = clWindowText
        Title.Font.Height = -13
        Title.Font.Name = 'Tahoma'
        Title.Font.Style = []
        Visible = True
      end
      item
        Color = clBtnFace
        Expanded = False
        FieldName = 'descricao'
        Title.Font.Charset = DEFAULT_CHARSET
        Title.Font.Color = clWindowText
        Title.Font.Height = -13
        Title.Font.Name = 'Tahoma'
        Title.Font.Style = []
        Width = 300
        Visible = True
      end
      item
        Color = clBtnFace
        Expanded = False
        FieldName = 'desc_segmento'
        Title.Font.Charset = DEFAULT_CHARSET
        Title.Font.Color = clWindowText
        Title.Font.Height = -13
        Title.Font.Name = 'Tahoma'
        Title.Font.Style = []
        Width = 200
        Visible = True
      end
      item
        Color = clBtnFace
        Expanded = False
        FieldName = 'valor'
        Title.Font.Charset = DEFAULT_CHARSET
        Title.Font.Color = clWindowText
        Title.Font.Height = -13
        Title.Font.Name = 'Tahoma'
        Title.Font.Style = []
        Visible = True
      end>
  end
  object QValores: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      'select'
      #9'vpp.id_plano_atual,'
      #9'p.descricao,'
      #9'case'
      #9#9'when (coalesce(vpp.segmento, 0) > 0) then (ss.descricao)'
      #9#9'else ('#39'TODOS'#39')'
      #9'end desc_segmento,'
      #9'vpp.valor'
      'from'
      #9'valores_planos_plano vpp'
      'inner join planos p on'
      #9'(vpp.id_plano_atual = p.id)'
      'left join segmento_software ss on'
      #9'(vpp.segmento = ss.cod_seg_sof)'
      'where'
      #9'vpp.id_plano = :id_plano')
    Left = 280
    Top = 240
    ParamData = <
      item
        Name = 'ID_PLANO'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end>
    object QValoresid_plano_atual: TIntegerField
      DisplayLabel = 'C'#243'digo'
      FieldName = 'id_plano_atual'
      Origin = 'id_plano_atual'
      Required = True
    end
    object QValoresdescricao: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Plano Atual'
      FieldName = 'descricao'
      Origin = 'descricao'
      ProviderFlags = []
      ReadOnly = True
      Size = 255
    end
    object QValoresdesc_segmento: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Segmento'
      FieldName = 'desc_segmento'
      Origin = 'desc_segmento'
      ProviderFlags = []
      ReadOnly = True
      Size = 80
    end
    object QValoresvalor: TFMTBCDField
      DisplayLabel = 'Valor'
      FieldName = 'valor'
      Origin = 'valor'
      Required = True
      DisplayFormat = ',#0.00'
      Precision = 18
      Size = 2
    end
  end
  object DSValores: TDataSource
    AutoEdit = False
    DataSet = QValores
    Left = 352
    Top = 240
  end
end
