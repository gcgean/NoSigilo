unit UCustomJSON;

interface

uses
  UCustomJSON.Contract, UCustomJSON.JSONObject;

type
  ICustomJSON = UCustomJSON.Contract.ICustomJSON;

  TCustomJSON = class
  public
    class function New: ICustomJSON;
  end;

implementation

{ TCustomJSON }

class function TCustomJSON.New: ICustomJSON;
begin
  Result := TCustomJSONJSONObject.Create;
end;

end.
