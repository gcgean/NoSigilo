object FrmAssinaturaCliente: TFrmAssinaturaCliente
  Left = 0
  Top = 0
  Caption = 'Criar/Alterar Assinatura do Cliente'
  ClientHeight = 742
  ClientWidth = 635
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  OnCreate = FormCreate
  OnKeyDown = FormKeyDown
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  DesignSize = (
    635
    742)
  PixelsPerInch = 96
  TextHeight = 13
  object Label2: TLabel
    Left = 16
    Top = 67
    Width = 135
    Height = 19
    Caption = 'Valor Assinatura'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlack
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label1: TLabel
    Left = 171
    Top = 67
    Width = 252
    Height = 19
    Caption = 'Vencimento Primeira Cobran'#231'a'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlack
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label4: TLabel
    Left = 443
    Top = 67
    Width = 174
    Height = 19
    Caption = 'Forma de Pagamento'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlack
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object PnCliente: TPanel
    Left = 0
    Top = 0
    Width = 635
    Height = 29
    Align = alTop
    BevelOuter = bvNone
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 1
  end
  object EdtValor: TcxCurrencyEdit
    Left = 16
    Top = 92
    TabStop = False
    EditValue = 0.000000000000000000
    ParentFont = False
    Properties.ReadOnly = False
    Style.Font.Charset = DEFAULT_CHARSET
    Style.Font.Color = clBlack
    Style.Font.Height = -16
    Style.Font.Name = 'Tahoma'
    Style.Font.Style = [fsBold]
    Style.IsFontAssigned = True
    TabOrder = 2
    Width = 135
  end
  object EdtVencimento: TDateTimePicker
    Left = 171
    Top = 92
    Width = 252
    Height = 27
    Date = 44842.000000000000000000
    Time = 0.458000833335972900
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 3
  end
  object ComboForma: TComboBox
    Left = 443
    Top = 92
    Width = 174
    Height = 27
    Style = csDropDownList
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 4
    OnChange = ComboFormaChange
    Items.Strings = (
      'Boleto / Pix'
      'Cart'#227'o de Cr'#233'dito')
  end
  object PCAssinatura: TPageControl
    Left = 16
    Top = 137
    Width = 601
    Height = 511
    ActivePage = TabDados
    Anchors = [akLeft, akTop, akRight]
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 5
    object TabDados: TTabSheet
      Caption = 'Dados'
      DesignSize = (
        593
        480)
      object Label3: TLabel
        Left = 16
        Top = 73
        Width = 137
        Height = 16
        Caption = 'Descri'#231#227'o da Assinatura'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clBlack
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
      end
      object Label7: TLabel
        Left = 16
        Top = 10
        Width = 111
        Height = 19
        Caption = 'Periodicidade'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clBlack
        Font.Height = -16
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object MemoDescricao: TMemo
        Left = 16
        Top = 95
        Width = 559
        Height = 242
        Anchors = [akLeft, akTop, akRight, akBottom]
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 1
      end
      object ComboPeriodicidade: TComboBox
        Left = 16
        Top = 35
        Width = 559
        Height = 27
        Style = csDropDownList
        Anchors = [akLeft, akTop, akRight]
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
        TabOrder = 0
        Items.Strings = (
          'Mensal'
          'Trimestral'
          'Semestral'
          'Anual')
      end
      object CheckAtualizarMensalidadesExistentes: TCheckBox
        Left = 16
        Top = 444
        Width = 473
        Height = 17
        Anchors = [akLeft, akBottom]
        Caption = 
          'Atualizar mensalidades j'#225' existentes com o novo valor ou forma d' +
          'e pagamento'
        TabOrder = 4
      end
      object RGTipoAlteracao: TRadioGroup
        Left = 16
        Top = 381
        Width = 559
        Height = 53
        Anchors = [akLeft, akBottom]
        Caption = 'Tipo de Altera'#231#227'o da Assinatura'
        Columns = 2
        Items.Strings = (
          'Alterar assinatura existente'
          'Remover assinatura existente e criar nova')
        TabOrder = 3
        OnClick = RGTipoAlteracaoClick
      end
      object CheckAlterarAssinaturaPlataformaCobranca: TCheckBox
        Left = 16
        Top = 352
        Width = 373
        Height = 17
        Anchors = [akLeft, akBottom]
        Caption = 'Alterar informa'#231#245'es da assinatura na plataforma de cobran'#231'a'
        TabOrder = 2
        OnClick = CheckAlterarAssinaturaPlataformaCobrancaClick
      end
    end
    object TabCartao: TTabSheet
      Caption = 'Dados do Cart'#227'o'
      ImageIndex = 1
      object Label5: TLabel
        Left = 16
        Top = 94
        Width = 121
        Height = 16
        Caption = 'M'#234's/Ano Vencimento'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clBlack
        Font.Height = -13
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
      end
      object Label6: TLabel
        Left = 16
        Top = 9
        Width = 135
        Height = 19
        Caption = 'Dados do Cart'#227'o'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object Label8: TLabel
        Left = 16
        Top = 153
        Width = 220
        Height = 19
        Caption = 'Dados do Titular do Cart'#227'o'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = 'Tahoma'
        Font.Style = [fsBold]
        ParentFont = False
      end
      object EdtNumeroCartao: TLabeledEdit
        Left = 16
        Top = 60
        Width = 129
        Height = 24
        EditLabel.Width = 105
        EditLabel.Height = 16
        EditLabel.Caption = 'N'#250'mero do Cart'#227'o'
        MaxLength = 16
        NumbersOnly = True
        TabOrder = 0
      end
      object EdtNomeCartao: TLabeledEdit
        Left = 168
        Top = 60
        Width = 401
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 150
        EditLabel.Height = 16
        EditLabel.Caption = 'Nome Impresso no Cart'#227'o'
        TabOrder = 1
      end
      object EdtVencimentoCartao: TMaskEdit
        Left = 16
        Top = 113
        Width = 128
        Height = 24
        EditMask = '99/99;1;_'
        MaxLength = 5
        TabOrder = 2
        Text = '  /  '
      end
      object EdtCodigoSegurancaCartao: TLabeledEdit
        Left = 168
        Top = 113
        Width = 125
        Height = 24
        EditLabel.Width = 122
        EditLabel.Height = 16
        EditLabel.Caption = 'C'#243'digo de Seguran'#231'a'
        MaxLength = 3
        NumbersOnly = True
        TabOrder = 3
      end
      object EdtNomeTitularCartao: TLabeledEdit
        Left = 16
        Top = 204
        Width = 387
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 91
        EditLabel.Height = 16
        EditLabel.Caption = 'Nome Completo'
        TabOrder = 4
      end
      object EdtCPFCNPJTitularCartao: TLabeledEdit
        Left = 427
        Top = 204
        Width = 142
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 55
        EditLabel.Height = 16
        EditLabel.Caption = 'CNPJ/CPF'
        MaxLength = 14
        NumbersOnly = True
        TabOrder = 5
      end
      object EdtEnderecoTitularCartao: TLabeledEdit
        Left = 16
        Top = 260
        Width = 289
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 53
        EditLabel.Height = 16
        EditLabel.Caption = 'Endere'#231'o'
        TabOrder = 6
      end
      object EdtNumeroTitularCartao: TLabeledEdit
        Left = 328
        Top = 260
        Width = 75
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 45
        EditLabel.Height = 16
        EditLabel.Caption = 'N'#250'mero'
        TabOrder = 7
      end
      object EdtBairroTitularCartao: TLabeledEdit
        Left = 427
        Top = 260
        Width = 142
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 34
        EditLabel.Height = 16
        EditLabel.Caption = 'Bairro'
        TabOrder = 8
      end
      object EdtCEPTitularCartao: TLabeledEdit
        Left = 16
        Top = 308
        Width = 73
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 22
        EditLabel.Height = 16
        EditLabel.Caption = 'CEP'
        MaxLength = 8
        NumbersOnly = True
        TabOrder = 9
      end
      object EdtComplementoTitularCartao: TLabeledEdit
        Left = 114
        Top = 308
        Width = 191
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 79
        EditLabel.Height = 16
        EditLabel.Caption = 'Complemento'
        TabOrder = 10
      end
      object EdtEmailTitularCartao: TLabeledEdit
        Left = 328
        Top = 308
        Width = 241
        Height = 24
        EditLabel.Width = 36
        EditLabel.Height = 16
        EditLabel.Caption = 'E-mail'
        TabOrder = 11
      end
      object EdtTelefoneTitularCartao: TLabeledEdit
        Left = 16
        Top = 356
        Width = 150
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 50
        EditLabel.Height = 16
        EditLabel.Caption = 'Telefone'
        TabOrder = 12
      end
      object EdtCelularTitularCartao: TLabeledEdit
        Left = 192
        Top = 356
        Width = 150
        Height = 24
        CharCase = ecUpperCase
        EditLabel.Width = 40
        EditLabel.Height = 16
        EditLabel.Caption = 'Celular'
        TabOrder = 13
      end
      object BtnGerarArquivo: TButton
        Left = 320
        Top = 112
        Width = 113
        Height = 25
        Caption = 'Exportar Dados'
        TabOrder = 14
        TabStop = False
        OnClick = BtnGerarArquivoClick
      end
      object BtnImportarDados: TButton
        Left = 456
        Top = 112
        Width = 113
        Height = 25
        Caption = 'Importar Dados'
        TabOrder = 15
        TabStop = False
        OnClick = BtnImportarDadosClick
      end
    end
  end
  object BtnOK: TButton
    Left = 214
    Top = 664
    Width = 209
    Height = 57
    Anchors = [akRight, akBottom]
    Caption = 'Confirmar'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 6
    OnClick = BtnOKClick
  end
  object CheckReceberCarneImpresso: TCheckBox
    Left = 16
    Top = 38
    Width = 359
    Height = 17
    TabStop = False
    Caption = 'Este cliente deseja receber o carn'#234' da assinatura impresso'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    OnClick = CheckAlterarAssinaturaPlataformaCobrancaClick
  end
  object Query: TFDQuery
    Connection = Dm.FDConexao
    Left = 40
    Top = 8
  end
  object DlgSave: TSaveDialog
    DefaultExt = '*.cs'
    Filter = 
      'Arquivo Command System (*.cs)|*.cs|Arquivo de Texto (*.txt)|*.tx' +
      't'
    Title = 'Escolha onde deseja salvar o arquivo'
    Left = 128
    Top = 8
  end
  object dlgOpen: TOpenDialog
    DefaultExt = '*.cs'
    Filter = 
      'Arquivo Command System (*.cs)|*.cs|Arquivo de Texto (*.txt)|*.tx' +
      't'
    Title = 'Escolha o arquivo que deseja importar'
    Left = 208
    Top = 8
  end
end
