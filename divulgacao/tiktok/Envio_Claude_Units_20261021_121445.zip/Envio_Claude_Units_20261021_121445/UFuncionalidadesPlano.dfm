object FrmFuncionalidadesPlano: TFrmFuncionalidadesPlano
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMaximize]
  Caption = 'Funcionalidades do Plano'
  ClientHeight = 507
  ClientWidth = 1014
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  OnCreate = FormCreate
  OnKeyDown = FormKeyDown
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 16
  object DBGFuncionalidades: TDBGrid
    Left = 0
    Top = 0
    Width = 1014
    Height = 507
    Align = alClient
    DataSource = DSFunc
    DrawingStyle = gdsGradient
    Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
    TabOrder = 0
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -13
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Expanded = False
        FieldName = 'funcionalidade'
        Width = 300
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'desc_funcionalidade'
        Width = 600
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'DESC_DESTACAR'
        Visible = True
      end>
  end
  object QFunc: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      
        'select *, case when (DESTACAR = 1) then ('#39'SIM'#39') else ('#39'N'#195'O'#39') end' +
        ' DESC_DESTACAR from funcionalidades_plano'
      'where id_plano = :id_plano'
      'order by id')
    Left = 216
    Top = 160
    ParamData = <
      item
        Name = 'ID_PLANO'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end>
    object QFuncid: TFDAutoIncField
      FieldName = 'id'
      Origin = 'id'
      ProviderFlags = [pfInWhere, pfInKey]
    end
    object QFuncid_plano: TIntegerField
      FieldName = 'id_plano'
      Origin = 'id_plano'
      Required = True
    end
    object QFuncfuncionalidade: TStringField
      DisplayLabel = 'FUNCIONALIDADE'
      FieldName = 'funcionalidade'
      Origin = 'funcionalidade'
      Required = True
      Size = 1000
    end
    object QFuncdesc_funcionalidade: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'DESCRI'#199#195'O'
      FieldName = 'desc_funcionalidade'
      Origin = 'desc_funcionalidade'
      Size = 1000
    end
    object QFuncdestacar: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'destacar'
      Origin = 'destacar'
    end
    object QFuncDESC_DESTACAR: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'DESTACAR?'
      FieldName = 'DESC_DESTACAR'
      Origin = 'DESC_DESTACAR'
      ProviderFlags = []
      ReadOnly = True
      Size = 3
    end
  end
  object DSFunc: TDataSource
    AutoEdit = False
    DataSet = QFunc
    Left = 288
    Top = 152
  end
end
