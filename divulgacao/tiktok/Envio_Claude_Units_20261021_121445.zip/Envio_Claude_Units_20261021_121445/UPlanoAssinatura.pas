unit UPlanoAssinatura;

interface

uses
  System.SysUtils,
  System.Generics.Collections,
  UAssinatura,
  System.Json,
  Vcl.Graphics
{$IFDEF MSWINDOWS}
    , Winapi.Windows
{$ENDIF}
    ;

type
  TTipoPlano = (tpNenhum, tpBasico, tpMedio, tpAvancado);

  TValorQuantidade = class
  private
    FQtdFinal: Integer;
    FQtdInicial: Integer;
    FValor: Currency;

    procedure SetQtdFinal(const Value: Integer);
    procedure SetQtdInicial(const Value: Integer);
    procedure SetValor(const Value: Currency);
  public
    property QtdInicial: Integer read FQtdInicial write SetQtdInicial;
    property QtdFinal: Integer read FQtdFinal write SetQtdFinal;
    property Valor: Currency read FValor write SetValor;

    constructor Create;
  end;

  TValorSegmento = class
  private
    FValor: Currency;
    FSegmento: Integer;

    procedure SetSegmento(const Value: Integer);
    procedure SetValor(const Value: Currency);
  public
    property Segmento: Integer read FSegmento write SetSegmento;
    property Valor: Currency read FValor write SetValor;

    constructor Create;
  end;

  TValorPeriodicidade = class
  private
    FValor: Currency;
    FPeriodicidade: TPeriodicidadeAssinatura;

    procedure SetPeriodicidade(const Value: TPeriodicidadeAssinatura);
    procedure SetValor(const Value: Currency);
  public
    property Periodicidade: TPeriodicidadeAssinatura read FPeriodicidade write SetPeriodicidade;
    property Valor: Currency read FValor write SetValor;

    constructor Create;
  end;

  TValorPlano = class
  private
    FValor: Currency;
    FSegmento: Integer;
    FDescricaoPlano: String;
    FIdPlano: Integer;
    procedure SetDescricaoPlano(const Value: String);
    procedure SetIdPlano(const Value: Integer);
    procedure SetSegmento(const Value: Integer);
    procedure SetValor(const Value: Currency);

  public
    property IdPlano: Integer read FIdPlano write SetIdPlano;
    property DescricaoPlano: String read FDescricaoPlano write SetDescricaoPlano;
    property Segmento: Integer read FSegmento write SetSegmento;
    property Valor: Currency read FValor write SetValor;

    constructor Create;
  end;

  TFuncionalidade = class
  private
    FFuncionalidade: String;
    FDestacar: Boolean;
    FDescricao: String;

    procedure SetDescricao(const Value: String);
    procedure SetDestacar(const Value: Boolean);
    procedure SetFuncionalidade(const Value: String);
  public
    property Funcionalidade: String read FFuncionalidade write SetFuncionalidade;
    property Descricao: String read FDescricao write SetDescricao;
    property Destacar: Boolean read FDestacar write SetDestacar;

    constructor Create;
  end;

  TCor = class
  private
    FGreen: Integer;
    FRed: Integer;
    FBlue: Integer;

    procedure SetBlue(const Value: Integer);
    procedure SetGreen(const Value: Integer);
    procedure SetRed(const Value: Integer);
  public
    property Red: Integer read FRed write SetRed;
    property Green: Integer read FGreen write SetGreen;
    property Blue: Integer read FBlue write SetBlue;

    constructor Create;
  end;

  TPlanoAssinatura = class
  private
    FId: Integer;
    FIdAPI: String;
    FAtivo: Boolean;
    FModulo: Boolean;
    FTipo: TTipoPlano;
    FUsaDFe: Boolean;
    FDescricao: String;
    FDescricaoDetalhada: String;
    FDetalhes: String;
    FIdSistema: Integer;
    FValor: Currency;
    FValorRevenda: Currency;
    FValorAdesao: Currency;
    FQtdGratis: Integer;
    FQtdAcima: Integer;
    FValorQtd: Currency;
    FValoresQuantidade: TObjectList<TValorQuantidade>;
    FValoresSegmento: TObjectList<TValorSegmento>;
    FValoresPeriodicidade: TObjectList<TValorPeriodicidade>;
    FValoresPlano: TObjectList<TValorPlano>;
    FFuncionalidades: TObjectList<TFuncionalidade>;
    FExibirPreco: Boolean;
    FCor: TCor;
    FMaisVendido: Boolean;
    FLinkVideo: String;
    FTamanhoMaximoNuvem: Integer;
    FExibirRevenda: Boolean;
    FQtdMaquinas: Integer;
    FPermiteQuantidade: Boolean;

    procedure SetAtivo(const Value: Boolean);
    procedure SetDescricao(const Value: String);
    procedure SetId(const Value: Integer);
    procedure SetValor(const Value: Currency);
    procedure SetModulo(const Value: Boolean);
    procedure SetIdAPI(const Value: String);
    procedure SetQtdAcima(const Value: Integer);
    procedure SetValorQtd(const Value: Currency);
    procedure SetIdSistema(const Value: Integer);
    procedure SetTipo(const Value: TTipoPlano);
    procedure SetUsaDFe(const Value: Boolean);
    procedure SetDetalhes(const Value: String);
    procedure SetMaisVendido(const Value: Boolean);
    procedure SetLinkVideo(const Value: String);
    procedure SetExibirPreco(const Value: Boolean);
    procedure SetValorAdesao(const Value: Currency);
    procedure SetTamanhoMaximoNuvem(const Value: Integer);
    procedure SetQtdGratis(const Value: Integer);
    procedure SetDescricaoDetalhada(const Value: String);
  public
    property Id: Integer read FId write SetId;
    property IdAPI: String read FIdAPI write SetIdAPI;
    property Descricao: String read FDescricao write SetDescricao;
    property Detalhes: String read FDetalhes write SetDetalhes;
    property DescricaoDetalhada: String read FDescricaoDetalhada write SetDescricaoDetalhada;
    property Ativo: Boolean read FAtivo write SetAtivo;
    property Valor: Currency read FValor write SetValor;
    property ValorRevenda: Currency read FValorRevenda write FValorRevenda;
    property ValorAdesao: Currency read FValorAdesao write SetValorAdesao;
    property Modulo: Boolean read FModulo write SetModulo;
    property MaisVendido: Boolean read FMaisVendido write SetMaisVendido;
    property Tipo: TTipoPlano read FTipo write SetTipo;
    property UsaDFe: Boolean read FUsaDFe write SetUsaDFe;
    property ExibirPreco: Boolean read FExibirPreco write SetExibirPreco;
    property QtdAcima: Integer read FQtdAcima write SetQtdAcima;
    property ValorQtd: Currency read FValorQtd write SetValorQtd;
    property QtdGratis: Integer read FQtdGratis write SetQtdGratis;
    property IdSistema: Integer read FIdSistema write SetIdSistema;
    property LinkVideo: String read FLinkVideo write SetLinkVideo;
    property TamanhoMaximoNuvem: Integer read FTamanhoMaximoNuvem write SetTamanhoMaximoNuvem;
    property Cor: TCor read FCor;
    property ValoresQuantidade: TObjectList<TValorQuantidade> read FValoresQuantidade;
    property ValoresSegmento: TObjectList<TValorSegmento> read FValoresSegmento;
    property ValoresPeriodicidade: TObjectList<TValorPeriodicidade> read FValoresPeriodicidade;
    property ValoresPlano: TObjectList<TValorPlano> read FValoresPlano;
    property Funcionalidades: TObjectList<TFuncionalidade> read FFuncionalidades;
    property ExibirRevenda: Boolean read FExibirRevenda write FExibirRevenda;
    property QtdMaquinas: Integer read FQtdMaquinas write FQtdMaquinas default 0;
    property PermiteQuantidade: Boolean read FPermiteQuantidade write FPermiteQuantidade
      default True;

    constructor Create; virtual;
    destructor Destroy; override;

    function IntToTipoPlano(const Value: Integer): TTipoPlano;

    function Clone: TPlanoAssinatura; overload;
    procedure ClearValoresQuantidade;
    procedure ClearValoresSegmento;
    procedure CelarValoresPeriodicidade;
    procedure ClearFuncionalidades;
    procedure ClearValoresPlano;

    function ToJsonRevendaPlano: TJSONObject;
    function ToJsonRevendaModulo: TJSONObject;
  end;

implementation

uses
  Rest.Json;

{ TPlanoAssinatura }

procedure TPlanoAssinatura.CelarValoresPeriodicidade;
begin
  FreeAndNil(FValoresPeriodicidade);
  FValoresPeriodicidade := TObjectList<TValorPeriodicidade>.Create();
end;

procedure TPlanoAssinatura.ClearFuncionalidades;
begin
  FreeAndNil(FFuncionalidades);
  FFuncionalidades := TObjectList<TFuncionalidade>.Create();
end;

procedure TPlanoAssinatura.ClearValoresPlano;
begin
  FreeAndNil(FValoresPlano);
  FValoresPlano := TObjectList<TValorPlano>.Create();
end;

procedure TPlanoAssinatura.ClearValoresQuantidade;
begin
  FreeAndNil(FValoresQuantidade);
  FValoresQuantidade := TObjectList<TValorQuantidade>.Create();
end;

procedure TPlanoAssinatura.ClearValoresSegmento;
begin
  FreeAndNil(FValoresSegmento);
  FValoresSegmento := TObjectList<TValorSegmento>.Create();
end;

function TPlanoAssinatura.Clone: TPlanoAssinatura;
var
  I: Integer;
begin
  Result := TPlanoAssinatura.Create;

  Result.Id := FId;
  Result.IdAPI := FIdAPI;
  Result.Descricao := FDescricao;
  Result.DescricaoDetalhada := FDescricaoDetalhada;
  Result.Detalhes := FDetalhes;
  Result.Ativo := FAtivo;
  Result.Valor := FValor;
  Result.ValorRevenda := FValorRevenda;
  Result.ValorAdesao := FValorAdesao;
  Result.Modulo := FModulo;
  Result.MaisVendido := FMaisVendido;
  Result.LinkVideo := FLinkVideo;
  Result.Tipo := FTipo;
  Result.UsaDFe := FUsaDFe;
  Result.ExibirPreco := FExibirPreco;
  Result.QtdAcima := FQtdAcima;
  Result.ValorQtd := FValorQtd;
  Result.QtdGratis := FQtdGratis;
  Result.IdSistema := FIdSistema;
  Result.TamanhoMaximoNuvem := FTamanhoMaximoNuvem;
  Result.ExibirRevenda := FExibirRevenda;
  Result.QtdMaquinas := FQtdMaquinas;
  Result.PermiteQuantidade := FPermiteQuantidade;

  Result.Cor.Red := FCor.Red;
  Result.Cor.Green := FCor.Green;
  Result.Cor.Blue := FCor.Blue;

  for I := 0 to FValoresQuantidade.Count - 1 do
  begin
    Result.ValoresQuantidade.Add(TValorQuantidade.Create);

    with Result.ValoresQuantidade[Result.ValoresQuantidade.Count - 1] do
    begin
      QtdInicial := FValoresQuantidade[I].QtdInicial;
      QtdFinal := FValoresQuantidade[I].QtdFinal;
      Valor := FValoresQuantidade[I].Valor;
    end;
  end;

  for I := 0 to FValoresSegmento.Count - 1 do
  begin
    Result.ValoresSegmento.Add(TValorSegmento.Create);

    with Result.ValoresSegmento[Result.ValoresSegmento.Count - 1] do
    begin
      Segmento := FValoresSegmento[I].Segmento;
      Valor := FValoresSegmento[I].Valor;
    end;
  end;

  for I := 0 to FValoresPeriodicidade.Count - 1 do
  begin
    Result.ValoresPeriodicidade.Add(TValorPeriodicidade.Create);

    with Result.ValoresPeriodicidade[Result.ValoresPeriodicidade.Count - 1] do
    begin
      Periodicidade := FValoresPeriodicidade[I].Periodicidade;
      Valor := FValoresPeriodicidade[I].Valor;
    end;
  end;

  for I := 0 to FValoresPlano.Count - 1 do
  begin
    Result.ValoresPlano.Add(TValorPlano.Create);

    with Result.ValoresPlano[Result.ValoresPlano.Count - 1] do
    begin
      IdPlano := FValoresPlano[I].IdPlano;
      DescricaoPlano := FValoresPlano[I].DescricaoPlano;
      Segmento := FValoresPlano[I].Segmento;
      Valor := FValoresPlano[I].Valor;
    end;
  end;

  for I := 0 to FFuncionalidades.Count - 1 do
  begin
    Result.Funcionalidades.Add(TFuncionalidade.Create);

    with Result.Funcionalidades[Result.Funcionalidades.Count - 1] do
    begin
      Funcionalidade := FFuncionalidades[I].Funcionalidade;
      Descricao := FFuncionalidades[I].Descricao;
      Destacar := FFuncionalidades[I].Destacar;
    end;
  end;
end;

constructor TPlanoAssinatura.Create;
begin
  FId := 0;
  FAtivo := True;
  FValor := 0;
  FValorRevenda := 0;
  FValorAdesao := 0;
  FModulo := False;
  FMaisVendido := False;
  FTipo := tpNenhum;
  FUsaDFe := False;
  FExibirPreco := True;
  FQtdAcima := 0;
  FValorQtd := 0;
  FQtdGratis := 0;
  FIdSistema := 0;
  FTamanhoMaximoNuvem := 0;
  FCor := TCor.Create;
  FExibirRevenda := True;
  FPermiteQuantidade := True;
  FQtdMaquinas := 0;

  FValoresQuantidade := TObjectList<TValorQuantidade>.Create;
  FValoresSegmento := TObjectList<TValorSegmento>.Create;
  FValoresPeriodicidade := TObjectList<TValorPeriodicidade>.Create;
  FValoresPlano := TObjectList<TValorPlano>.Create;
  FFuncionalidades := TObjectList<TFuncionalidade>.Create;
end;

destructor TPlanoAssinatura.Destroy;
begin
  if Assigned(FCor) then
    FreeAndNil(FCor);

  if Assigned(FValoresQuantidade) then
    FreeAndNil(FValoresQuantidade);

  if Assigned(FValoresPlano) then
    FreeAndNil(FValoresPlano);

  if Assigned(FValoresSegmento) then
    FreeAndNil(FValoresSegmento);

  if Assigned(FValoresPeriodicidade) then
    FreeAndNil(FValoresPeriodicidade);

  if Assigned(FFuncionalidades) then
    FreeAndNil(FFuncionalidades);

  inherited;
end;

function TPlanoAssinatura.IntToTipoPlano(const Value: Integer): TTipoPlano;
begin
  Result := tpNenhum;

  case Value of
    1:
      Result := tpBasico;
    2:
      Result := tpMedio;
    3:
      Result := tpAvancado;
  end;
end;

procedure TPlanoAssinatura.SetAtivo(const Value: Boolean);
begin
  FAtivo := Value;
end;

procedure TPlanoAssinatura.SetDescricao(const Value: String);
begin
  FDescricao := Value;
end;

procedure TPlanoAssinatura.SetDescricaoDetalhada(const Value: String);
begin
  FDescricaoDetalhada := Value;
end;

procedure TPlanoAssinatura.SetDetalhes(const Value: String);
begin
  FDetalhes := Value;
end;

procedure TPlanoAssinatura.SetExibirPreco(const Value: Boolean);
begin
  FExibirPreco := Value;
end;

procedure TPlanoAssinatura.SetId(const Value: Integer);
begin
  FId := Value;
end;

procedure TPlanoAssinatura.SetIdAPI(const Value: String);
begin
  FIdAPI := Value;
end;

procedure TPlanoAssinatura.SetIdSistema(const Value: Integer);
begin
  FIdSistema := Value;
end;

procedure TPlanoAssinatura.SetLinkVideo(const Value: String);
begin
  FLinkVideo := Value;
end;

procedure TPlanoAssinatura.SetMaisVendido(const Value: Boolean);
begin
  FMaisVendido := Value;
end;

procedure TPlanoAssinatura.SetModulo(const Value: Boolean);
begin
  FModulo := Value;
end;

procedure TPlanoAssinatura.SetQtdAcima(const Value: Integer);
begin
  FQtdAcima := Value;
end;

procedure TPlanoAssinatura.SetQtdGratis(const Value: Integer);
begin
  FQtdGratis := Value;
end;

procedure TPlanoAssinatura.SetTamanhoMaximoNuvem(const Value: Integer);
begin
  FTamanhoMaximoNuvem := Value;
end;

procedure TPlanoAssinatura.SetTipo(const Value: TTipoPlano);
begin
  FTipo := Value;
end;

procedure TPlanoAssinatura.SetUsaDFe(const Value: Boolean);
begin
  FUsaDFe := Value;
end;

procedure TPlanoAssinatura.SetValor(const Value: Currency);
begin
  FValor := Value;
end;

procedure TPlanoAssinatura.SetValorAdesao(const Value: Currency);
begin
  FValorAdesao := Value;
end;

procedure TPlanoAssinatura.SetValorQtd(const Value: Currency);
begin
  FValorQtd := Value;
end;

function TPlanoAssinatura.ToJsonRevendaModulo: TJSONObject;
var
  LJSONArray: TJSONArray;
  LItem: TValorQuantidade;
begin
  Result := TJson.ObjectToJsonObject(Self);

  Result.RemovePair('idAPI').Free;
  Result.RemovePair('ativo').Free;
  Result.RemovePair('modulo').Free;
  Result.RemovePair('tipo').Free;
  Result.RemovePair('usaDFe').Free;
  Result.RemovePair('descricaoDetalhada').Free;
  Result.RemovePair('idSistema').Free;
  Result.RemovePair('valorRevenda').Free;
  Result.RemovePair('valorAdesao').Free;
  Result.RemovePair('qtdAcima').Free;
  Result.RemovePair('valorQtd').Free;
  Result.RemovePair('valoresSegmento').Free;
  Result.RemovePair('valoresPeriodicidade').Free;
  Result.RemovePair('valoresPlano').Free;
  Result.RemovePair('funcionalidades').Free;
  Result.RemovePair('exibirPreco').Free;
  Result.RemovePair('cor').Free;
  Result.RemovePair('maisVendido').Free;
  Result.RemovePair('tamanhoMaximoNuvem').Free;
  Result.RemovePair('exibirRevenda').Free;
  Result.RemovePair('qtdMaquinas').Free;

  LJSONArray := TJSONArray.Create;

  for LItem in FValoresQuantidade do
    LJSONArray.AddElement(TJson.ObjectToJsonObject(LItem));

  Result.RemovePair('valoresQuantidade').Free;
  Result.AddPair('valoresQuantidade', LJSONArray);
end;

function TPlanoAssinatura.ToJsonRevendaPlano: TJSONObject;
var
  LJSONArray: TJSONArray;
  LItem: TFuncionalidade;
  LCor: Longint;
begin
  Result := TJson.ObjectToJsonObject(Self);

  Result.RemovePair('idAPI').Free;
  Result.RemovePair('ativo').Free;
  Result.RemovePair('modulo').Free;
  Result.RemovePair('tipo').Free;
  Result.RemovePair('usaDFe').Free;
  Result.RemovePair('descricaoDetalhada').Free;
  Result.RemovePair('idSistema').Free;
  Result.RemovePair('valor').Free;
  Result.RemovePair('valorRevenda').Free;
  Result.AddPair('valor', TJSONNumber.Create(FValorRevenda));
  Result.RemovePair('valorAdesao').Free;
  Result.RemovePair('qtdGratis').Free;
  Result.RemovePair('qtdAcima').Free;
  Result.RemovePair('valorQtd').Free;
  Result.RemovePair('valoresQuantidade').Free;
  Result.RemovePair('valoresSegmento').Free;
  Result.RemovePair('valoresPeriodicidade').Free;
  Result.RemovePair('valoresPlano').Free;
  Result.RemovePair('exibirPreco').Free;
  Result.RemovePair('tamanhoMaximoNuvem').Free;
  Result.RemovePair('exibirRevenda').Free;
  Result.RemovePair('permiteQuantidade').Free;

  LJSONArray := TJSONArray.Create;

  for LItem in FFuncionalidades do
    LJSONArray.AddElement(TJson.ObjectToJsonObject(LItem));

  Result.RemovePair('funcionalidades').Free;
  Result.AddPair('funcionalidades', LJSONArray);

{$IFDEF MSWINDOWS}
  LCor := ColorToRGB(RGB(FCor.Red, FCor.Green, FCor.Blue));
  FCor.Red := GetRValue(LCor);
  FCor.Green := GetGValue(LCor);
  FCor.Blue := GetBValue(LCor);

  Result.RemovePair('cor').Free;
  Result.AddPair('cor', TJSONObject.Create //
    .AddPair('red', TJSONNumber.Create(FCor.Red)) //
    .AddPair('green', TJSONNumber.Create(FCor.Green)) //
    .AddPair('blue', TJSONNumber.Create(FCor.Blue)));
{$ENDIF}
end;

{ TValorQuantidade }

constructor TValorQuantidade.Create;
begin
  FQtdFinal := 0;
  FQtdInicial := 0;
  FValor := 0;
end;

procedure TValorQuantidade.SetQtdFinal(const Value: Integer);
begin
  FQtdFinal := Value;
end;

procedure TValorQuantidade.SetQtdInicial(const Value: Integer);
begin
  FQtdInicial := Value;
end;

procedure TValorQuantidade.SetValor(const Value: Currency);
begin
  FValor := Value;
end;

{ TValorSegmento }

constructor TValorSegmento.Create;
begin
  FSegmento := 0;
  FValor := 0;
end;

procedure TValorSegmento.SetSegmento(const Value: Integer);
begin
  FSegmento := Value;
end;

procedure TValorSegmento.SetValor(const Value: Currency);
begin
  FValor := Value;
end;

{ TFuncionalidade }

constructor TFuncionalidade.Create;
begin
  FDestacar := False;
end;

procedure TFuncionalidade.SetDescricao(const Value: String);
begin
  FDescricao := Value;
end;

procedure TFuncionalidade.SetDestacar(const Value: Boolean);
begin
  FDestacar := Value;
end;

procedure TFuncionalidade.SetFuncionalidade(const Value: String);
begin
  FFuncionalidade := Value;
end;

{ TCor }

constructor TCor.Create;
begin
  FRed := 0;
  FGreen := 0;
  FBlue := 0;
end;

procedure TCor.SetBlue(const Value: Integer);
begin
  FBlue := Value;
end;

procedure TCor.SetGreen(const Value: Integer);
begin
  FGreen := Value;
end;

procedure TCor.SetRed(const Value: Integer);
begin
  FRed := Value;
end;

{ TValorPlano }

constructor TValorPlano.Create;
begin
  FIdPlano := 0;
  FSegmento := 0;
  FValor := 0;
end;

procedure TValorPlano.SetDescricaoPlano(const Value: String);
begin
  FDescricaoPlano := Value;
end;

procedure TValorPlano.SetIdPlano(const Value: Integer);
begin
  FIdPlano := Value;
end;

procedure TValorPlano.SetSegmento(const Value: Integer);
begin
  FSegmento := Value;
end;

procedure TValorPlano.SetValor(const Value: Currency);
begin
  FValor := Value;
end;

{ TValorPeriodicidade }

constructor TValorPeriodicidade.Create;
begin
  FPeriodicidade := TPeriodicidadeAssinatura.paMensal;
  FValor := 0;
end;

procedure TValorPeriodicidade.SetPeriodicidade(const Value: TPeriodicidadeAssinatura);
begin
  FPeriodicidade := Value;
end;

procedure TValorPeriodicidade.SetValor(const Value: Currency);
begin
  FValor := Value;
end;

end.
