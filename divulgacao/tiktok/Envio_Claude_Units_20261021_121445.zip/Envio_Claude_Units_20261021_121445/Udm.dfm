object Dm: TDm
  OldCreateOrder = False
  OnCreate = DataModuleCreate
  Height = 637
  Width = 1062
  object FDConexao: TFDConnection
    Params.Strings = (
      'User_Name=<CREDENCIAL_REMOVIDA>'
      'Database=Suporte'
      'Server=analitcs.ciloscloud.com.br'
      'Password=<CREDENCIAL_REMOVIDA>'
      'MonitorBy=SDGdfa45342'
      'DriverID=MySQL')
    FetchOptions.AssignedValues = [evMode, evRowsetSize, evAutoFetchAll]
    FetchOptions.Mode = fmAll
    FetchOptions.RowsetSize = 300
    ResourceOptions.AssignedValues = [rvAutoReconnect]
    ResourceOptions.AutoReconnect = True
    Connected = True
    LoginPrompt = False
    OnRecover = FDConexaoRecover
    BeforeConnect = FDConexaoBeforeConnect
    Left = 29
    Top = 13
  end
  object FDGUIxWaitCursor1: TFDGUIxWaitCursor
    Provider = 'Forms'
    Left = 24
    Top = 56
  end
  object FDPhysMySQLDriverLink1: TFDPhysMySQLDriverLink
    VendorLib = 'C:\Dev\Command Analytics\libmySQL50.dll'
    Left = 136
    Top = 124
  end
  object FDPServer: TFDConnection
    Params.Strings = (
      
        'Database=C:\Windows\DataCloud\Connection - Command\data\datacomm' +
        'and.fdb'
      'User_Name=<CREDENCIAL_REMOVIDA>'
      'Password=<CREDENCIAL_REMOVIDA>'
      'Port=3050'
      'Server=commandsystem.commandcloud.com.br'
      'CharacterSet=WIN1252'
      'DriverID=FB')
    LoginPrompt = False
    Left = 583
    Top = 79
  end
  object FDQAuxServer: TFDQuery
    Connection = FDPServer
    Transaction = FDTAuxServer
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    Left = 575
    Top = 17
  end
  object FDTAuxServer: TFDTransaction
    Connection = FDPServer
    Left = 651
    Top = 23
  end
  object FDPhysFBDriverLink1: TFDPhysFBDriverLink
    Left = 672
    Top = 64
  end
  object FDQInsert: TFDQuery
    Connection = FDConexao
    SQL.Strings = (
      '')
    Left = 159
    Top = 55
  end
  object FDTContatoCli: TFDTransaction
    Connection = FDPServer
    Left = 680
    Top = 128
  end
  object FDQContatoCli: TFDQuery
    Connection = FDPServer
    Transaction = FDTContatoCli
    SQL.Strings = (
      'select * from contatos c')
    Left = 605
    Top = 132
    object FDQContatoCliCODIGO: TIntegerField
      FieldName = 'CODIGO'
      Origin = 'CODIGO'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Required = True
    end
    object FDQContatoCliCOD_CLI: TIntegerField
      FieldName = 'COD_CLI'
      Origin = 'COD_CLI'
    end
    object FDQContatoCliCOD_FOR: TIntegerField
      FieldName = 'COD_FOR'
      Origin = 'COD_FOR'
    end
    object FDQContatoCliDESCRICAO: TStringField
      FieldName = 'DESCRICAO'
      Origin = 'DESCRICAO'
      Size = 60
    end
    object FDQContatoCliSETOR: TStringField
      FieldName = 'SETOR'
      Origin = 'SETOR'
      Size = 60
    end
    object FDQContatoCliNUMERO: TStringField
      FieldName = 'NUMERO'
      Origin = 'NUMERO'
    end
    object FDQContatoCliCOD_AGENTE: TIntegerField
      FieldName = 'COD_AGENTE'
      Origin = 'COD_AGENTE'
    end
    object FDQContatoCliEMAIL: TStringField
      FieldName = 'EMAIL'
      Origin = 'EMAIL'
      Size = 200
    end
  end
  object FDQInsertFB: TFDQuery
    Connection = FDPServer
    Transaction = FDTInsertFB
    SQL.Strings = (
      'select * from contatos c')
    Left = 583
    Top = 192
    object IntegerField1: TIntegerField
      FieldName = 'CODIGO'
      Origin = 'CODIGO'
      ProviderFlags = [pfInUpdate, pfInWhere, pfInKey]
      Required = True
    end
    object IntegerField2: TIntegerField
      FieldName = 'COD_CLI'
      Origin = 'COD_CLI'
    end
    object IntegerField3: TIntegerField
      FieldName = 'COD_FOR'
      Origin = 'COD_FOR'
    end
    object StringField1: TStringField
      FieldName = 'DESCRICAO'
      Origin = 'DESCRICAO'
      Size = 60
    end
    object StringField2: TStringField
      FieldName = 'SETOR'
      Origin = 'SETOR'
      Size = 60
    end
    object StringField3: TStringField
      FieldName = 'NUMERO'
      Origin = 'NUMERO'
    end
    object IntegerField4: TIntegerField
      FieldName = 'COD_AGENTE'
      Origin = 'COD_AGENTE'
    end
    object StringField4: TStringField
      FieldName = 'EMAIL'
      Origin = 'EMAIL'
      Size = 200
    end
  end
  object FDTInsertFB: TFDTransaction
    Connection = FDPServer
    Left = 679
    Top = 185
  end
  object NotificationCenter1: TNotificationCenter
    Left = 40
    Top = 176
  end
  object FDTMODULOSDisp: TFDTransaction
    Connection = FDPServer
    Left = 562
    Top = 271
  end
  object FDTModulosUtil: TFDTransaction
    Connection = FDPServer
    Left = 562
    Top = 327
  end
  object FDQModulosUtil: TFDQuery
    Connection = FDPServer
    SQL.Strings = (
      'SELECT  p.cod_op,p.descricao FROM operacoes_disp_cliente_ult u'
      '      INNER JOIN operacoes_disp_cliente p'
      '       ON p.cod_op = u.cod_op'
      '       WHERE u.cod_cli = :cod_cli  ORDER BY descricao')
    Left = 617
    Top = 326
    ParamData = <
      item
        Name = 'COD_CLI'
        DataType = ftInteger
        ParamType = ptInput
      end>
    object FDQModulosUtilCOD_OP: TIntegerField
      FieldName = 'COD_OP'
      Origin = 'COD_OP'
      Required = True
    end
    object FDQModulosUtilDESCRICAO: TStringField
      FieldName = 'DESCRICAO'
      Origin = 'DESCRICAO'
      Size = 100
    end
  end
  object FDQModulosDisp: TFDQuery
    Connection = FDPServer
    SQL.Strings = (
      '       SELECT * FROM operacoes_disp_cliente p'
      '      WHERE p.cod_op NOT IN'
      '      (SELECT cod_op FROM operacoes_disp_cliente_ult U'
      '      where U.cod_cli = :COD_CLI  )')
    Left = 632
    Top = 272
    ParamData = <
      item
        Name = 'COD_CLI'
        DataType = ftInteger
        ParamType = ptInput
      end>
    object FDQModulosDispCOD_OP: TIntegerField
      FieldName = 'COD_OP'
      Origin = 'COD_OP'
      Required = True
    end
    object FDQModulosDispDESCRICAO: TStringField
      FieldName = 'DESCRICAO'
      Origin = 'DESCRICAO'
      Size = 100
    end
  end
  object DsModulosDisp: TDataSource
    DataSet = FDQModulosDisp
    Left = 682
    Top = 280
  end
  object DsModulosUtil: TDataSource
    DataSet = FDQModulosUtil
    Left = 680
    Top = 336
  end
  object cxStyleRepository1: TcxStyleRepository
    Left = 469
    Top = 320
    PixelsPerInch = 96
    object cxCinzaClaro: TcxStyle
      AssignedValues = [svColor]
      Color = 15790320
    end
    object cxBranco: TcxStyle
      AssignedValues = [svColor]
      Color = clWhite
    end
    object cxAzulClaro: TcxStyle
      AssignedValues = [svColor]
      Color = 16777185
    end
    object cxAzulMarinhoClaro: TcxStyle
      AssignedValues = [svColor]
      Color = 16763594
    end
    object cxVermelhoClaro: TcxStyle
      AssignedValues = [svColor]
      Color = 12171775
    end
    object cxVerdeClaro: TcxStyle
      AssignedValues = [svColor]
      Color = 14483385
    end
  end
  object FDQConscontatoCli: TFDQuery
    Connection = FDPServer
    Transaction = FDTContatoCli
    SQL.Strings = (
      'select * from contatos c')
    Left = 514
    Top = 120
  end
  object PDC: TPlataformaContador
    Autenticacao.Email = 'admin@admin.com'
    Autenticacao.Senha = '<CREDENCIAL_REMOVIDA>'
    TimeOut = 10
    BaseURL = 'http://commandcontador.com.br'
    Left = 456
    Top = 208
  end
  object FDQConsulta: TFDQuery
    Connection = FDConexao
    Left = 96
    Top = 32
  end
  object SaveDialogGrid: TSaveDialog
    Left = 211
    Top = 218
  end
  object RLXLSFilter: TRLXLSFilter
    DisplayName = 'Planilha Excel 97-2013'
    Left = 224
    Top = 320
  end
  object RLPDFFilter: TRLPDFFilter
    DocumentInfo.Creator = 'Command System'
    DisplayName = 'Documento PDF'
    Left = 192
    Top = 303
  end
  object frxDOCXExport: TfrxDOCXExport
    UseFileCache = True
    ShowProgress = True
    OverwritePrompt = False
    DataOnly = False
    OpenAfterExport = False
    PictureType = gpPNG
    Left = 389
    Top = 266
  end
  object frxXLSExport1: TfrxXLSExport
    UseFileCache = True
    ShowProgress = True
    OverwritePrompt = False
    DataOnly = False
    ExportEMF = True
    AsText = False
    Background = True
    FastExport = True
    PageBreaks = True
    EmptyLines = True
    SuppressPageHeadersFooters = False
    Left = 367
    Top = 194
  end
  object frxPDFExport: TfrxPDFExport
    UseFileCache = True
    ShowProgress = True
    OverwritePrompt = False
    DataOnly = False
    EmbeddedFonts = True
    OpenAfterExport = False
    PrintOptimized = False
    Outline = False
    Background = False
    HTMLTags = True
    Quality = 95
    Transparency = False
    Author = 'Command System'
    Subject = 'Exportar relat'#243'rio para PDF'
    ProtectionFlags = [ePrint, eModify, eCopy, eAnnot]
    HideToolbar = False
    HideMenubar = False
    HideWindowUI = False
    FitWindow = False
    CenterWindow = False
    PrintScaling = False
    PdfA = False
    PDFStandard = psNone
    PDFVersion = pv17
    Left = 306
    Top = 191
  end
  object CPPrinter: TdxComponentPrinter
    CurrentLink = DPrnLink
    Version = 0
    Left = 309
    Top = 130
    PixelsPerInch = 96
    object DPrnLink: TdxGridReportLink
      PageNumberFormat = pnfNumeral
      PrinterPage.DMPaper = 9
      PrinterPage.Footer = 6350
      PrinterPage.GrayShading = True
      PrinterPage.Header = 6350
      PrinterPage.Margins.Bottom = 12700
      PrinterPage.Margins.Left = 12700
      PrinterPage.Margins.Right = 12700
      PrinterPage.Margins.Top = 12700
      PrinterPage.Orientation = poLandscape
      PrinterPage.PageSize.X = 210000
      PrinterPage.PageSize.Y = 297000
      PrinterPage._dxMeasurementUnits_ = 0
      PrinterPage._dxLastMU_ = 2
      TimeFormat = 0
      PixelsPerInch = 96
      BuiltInReportLink = True
    end
  end
  object WebGrafMP: TWebCharts
    Left = 32
    Top = 264
  end
  object CdsGraficMP: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 32
    Top = 313
    object CdsGraficMPLabel: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object CdsGraficMPValue: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object CdsGraficMPRGB: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object FDConexaoEmpAntiga: TFDConnection
    Params.Strings = (
      'User_Name=<CREDENCIAL_REMOVIDA>'
      'Database=Suporte'
      'Server=gruposi.com.br'
      'Password=<CREDENCIAL_REMOVIDA>'
      'DriverID=MySQL')
    FetchOptions.AssignedValues = [evMode, evRowsetSize, evAutoFetchAll]
    FetchOptions.Mode = fmAll
    FetchOptions.RowsetSize = 300
    ResourceOptions.AssignedValues = [rvAutoReconnect]
    ResourceOptions.AutoReconnect = True
    LoginPrompt = False
    OnRecover = FDConexaoRecover
    BeforeConnect = FDConexaoBeforeConnect
    Left = 911
    Top = 475
  end
  object QConsEmpAntiga: TFDQuery
    Connection = FDConexaoEmpAntiga
    Left = 859
    Top = 475
  end
  object QCertificadosMes: TFDQuery
    OnCalcFields = QCertificadosMesCalcFields
    Connection = FDConexao
    SQL.Strings = (
      
        'SELECT C.*,CO.NOME_COMERCIAL,CO.TELEFONE AS TELEFONE_CONTADOR ,C' +
        'O.EMAIL'
      'FROM certificados C'
      'LEFT JOIN cliente CI ON CI.CNPJ_CLI = C.CNPJ_CLI'
      'LEFT JOIN contador_cliente CE ON  CE.COD_CLIENTE = CI.cod_cli'
      'LEFT JOIN contador CO ON CO.ID_CONTADOR =CE.COD_CONTADOR'
      'WHERE C.DATA_VAL_CERT_DIG BETWEEN '#39'2022-05-27'#39' AND '#39'2022-08-27'#39
      ''
      ''
      '')
    Left = 224
    Top = 15
    object QCertificadosMesID: TFDAutoIncField
      FieldName = 'ID'
      Origin = 'ID'
      ProviderFlags = [pfInWhere, pfInKey]
      ReadOnly = True
    end
    object QCertificadosMesRAZAO_EMP: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'RAZAO_EMP'
      Origin = 'RAZAO_EMP'
      Size = 100
    end
    object QCertificadosMesNOME_FANTASIA: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_FANTASIA'
      Origin = 'NOME_FANTASIA'
      Size = 100
    end
    object QCertificadosMesCIDADE: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CIDADE'
      Origin = 'CIDADE'
      Size = 100
    end
    object QCertificadosMesTELEFONE: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'TELEFONE'
      Origin = 'TELEFONE'
      Size = 13
    end
    object QCertificadosMesCELULAR_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CELULAR_CLI'
      Origin = 'CELULAR_CLI'
      Size = 13
    end
    object QCertificadosMesEMAIL_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'EMAIL_CLI'
      Origin = 'EMAIL_CLI'
      Size = 100
    end
    object QCertificadosMesCNPJ_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CNPJ_CLI'
      Origin = 'CNPJ_CLI'
      Size = 18
    end
    object QCertificadosMesTIPO: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'TIPO'
      Origin = 'TIPO'
      FixedChar = True
      Size = 1
    end
    object QCertificadosMesDATA_VAL_CERT_DIG: TDateField
      AutoGenerateValue = arDefault
      FieldName = 'DATA_VAL_CERT_DIG'
      Origin = 'DATA_VAL_CERT_DIG'
    end
    object QCertificadosMesDATA_SINCR_DADOS: TDateField
      AutoGenerateValue = arDefault
      FieldName = 'DATA_SINCR_DADOS'
      Origin = 'DATA_SINCR_DADOS'
    end
    object QCertificadosMesCALC_DIA_CERT: TStringField
      FieldKind = fkCalculated
      FieldName = 'CALC_DIA_CERT'
      Size = 30
      Calculated = True
    end
    object QCertificadosMesNOME_COMERCIAL: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_COMERCIAL'
      Origin = 'NOME_COMERCIAL'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
    object QCertificadosMesTELEFONE_CONTADOR: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'TELEFONE_CONTADOR'
      Origin = 'TELEFONE'
      ProviderFlags = []
      ReadOnly = True
    end
    object QCertificadosMesEMAIL: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'EMAIL'
      Origin = 'EMAIL'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
  end
  object DSCertificadosMes: TDataSource
    DataSet = QCertificadosMes
    Left = 312
    Top = 16
  end
  object FDQConsAgenda: TFDQuery
    AfterScroll = FDQConsAgendaAfterScroll
    OnCalcFields = FDQConsAgendaCalcFields
    Connection = FDConexao
    SQL.Strings = (
      'SELECT '
      '  a.*,'
      '  c.NOME_CLI,'
      '  c.NOME_FANTASIA,'
      '  c.CIDRES_CLI,'
      '  c.STATUS_INSTAL,'
      
        '  (SELECT nome_usu FROM usuario l WHERE l.COD_USU = a.cod_usu_la' +
        'nc) AS UsuLancamento,'
      
        '  (SELECT nome_usu FROM usuario o WHERE o.COD_USU = a.cod_colabo' +
        'rador) AS UsuColaborador,'
      
        '    (SELECT t.ID_TELEGRAM FROM usuario t WHERE t.COD_USU = a.cod' +
        '_colaborador) AS id_telegram,'
      '  CASE '
      '    WHEN a.Status_agendamento = 0 THEN '#39'AGUARDANDO'#39
      '    WHEN a.Status_agendamento = 1 THEN '#39'EFETUADO'#39
      '    WHEN a.Status_agendamento = 2 THEN '#39'N'#195'O EFETUADO'#39
      '    WHEN a.Status_agendamento = 3 THEN '#39'REAGENDADO'#39
      
        '    ELSE '#39'SEM STATUS'#39' -- Caso haja algum valor que n'#227'o se encaix' +
        'e nas op'#231#245'es acima'
      '  END AS DESC_STATUS'
      'FROM '
      '  agenda a'
      'INNER JOIN '
      '  cliente c ON c.cod_cli = a.cod_cli'
      'WHERE '
      '  a.cod_agenda > 0;'
      ''
      ''
      '')
    Left = 301
    Top = 479
    object FDQConsAgendacod_agenda: TFDAutoIncField
      FieldName = 'cod_agenda'
      Origin = 'cod_agenda'
      ProviderFlags = [pfInWhere, pfInKey]
      ReadOnly = True
    end
    object FDQConsAgendadescricao: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'descricao'
      Origin = 'descricao'
      Size = 2000
    end
    object FDQConsAgendacod_colaborador: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_colaborador'
      Origin = 'cod_colaborador'
    end
    object FDQConsAgendadata_agendamento: TDateField
      AutoGenerateValue = arDefault
      FieldName = 'data_agendamento'
      Origin = 'data_agendamento'
    end
    object FDQConsAgendadata_hora_lancamento: TDateTimeField
      AutoGenerateValue = arDefault
      FieldName = 'data_hora_lancamento'
      Origin = 'data_hora_lancamento'
    end
    object FDQConsAgendacod_usu_lanc: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_usu_lanc'
      Origin = 'cod_usu_lanc'
    end
    object FDQConsAgendahora_ini: TTimeField
      AutoGenerateValue = arDefault
      FieldName = 'hora_ini'
      Origin = 'hora_ini'
    end
    object FDQConsAgendahora_fin: TTimeField
      AutoGenerateValue = arDefault
      FieldName = 'hora_fin'
      Origin = 'hora_fin'
    end
    object FDQConsAgendacod_cli: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_cli'
      Origin = 'cod_cli'
    end
    object FDQConsAgendacod_ponto_revenda: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_ponto_revenda'
      Origin = 'cod_ponto_revenda'
    end
    object FDQConsAgendaNOME_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_CLI'
      Origin = 'NOME_CLI'
      ProviderFlags = []
      ReadOnly = True
      Size = 60
    end
    object FDQConsAgendaNOME_FANTASIA: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_FANTASIA'
      Origin = 'NOME_FANTASIA'
      ProviderFlags = []
      ReadOnly = True
      Size = 60
    end
    object FDQConsAgendaUsuLancamento: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'UsuLancamento'
      Origin = 'UsuLancamento'
      ProviderFlags = []
      ReadOnly = True
      Size = 50
    end
    object FDQConsAgendaUsuColaborador: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'UsuColaborador'
      Origin = 'UsuColaborador'
      ProviderFlags = []
      ReadOnly = True
      Size = 50
    end
    object FDQConsAgendadata_fin_agendamento: TDateField
      AutoGenerateValue = arDefault
      FieldName = 'data_fin_agendamento'
      Origin = 'data_fin_agendamento'
    end
    object FDQConsAgendaCIDRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CIDRES_CLI'
      Origin = 'CIDRES_CLI'
      ProviderFlags = []
      ReadOnly = True
      Size = 30
    end
    object FDQConsAgendadia_semana: TStringField
      FieldKind = fkCalculated
      FieldName = 'dia_semana'
      Size = 50
      Calculated = True
    end
    object FDQConsAgendaStatus_agendamento: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'Status_agendamento'
      Origin = 'Status_agendamento'
    end
    object FDQConsAgendaSomente_usuario_Visualizar: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'Somente_usuario_Visualizar'
      Origin = 'Somente_usuario_Visualizar'
      FixedChar = True
      Size = 1
    end
    object FDQConsAgendaTipo: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'Tipo'
      Origin = 'Tipo'
    end
    object FDQConsAgendaNota: TSingleField
      AutoGenerateValue = arDefault
      FieldName = 'Nota'
      Origin = 'Nota'
    end
    object FDQConsAgendaDESC_STATUS: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'DESC_STATUS'
      Origin = 'DESC_STATUS'
      ProviderFlags = []
      ReadOnly = True
      Size = 12
    end
    object FDQConsAgendaSTATUS_INSTAL: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'STATUS_INSTAL'
      Origin = 'STATUS_INSTAL'
      ProviderFlags = []
      ReadOnly = True
    end
    object FDQConsAgendaCALC_STATUS_INSTAL: TStringField
      FieldKind = fkCalculated
      FieldName = 'CALC_STATUS_INSTAL'
      Size = 100
      Calculated = True
    end
    object FDQConsAgendaid_telegram: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'id_telegram'
      Origin = 'id_telegram'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
  end
  object DsConsAgenda: TDataSource
    DataSet = FDQConsAgenda
    Left = 389
    Top = 481
  end
  object ACBrValidador: TACBrValidador
    TipoDocto = docEmail
    IgnorarChar = './-'
    AjustarTamanho = True
    PermiteVazio = True
    Left = 384
    Top = 130
  end
  object QNPS: TFDQuery
    OnCalcFields = QCertificadosMesCalcFields
    Connection = FDConexao
    SQL.Strings = (
      
        'SELECT EXTRACT(MONTH FROM F.data_hora_sug) AS MES,EXTRACT(YEAR F' +
        'ROM F.data_hora_sug) AS ANO,'
      'AVG(F.nota) AS SUPORTE ,AVG(F.nota_dev) AS DESENVOLVIMENTO '
      ' FROM fale_conosco F'
      ' GROUP BY 1,2')
    Left = 240
    Top = 64
    object QNPSMES: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'MES'
      Origin = 'MES'
      ProviderFlags = []
      ReadOnly = True
    end
    object QNPSANO: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'ANO'
      Origin = 'ANO'
      ProviderFlags = []
      ReadOnly = True
    end
    object QNPSSUPORTE: TBCDField
      AutoGenerateValue = arDefault
      FieldName = 'SUPORTE'
      Origin = 'SUPORTE'
      ProviderFlags = []
      ReadOnly = True
      Precision = 14
    end
    object QNPSDESENVOLVIMENTO: TBCDField
      AutoGenerateValue = arDefault
      FieldName = 'DESENVOLVIMENTO'
      Origin = 'DESENVOLVIMENTO'
      ProviderFlags = []
      ReadOnly = True
      Precision = 14
    end
  end
  object CdsGraficMP02: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 40
    Top = 369
    object StringField5: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object StringField6: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object StringField7: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object QRecorrenciaMRR: TFDQuery
    Connection = FDPServer
    Transaction = FDTInsertFB
    SQL.Strings = (
      
        '                         SELECT *  FROM SP_CLIENTES_MRR(:DATAINI' +
        ',:DATAFIN,:COD_CLA,:COD_CON,:CODIGO_IBGE)')
    Left = 684
    Top = 228
    ParamData = <
      item
        Name = 'DATAINI'
        DataType = ftDate
        ParamType = ptInput
      end
      item
        Name = 'DATAFIN'
        DataType = ftDate
        ParamType = ptInput
      end
      item
        Name = 'COD_CLA'
        DataType = ftInteger
        ParamType = ptInput
      end
      item
        Name = 'COD_CON'
        DataType = ftInteger
        ParamType = ptInput
      end
      item
        Name = 'CODIGO_IBGE'
        DataType = ftInteger
        ParamType = ptInput
      end>
  end
  object QContadorCliente: TFDQuery
    OnCalcFields = QCertificadosMesCalcFields
    Connection = FDConexao
    SQL.Strings = (
      'SELECT '
      
        'CO.COD_CONTADOR,CT.NOME_COMERCIAL,CT.TELEFONE,CT.DESCRICAO_ESCRI' +
        'TORIO,CT.CIDADE,'
      'CT.EMAIL,CT.TELEFONE,CT.NOME_RESP,CT.SISTEMA_CONTADOR,'
      
        'CT.EMAIL_ENVIO_ARQUIVOS,CT.MELHOR_DIA_ENVIO_ARQUIVOS,CT.USA_PLAT' +
        'AFORMA_DO_CONTADOR,'
      'CT.CPF_CONTADOR,CT.CRC_CONTADOR,'
      'COUNT(CO.COD_CLIENTE) AS QTD'
      'FROM  '
      'contador_cliente CO'
      'INNER JOIN cliente C'
      'ON C.cod_cli = CO.COD_CLIENTE'
      'INNER JOIN contador CT'
      'ON CT.ID_CONTADOR = CO.COD_CONTADOR'
      'GROUP BY CO.COD_CONTADOR'
      'ORDER BY  COUNT(CO.COD_CLIENTE) desc'
      ''
      '')
    Left = 176
    Top = 432
    object QContadorClienteCOD_CONTADOR: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'COD_CONTADOR'
      Origin = 'COD_CONTADOR'
    end
    object QContadorClienteNOME_COMERCIAL: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_COMERCIAL'
      Origin = 'NOME_COMERCIAL'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
    object QContadorClienteTELEFONE: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'TELEFONE'
      Origin = 'TELEFONE'
      ProviderFlags = []
      ReadOnly = True
    end
    object QContadorClienteDESCRICAO_ESCRITORIO: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'DESCRICAO_ESCRITORIO'
      Origin = 'DESCRICAO_ESCRITORIO'
      ProviderFlags = []
      ReadOnly = True
      Size = 50
    end
    object QContadorClienteQTD: TLargeintField
      AutoGenerateValue = arDefault
      FieldName = 'QTD'
      Origin = 'QTD'
      ProviderFlags = []
      ReadOnly = True
    end
    object QContadorClienteEMAIL: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'EMAIL'
      Origin = 'EMAIL'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
    object QContadorClienteTELEFONE_1: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'TELEFONE_1'
      Origin = 'TELEFONE'
      ProviderFlags = []
      ReadOnly = True
    end
    object QContadorClienteNOME_RESP: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_RESP'
      Origin = 'NOME_RESP'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
    object QContadorClienteSISTEMA_CONTADOR: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'SISTEMA_CONTADOR'
      Origin = 'SISTEMA_CONTADOR'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
    object QContadorClienteMELHOR_DIA_ENVIO_ARQUIVOS: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'MELHOR_DIA_ENVIO_ARQUIVOS'
      Origin = 'MELHOR_DIA_ENVIO_ARQUIVOS'
      ProviderFlags = []
      ReadOnly = True
    end
    object QContadorClienteEMAIL_ENVIO_ARQUIVOS: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'EMAIL_ENVIO_ARQUIVOS'
      Origin = 'EMAIL_ENVIO_ARQUIVOS'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
    object QContadorClienteUSA_PLATAFORMA_DO_CONTADOR: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'USA_PLATAFORMA_DO_CONTADOR'
      Origin = 'USA_PLATAFORMA_DO_CONTADOR'
      ProviderFlags = []
      ReadOnly = True
      Size = 10
    end
    object QContadorClienteCPF_CONTADOR: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CPF_CONTADOR'
      Origin = 'CPF_CONTADOR'
      ProviderFlags = []
      ReadOnly = True
      Size = 18
    end
    object QContadorClienteCRC_CONTADOR: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CRC_CONTADOR'
      Origin = 'CRC_CONTADOR'
      ProviderFlags = []
      ReadOnly = True
      Size = 18
    end
    object QContadorClienteCIDADE: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CIDADE'
      Origin = 'CIDADE'
      ProviderFlags = []
      ReadOnly = True
      Size = 100
    end
  end
  object DsContadorCliente: TDataSource
    DataSet = QContadorCliente
    Left = 232
    Top = 407
  end
  object ImportExcel: TImportExcel
    Left = 808
    Top = 288
  end
  object OpDExcel: TOpenDialog
    Left = 904
    Top = 304
  end
  object QConsFB: TFDQuery
    Connection = FDPServer
    Transaction = FDTInsertFB
    SQL.Strings = (
      'select * from contatos c')
    Left = 825
    Top = 176
  end
  object QFDQConsulta2: TFDQuery
    Connection = FDConexao
    Left = 97
    Top = 96
  end
  object QFDQConsulta3: TFDQuery
    Connection = FDConexao
    Left = 104
    Top = 168
  end
  object NotificationCenter: TNotificationCenter
    Left = 840
    Top = 112
  end
  object dxAlertWindowManager: TdxAlertWindowManager
    LookAndFeel.NativeStyle = False
    LookAndFeel.SkinName = 'Office2010Blue'
    OptionsAnimate.AlphaBlendValue = 230
    OptionsBehavior.DisplayTime = 5000
    OptionsButtons.Buttons = <>
    OptionsCaptionButtons.CaptionButtons = [awcbClose]
    OptionsMessage.Caption.Font.Charset = DEFAULT_CHARSET
    OptionsMessage.Caption.Font.Color = clWindowText
    OptionsMessage.Caption.Font.Height = -15
    OptionsMessage.Caption.Font.Name = 'Candara'
    OptionsMessage.Caption.Font.Style = [fsBold]
    OptionsMessage.Text.Font.Charset = DEFAULT_CHARSET
    OptionsMessage.Text.Font.Color = clWindowText
    OptionsMessage.Text.Font.Height = -13
    OptionsMessage.Text.Font.Name = 'Candara'
    OptionsMessage.Text.Font.Style = []
    OptionsNavigationPanel.Font.Charset = DEFAULT_CHARSET
    OptionsNavigationPanel.Font.Color = clWindowText
    OptionsNavigationPanel.Font.Height = -11
    OptionsNavigationPanel.Font.Name = 'Tahoma'
    OptionsNavigationPanel.Font.Style = []
    OptionsSize.AutoHeight = True
    OptionsSize.AutoWidth = True
    OptionsSize.AutoSizeAdjustment = True
    OptionsSize.MinHeight = 10
    OptionsSize.MinWidth = 270
    OptionsSize.Width = 500
    WindowPosition = awpBottomLeft
    Left = 896
    Top = 416
    PixelsPerInch = 96
  end
  object CdsConsAgenda: TFDMemTable
    AfterScroll = CdsConsAgendaAfterScroll
    OnCalcFields = CdsConsAgendaCalcFields
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 132
    Top = 406
    object CdsConsAgendadescricao: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'descricao'
      Origin = 'descricao'
      Size = 2000
    end
    object CdsConsAgendacod_colaborador: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_colaborador'
      Origin = 'cod_colaborador'
    end
    object CdsConsAgendadata_agendamento: TDateField
      AutoGenerateValue = arDefault
      FieldName = 'data_agendamento'
      Origin = 'data_agendamento'
    end
    object CdsConsAgendadata_hora_lancamento: TDateTimeField
      AutoGenerateValue = arDefault
      FieldName = 'data_hora_lancamento'
      Origin = 'data_hora_lancamento'
    end
    object CdsConsAgendacod_usu_lanc: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_usu_lanc'
      Origin = 'cod_usu_lanc'
    end
    object CdsConsAgendahora_ini: TTimeField
      AutoGenerateValue = arDefault
      FieldName = 'hora_ini'
      Origin = 'hora_ini'
    end
    object CdsConsAgendahora_fin: TTimeField
      AutoGenerateValue = arDefault
      FieldName = 'hora_fin'
      Origin = 'hora_fin'
    end
    object CdsConsAgendacod_cli: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_cli'
      Origin = 'cod_cli'
    end
    object CdsConsAgendacod_ponto_revenda: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'cod_ponto_revenda'
      Origin = 'cod_ponto_revenda'
    end
    object CdsConsAgendaNOME_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_CLI'
      Origin = 'NOME_CLI'
      ProviderFlags = []
      Size = 60
    end
    object CdsConsAgendaUsuLancamento: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'UsuLancamento'
      Origin = 'UsuLancamento'
      ProviderFlags = []
      Size = 50
    end
    object CdsConsAgendaNOME_FANTASIA: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'NOME_FANTASIA'
      Origin = 'NOME_FANTASIA'
      ProviderFlags = []
      Size = 60
    end
    object CdsConsAgendaUsuColaborador: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'UsuColaborador'
      Origin = 'UsuColaborador'
      ProviderFlags = []
      Size = 50
    end
    object CdsConsAgendadata_fin_agendamento: TDateField
      AutoGenerateValue = arDefault
      FieldName = 'data_fin_agendamento'
      Origin = 'data_fin_agendamento'
    end
    object CdsConsAgendadia_semana: TStringField
      FieldKind = fkCalculated
      FieldName = 'dia_semana'
      Size = 50
      Calculated = True
    end
    object CdsConsAgendaCIDRES_CLI: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'CIDRES_CLI'
      Origin = 'CIDRES_CLI'
      ProviderFlags = []
      Size = 30
    end
    object CdsConsAgendaStatus_agendamento: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'Status_agendamento'
      Origin = 'Status_agendamento'
    end
    object CdsConsAgendaDESC_STATUS: TStringField
      FieldKind = fkCalculated
      FieldName = 'DESC_STATUS'
      Size = 30
      Calculated = True
    end
    object CdsConsAgendaSomente_usuario_Visualizar: TStringField
      AutoGenerateValue = arDefault
      FieldName = 'Somente_usuario_Visualizar'
      Origin = 'Somente_usuario_Visualizar'
      FixedChar = True
      Size = 1
    end
    object CdsConsAgendacod_agenda: TIntegerField
      FieldName = 'cod_agenda'
    end
    object CdsConsAgendaSTATUS_INSTAL: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'STATUS_INSTAL'
      Origin = 'STATUS_INSTAL'
      ProviderFlags = []
    end
    object CdsConsAgendaCALC_STATUS_INSTAL: TStringField
      FieldKind = fkCalculated
      FieldName = 'CALC_STATUS_INSTAL'
      Size = 100
      Calculated = True
    end
  end
  object CdsGraficMP03: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 41
    Top = 422
    object CdsGraficMP03Label: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object CdsGraficMP03Value: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object CdsGraficMP03RGB: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object CdsGraficMP04: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 41
    Top = 475
    object CdsGraficMP04Label: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object CdsGraficMP04Value: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object CdsGraficMP04RGB: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object CdsGraficMP05: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 47
    Top = 531
    object CdsGraficMP05Label: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object CdsGraficMP05Value: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object CdsGraficMP05RGB: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object CdsGraficMP06: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 133
    Top = 512
    object CdsGraficMP06Label: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object CdsGraficMP06Value: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object CdsGraficMP06RGB: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object CdsGraficMP07: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 217
    Top = 534
    object CdsGraficMP07Label: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object CdsGraficMP07Value: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object CdsGraficMP07RGB: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object CdsGraficMP08: TFDMemTable
    Filter = 
      'DESCRICAO <> '#39'LUCRO LIQU'#205'DO (%)'#39' AND DESCRICAO <>  '#39'LUCRO LIQU'#205'D' +
      'O (R$)'#39
    FieldDefs = <>
    IndexDefs = <>
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    StoreDefs = True
    Left = 287
    Top = 551
    object CdsGraficMP08Label: TStringField
      FieldName = 'Label'
      Size = 60
    end
    object CdsGraficMP08Value: TStringField
      FieldName = 'Value'
      Size = 60
    end
    object CdsGraficMP08RGB: TStringField
      FieldName = 'RGB'
      Size = 60
    end
  end
  object FDPhysPgDriverLink1: TFDPhysPgDriverLink
    Left = 685
    Top = 416
  end
  object FDConexaoCommandZap: TFDConnection
    Params.Strings = (
      'Database=whatsapp_api'
      'User_Name=<CREDENCIAL_REMOVIDA>'
      'Password=<CREDENCIAL_REMOVIDA>'
      'Server=45.143.7.87'
      'CharacterSet=UTF8'
      'DriverID=PG')
    LoginPrompt = False
    BeforeConnect = FDConexaoCommandZapBeforeConnect
    Left = 614
    Top = 467
  end
  object FDConexaoCRM: TFDConnection
    Params.Strings = (
      'Database=crm_api'
      'User_Name=<CREDENCIAL_REMOVIDA>'
      'Password=<CREDENCIAL_REMOVIDA>'
      'Server=195.200.5.223'
      'Port=5433'
      'CharacterSet=UTF8'
      'DriverID=PG')
    LoginPrompt = False
    BeforeConnect = FDConexaoCommandZapBeforeConnect
    Left = 715
    Top = 466
  end
  object QConsultaPG: TFDQuery
    Connection = FDConexaoCommandZap
    Left = 621
    Top = 529
  end
  object QinsertPG: TFDQuery
    Connection = FDConexaoCommandZap
    Left = 758
    Top = 500
  end
  object QConsultaPG2: TFDQuery
    Connection = FDConexaoCommandZap
    Left = 703
    Top = 544
  end
  object PopContador: TPopupMenu
    Left = 241
    Top = 454
    object po: TMenuItem
      Caption = 'Copiar C'#233'lula'
      OnClick = poClick
    end
  end
  object QConsFB2: TFDQuery
    Connection = FDPServer
    Transaction = FDTInsertFB
    SQL.Strings = (
      'select * from contatos c')
    Left = 885
    Top = 184
  end
  object QConsultaPG3: TFDQuery
    Connection = FDConexaoCommandZap
    Left = 770
    Top = 557
  end
  object QConsultaPG4: TFDQuery
    Connection = FDConexaoCommandZap
    Left = 837
    Top = 565
  end
  object QConsultaCRM: TFDQuery
    Connection = FDConexaoCRM
    Left = 715
    Top = 529
  end
end
