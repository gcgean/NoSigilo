unit UServicoContratado;

interface

uses
  System.SysUtils,
  System.Math,
  System.JSON,
  UPlanoAssinatura;

type
  TServicoContratado = class
  private
    FQtd: Integer;
    FValor: Currency;
    FPlano: TPlanoAssinatura;
    FValorTotal: Currency;
    FDataPlano: TDateTime;
    FQtdLiberada: Integer;

    procedure SetQtd(const Value: Integer);
    procedure SetValor(const Value: Currency);
    procedure SetValorTotal(const Value: Currency);
    procedure SetDataPlano(const Value: TDateTime);
  public
    property Plano: TPlanoAssinatura read FPlano;
    property Qtd: Integer read FQtd write SetQtd;
    property QtdLiberada: Integer read FQtdLiberada write FQtdLiberada;
    property Valor: Currency read FValor write SetValor;
    property ValorTotal: Currency read FValorTotal write SetValorTotal;
    property DataPlano: TDateTime read FDataPlano write SetDataPlano;

    procedure CalcularValorTotal;
    procedure AlterarPlano(const APlano: TPlanoAssinatura);

    function Clone: TServicoContratado;
    function ToJson: TJSONObject;

    constructor Create;
    destructor Destroy; override;
  end;

implementation

uses
  Rest.JSON;

{ TServicoContratado }

procedure TServicoContratado.AlterarPlano(const APlano: TPlanoAssinatura);
begin
  if Assigned(FPlano) then
    FreeAndNil(FPlano);

  FPlano := APlano.Clone;
end;

procedure TServicoContratado.CalcularValorTotal;
var
  I: Integer;
begin
  for I := 0 to Plano.ValoresQuantidade.Count - 1 do
    if (FQtd >= Plano.ValoresQuantidade[I].QtdInicial) and
      (FQtd <= Plano.ValoresQuantidade[I].QtdFinal) then
    begin
      FValor := Plano.ValoresQuantidade[I].Valor;
      break;
    end;

  if FValor <= 0 then
    FValor := Plano.Valor;

  FValorTotal := RoundTo((FQtd - FQtdLiberada) * FValor, -2);
end;

function TServicoContratado.Clone: TServicoContratado;
begin
  Result := TServicoContratado.Create;

  if Assigned(FPlano) then
    Result.AlterarPlano(FPlano);

  Result.Qtd := FQtd;
  Result.QtdLiberada := FQtdLiberada;
  Result.Valor := FValor;
  Result.ValorTotal := FValorTotal;
  Result.DataPlano := FDataPlano;
end;

constructor TServicoContratado.Create;
begin
  FPlano := TPlanoAssinatura.Create;
  FQtd := 0;
  FValor := 0;
  FValorTotal := 0;
  FQtdLiberada := 0;
end;

destructor TServicoContratado.Destroy;
begin
  if Assigned(FPlano) then
    FreeAndNil(FPlano);

  inherited;
end;

procedure TServicoContratado.SetDataPlano(const Value: TDateTime);
begin
  FDataPlano := Value;
end;

procedure TServicoContratado.SetQtd(const Value: Integer);
begin
  FQtd := Value;
end;

procedure TServicoContratado.SetValor(const Value: Currency);
begin
  FValor := Value;
end;

procedure TServicoContratado.SetValorTotal(const Value: Currency);
begin
  FValorTotal := Value;
end;

function TServicoContratado.ToJson: TJSONObject;
begin
  Result := TJSONObject.Create;

  Result.AddPair('id', TJSONNumber.Create(FPlano.Id));
  Result.AddPair('descricao', FPlano.Descricao.Trim);
  Result.AddPair('qtdPaga', TJSONNumber.Create(FQtd - FQtdLiberada));
  Result.AddPair('qtdGratis', TJSONNumber.Create(FQtdLiberada));
  Result.AddPair('qtdTotal', TJSONNumber.Create(FQtd));
  Result.AddPair('valorUnit', TJSONNumber.Create(FValor));
  Result.AddPair('valorTotal', TJSONNumber.Create(FValorTotal));
end;

end.
