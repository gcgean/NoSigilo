unit UValoresPlanoAtualPlano;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async,
  FireDAC.DApt, Data.DB, FireDAC.Comp.DataSet, FireDAC.Comp.Client, Vcl.Grids, Vcl.DBGrids;

type
  TFrmValoresPlanoAtualPlano = class(TForm)
    QValores: TFDQuery;
    QValoresid_plano_atual: TIntegerField;
    QValoresdescricao: TStringField;
    QValoresdesc_segmento: TStringField;
    QValoresvalor: TFMTBCDField;
    DSValores: TDataSource;
    DBGFuncionalidades: TDBGrid;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormShow(Sender: TObject);
  private
  public
    IDPlano: Integer;
  end;

var
  FrmValoresPlanoAtualPlano: TFrmValoresPlanoAtualPlano;

implementation

uses
  uDM;

{$R *.dfm}

procedure TFrmValoresPlanoAtualPlano.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
end;

procedure TFrmValoresPlanoAtualPlano.FormCreate(Sender: TObject);
begin
  IDPlano := 0;
end;

procedure TFrmValoresPlanoAtualPlano.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key = vk_escape then
    close;
end;

procedure TFrmValoresPlanoAtualPlano.FormShow(Sender: TObject);
begin
  Self.Align := alClient;

  QValores.close;
  QValores.parambyname('id_plano').asinteger := IDPlano;
  QValores.open;
  QValores.disablecontrols;

  try
    QValores.last;
    QValores.first;
  finally
    QValores.enablecontrols;
  end;
end;

end.
