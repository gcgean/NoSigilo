unit UCustomJSON.Contract;

interface

type
  ICustomJSON = interface
    ['{E26F118A-24EB-45AC-A5B7-90F5B7FE51CC}']
    function AddString(Name: String; Value: String; AddEmpty: Boolean = False): ICustomJSON;
    function AddInteger(Name: String; Value: Integer): ICustomJSON;
    function AddCurrency(Name: String; Value: Currency): ICustomJSON;
    function AddBoolean(Name: String; Value: Boolean): ICustomJSON;
    function AddJson(Name: String; Value: String): ICustomJSON;
    function ToJsonString: String;
  end;

implementation

end.
