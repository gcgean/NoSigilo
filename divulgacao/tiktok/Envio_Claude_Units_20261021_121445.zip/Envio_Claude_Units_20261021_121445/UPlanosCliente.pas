unit UPlanosCliente;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, cxGraphics, cxControls, cxLookAndFeels,
  cxLookAndFeelPainters, cxStyles, cxCustomData, cxFilter, cxData, cxDataStorage, cxEdit,
  cxNavigator, dxDateRanges, cxDataControllerConditionalFormattingRulesManagerDialog, Data.DB,
  cxDBData, cxGridLevel, cxClasses, cxGridCustomView, cxGridCustomTableView, cxGridTableView,
  cxGridDBTableView, cxGrid, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Comp.DataSet,
  FireDAC.Comp.Client, cxCheckBox, cxCurrencyEdit, cxContainer, cxTextEdit, Vcl.StdCtrls,
  FireDAC.Stan.Async, FireDAC.DApt, System.StrUtils, System.DateUtils, Vcl.Menus, Rest.Types;

type
  TFrmPlanosCliente = class(TForm)
    PnCliente: TPanel;
    Panel1: TPanel;
    MTPlanos: TFDMemTable;
    MTPlanosSELEC: TBooleanField;
    MTPlanosID: TIntegerField;
    MTPlanosDESCRICAO: TStringField;
    MTPlanosMODULO: TBooleanField;
    MTPlanosQTD_ACIMA: TIntegerField;
    MTPlanosVALOR_QTD: TFMTBCDField;
    MTPlanosQTD: TIntegerField;
    MTPlanosVALOR_TOTAL: TFMTBCDField;
    DSPlanos: TDataSource;
    MTPlanosVALOR: TFMTBCDField;
    Label1: TLabel;
    EdtValorTotal: TcxCurrencyEdit;
    Label2: TLabel;
    EdtValorAssinatura: TcxCurrencyEdit;
    BtnOK: TButton;
    QPlanos: TFDQuery;
    GPlanos: TcxGrid;
    GPlanosDBTableView: TcxGridDBTableView;
    GPlanosLevel: TcxGridLevel;
    GPlanosDBTableViewSELEC: TcxGridDBColumn;
    GPlanosDBTableViewID: TcxGridDBColumn;
    GPlanosDBTableViewDESCRICAO: TcxGridDBColumn;
    GPlanosDBTableViewMODULO: TcxGridDBColumn;
    GPlanosDBTableViewVALOR: TcxGridDBColumn;
    GPlanosDBTableViewQTD: TcxGridDBColumn;
    GPlanosDBTableViewVALOR_TOTAL: TcxGridDBColumn;
    CheckValor: TCheckBox;
    QAux: TFDQuery;
    PopupPlano: TPopupMenu;
    V1: TMenuItem;
    V2: TMenuItem;
    MTPlanosVALOR_PLANO: TFMTBCDField;
    MTPlanosVALOR_TOTAL_PLANO: TFMTBCDField;
    GPlanosDBTableViewVALOR_PLANO: TcxGridDBColumn;
    GPlanosDBTableViewVALOR_TOTAL_PLANO: TcxGridDBColumn;
    EdtObservacaoVenda: TLabeledEdit;
    MTPlanosTAMANHO_MAX_NUVEM: TIntegerField;
    MTPlanosQTD_GRATIS: TIntegerField;
    QPlanosOld: TFDQuery;
    MTPlanosOld: TFDMemTable;
    MTPlanosNew: TFDMemTable;
    MTPlanosOldid_plano: TIntegerField;
    MTPlanosOldmodulo: TBooleanField;
    MTPlanosOldqtd: TIntegerField;
    MTPlanosOldvalor_total: TFMTBCDField;
    MTPlanosOldvalor: TFMTBCDField;
    MTPlanosNewid_plano: TIntegerField;
    MTPlanosNewmodulo: TBooleanField;
    MTPlanosNewqtd: TIntegerField;
    MTPlanosNewvalor_total: TFMTBCDField;
    MTPlanosNewvalor: TFMTBCDField;
    MTPlanosOldalterado: TBooleanField;
    MTPlanosOldremovido: TBooleanField;
    MTPlanosNewincluido: TBooleanField;
    QLog: TFDQuery;
    MTPlanosQTD_LIBERADA: TIntegerField;
    GPlanosDBTableViewQTD_LIBERADA: TcxGridDBColumn;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure FormShow(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure GPlanosEnter(Sender: TObject);
    procedure GPlanosExit(Sender: TObject);
    procedure GPlanosDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
      AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure GPlanosDBTableViewSELECPropertiesValidate(Sender: TObject; var DisplayValue: Variant;
      var ErrorText: TCaption; var Error: Boolean);
    procedure GPlanosDBTableViewQTDPropertiesValidate(Sender: TObject; var DisplayValue: Variant;
      var ErrorText: TCaption; var Error: Boolean);
    procedure GPlanosDBTableViewKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure GPlanosDBTableViewEditKeyDown(Sender: TcxCustomGridTableView;
      AItem: TcxCustomGridTableItem; AEdit: TcxCustomEdit; var Key: Word; Shift: TShiftState);
    procedure CheckValorClick(Sender: TObject);
    procedure BtnOKClick(Sender: TObject);
    procedure V1Click(Sender: TObject);
    procedure V2Click(Sender: TObject);
    procedure GPlanosDBTableViewVALORPropertiesValidate(Sender: TObject; var DisplayValue: Variant;
      var ErrorText: TCaption; var Error: Boolean);
    procedure GPlanosDBTableViewQTD_LIBERADAPropertiesValidate(Sender: TObject;
      var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
  private
    bPossuiPlano: Boolean;
    iQuantidadeMinimaMesesAlterarPlano: Integer;
    dDataPlanoCliente: TDate;
    FValorAssinaturaOld: Currency;

    procedure InserirLog;
    procedure BuscarPlanos;
    procedure CalcularTotal(AplicarValorAssinatura: Boolean = True);
    function Coalesce(Value: Variant; Default: Variant): Variant;
  public
    iCodigoCliente: Integer;
    sNomeCliente: String;
    sCNPJCliente: String;
  end;

var
  FrmPlanosCliente: TFrmPlanosCliente;

implementation

uses
  UDM, UFuncionalidadesPlano, UValoresPlanoAtualPlano, RestRequest4D, UCustomJSON,
  ULogAssinaturaCliente;

{$R *.dfm}

procedure TFrmPlanosCliente.BtnOKClick(Sender: TObject);
begin
  InserirLog;

  with QAux do
  begin
    Close;
    SQL.Clear;
    SQL.Text := 'delete from CLIENTE_PLANOS where id_cli = ' + iCodigoCliente.ToString;
    ExecSQL;
  end;

  with MTPlanos do
  begin
    DisableControls;

    try
      First;

      while not Eof do
      begin
        if MTPlanosSELEC.AsBoolean then
        begin
          QAux.Close;
          QAux.SQL.Clear;
          QAux.SQL.Text :=
            'insert into CLIENTE_PLANOS (ID_CLI, ID_PLANO, QTD, VALOR, VALOR_TOTAL, DATA_PLANO, ' +
            'QTD_LIBERADA) values (:ID_CLI, :ID_PLANO, :QTD, :VALOR, :VALOR_TOTAL, :DATA_PLANO, ' +
            ':QTD_LIBERADA)';
          QAux.ParamByName('ID_CLI').AsInteger := iCodigoCliente;
          QAux.ParamByName('ID_PLANO').AsInteger := MTPlanosID.AsInteger;
          QAux.ParamByName('QTD').AsInteger := MTPlanosQTD.AsInteger;
          QAux.ParamByName('VALOR').AsCurrency := MTPlanosVALOR.AsCurrency;
          QAux.ParamByName('VALOR_TOTAL').AsCurrency := MTPlanosVALOR_TOTAL.AsCurrency;
          QAux.ParamByName('DATA_PLANO').AsDate := Date;
          QAux.ParamByName('QTD_LIBERADA').AsInteger := MTPlanosQTD_LIBERADA.AsInteger;
          QAux.ExecSQL;
        end;

        Next;
      end;
    finally
      EnableControls;
    end;
  end;

  try
    DM.ExecutarRequestAPICommand(TRequest.New.BaseURL('/clientes/' + DM.RemoveChar(sCNPJCliente) +
      '/mensalidade') //
      .AddBody( //
      TCustomJSON.New.AddCurrency('valorMensalidade', EdtValorAssinatura.Value) //
      .ToJsonString //
      ).ContentType('application/json;charset=UTF-8'), rmPATCH);
  except
    on E: Exception do
    begin
      ShowMessage('Falha ao atualizar o valor da assinatura do cliente: ' + E.Message);
      exit;
    end;
  end;

  try
    DM.ExecutarRequestAPICommand(TRequest.New.BaseURL('/clientes/' + DM.RemoveChar(sCNPJCliente) +
      '/observacao') //
      .AddBody( //
      TCustomJSON.New.AddString('observacaoVenda', Trim(Copy(Trim(EdtObservacaoVenda.Text), 1, 200)
      ), True) //
      .ToJsonString //
      ).ContentType('application/json;charset=UTF-8'), rmPATCH);
  except
    on E: Exception do
    begin
      ShowMessage('Falha ao atualizar a observa��o de venda do cliente: ' + E.Message);
      exit;
    end;
  end;

  Close;
end;

procedure TFrmPlanosCliente.BuscarPlanos;
begin
  QPlanos.Close;
  QPlanos.ParamByName('ID_CLI').AsInteger := iCodigoCliente;
  QPlanos.Open;

  MTPlanos.Open;
  MTPlanos.DisableControls;

  try
    MTPlanos.EmptyDataSet;

    while not QPlanos.Eof do
    begin
      MTPlanos.Append;
      MTPlanosSELEC.AsBoolean := QPlanos.FieldByName('selec').AsInteger = 1;
      MTPlanosID.AsInteger := QPlanos.FieldByName('id').AsInteger;
      MTPlanosDESCRICAO.asstring := QPlanos.FieldByName('descricao').asstring;
      MTPlanosMODULO.AsBoolean := QPlanos.FieldByName('modulo').AsInteger = 1;

      if (not MTPlanosMODULO.AsBoolean) and (MTPlanosSELEC.AsBoolean) then
        bPossuiPlano := True;

      MTPlanosQTD_ACIMA.AsInteger := QPlanos.FieldByName('qtd_acima').AsInteger;
      MTPlanosVALOR_QTD.AsCurrency := QPlanos.FieldByName('valor_qtd').AsCurrency;
      MTPlanosQTD.AsInteger := QPlanos.FieldByName('qtd').AsInteger;
      MTPlanosQTD_LIBERADA.AsInteger := QPlanos.FieldByName('qtd_liberada').AsInteger;
      MTPlanosVALOR_TOTAL.AsCurrency := QPlanos.FieldByName('valor_total').AsCurrency;
      MTPlanosVALOR.AsCurrency := QPlanos.FieldByName('valor').AsCurrency;
      MTPlanosVALOR_TOTAL_PLANO.AsCurrency := QPlanos.FieldByName('valor_total_plano').AsCurrency;
      MTPlanosVALOR_PLANO.AsCurrency := QPlanos.FieldByName('valor_plano').AsCurrency;
      MTPlanosTAMANHO_MAX_NUVEM.AsInteger := QPlanos.FieldByName('tamanho_max_nuvem').AsInteger;
      MTPlanosQTD_GRATIS.AsInteger := QPlanos.FieldByName('qtd_gratis').AsInteger;
      MTPlanos.Post;

      QPlanos.Next;
    end;
  finally
    QPlanos.Close;

    MTPlanos.First;
    MTPlanos.EnableControls;
  end;

  // Busca observa��o de venda do cliente
  with QAux do
  begin
    Close;
    SQL.Clear;
    SQL.Text := 'select OBS_VENDA from CLIENTE where COD_CLI = ' + iCodigoCliente.ToString;
    Open;

    EdtObservacaoVenda.Text := Trim(Copy(FieldByName('OBS_VENDA').asstring.Trim, 1, 200));

    Close;
  end;

  // Busca data do plano
  with QAux do
  begin
    Close;
    SQL.Clear;
    SQL.Text := 'select cp.id_plano, cp.data_plano from cliente_planos cp inner join planos p on ' +
      '(cp.id_plano = p.id) where p.modulo = false and cp.id_cli = ' + iCodigoCliente.ToString +
      ' limit 1';
    Open;

    if FieldByName('id_plano').AsInteger > 0 then
      dDataPlanoCliente := FieldByName('data_plano').AsDateTime;

    Close;
  end;

  // Busca quantidade minima de meses para voltar o plano
  with QAux do
  begin
    Close;
    SQL.Clear;
    SQL.Text := 'select QTD_MESES_VOLTAR_PLANO as QTD from PARAMETROS where ID = 1';
    Open;

    iQuantidadeMinimaMesesAlterarPlano := FieldByName('QTD').AsInteger;

    Close;
  end;
end;

procedure TFrmPlanosCliente.CalcularTotal(AplicarValorAssinatura: Boolean);
var
  Total: Currency;
  Codigo: Integer;
begin
  Total := 0;

  with MTPlanos do
  begin
    DisableControls;
    Codigo := MTPlanosID.AsInteger;

    try
      First;

      while not Eof do
      begin
        if MTPlanosSELEC.AsBoolean then
          Total := Total + MTPlanosVALOR_TOTAL.AsCurrency;

        Next;
      end;
    finally
      Locate('ID', Codigo, []);
      EnableControls;

      EdtValorTotal.Value := Total;

      if (CheckValor.Checked) and (AplicarValorAssinatura) then
        EdtValorAssinatura.Value := Total;
    end;
  end;
end;

procedure TFrmPlanosCliente.CheckValorClick(Sender: TObject);
begin
  DM.GravaIni('command.ini', 'ConfiguracaoLocal', 'FrmPlanosCliente.CheckValor',
    IfThen(CheckValor.Checked, 'S', 'N'));
end;

function TFrmPlanosCliente.Coalesce(Value, Default: Variant): Variant;
begin
  case TVarData(Value).vType of
    varSmallInt, varInteger, varDouble, varCurrency, varDate:
      begin
        if Value <= 0 then
          Result := Default
        else
          Result := Value;
      end;
    varNull, varEmpty:
      Result := Default;
  else
    if Value = Null then
      Result := Default
    else if Trim(Value) = '' then
      Result := Default
    else
      Result := Value;
  end;
end;

procedure TFrmPlanosCliente.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
  FrmPlanosCliente := nil;
end;

procedure TFrmPlanosCliente.FormCreate(Sender: TObject);
begin
  iCodigoCliente := 0;
  sNomeCliente := '';
  iQuantidadeMinimaMesesAlterarPlano := 0;
  dDataPlanoCliente := 0;
end;

procedure TFrmPlanosCliente.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key = VK_ESCAPE then
    Close
  else if Key = VK_F12 then
  begin
    Application.CreateForm(TFrmLogAssinaturaCliente, FrmLogAssinaturaCliente);
    FrmLogAssinaturaCliente.FCodigoCliente := iCodigoCliente;
    FrmLogAssinaturaCliente.ShowModal;
  end;
end;

procedure TFrmPlanosCliente.FormKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    SelectNext(ActiveControl, True, True);
  end;
end;

procedure TFrmPlanosCliente.FormShow(Sender: TObject);
begin
  CheckValor.Checked := Trim(DM.LeIni('command.ini', 'ConfiguracaoLocal',
    'FrmPlanosCliente.CheckValor')) = 'S';
  PnCliente.Caption := iCodigoCliente.ToString + ' - ' + sNomeCliente;

  BuscarPlanos;
  CalcularTotal(False);
  FValorAssinaturaOld := EdtValorAssinatura.Value;

  GPlanos.Setfocus;
end;

procedure TFrmPlanosCliente.GPlanosDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  bModulo: Boolean;
begin
  if not AViewInfo.Selected then
  begin
    if MTPlanosID.AsInteger > 0 then
    begin
      if (AViewInfo.Item.Index >= 0) then
      begin
        if (AViewInfo.Item.Index = GPlanosDBTableViewVALOR_TOTAL.Index) then
          ACanvas.Font.Style := [fsBold];

        try
          bModulo := VarAsType(GPlanosDBTableView.ViewData.Records[AViewInfo.GridRecord.Index]
            .Values[GPlanosDBTableViewMODULO.Index], varBoolean);
        except
          bModulo := True;
        end;

        if not bModulo then
          ACanvas.Font.Color := clBlue;

        if (AViewInfo.Item.Index = GPlanosDBTableViewQTD.Index) or
          (AViewInfo.Item.Index = GPlanosDBTableViewQTD_LIBERADA.Index) or
          (AViewInfo.Item.Index = GPlanosDBTableViewVALOR.Index) then
        begin
          ACanvas.Brush.Color := $00FFF5E1;

          if bModulo then
            ACanvas.Font.Color := clBlack;
        end;
      end;
    end;
  end;
end;

procedure TFrmPlanosCliente.GPlanosDBTableViewEditKeyDown(Sender: TcxCustomGridTableView;
  AItem: TcxCustomGridTableItem; AEdit: TcxCustomEdit; var Key: Word; Shift: TShiftState);
begin
  FormKeyDown(Sender, Key, Shift);
end;

procedure TFrmPlanosCliente.GPlanosDBTableViewKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  FormKeyDown(Sender, Key, Shift);
end;

procedure TFrmPlanosCliente.GPlanosDBTableViewQTDPropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
var
  sDescTempo: String;
begin
  MTPlanos.DisableControls;
  MTPlanos.Edit;
  DisplayValue := Coalesce(DisplayValue, 0);

  try
    if DisplayValue < 0 then
    begin
      ShowMessage('a quantidade n�o pode ser menor que zero!');
      DisplayValue := MTPlanosQTD.OldValue;
    end
    else if not MTPlanosMODULO.AsBoolean then
    begin
      if DisplayValue > 1 then
        DisplayValue := 1;

      if MTPlanosQTD.OldValue = DisplayValue then
        exit;

      if DisplayValue <= 0 then
      begin
        MTPlanosSELEC.AsBoolean := False;
        bPossuiPlano := False;

        if iQuantidadeMinimaMesesAlterarPlano > 0 then
          if MonthsBetween(Now, dDataPlanoCliente) <= iQuantidadeMinimaMesesAlterarPlano then
          begin
            if iQuantidadeMinimaMesesAlterarPlano - MonthsBetween(Now, dDataPlanoCliente) <= 0 then
              sDescTempo := '1 m�s'
            else if iQuantidadeMinimaMesesAlterarPlano - MonthsBetween(Now, dDataPlanoCliente) = 1
            then
              sDescTempo := '1 m�s'
            else
              sDescTempo := (iQuantidadeMinimaMesesAlterarPlano - MonthsBetween(Now,
                dDataPlanoCliente)).ToString + ' meses';

            ShowMessage('Voc� s� poder� voltar para um plano menor daqui a ' + sDescTempo);

            MTPlanosSELEC.AsBoolean := True;
            bPossuiPlano := True;
            DisplayValue := 1;
          end;
      end
      else
      begin
        if bPossuiPlano then
        begin
          MTPlanosSELEC.AsBoolean := False;
          DisplayValue := 0;
          ShowMessage
            ('Este cliente j� possui um plano! Por favor, desmarque um plano para marcar outro.');
        end
        else
        begin
          MTPlanosSELEC.AsBoolean := True;
          bPossuiPlano := True;
        end;
      end;
    end
    else
    begin
      if DisplayValue <= 0 then
        MTPlanosSELEC.AsBoolean := False
      else
        MTPlanosSELEC.AsBoolean := True;
    end;
  finally
    MTPlanosQTD.AsCurrency := DisplayValue;

    QAux.Close;
    QAux.SQL.Clear;
    QAux.SQL.Text := 'select valor, (select vqp.valor from valores_qtd_plano vqp where ' +
      'vqp.id_plano = :id_plano and :qtd between vqp.qtd_ini and vqp.qtd_fin order by ' +
      'vqp.id desc limit 1) valor_qtd from planos where id = :id_plano';
    QAux.ParamByName('id_plano').AsInteger := MTPlanosID.AsInteger;
    QAux.ParamByName('qtd').AsInteger := MTPlanosQTD.AsInteger - MTPlanosQTD_LIBERADA.AsInteger;
    QAux.Open;

    if QAux.FieldByName('valor_qtd').AsCurrency > 0 then
      MTPlanosVALOR.AsCurrency := QAux.FieldByName('valor_qtd').AsCurrency
    else
      MTPlanosVALOR.AsCurrency := QAux.FieldByName('valor').AsCurrency;

    QAux.Close;

    if MTPlanosQTD.AsInteger < MTPlanosQTD_LIBERADA.AsInteger then
      MTPlanosVALOR_TOTAL.AsCurrency := 0
    else
      MTPlanosVALOR_TOTAL.AsCurrency := (MTPlanosQTD.AsInteger - MTPlanosQTD_LIBERADA.AsInteger) *
        MTPlanosVALOR.AsCurrency;

    MTPlanos.Post;
    MTPlanos.EnableControls;

    CalcularTotal;
  end;
end;

procedure TFrmPlanosCliente.GPlanosDBTableViewQTD_LIBERADAPropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
var
  sDescTempo: String;
begin
  MTPlanos.DisableControls;
  MTPlanos.Edit;
  DisplayValue := Coalesce(DisplayValue, 0);

  if (not MTPlanosMODULO.AsBoolean) and (DisplayValue > 0) then
  begin
    ShowMessage('a quantidade liberada gr�tis n�o pode ser aplicada para planos!');
    DisplayValue := 0;
    MTPlanosQTD_LIBERADA.AsCurrency := DisplayValue;
    MTPlanos.Post;
    MTPlanos.EnableControls;
    exit;
  end;

  try
    if DisplayValue < 0 then
    begin
      ShowMessage('a quantidade liberada gr�tis n�o pode ser menor que zero!');
      DisplayValue := MTPlanosQTD_LIBERADA.OldValue;
    end
  finally
    MTPlanosQTD_LIBERADA.AsCurrency := DisplayValue;

    QAux.Close;
    QAux.SQL.Clear;
    QAux.SQL.Text := 'select valor, (select vqp.valor from valores_qtd_plano vqp where ' +
      'vqp.id_plano = :id_plano and :qtd between vqp.qtd_ini and vqp.qtd_fin order by ' +
      'vqp.id desc limit 1) valor_qtd from planos where id = :id_plano';
    QAux.ParamByName('id_plano').AsInteger := MTPlanosID.AsInteger;
    QAux.ParamByName('qtd').AsInteger := MTPlanosQTD.AsInteger - MTPlanosQTD_LIBERADA.AsInteger;
    QAux.Open;

    if QAux.FieldByName('valor_qtd').AsCurrency > 0 then
      MTPlanosVALOR.AsCurrency := QAux.FieldByName('valor_qtd').AsCurrency
    else
      MTPlanosVALOR.AsCurrency := QAux.FieldByName('valor').AsCurrency;

    QAux.Close;

    if MTPlanosQTD.AsInteger < MTPlanosQTD_LIBERADA.AsInteger then
      MTPlanosVALOR_TOTAL.AsCurrency := 0
    else
      MTPlanosVALOR_TOTAL.AsCurrency := (MTPlanosQTD.AsInteger - MTPlanosQTD_LIBERADA.AsInteger) *
        MTPlanosVALOR.AsCurrency;

    MTPlanos.Post;
    MTPlanos.EnableControls;

    CalcularTotal;
  end;
end;

procedure TFrmPlanosCliente.GPlanosDBTableViewSELECPropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
var
  sDescTempo: String;
  LCodigo: Integer;
begin
  if (not MTPlanosMODULO.AsBoolean) then
  begin
    if DisplayValue then
    begin
      if bPossuiPlano then
      begin
        ShowMessage
          ('Este cliente j� possui um plano! Por favor, desmarque um plano para marcar outro.');

        DisplayValue := False;

        MTPlanos.Edit;
        MTPlanosSELEC.AsBoolean := False;
        MTPlanos.Post;

        exit;
      end;
    end
    else
    begin
      if iQuantidadeMinimaMesesAlterarPlano > 0 then
        if MonthsBetween(Now, dDataPlanoCliente) <= iQuantidadeMinimaMesesAlterarPlano then
        begin
          if iQuantidadeMinimaMesesAlterarPlano - MonthsBetween(Now, dDataPlanoCliente) <= 0 then
            sDescTempo := '1 m�s'
          else if iQuantidadeMinimaMesesAlterarPlano - MonthsBetween(Now, dDataPlanoCliente) = 1
          then
            sDescTempo := '1 m�s'
          else
            sDescTempo := (iQuantidadeMinimaMesesAlterarPlano - MonthsBetween(Now,
              dDataPlanoCliente)).ToString + ' meses';

          ShowMessage('Voc� s� poder� voltar para um plano menor daqui a ' + sDescTempo);

          DisplayValue := True;

          MTPlanos.Edit;
          MTPlanosSELEC.AsBoolean := True;
          MTPlanos.Post;

          exit;
        end;
    end;

    bPossuiPlano := DisplayValue;
  end;

  if DisplayValue then
  begin
    MTPlanos.Edit;
    MTPlanosSELEC.AsBoolean := True;
    MTPlanosQTD.AsInteger := 1;
    MTPlanosVALOR_TOTAL.AsCurrency := MTPlanosVALOR.AsCurrency;
    MTPlanos.Post;

    if MTPlanosTAMANHO_MAX_NUVEM.AsInteger > 0 then
    begin
      with QAux do
      begin
        Close;
        SQL.Clear;
        SQL.Text := 'select cp.id_plano from cliente_planos cp ' +
          'inner join planos p on (cp.id_plano = p.id) where cp.id_cli = ' + iCodigoCliente.ToString
          + ' and p.modulo = true and p.tamanho_max_nuvem > 0 limit 1';
        Open;

        if FieldByName('id_plano').AsInteger <= 0 then
        begin
          LCodigo := MTPlanosID.AsInteger;

          MTPlanos.DisableControls;

          try
            MTPlanos.First;

            while not MTPlanos.Eof do
            begin
              if (not MTPlanosSELEC.AsBoolean) and (MTPlanosMODULO.AsBoolean) and
                (MTPlanosQTD_GRATIS.AsInteger > 0) then
              begin
                MTPlanos.Edit;
                MTPlanosSELEC.AsBoolean := True;
                MTPlanosQTD.AsInteger := MTPlanosQTD_GRATIS.AsInteger;
                MTPlanosVALOR.AsCurrency := 0;
                MTPlanosVALOR_TOTAL.AsCurrency := 0;
                MTPlanos.Post;
              end;

              MTPlanos.Next;
            end;
          finally
            MTPlanos.Locate('ID', LCodigo, []);
            MTPlanos.EnableControls;
          end;
        end;
      end;
    end;
  end
  else
  begin
    MTPlanos.Edit;
    MTPlanosSELEC.AsBoolean := False;
    MTPlanosQTD.AsInteger := 0;
    MTPlanosQTD_LIBERADA.AsInteger := 0;
    MTPlanosVALOR_TOTAL.AsCurrency := 0;
    MTPlanos.Post;
  end;

  CalcularTotal;
end;

procedure TFrmPlanosCliente.GPlanosDBTableViewVALORPropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
begin
  MTPlanos.DisableControls;
  MTPlanos.Edit;
  DisplayValue := Coalesce(DisplayValue, 0);

  try
    if DisplayValue < 0 then
    begin
      ShowMessage('o valor n�o pode ser menor ou igual a zero!');
      DisplayValue := MTPlanosVALOR.OldValue;
    end;
  finally
    MTPlanosVALOR.AsCurrency := DisplayValue;

    if MTPlanosQTD.AsInteger < MTPlanosQTD_LIBERADA.AsInteger then
      MTPlanosVALOR_TOTAL.AsCurrency := 0
    else
      MTPlanosVALOR_TOTAL.AsCurrency := (MTPlanosQTD.AsInteger - MTPlanosQTD_LIBERADA.AsInteger) *
        MTPlanosVALOR.AsCurrency;

    MTPlanos.Post;
    MTPlanos.EnableControls;

    CalcularTotal;
  end;
end;

procedure TFrmPlanosCliente.GPlanosEnter(Sender: TObject);
begin
  KeyPreview := False;
end;

procedure TFrmPlanosCliente.GPlanosExit(Sender: TObject);
begin
  KeyPreview := True;
end;

procedure TFrmPlanosCliente.InserirLog;
var
  LCodigoPlanoAnterior: Integer;
  LValorPlanoAnterior: Currency;
  LCodigoPlanoAtual: Integer;
  LValorPlanoAtual: Currency;
begin
  // Busca como esta atualmente os planos e modulos
  QPlanosOld.Close;
  QPlanosOld.ParamByName('ID_CLI').AsInteger := iCodigoCliente;
  QPlanosOld.Open;
  QPlanosOld.Last;
  QPlanosOld.First;

  MTPlanosOld.Open;

  try
    MTPlanosOld.EmptyDataSet;

    while not QPlanosOld.Eof do
    begin
      MTPlanosOld.Append;
      MTPlanosOldid_plano.AsInteger := QPlanosOld.FieldByName('id_plano').AsInteger;
      MTPlanosOldmodulo.AsBoolean := QPlanosOld.FieldByName('modulo').AsBoolean;
      MTPlanosOldqtd.AsInteger := QPlanosOld.FieldByName('qtd').AsInteger;
      MTPlanosOldvalor_total.AsCurrency := QPlanosOld.FieldByName('valor_total').AsCurrency;
      MTPlanosOldvalor.AsCurrency := QPlanosOld.FieldByName('valor').AsCurrency;
      MTPlanosOldalterado.AsBoolean := False;
      MTPlanosOldremovido.AsBoolean := False;
      MTPlanosOld.Post;

      QPlanosOld.Next;
    end;
  finally
    QPlanosOld.Close;

    MTPlanosOld.First;
  end;

  // Pega os novos planos e modulos
  MTPlanosNew.Open;
  MTPlanos.DisableControls;
  MTPlanos.First;

  try
    MTPlanosNew.EmptyDataSet;

    while not MTPlanos.Eof do
    begin
      if MTPlanosSELEC.AsBoolean then
      begin
        MTPlanosNew.Append;
        MTPlanosNewid_plano.AsInteger := MTPlanosID.AsInteger;
        MTPlanosNewmodulo.AsBoolean := MTPlanosMODULO.AsBoolean;
        MTPlanosNewqtd.AsInteger := MTPlanosQTD.AsInteger;
        MTPlanosNewvalor_total.AsCurrency := MTPlanosVALOR_TOTAL.AsCurrency;
        MTPlanosNewvalor.AsCurrency := MTPlanosVALOR.AsCurrency;
        MTPlanosNewincluido.AsBoolean := False;
        MTPlanosNew.Post;
      end;

      MTPlanos.Next;
    end;
  finally
    MTPlanosNew.First;

    MTPlanos.First;
    MTPlanos.EnableControls;
  end;

  //
  //
  // Tratar inclus�o, altera��o e remo��o de plano
  //
  //

  LCodigoPlanoAnterior := 0;
  LValorPlanoAnterior := 0;
  MTPlanosOld.First;

  while not MTPlanosOld.Eof do
  begin
    if not MTPlanosOldmodulo.AsBoolean then
    begin
      LCodigoPlanoAnterior := MTPlanosOldid_plano.AsInteger;
      LValorPlanoAnterior := MTPlanosOldvalor.AsCurrency;
      break;
    end;

    MTPlanosOld.Next;
  end;

  LCodigoPlanoAtual := 0;
  LValorPlanoAtual := 0;
  MTPlanosNew.First;

  while not MTPlanosNew.Eof do
  begin
    if not MTPlanosNewmodulo.AsBoolean then
    begin
      LCodigoPlanoAtual := MTPlanosNewid_plano.AsInteger;
      LValorPlanoAtual := MTPlanosNewvalor.AsCurrency;
      break;
    end;

    MTPlanosNew.Next;
  end;

  if (LCodigoPlanoAnterior <= 0) and (LCodigoPlanoAtual > 0) then // Inclusao de plano
  begin
    QLog.Close;
    QLog.ParamByName('id_cli').AsInteger := iCodigoCliente;
    QLog.ParamByName('tipo').AsInteger := 0;
    QLog.ParamByName('nome_usuario').asstring := DM.snomeusu;
    QLog.ParamByName('id_usu').AsInteger := DM.icodusu;
    QLog.ParamByName('id_plano_anterior').Value := Null;
    QLog.ParamByName('qtd_plano_anterior').AsInteger := 0;
    QLog.ParamByName('valor_plano_anterior').AsCurrency := 0;
    QLog.ParamByName('valor_total_plano_anterior').AsCurrency := 0;
    QLog.ParamByName('valor_assinatura_anterior').AsCurrency := FValorAssinaturaOld;
    QLog.ParamByName('id_plano_atual').AsInteger := LCodigoPlanoAtual;
    QLog.ParamByName('qtd_plano_atual').AsInteger := 1;
    QLog.ParamByName('valor_plano_atual').AsCurrency := LValorPlanoAtual;
    QLog.ParamByName('valor_total_plano_atual').AsCurrency := LValorPlanoAtual;
    QLog.ParamByName('valor_assinatura_atual').AsCurrency := EdtValorAssinatura.Value;
    QLog.ExecSQL;
  end
  else if (LCodigoPlanoAnterior > 0) and (LCodigoPlanoAtual <= 0) then // Remo��o de plano
  begin
    QLog.Close;
    QLog.ParamByName('id_cli').AsInteger := iCodigoCliente;
    QLog.ParamByName('tipo').AsInteger := 2;
    QLog.ParamByName('nome_usuario').asstring := DM.snomeusu;
    QLog.ParamByName('id_usu').AsInteger := DM.icodusu;
    QLog.ParamByName('id_plano_anterior').Value := LCodigoPlanoAnterior;
    QLog.ParamByName('qtd_plano_anterior').AsInteger := 1;
    QLog.ParamByName('valor_plano_anterior').AsCurrency := LValorPlanoAnterior;
    QLog.ParamByName('valor_total_plano_anterior').AsCurrency := LValorPlanoAnterior;
    QLog.ParamByName('valor_assinatura_anterior').AsCurrency := FValorAssinaturaOld;
    QLog.ParamByName('id_plano_atual').Value := Null;
    QLog.ParamByName('qtd_plano_atual').AsInteger := 0;
    QLog.ParamByName('valor_plano_atual').AsCurrency := 0;
    QLog.ParamByName('valor_total_plano_atual').AsCurrency := 0;
    QLog.ParamByName('valor_assinatura_atual').AsCurrency := EdtValorAssinatura.Value;
    QLog.ExecSQL;
  end
  else if ((LCodigoPlanoAnterior > 0) and (LCodigoPlanoAtual > 0)) and
    (LValorPlanoAnterior <> LValorPlanoAtual) then // Altera��o de plano
  begin
    QLog.Close;
    QLog.ParamByName('id_cli').AsInteger := iCodigoCliente;
    QLog.ParamByName('tipo').AsInteger := 1;
    QLog.ParamByName('nome_usuario').asstring := DM.snomeusu;
    QLog.ParamByName('id_usu').AsInteger := DM.icodusu;
    QLog.ParamByName('id_plano_anterior').Value := LCodigoPlanoAnterior;
    QLog.ParamByName('qtd_plano_anterior').AsInteger := 1;
    QLog.ParamByName('valor_plano_anterior').AsCurrency := LValorPlanoAnterior;
    QLog.ParamByName('valor_total_plano_anterior').AsCurrency := LValorPlanoAnterior;
    QLog.ParamByName('valor_assinatura_anterior').AsCurrency := FValorAssinaturaOld;
    QLog.ParamByName('id_plano_atual').AsInteger := LCodigoPlanoAtual;
    QLog.ParamByName('qtd_plano_atual').AsInteger := 1;
    QLog.ParamByName('valor_plano_atual').AsCurrency := LValorPlanoAtual;
    QLog.ParamByName('valor_total_plano_atual').AsCurrency := LValorPlanoAtual;
    QLog.ParamByName('valor_assinatura_atual').AsCurrency := EdtValorAssinatura.Value;
    QLog.ExecSQL;
  end;

  //
  //
  // Tratar inclus�o, altera��o e remo��o de modulos
  //
  //

  // Verifica se teve modulo que foi removido ou alterado
  MTPlanosOld.First;

  while not MTPlanosOld.Eof do
  begin
    if MTPlanosOldmodulo.AsBoolean then
      if not MTPlanosNew.Locate('id_plano', MTPlanosOldid_plano.AsInteger, []) then
      begin
        MTPlanosOld.Edit;
        MTPlanosOldremovido.AsBoolean := True;
        MTPlanosOld.Post;
      end
      else if (MTPlanosNewqtd.AsInteger <> MTPlanosOldqtd.AsInteger) or
        (MTPlanosNewvalor_total.AsCurrency <> MTPlanosOldvalor_total.AsCurrency) or
        (MTPlanosNewvalor.AsCurrency <> MTPlanosOldvalor.AsCurrency) then
      begin
        MTPlanosOld.Edit;
        MTPlanosOldalterado.AsBoolean := True;
        MTPlanosOld.Post;
      end;

    MTPlanosOld.Next;
  end;

  // Verifica se teve modulo que foi incluido
  MTPlanosNew.First;

  while not MTPlanosNew.Eof do
  begin
    if MTPlanosNewmodulo.AsBoolean then
      if not MTPlanosOld.Locate('id_plano', MTPlanosNewid_plano.AsInteger, []) then
      begin
        MTPlanosNew.Edit;
        MTPlanosNewincluido.AsBoolean := True;
        MTPlanosNew.Post;
      end;

    MTPlanosNew.Next;
  end;

  // Insere log dos modulos incluidos
  MTPlanosNew.First;

  while not MTPlanosNew.Eof do
  begin
    if MTPlanosNewmodulo.AsBoolean then
      if MTPlanosNewincluido.AsBoolean then
      begin
        QLog.Close;
        QLog.ParamByName('id_cli').AsInteger := iCodigoCliente;
        QLog.ParamByName('tipo').AsInteger := 0;
        QLog.ParamByName('nome_usuario').asstring := DM.snomeusu;
        QLog.ParamByName('id_usu').AsInteger := DM.icodusu;
        QLog.ParamByName('id_plano_anterior').Value := Null;
        QLog.ParamByName('qtd_plano_anterior').AsInteger := 0;
        QLog.ParamByName('valor_plano_anterior').AsCurrency := 0;
        QLog.ParamByName('valor_total_plano_anterior').AsCurrency := 0;
        QLog.ParamByName('valor_assinatura_anterior').AsCurrency := FValorAssinaturaOld;
        QLog.ParamByName('id_plano_atual').AsInteger := MTPlanosNewid_plano.AsInteger;
        QLog.ParamByName('qtd_plano_atual').AsInteger := MTPlanosNewqtd.AsInteger;
        QLog.ParamByName('valor_plano_atual').AsCurrency := MTPlanosNewvalor.AsCurrency;
        QLog.ParamByName('valor_total_plano_atual').AsCurrency := MTPlanosNewvalor_total.AsCurrency;
        QLog.ParamByName('valor_assinatura_atual').AsCurrency := EdtValorAssinatura.Value;
        QLog.ExecSQL;
      end;

    MTPlanosNew.Next;
  end;

  // Insere log dos modulos alterados ou removidos
  MTPlanosOld.First;

  while not MTPlanosOld.Eof do
  begin
    if MTPlanosOldmodulo.AsBoolean then
      if MTPlanosOldalterado.AsBoolean then
      begin
        MTPlanosNew.Locate('id_plano', MTPlanosOldid_plano.AsInteger, []);

        QLog.Close;
        QLog.ParamByName('id_cli').AsInteger := iCodigoCliente;
        QLog.ParamByName('tipo').AsInteger := 1;
        QLog.ParamByName('nome_usuario').asstring := DM.snomeusu;
        QLog.ParamByName('id_usu').AsInteger := DM.icodusu;
        QLog.ParamByName('id_plano_anterior').Value := MTPlanosOldid_plano.AsInteger;
        QLog.ParamByName('qtd_plano_anterior').AsInteger := MTPlanosOldqtd.AsInteger;
        QLog.ParamByName('valor_plano_anterior').AsCurrency := MTPlanosOldvalor.AsCurrency;
        QLog.ParamByName('valor_total_plano_anterior').AsCurrency :=
          MTPlanosOldvalor_total.AsCurrency;
        QLog.ParamByName('valor_assinatura_anterior').AsCurrency := FValorAssinaturaOld;
        QLog.ParamByName('id_plano_atual').AsInteger := MTPlanosNewid_plano.AsInteger;
        QLog.ParamByName('qtd_plano_atual').AsInteger := MTPlanosNewqtd.AsInteger;
        QLog.ParamByName('valor_plano_atual').AsCurrency := MTPlanosNewvalor.AsCurrency;
        QLog.ParamByName('valor_total_plano_atual').AsCurrency := MTPlanosNewvalor_total.AsCurrency;
        QLog.ParamByName('valor_assinatura_atual').AsCurrency := EdtValorAssinatura.Value;
        QLog.ExecSQL;
      end
      else if MTPlanosOldremovido.AsBoolean then
      begin
        MTPlanosNew.Locate('id_plano', MTPlanosOldid_plano.AsInteger, []);

        QLog.Close;
        QLog.ParamByName('id_cli').AsInteger := iCodigoCliente;
        QLog.ParamByName('tipo').AsInteger := 2;
        QLog.ParamByName('nome_usuario').asstring := DM.snomeusu;
        QLog.ParamByName('id_usu').AsInteger := DM.icodusu;
        QLog.ParamByName('id_plano_anterior').Value := MTPlanosOldid_plano.AsInteger;
        QLog.ParamByName('qtd_plano_anterior').AsInteger := MTPlanosOldqtd.AsInteger;
        QLog.ParamByName('valor_plano_anterior').AsCurrency := MTPlanosOldvalor.AsCurrency;
        QLog.ParamByName('valor_total_plano_anterior').AsCurrency :=
          MTPlanosOldvalor_total.AsCurrency;
        QLog.ParamByName('valor_assinatura_anterior').AsCurrency := FValorAssinaturaOld;
        QLog.ParamByName('id_plano_atual').Value := Null;
        QLog.ParamByName('qtd_plano_atual').AsInteger := 0;
        QLog.ParamByName('valor_plano_atual').AsCurrency := 0;
        QLog.ParamByName('valor_total_plano_atual').AsCurrency := 0;
        QLog.ParamByName('valor_assinatura_atual').AsCurrency := EdtValorAssinatura.Value;
        QLog.ExecSQL;
      end;

    MTPlanosOld.Next;
  end;
end;

procedure TFrmPlanosCliente.V1Click(Sender: TObject);
begin
  if MTPlanos.isempty then
    exit;

  if MTPlanosMODULO.AsBoolean then
  begin
    ShowMessage('o registro selecionado n�o � um plano!');
    exit;
  end;

  Application.CreateForm(TFrmFuncionalidadesPlano, FrmFuncionalidadesPlano);
  FrmFuncionalidadesPlano.IDPlano := MTPlanosID.AsInteger;
  FrmFuncionalidadesPlano.ShowModal;

  GPlanos.Setfocus;
end;

procedure TFrmPlanosCliente.V2Click(Sender: TObject);
begin
  if MTPlanos.isempty then
    exit;

  if MTPlanosMODULO.AsBoolean then
  begin
    ShowMessage('o registro selecionado n�o � um plano!');
    exit;
  end;

  Application.CreateForm(TFrmValoresPlanoAtualPlano, FrmValoresPlanoAtualPlano);
  FrmValoresPlanoAtualPlano.IDPlano := MTPlanosID.AsInteger;
  FrmValoresPlanoAtualPlano.ShowModal;

  GPlanos.Setfocus;
end;

end.
