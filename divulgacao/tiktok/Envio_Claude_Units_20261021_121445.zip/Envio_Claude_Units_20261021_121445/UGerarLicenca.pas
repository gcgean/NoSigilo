unit UGerarLicenca;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Data.DB, cxGraphics, cxControls,
  cxLookAndFeels, System.StrUtils,
  cxLookAndFeelPainters, cxContainer, cxEdit, Vcl.ComCtrls, dxCore, cxDateUtils, Vcl.StdCtrls,
  cxTextEdit, cxMaskEdit,
  cxDropDownEdit, cxCalendar, Vcl.Grids, Vcl.DBGrids, FireDAC.Stan.Intf, FireDAC.Stan.Option,
  FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async,
  FireDAC.DApt,
  FireDAC.Comp.DataSet, FireDAC.Comp.Client;

type
  TFrmGerarLicenca = class(TForm)
    Panel1: TPanel;
    DBGrid1: TDBGrid;
    EdtQuant: TLabeledEdit;
    CheckValidade: TCheckBox;
    EdtValidade: TcxDateEdit;
    Label1: TLabel;
    BtnChave: TButton;
    MemoChave: TMemo;
    Label2: TLabel;
    QSistema: TFDQuery;
    QSistemaid: TFDAutoIncField;
    QSistemadescricao: TStringField;
    DSSistema: TDataSource;
    QChave: TFDQuery;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure FormShow(Sender: TObject);
    procedure BtnChaveClick(Sender: TObject);
  private
    function RemoveChar(const Texto: string): string;
    function RemoveCharTudo(const Texto: string): string;
    function Crypt(Action, Src: String): String;
    function PreencheStringEsquerda(Text, Complemento: string; Tamanho: Integer): string;
  public
    { Public declarations }
  end;

var
  FrmGerarLicenca: TFrmGerarLicenca;

implementation

uses
  udm, umonitorclientes;

{$R *.dfm}

procedure TFrmGerarLicenca.BtnChaveClick(Sender: TObject);
var
  sCNPJ: String;
  sChave: String;
begin
  if QSistema.isempty then
    exit;

  if CheckValidade.Checked then
    if trim(EdtValidade.Text) = '' then
    begin
      showmessage('Informe a validade!');
      EdtValidade.setfocus;
      exit;
    end;

  sCNPJ := trim(RemoveCharTudo(frmMonitorClientes.FDQClientesContadorCNPJ_CLI.AsString));

  sChave := '';
  sChave := Crypt('C', trim(PreencheStringEsquerda(sCNPJ, '0', 14) +
    PreencheStringEsquerda(inttostr(strtointdef(EdtQuant.Text, 0)), '0',
    3) + ifthen(CheckValidade.Checked, trim(formatdatetime('ddmm', EdtValidade.date) +
    copy(formatdatetime('yyyy', EdtValidade.date), 3, 2)), '000000') +
    PreencheStringEsquerda(inttostr(QSistemaid.asinteger), '0', 2)));
  sChave := trim(sChave);

  MemoChave.Text := sChave;

  with QChave do
  begin
    close;
    sql.clear;
    sql.Text := 'DELETE FROM licencas WHERE cnpj = :cnpj AND sistema_id = :sistemaid';
    ParamByName('cnpj').AsString := Trim(frmMonitorClientes.FDQClientesContadorCNPJ_CLI.AsString);
    ParamByName('sistemaid').asinteger := QSistemaid.asinteger;
    ExecSQL;
  end;

  with QChave do
  begin
    close;
    sql.clear;
    sql.Text := 'INSERT INTO licencas(chave, sistema_id, cnpj, num_maquinas, ';

    if CheckValidade.Checked then
      sql.add('vencimento,');

    sql.add('demo) VALUES (:chave, :sistemaid, :cnpj, :nummaq, ');

    if CheckValidade.Checked then
      sql.add(':venc, ');

    sql.add(':demo)');

    ParamByName('chave').AsString := sChave;
    ParamByName('sistemaid').asinteger := QSistemaid.asinteger;
    ParamByName('cnpj').AsString := Trim(frmMonitorClientes.FDQClientesContadorCNPJ_CLI.AsString);;
    ParamByName('nummaq').asinteger := strtointdef(EdtQuant.Text, 0);

    if CheckValidade.Checked then
      ParamByName('venc').AsDate := EdtValidade.date;

    ParamByName('demo').AsString := ifthen(CheckValidade.Checked, 'S', 'N');
    ExecSQL;
  end;

  EdtQuant.clear;
  CheckValidade.Checked := false;
  EdtValidade.clear;
  showmessage('Chave gerada com sucesso!');
end;

function TFrmGerarLicenca.Crypt(Action, Src: String): String;
Label Fim;
var
  KeyLen: Integer;
  KeyPos: Integer;
  OffSet: Integer;
  Dest, Key: String;
  SrcPos: Integer;
  SrcAsc: Integer;
  TmpSrcAsc: Integer;
  Range: Integer;
begin
  if (Src = '') Then
  begin
    Result := '';
    Goto Fim;
  end;
  Key := 'I21EFVBF165!9/ASD$WBKXCWSNAFS@7B21ASDF*11L*SIWGG1?H7K8K0 0JEBAIE!@#/BCY';
  Dest := '';
  KeyLen := Length(Key);
  KeyPos := 0;
  Range := 256;
  if (Action = UpperCase('C')) then
  begin
    Randomize;
    OffSet := Random(Range);
    Dest := format('%1.2x', [OffSet]);
    for SrcPos := 1 to Length(Src) do
    begin
      Application.ProcessMessages;
      SrcAsc := (Ord(Src[SrcPos]) + OffSet) Mod 255;
      if KeyPos < KeyLen then
        KeyPos := KeyPos + 1
      else
        KeyPos := 1;

      SrcAsc := SrcAsc Xor Ord(Key[KeyPos]);
      Dest := Dest + format('%1.2x', [SrcAsc]);
      OffSet := SrcAsc;
    end;
  end
  Else if (Action = UpperCase('D')) then
  begin
    OffSet := StrToInt('$' + copy(Src, 1, 2));
    // <--------------- adiciona o $ entra as aspas simples
    SrcPos := 3;
    repeat
      SrcAsc := StrToInt('$' + copy(Src, SrcPos, 2));
      // <--------------- adiciona o $ entra as aspas simples
      if (KeyPos < KeyLen) Then
        KeyPos := KeyPos + 1
      else
        KeyPos := 1;
      TmpSrcAsc := SrcAsc Xor Ord(Key[KeyPos]);
      if TmpSrcAsc <= OffSet then
        TmpSrcAsc := 255 + TmpSrcAsc - OffSet
      else
        TmpSrcAsc := TmpSrcAsc - OffSet;
      Dest := Dest + Chr(TmpSrcAsc);
      OffSet := SrcAsc;
      SrcPos := SrcPos + 2;
    until (SrcPos >= Length(Src));
  end;
  Result := Dest;
Fim:
end;

procedure TFrmGerarLicenca.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
end;

procedure TFrmGerarLicenca.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key = VK_ESCAPE then
    close;
end;

procedure TFrmGerarLicenca.FormKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    SelectNext(ActiveControl, true, true);
  end;
end;

procedure TFrmGerarLicenca.FormShow(Sender: TObject);
begin
  QSistema.Open;
  QSistema.First;
  DBGrid1.setfocus;
end;

function TFrmGerarLicenca.PreencheStringEsquerda(Text, Complemento: string;
  Tamanho: Integer): string;
var
  X, Y: Integer;
begin
  Y := Length(Text);

  for X := Y to Tamanho do
  begin
    if (X <> Tamanho) then
      Text := Complemento + Text
    else
      Text := '' + Text;
  end;

  Result := Text;
end;

function TFrmGerarLicenca.RemoveChar(const Texto: string): string;
var
  I: Integer;
  s: string;
begin
  s := '';

  for I := 1 to Length(Texto) do
  begin
    if (CharInSet(Texto[I], ['0' .. '9'])) or (CharInSet(Texto[I], ['-', '.', '/'])) then
    begin
      s := s + copy(Texto, I, 1);
    end;
  end;

  Result := s;
end;

function TFrmGerarLicenca.RemoveCharTudo(const Texto: string): string;
var
  I: integer;
  s: string;
begin
  s := '';

  for I := 1 to Length(Texto) do
  begin
    if (CharInSet(Texto[I], ['0' .. '9'])) then
    begin
      s := s + copy(Texto, I, 1);
    end;
  end;

  Result := s;
end;

end.
