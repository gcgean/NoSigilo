unit UDM;

interface

uses
  System.SysUtils, cxGridExportLink, System.Classes, cxGrid, FireDAC.Stan.Intf,
  FireDAC.Stan.Option, ACBrUtil, System.DateUtils,
  IniFiles,
  FireDAC.Stan.Param, FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf,
  FireDAC.DApt.Intf, FireDAC.Stan.Async, FireDAC.DApt, FireDAC.UI.Intf,
  FireDAC.Stan.Def, FireDAC.Stan.Pool, FireDAC.Phys, FireDAC.Phys.PG,
  FireDAC.Phys.PGDef, FireDAC.VCLUI.Wait, FireDAC.Comp.UI, FireDAC.Comp.Client,
  Data.DB, FireDAC.Comp.DataSet, Winsock, ClipBrd, Winapi.Windows,
  Winapi.Messages,
  System.Variants, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ComCtrls, Vcl.ExtCtrls,
  FireDAC.Phys.MySQL, FireDAC.Phys.MySQLDef, FireDAC.Phys.FB,
  FireDAC.Phys.FBDef, FireDAC.Phys.IBBase, System.Notification, cxStyles,
  cxClasses, UPlataformaContador, cxGridDBTableView, frxExportPDF, frxExportXLS,
  frxClass, frxExportBaseDialog, frxExportDOCX, RLPDFFilter, RLFilters,
  RLXLSFilter, dxPSGlbl, dxPSUtl, dxPSEngn, dxPrnPg, dxBkgnd, dxWrap, dxPrnDev,
  dxPSCompsProvider, dxPSFillPatterns, dxPSEdgePatterns, dxPSPDFExportCore,
  dxPSPDFExport, cxDrawTextUtils, dxPSPrVwStd, dxPSPrVwAdv, dxPSPrVwRibbon,
  dxPScxPageControlProducer, dxPScxGridLnk, dxPScxGridLayoutViewLnk,
  dxPScxEditorProducers, dxPScxExtEditorProducers, dxPSCore, dxPScxCommon,
  RestRequest4D, Rest.Types, System.JSON, View.WebCharts, Interfaces,
  charts.Types, ACBrBase, ACBrValidador, uImportExcel, cxLookAndFeelPainters,
  cxGraphics, dxAlertWindow, Vcl.Menus, UEnvioWhatsAppCommand;

type
  TDM = class(TDataModule)
    FDConexao: TFDConnection;
    FDGUIxWaitCursor1: TFDGUIxWaitCursor;
    FDPhysMySQLDriverLink1: TFDPhysMySQLDriverLink;
    FDPServer: TFDConnection;
    FDQAuxServer: TFDQuery;
    FDTAuxServer: TFDTransaction;
    FDPhysFBDriverLink1: TFDPhysFBDriverLink;
    FDQInsert: TFDQuery;
    FDTContatoCli: TFDTransaction;
    FDQContatoCli: TFDQuery;
    FDQContatoCliCODIGO: TIntegerField;
    FDQContatoCliCOD_CLI: TIntegerField;
    FDQContatoCliCOD_FOR: TIntegerField;
    FDQContatoCliDESCRICAO: TStringField;
    FDQContatoCliSETOR: TStringField;
    FDQContatoCliNUMERO: TStringField;
    FDQContatoCliCOD_AGENTE: TIntegerField;
    FDQContatoCliEMAIL: TStringField;
    FDQInsertFB: TFDQuery;
    IntegerField1: TIntegerField;
    IntegerField2: TIntegerField;
    IntegerField3: TIntegerField;
    StringField1: TStringField;
    StringField2: TStringField;
    StringField3: TStringField;
    IntegerField4: TIntegerField;
    StringField4: TStringField;
    FDTInsertFB: TFDTransaction;
    NotificationCenter1: TNotificationCenter;
    FDTMODULOSDisp: TFDTransaction;
    FDTModulosUtil: TFDTransaction;
    FDQModulosUtil: TFDQuery;
    FDQModulosDisp: TFDQuery;
    DsModulosDisp: TDataSource;
    DsModulosUtil: TDataSource;
    FDQModulosDispCOD_OP: TIntegerField;
    FDQModulosDispDESCRICAO: TStringField;
    FDQModulosUtilCOD_OP: TIntegerField;
    FDQModulosUtilDESCRICAO: TStringField;
    cxStyleRepository1: TcxStyleRepository;
    cxCinzaClaro: TcxStyle;
    cxBranco: TcxStyle;
    FDQConscontatoCli: TFDQuery;
    cxAzulClaro: TcxStyle;
    cxAzulMarinhoClaro: TcxStyle;
    cxVermelhoClaro: TcxStyle;
    cxVerdeClaro: TcxStyle;
    PDC: TPlataformaContador;
    FDQConsulta: TFDQuery;
    SaveDialogGrid: TSaveDialog;
    RLXLSFilter: TRLXLSFilter;
    RLPDFFilter: TRLPDFFilter;
    frxDOCXExport: TfrxDOCXExport;
    frxXLSExport1: TfrxXLSExport;
    frxPDFExport: TfrxPDFExport;
    CPPrinter: TdxComponentPrinter;
    DPrnLink: TdxGridReportLink;
    WebGrafMP: TWebCharts;
    CdsGraficMP: TFDMemTable;
    CdsGraficMPLabel: TStringField;
    CdsGraficMPValue: TStringField;
    CdsGraficMPRGB: TStringField;
    FDConexaoEmpAntiga: TFDConnection;
    QConsEmpAntiga: TFDQuery;
    QCertificadosMes: TFDQuery;
    QCertificadosMesID: TFDAutoIncField;
    QCertificadosMesRAZAO_EMP: TStringField;
    QCertificadosMesNOME_FANTASIA: TStringField;
    QCertificadosMesCIDADE: TStringField;
    QCertificadosMesTELEFONE: TStringField;
    QCertificadosMesCELULAR_CLI: TStringField;
    QCertificadosMesEMAIL_CLI: TStringField;
    QCertificadosMesCNPJ_CLI: TStringField;
    QCertificadosMesTIPO: TStringField;
    QCertificadosMesDATA_VAL_CERT_DIG: TDateField;
    QCertificadosMesDATA_SINCR_DADOS: TDateField;
    DSCertificadosMes: TDataSource;
    FDQConsAgendacod_agenda: TFDAutoIncField;
    FDQConsAgendadescricao: TStringField;
    FDQConsAgendacod_colaborador: TIntegerField;
    FDQConsAgendadata_agendamento: TDateField;
    FDQConsAgendadata_hora_lancamento: TDateTimeField;
    FDQConsAgendacod_usu_lanc: TIntegerField;
    FDQConsAgendahora_ini: TTimeField;
    FDQConsAgendahora_fin: TTimeField;
    FDQConsAgendacod_cli: TIntegerField;
    FDQConsAgendacod_ponto_revenda: TIntegerField;
    FDQConsAgendaNOME_CLI: TStringField;
    FDQConsAgendaNOME_FANTASIA: TStringField;
    FDQConsAgendaUsuLancamento: TStringField;
    FDQConsAgendaUsuColaborador: TStringField;
    FDQConsAgendadata_fin_agendamento: TDateField;
    FDQConsAgendaCIDRES_CLI: TStringField;
    DsConsAgenda: TDataSource;
    FDQConsAgendadia_semana: TStringField;
    ACBrValidador: TACBrValidador;
    QCertificadosMesCALC_DIA_CERT: TStringField;
    QCertificadosMesNOME_COMERCIAL: TStringField;
    QCertificadosMesTELEFONE_CONTADOR: TStringField;
    QCertificadosMesEMAIL: TStringField;
    QNPS: TFDQuery;
    QNPSMES: TIntegerField;
    QNPSANO: TIntegerField;
    QNPSSUPORTE: TBCDField;
    QNPSDESENVOLVIMENTO: TBCDField;
    CdsGraficMP02: TFDMemTable;
    StringField5: TStringField;
    StringField6: TStringField;
    StringField7: TStringField;
    QRecorrenciaMRR: TFDQuery;
    QContadorCliente: TFDQuery;
    DsContadorCliente: TDataSource;
    QContadorClienteCOD_CONTADOR: TIntegerField;
    QContadorClienteNOME_COMERCIAL: TStringField;
    QContadorClienteTELEFONE: TStringField;
    QContadorClienteDESCRICAO_ESCRITORIO: TStringField;
    QContadorClienteQTD: TLargeintField;
    ImportExcel: TImportExcel;
    OpDExcel: TOpenDialog;
    QConsFB: TFDQuery;
    QFDQConsulta2: TFDQuery;
    QFDQConsulta3: TFDQuery;
    NotificationCenter: TNotificationCenter;
    dxAlertWindowManager: TdxAlertWindowManager;
    FDQConsAgendaStatus_agendamento: TIntegerField;
    QContadorClienteEMAIL: TStringField;
    QContadorClienteTELEFONE_1: TStringField;
    QContadorClienteNOME_RESP: TStringField;
    QContadorClienteSISTEMA_CONTADOR: TStringField;
    FDQConsAgendaSomente_usuario_Visualizar: TStringField;
    CdsConsAgenda: TFDMemTable;
    CdsConsAgendadescricao: TStringField;
    CdsConsAgendacod_colaborador: TIntegerField;
    CdsConsAgendadata_agendamento: TDateField;
    CdsConsAgendadata_hora_lancamento: TDateTimeField;
    CdsConsAgendacod_usu_lanc: TIntegerField;
    CdsConsAgendahora_ini: TTimeField;
    CdsConsAgendahora_fin: TTimeField;
    CdsConsAgendacod_cli: TIntegerField;
    CdsConsAgendacod_ponto_revenda: TIntegerField;
    CdsConsAgendaNOME_CLI: TStringField;
    CdsConsAgendaNOME_FANTASIA: TStringField;
    CdsConsAgendaUsuLancamento: TStringField;
    CdsConsAgendaUsuColaborador: TStringField;
    CdsConsAgendadata_fin_agendamento: TDateField;
    CdsConsAgendaCIDRES_CLI: TStringField;
    CdsConsAgendadia_semana: TStringField;
    CdsConsAgendaStatus_agendamento: TIntegerField;
    CdsConsAgendaDESC_STATUS: TStringField;
    CdsConsAgendaSomente_usuario_Visualizar: TStringField;
    CdsConsAgendacod_agenda: TIntegerField;
    CdsGraficMP03: TFDMemTable;
    CdsGraficMP03Label: TStringField;
    CdsGraficMP03Value: TStringField;
    CdsGraficMP03RGB: TStringField;
    CdsGraficMP04: TFDMemTable;
    CdsGraficMP05: TFDMemTable;
    CdsGraficMP04Label: TStringField;
    CdsGraficMP04Value: TStringField;
    CdsGraficMP04RGB: TStringField;
    CdsGraficMP05Label: TStringField;
    CdsGraficMP05Value: TStringField;
    CdsGraficMP05RGB: TStringField;
    CdsGraficMP06: TFDMemTable;
    CdsGraficMP07: TFDMemTable;
    CdsGraficMP06Label: TStringField;
    CdsGraficMP06Value: TStringField;
    CdsGraficMP06RGB: TStringField;
    CdsGraficMP07Label: TStringField;
    CdsGraficMP07Value: TStringField;
    CdsGraficMP07RGB: TStringField;
    CdsGraficMP08: TFDMemTable;
    CdsGraficMP08Label: TStringField;
    CdsGraficMP08Value: TStringField;
    CdsGraficMP08RGB: TStringField;
    FDPhysPgDriverLink1: TFDPhysPgDriverLink;
    FDConexaoCommandZap: TFDConnection;
    FDConexaoCRM: TFDConnection;
    QConsultaPG: TFDQuery;
    QinsertPG: TFDQuery;
    QConsultaPG2: TFDQuery;
    FDQConsAgendaTipo: TStringField;
    FDQConsAgendaNota: TSingleField;
    FDQConsAgenda: TFDQuery;
    QContadorClienteEMAIL_ENVIO_ARQUIVOS: TStringField;
    QContadorClienteMELHOR_DIA_ENVIO_ARQUIVOS: TIntegerField;
    QContadorClienteUSA_PLATAFORMA_DO_CONTADOR: TStringField;
    QContadorClienteCPF_CONTADOR: TStringField;
    QContadorClienteCRC_CONTADOR: TStringField;
    PopContador: TPopupMenu;
    po: TMenuItem;
    FDQConsAgendaDESC_STATUS: TStringField;
    QConsFB2: TFDQuery;
    QContadorClienteCIDADE: TStringField;
    QConsultaPG3: TFDQuery;
    QConsultaPG4: TFDQuery;
    QConsultaCRM: TFDQuery;
    FDQConsAgendaSTATUS_INSTAL: TIntegerField;
    FDQConsAgendaCALC_STATUS_INSTAL: TStringField;
    CdsConsAgendaSTATUS_INSTAL: TIntegerField;
    CdsConsAgendaCALC_STATUS_INSTAL: TStringField;
    FDQConsAgendaid_telegram: TStringField;
    procedure ConectaBanco(const ABancoDados: Integer);
    procedure ConectaBancoChatBot;
    procedure ConectaBancoCRM;
    Function GetIP: string;
    function Mensagem(iTipoMensagem, iTag: Integer; sMensagem: string; sTitulo: string = '';
      sBotaoFoco: string = ''): boolean;
    Function LeIni(sArqIni: string; sSecao: string; sVariavel: string): string;
    procedure GravaIni(sArqIni: string; sSecao: string; sVariavel: string; sValor: string);
    procedure ConectaBancoFB(const ABancoDados: Integer);
    function FormataStringD(Valor, Tamanho, Complemento: string): string;
    procedure FDConexaoBeforeConnect(Sender: TObject);
    procedure GravaLogdoATendimento(Observacao: string; icod_atendimento, iUsu: Integer);
    function BuscaGrupoUsuario(icod_usu: Integer): Integer;
    procedure BuscaContatoCli(icodcli: Integer);
    procedure NotificationAtendimentos(iCodAtendimento: Integer; SName, sTutulo, SAlerta: string);
    procedure BuscaValorHoraExtra;
    procedure FDConexaoRecover(ASender, AInitiator: TObject; AException: Exception;
      var AAction: TFDPhysConnectionRecoverAction);
    function VerificaHoraExtra(Data: tdate; Hora: ttime): boolean;
    function FormataCNPJ(cnpj: string): string;
    function EliminaCaracter(stext: string): string;
    procedure AlterarStatusAtendimento(codAtendimento, codusu, CodStatus: Integer);
    PROCEDURE GeraGraficoNPS;
    procedure GeraLembretesAutomaticosViaAgendamento(icodusu: Integer);
    procedure InformarDesenvolvedor(codAtendimento, CodDesenvolvedor: Integer);
    procedure CopiarValorCelulaGrid(DBTableView: TcxGridDBTableView);
    procedure ExportarDadosGrid(Grid: TcxGrid);
    procedure ImprimirDadosGrid(Grid: TcxGrid; DBTableView: TcxGridDBTableView; title: string);
    function RetornaMesMaisAnoPorNumeroDias(idias: currency): string;
    procedure GeraGraficoVersoesGeral;
    procedure GeraGraficoVersaoLimoeiro;
    procedure GeraGraficoVersaoAracati;
    procedure GeraGraficosInstalacoes(qtdAguardInstalacao, EmInstalacao, AgendarTreinamento,
      ReagendarTreinamento, TreinamentoConcluido, Retorno, Testes, PosVenda, desistencia,
      AguardandoClienteParaInstalacao, AguardandoMigracao, PrimeiroTreinamento, SegundoTreinamento,
      EmMigracao, EmConferenciaMigracao: String);
    procedure GeraListagemCertificadoMes(Tipo: string);
    Procedure GeraGraficosCertificadosProxMeses(Tipo: string);
    procedure GraficoProcedimentos(cQtdClientesParaBaterMeta, idiasRestantesMeta, cPercAtigindo,
      cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta, cQtdClientesNovosMetaLimoeiro,
      cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara,
      cPercClientesNovosMetaAnoAnterior, cPercClientesPERDIDOSMetaAnoAnterior,
      CPercSaldoMetaAnoAnterior: string);
    procedure GraficoProcedimentosMes(cQtdClientesParaBaterMeta, idiasRestantesMeta, cPercAtigindo,
      cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta, cQtdClientesNovosMetaLimoeiro,
      cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara,
      cPercClientesNovosMetaAnoAnterior, cPercClientesPERDIDOSMetaAnoAnterior,
      CPercSaldoMetaAnoAnterior: string);
    procedure GraficoProcedimentosMesLimoeiro(cQtdClientesParaBaterMeta, idiasRestantesMeta,
      cPercAtigindo, cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta,
      cQtdClientesNovosMetaLimoeiro, cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara,
      cPercClientesNovosMetaAnoAnterior, cPercClientesPERDIDOSMetaAnoAnterior,
      CPercSaldoMetaAnoAnterior: string);
    procedure GraficoProcedimentosMesAracati(cQtdClientesParaBaterMeta, idiasRestantesMeta,
      cPercAtigindo, cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta,
      cQtdClientesNovosMetaLimoeiro, cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara,
      cPercClientesNovosMetaAnoAnterior, cPercClientesPERDIDOSMetaAnoAnterior,
      CPercSaldoMetaAnoAnterior: string);
    // fun��o que retorna o mes e o ano
    function mesAno(mes: Integer): string;
    // fun��o que retorna o dia da semana resumida
    function DiaSemanaResumida(dia: Integer): string;
    procedure FDQConsAgendaCalcFields(DataSet: TDataSet);
    procedure FDQConsAgendaAfterScroll(DataSet: TDataSet);
    procedure EnviaMSGWhatsappp(cod_usu: Integer; Mensagem1, Mensagem2: string);
    // Remover todos os caracteres de uma string, deixando apenas numeros
    function RemoveChar(const Texto: string): string;
    // Validar CPF
    function ValidaCPF(num: string): string;
    // Validar CNPJ
    function ValidaCNPJ(s: string): string;
    // VALIDA EMAIL
    function ValidaEmail(s: String): string;
    // Arredondar o valor para a casa decimal informada, seguindo as regras ABNT
    function ABNTRound(Valor: currency; CasasDecimais: Integer = 2): currency;

    function BuscaQtdClientesPeriodo(smes, sAno: String): string;

    procedure GeraGraficoIndiceEscalabilidadeSuporte;

    PROCEDURE GraficoReceitasGanhasXReceitasPerdidas(Ganho, Perdido: currency);
    // recebido em N casas decimal, retornando o valor exato.
    function ExatoCurrency(Value: currency; Decimal: Integer): currency;
    // converte minutos em horas
    function MinutosEmHoras(Minutos: Integer): String;
    procedure QCertificadosMesCalcFields(DataSet: TDataSet);
    function BuscaPlanoPrincipalCliente(codcli: Integer): Integer;
    procedure NotificacaoGEralWindowsS(Name, sTutulo, SAlerta: String);
    procedure GeraDashboardSuporte(cTempo_medio_atendimento, cQtd_medio_atendimento, cQTDUsu,
      cCAPACIDADE_GERAL_MIN, CCAPACIDADE_GERAL_QTD, CCAPACIDADE_POR_ATENTENDE,
      cPerc_nivel_Demanda_Suporte, cqtdtotal_Atendimentos, cCidadesAtendidas,
      cUsuariosParticipantes, cQtdclientes, CpercCliAtendidos, cQtdCertificados, cQtdpROCEDIMENTOS,
      cValorVendidoCampeao, sNomeCampeaoVendas: string);
    procedure CdsConsAgendaCalcFields(DataSet: TDataSet);
    procedure CdsConsAgendaAfterScroll(DataSet: TDataSet);
    procedure FDConexaoCommandZapBeforeConnect(Sender: TObject);
    procedure poClick(Sender: TObject);
    procedure GraficoMetaValores(ValorMeta, ValorAlcancado, ValorNovosClientes, ValorReativacao,
      ValorUpgrade, ValorFaltaMeta, cPercNovosClientes, cPercReativacoes, cUpgrades: string);
    procedure DataModuleCreate(Sender: TObject);
  private
    FBancoDados: Integer;
  public
    bConfirmar, bTECNICO_ATEND_NAO_ENC: boolean;
    icodusu, icod_GrupoUsu, ipontoRevenda, iidConexao: Integer;
    sNomeUsu: string;
    cValorHoraExtraNormal, cValorHoraExtraEspecial: currency;
    iVerifInternet: Integer;

    function ExecutarRequestAPICommand(Request: IRequest; TipoRequest: TRESTRequestMethod;
      const ATimeOut: Integer = 0): IResponse;
    function EnviarMensagemWhatsApp(const ACelular: String; const AMensagem: String): boolean;
    function Crypt(Action, Src: String): String;
    function ShowAlertWindow(Titulo: string; Mensagem: string; ImageIndex: Integer = -1;
      ProcedureClick: TProc = nil; Tag: Integer = 0; DisplayTime: Integer = 5000): TdxAlertWindow;
    function IsBisexto(const ano: word): boolean;
  end;

var
  DM: TDM;

implementation

{%CLASSGROUP 'Vcl.Controls.TControl'}

uses uMensagemPadrao, Umenu, USocketPing, UAgenda, UHistoricoAtendimentos,
  UBoletimCommand, UMonitorClientes;

{$R *.dfm}

function TDM.ABNTRound(Valor: currency; CasasDecimais: Integer): currency;
begin
  Result := RoundABNT(Valor, CasasDecimais);
end;

procedure TDM.AlterarStatusAtendimento(codAtendimento, codusu, CodStatus: Integer);
begin
  with FDQInsert do
  begin
    close;
    sql.clear;
    sql.add(' UPDATE atendimentos a SET a.Status_Atendimento = :status  ' +
      ' WHERE a.id_Atend = :id_Atend ');
    parambyname('id_Atend').asinteger := codAtendimento;
    parambyname('status').asinteger := CodStatus;
    execsql;
  end;
end;

procedure TDM.BuscaContatoCli(icodcli: Integer);
begin
  { busca contato do cliente }
  if DM.FDTContatoCli.Active then
    DM.FDTContatoCli.Commit;
  DM.FDTContatoCli.StartTransaction;

  with DM.FDQContatoCli do
  begin
    close;
    sql.clear;
    sql.add('select * from contatos c ' + ' where c.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := icodcli;
    open;
    last;
    first;
  end;

end;

function TDM.BuscaGrupoUsuario(icod_usu: Integer): Integer;
begin
  with FDQConsulta do
  begin
    close;
    sql.clear;
    sql.add(' SELECT g.COD_GRUPO, g.NOME_GRUPO FROM grupo_usuario g ' + ' INNER JOIN usuario u    '
      + ' ON u.COD_GRUPO = g.COD_GRUPO  ' + ' WHERE u.COD_USU = :COD_USU ');
    parambyname('COD_USU').asinteger := icod_usu;
    open;
    last;
    first;
  end;
  Result := FDQConsulta.fieldbyname('COD_GRUPO').asinteger;
end;

function TDM.BuscaPlanoPrincipalCliente(codcli: Integer): Integer;
begin
  { busca qual o plano do cliente }

  with QFDQConsulta3 do
  begin
    close;
    sql.clear;
    sql.add('  SELECT  ' + ' cp.id_plano            ' + ' FROM cliente_planos cp   ' +
      ' WHERE cp.id_cli = :id_cli      ' + ' AND ((cp.id_plano  = 1) or ' +
      ' (cp.id_plano  = 2) or(cp.id_plano  = 3)      ' +
      ' or(cp.id_plano  = 4) OR (cp.id_plano  = 5) )  ');
    parambyname('id_cli').asinteger := codcli;
    open;
  end;
  Result := QFDQConsulta3.fieldbyname('id_plano').asinteger;
end;

function TDM.BuscaQtdClientesPeriodo(smes, sAno: String): string;
begin
  { busca a qtd de clientes que existiam em um periodo }
  with FDQAuxServer do
  begin
    close;
    sql.clear;
    sql.add('SELECT ' + ' D1.ANO,D1.MES, ' + ' D1.quantidade_clientes_acumulada ' + 'FROM ' +
      '(SELECT ' + '  EXTRACT(YEAR FROM c.datacadastro_cli) AS ano, ' +
      '  EXTRACT(MONTH FROM c.datacadastro_cli) AS mes, ' + '  COUNT(*) AS quantidade_clientes, ' +
      '  (SELECT COUNT(*) ' + '   FROM cliente sub ' +
      '   WHERE (EXTRACT(YEAR FROM sub.datacadastro_cli) < EXTRACT(YEAR FROM c.datacadastro_cli) ' +
      '      OR (EXTRACT(YEAR FROM sub.datacadastro_cli) = EXTRACT(YEAR FROM c.datacadastro_cli) ' +
      '      AND EXTRACT(MONTH FROM sub.datacadastro_cli) <= EXTRACT(MONTH FROM c.datacadastro_cli))) '
      + '      AND sub.ativo_cli = ' + quotedstr('S') +
      '    AND sub.COD_CLI <> 1 and       sub.COD_CLI < 10000000 and       sub.COD_CLI <> 7 and ' +
      '     sub.COD_CLI <> 8 and       sub.COD_CLI <> 6  AND sub.cod_cla <>3 ' + ' ' +
      '      ) AS quantidade_clientes_acumulada ' + 'FROM ' + '  cliente c ' + 'WHERE ' +
      '  c.ativo_cli = ' + quotedstr('S') +
      '    AND c.COD_CLI <> 1 and       c.COD_CLI < 10000000 and       c.COD_CLI <> 7 and ' +
      '     c.COD_CLI <> 8 and       c.COD_CLI <> 6    AND c.cod_cla <>3 ' + 'GROUP BY ' + '  1, 2 '
      + 'ORDER BY ' + '  1, 2 desc )  as D1 ' + ' ' + '  WHERE  MES = :MES ' +
      '  AND ANO =  :ANO ');

    parambyname('MES').asstring := smes;
    parambyname('ANO').asstring := sAno;
  end;
  FDQAuxServer.open;

  Result := inttostr(trunc(FDQAuxServer.fieldbyname('quantidade_clientes_acumulada').asinteger));
end;

procedure TDM.BuscaValorHoraExtra;
begin
  WITH FDQConsulta DO
  BEGIN
    close;
    sql.clear;
    sql.add(' selECT  c.VL_HORA_EXTRA_NORMAL,c.VL_HORA_EXTRA_NORMAL_ESP,TECNICO_ATEND_NAO_ENC FROM configuracoes c ');
    open;
  END;
  cValorHoraExtraNormal := FDQConsulta.fieldbyname('VL_HORA_EXTRA_NORMAL').ascurrency;
  cValorHoraExtraEspecial := FDQConsulta.fieldbyname('VL_HORA_EXTRA_NORMAL_ESP').ascurrency;

  if FDQConsulta.fieldbyname('TECNICO_ATEND_NAO_ENC').asstring = 'S' then
  begin
    bTECNICO_ATEND_NAO_ENC := true;
  end;

end;

procedure TDM.CdsConsAgendaAfterScroll(DataSet: TDataSet);
begin
  if frmagenda <> nil then
  begin
    frmagenda.MoBS.Text := DM.FDQConsAgendadescricao.asstring;
  end
  else
  begin
    frmmenu.MoBS.Text := DM.CdsConsAgendadescricao.asstring;
  end;

end;

procedure TDM.CdsConsAgendaCalcFields(DataSet: TDataSet);
begin
  CdsConsAgendadia_semana.asstring :=
    DM.DiaSemanaResumida(DayOfTheWeek(CdsConsAgendadata_agendamento.asdatetime));

  if CdsConsAgendaStatus_agendamento.asinteger = 0 THEN
    CdsConsAgendaDESC_STATUS.asstring := 'AGUARDANDO'
  ELSE if CdsConsAgendaStatus_agendamento.asinteger = 1 then
    CdsConsAgendaDESC_STATUS.asstring := 'EFETUADO'
  ELSE if CdsConsAgendaStatus_agendamento.asinteger = 2 then
    CdsConsAgendaDESC_STATUS.asstring := 'N�O EFETUADO';
end;

procedure TDM.ConectaBanco(const ABancoDados: Integer);
begin
  FBancoDados := ABancoDados;

  FDConexao.connected := false;

  if ABancoDados = 1 then
  begin
    FDConexao.params.values['database'] := 'CILOS';
    FDConexao.params.values['user_name'] := '<CREDENCIAL_REMOVIDA>';
    FDConexao.params.values['password'] := '<CREDENCIAL_REMOVIDA>';
    FDConexao.params.values['server'] := '185.100.215.16';
    FDConexao.params.values['port'] := '3306';
    FDConexao.connected := true;
  end
  else
  begin
    FDConexao.params.values['database'] := 'SUPORTE';
    FDConexao.params.values['user_name'] := '<CREDENCIAL_REMOVIDA>';
    FDConexao.params.values['password'] := '<CREDENCIAL_REMOVIDA>';
    FDConexao.params.values['server'] := 'analitcs.ciloscloud.com.br';
    FDConexao.params.values['port'] := '3306';
    FDConexao.connected := true;
  end;

end;

procedure TDM.ConectaBancoChatBot;
begin
  if FDConexaoCommandZap.Connected then
    Exit;
  FDConexaoCommandZap.params.values['database'] := 'whatsapp_api';
  FDConexaoCommandZap.params.values['user_name'] := '<CREDENCIAL_REMOVIDA>';
  FDConexaoCommandZap.params.values['password'] := '<CREDENCIAL_REMOVIDA>';
  FDConexaoCommandZap.params.values['server'] := '45.143.7.87';
  FDConexaoCommandZap.params.values['port'] := '5432';
  FDConexaoCommandZap.connected := true;
end;

procedure TDM.ConectaBancoCRM;
begin
  if FDConexaoCRM.Connected then
    Exit;
  FDConexaoCRM.params.values['database'] := 'crm_api';
  FDConexaoCRM.params.values['user_name'] := '<CREDENCIAL_REMOVIDA>';
  FDConexaoCRM.params.values['password'] := '<CREDENCIAL_REMOVIDA>';
  FDConexaoCRM.params.values['server'] := '195.200.5.223';
  FDConexaoCRM.params.values['port'] := '5433';
  FDConexaoCRM.connected := true;
end;

procedure TDM.ConectaBancoFB(const ABancoDados: Integer);
begin
  DM.FDPServer.connected := false;
  DM.FDPServer.params.values['DriverID'] := 'FB';

  if ABancoDados = 1 then
  begin
    DM.FDPServer.params.values['Server'] := '185.100.215.16';
    DM.FDPServer.params.values['Database'] :=
      'C:\Windows\DataCloud\Connection - Cilos\data\data.fdb'
  end
  else
  begin
    DM.FDPServer.params.values['Server'] := 'commandsystem.commandcloud.com.br';
    DM.FDPServer.params.values['Database'] :=
      'C:\Windows\DataCloud\Connection - Command\data\datacommand.fdb';
  end;

  DM.FDPServer.params.values['User_name'] := '<CREDENCIAL_REMOVIDA>';
  DM.FDPServer.params.values['Password'] := '<CREDENCIAL_REMOVIDA>';
  DM.FDPServer.params.values['port'] := '3050';
  DM.FDPServer.connected := true;
end;

procedure TDM.CopiarValorCelulaGrid(DBTableView: TcxGridDBTableView);
begin
  ClipBoard.AsText := VarAsType(DBTableView.DataController.values
    [DBTableView.DataController.FocusedRecordIndex, DBTableView.Controller.FocusedColumn.Index],
    varString)
end;

function TDM.Crypt(Action, Src: String): String;
Label Fim;
var
  KeyLen: Integer;
  KeyPos: Integer;
  OffSet: Integer;
  Dest: String;
  SrcPos: Integer;
  SrcAsc: Integer;
  TmpSrcAsc: Integer;
  Range: Integer;
  Key: String;
begin
  Key := 'I21EFVBF165!9/ASD$WBKXCWSNAFS@7B21ASDF*11L*SIWGG1?H7K8K0 0JEBAIE!@#/BCY';
  if (Src = '') Then
  begin
    Result := '';
    Goto Fim;
  end;
  Dest := '';
  KeyLen := length(Key);
  KeyPos := 0;
  Range := 256;
  if (Action = UpperCase('C')) then
  begin
    Randomize;
    OffSet := Random(Range);
    Dest := Format('%1.2x', [OffSet]);
    for SrcPos := 1 to length(Src) do
    begin
      Application.ProcessMessages;
      SrcAsc := (Ord(Src[SrcPos]) + OffSet) Mod 255;
      if KeyPos < KeyLen then
        KeyPos := KeyPos + 1
      else
        KeyPos := 1;

      SrcAsc := SrcAsc Xor Ord(Key[KeyPos]);
      Dest := Dest + Format('%1.2x', [SrcAsc]);
      OffSet := SrcAsc;
    end;
  end
  Else if (Action = UpperCase('D')) then
  begin
    OffSet := StrToInt('$' + Copy(Src, 1, 2));
    // <--------------- adiciona o $ entra as aspas simples
    SrcPos := 3;
    repeat
      SrcAsc := StrToInt('$' + Copy(Src, SrcPos, 2));
      // <--------------- adiciona o $ entra as aspas simples
      if (KeyPos < KeyLen) Then
        KeyPos := KeyPos + 1
      else
        KeyPos := 1;
      TmpSrcAsc := SrcAsc Xor Ord(Key[KeyPos]);
      if TmpSrcAsc <= OffSet then
        TmpSrcAsc := 255 + TmpSrcAsc - OffSet
      else
        TmpSrcAsc := TmpSrcAsc - OffSet;
      Dest := Dest + Chr(TmpSrcAsc);
      OffSet := SrcAsc;
      SrcPos := SrcPos + 2;
    until (SrcPos >= length(Src));
  end;
  Result := Dest;
Fim:
end;

procedure TDM.DataModuleCreate(Sender: TObject);
begin
  FBancoDados := 0;
end;

function TDM.DiaSemanaResumida(dia: Integer): string;
begin
  case dia of
    0:
      Result := 'DOMINGO';
    1:
      Result := 'SEGUNDA';
    2:
      Result := 'TER�A';
    3:
      Result := 'QUARTA';
    4:
      Result := 'QUINTA';
    5:
      Result := 'SEXTA';
    6:
      Result := 'SABADO';

  end;
end;

function TDM.EliminaCaracter(stext: string): string;
var
  npos: Integer;
begin
  Result := '';
  npos := 1;
  while npos <= length(stext) do
  begin
    if (stext[npos] = '.') or (stext[npos] = '-') or (stext[npos] = '/') or (stext[npos] = ')') or
      (stext[npos] = '(') or (stext[npos] = ',') then
    begin
      inc(npos);
    end
    else
    begin
      Result := Result + stext[npos];
      inc(npos);
    end;
  end;
end;

procedure TDM.EnviaMSGWhatsappp(cod_usu: Integer; Mensagem1, Mensagem2: string);
var
  LResultadoEnvio: boolean;
begin

  try
    { Busca o numero de telefone do usu�rio }
    with QFDQConsulta2 do
    begin
      close;
      sql.clear;
      sql.add('SELECT u.TELEFONE_USUARIO from usuario u  ' + ' WHERE u.COD_USU = :COD_USU');
      parambyname('COD_USU').asinteger := cod_usu;
      open;
    end;

    LResultadoEnvio := TWhatsAppCommand.New.FromCommandSystem // ou FromCilos
      .IdConfiguracaoWhatsApp(2).Numero(QFDQConsulta2.fieldbyname('TELEFONE_USUARIO').asstring)
      .Mensagem('*' + Mensagem1 + '*' + sLineBreak + Mensagem2)
    // .Anexo('C:\temp\teste.txt') // Se for enviar arquivo
      .EnviarWhatsApp;
  except

  end;

  { if not LResultadoEnvio then
    ShowMessage('Erro ao enviar mensagem de whatsapp!'); }
end;

function TDM.EnviarMensagemWhatsApp(const ACelular, AMensagem: String): boolean;
begin

end;

function TDM.ExatoCurrency(Value: currency; Decimal: Integer): currency;
const
  arrDecimal: array [0 .. 5] of Integer = (1, 10, 100, 1000, 10000, 100000);
begin
  if (Abs(Decimal) > 5) then
    raise ERangeError.Create('TruncExato: O decimal deve est� no intervalo de: 0..5');
  Result := trunc(Value * arrDecimal[Decimal]) / arrDecimal[Decimal];
end;

function TDM.ExecutarRequestAPICommand(Request: IRequest; TipoRequest: TRESTRequestMethod;
  const ATimeOut: Integer): IResponse;
var
  JsonObj: TJSONObject;
  errorMessage: string;
  BaseURLRequest: String;
  LBaseURL: String;
begin
  BaseURLRequest := Trim(Copy(Request.BaseURL, 8, length(Trim(Request.BaseURL))));

  if FBancoDados = 1 then
    LBaseURL := 'https://apicilos.com.br'
  else
    LBaseURL := 'http://apicommandsystem.com.br:2450';

  Request //
    .BaseURL(LBaseURL + '/commandapi' + BaseURLRequest) //
    .BasicAuthentication('<USUARIO_REMOVIDO>', '<SENHA_REMOVIDA>');

  if ATimeOut > 0 then
    Request.Timeout(ATimeOut);

  try
    case TipoRequest of
      rmPOST:
        Result := Request.Post;
      rmPUT:
        Result := Request.Put;
      rmGET:
        Result := Request.Get;
      rmDELETE:
        Result := Request.Delete;
      rmPATCH:
        Result := Request.Patch;
    end;
  except
    on E: Exception do
      errorMessage := E.message;
  end;

  if StrToIntDef(Copy(Result.StatusCode.ToString, 1, 1), 0) in [4, 5] then
  begin
    if not Result.Content.Trim.IsEmpty then
    begin
      JsonObj := TJSONObject.ParseJSONValue(TEncoding.UTF8.GetBytes(Result.Content), 0)
        as TJSONObject;

      try
        if JsonObj.Get('errorMessage') <> nil then
          errorMessage := JsonObj.GetValue<string>('errorMessage');
      finally
        if Assigned(JsonObj) then
          FreeAndNil(JsonObj);
      end;
    end;

    raise Exception.Create(errorMessage);
  end
  else if not errorMessage.Trim.IsEmpty then
    raise Exception.Create(errorMessage);
end;

procedure TDM.ExportarDadosGrid(Grid: TcxGrid);
var
  FileExt: string;
begin
  SaveDialogGrid.Filter :=
    'Excel (*.xls) |*.xls|XML (*.xml) |*.xml|Arquivo de Texto (*.txt) |*.txt|P�gina Web (*.html)|*.html';
  SaveDialogGrid.title := 'Exportar Dados';
  SaveDialogGrid.DefaultExt := 'xls';

  if SaveDialogGrid.Execute then
  begin
    if Trim(SaveDialogGrid.FileName) <> EmptyStr then
    begin
      FileExt := LowerCase(ExtractFileExt(SaveDialogGrid.FileName));

      if FileExt = '.xls' then
        ExportGridToExcel(SaveDialogGrid.FileName, Grid, false)
      else if FileExt = '.xml' then
        ExportGridToXML(SaveDialogGrid.FileName, Grid, false)
      else if FileExt = '.txt' then
        ExportGridToText(SaveDialogGrid.FileName, Grid, false)
      else if FileExt = '.html' then
        ExportGridToHTML(SaveDialogGrid.FileName, Grid, false);

    end;
  end;
end;

procedure TDM.FDConexaoBeforeConnect(Sender: TObject);
begin
  if FileExists(ExtractFilePath(Application.ExeName) + 'libmysql50.dll') then
    FDPhysMySQLDriverLink1.VendorLib := ExtractFilePath(Application.ExeName) + 'libmysql50.dll';
end;

procedure TDM.FDConexaoCommandZapBeforeConnect(Sender: TObject);
begin
  if FileExists(ExtractFilePath(Application.ExeName) + 'libpq.dll') then
    FDPhysPgDriverLink1.VendorLib := ExtractFilePath(Application.ExeName) + 'libpq.dll';
end;

procedure TDM.FDConexaoRecover(ASender, AInitiator: TObject; AException: Exception;
  var AAction: TFDPhysConnectionRecoverAction);
begin
  AAction := faretry;
end;

procedure TDM.FDQConsAgendaAfterScroll(DataSet: TDataSet);
begin
  if frmagenda <> nil then
  begin
    frmagenda.MoBS.Text := DM.FDQConsAgendadescricao.asstring;
  end;
  frmmenu.MoBS.Text := DM.FDQConsAgendadescricao.asstring;

end;

procedure TDM.FDQConsAgendaCalcFields(DataSet: TDataSet);
begin
  FDQConsAgendadia_semana.asstring :=
    DM.DiaSemanaResumida(DayOfTheWeek(FDQConsAgendadata_agendamento.asdatetime));

  if ((FDQConsAgendaSTATUS_INSTAL.asinteger = 0) or (FDQConsAgendaSTATUS_INSTAL.asinteger = 1)) then
  begin
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'AGUARDANDO INSTALA��O'
  end
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 2 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'EM INSTALA��O'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 3 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'AGENDAR TREINAMENTO'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 4 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'REAGENDAR TREINAMENTO'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 5 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'TREINAMENTO CONCLU�DO'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 6 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'RETORNO'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 7 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'CONCLUIDO'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 8 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'TESTE DEMOSTRA��O'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 9 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'P�S VENDA'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 10 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'DESIST�NCIA'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 11 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'AGUARDANDO O CLIENTE PARA INSTALA��O'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 12 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'AGUARDANDO MIGRA��O'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 13 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'PRIMEIRO TREINAMENTO'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 14 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'SEGUNDO TREINAMENTO'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 15 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'EM MIGRA��O'
  else if FDQConsAgendaSTATUS_INSTAL.asinteger = 16 then
    FDQConsAgendaCALC_STATUS_INSTAL.asstring := 'AGUARDNDO CONFER�NCIA MIGRA��O';

end;

function TDM.FormataCNPJ(cnpj: string): string;
var
  sAux, sCNPJ: string;
begin
  sAux := EliminaCaracter(cnpj);
  case length(sAux) of
    11:
      begin
        sCNPJ := Copy(sAux, 1, 3) + '.' + Copy(sAux, 4, 3) + '.' + Copy(sAux, 7, 3) + '-' +
          Copy(sAux, 10, 2);
        Result := sCNPJ;
      end;
    14:
      begin
        sCNPJ := Copy(sAux, 1, 2) + '.' + Copy(sAux, 3, 3) + '.' + Copy(sAux, 6, 3) + '/' +
          Copy(sAux, 9, 4) + '-' + Copy(sAux, 13, 2);
        Result := sCNPJ;
      end;
  else
    Result := '';
  end;
end;

function TDM.FormataStringD(Valor, Tamanho, Complemento: string): string;
var
  X, Y: Integer;
begin
  Y := length(Valor);
  for X := Y to StrToInt(Tamanho) do
  begin
    if (X <> StrToInt(Tamanho)) then
      Valor := Complemento + Valor
    else
      Valor := '' + Valor;
  end;
  Result := Valor;
end;

procedure TDM.GeraDashboardSuporte(cTempo_medio_atendimento, cQtd_medio_atendimento, cQTDUsu,
  cCAPACIDADE_GERAL_MIN, CCAPACIDADE_GERAL_QTD, CCAPACIDADE_POR_ATENTENDE,
  cPerc_nivel_Demanda_Suporte, cqtdtotal_Atendimentos, cCidadesAtendidas, cUsuariosParticipantes,
  cQtdclientes, CpercCliAtendidos, cQtdCertificados, cQtdpROCEDIMENTOS, cValorVendidoCampeao,
  sNomeCampeaoVendas: string);
begin
  { Gera grafico de dashboard suporte }
  WebGrafMP.Container(fluid).NewProject.Rows.title.Config.H5
    ('>>>>INFORMA��ES REFERENTE AOS ULTIMOS 30 DIAS DE SUPORTE<<<< ')
    .&End.&End.&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject
    { TMA - TEMPO M�DIO EM ATENDIMENTO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8000ff,#8000ff,#8000ff)').DefaultFontColor('255,255,255')
    .title.Text('TMA').&End.Body.Text(cTempo_medio_atendimento)
    .&End.Footer.Text('Tempo m�dio em atendimento em minutos').&End.Shape.Icon('fas fa-dollar-sign')
    .Style.BackgroundColor('#4000ff').&End.&End.&End.&End
    { quantidade m�dia de atendimentos }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#bf00ff,#bf00ff,#bf00ff)').DefaultFontColor('255,255,255')
    .title.Text('M�DIA POR DIA').&End.Body.Text(cQtd_medio_atendimento)
    .&End.Footer.Text('Quantidade m�dia de atendimentos').&End.Shape.Icon('fas fa-tachometer-alt')
    .Style.BackgroundColor('#4000ff').&End.&End.&End.&End
    { QUANTIDADE TOTAL DE ATENDIMENTOS }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0080ff,#0080ff,#0080ff)').DefaultFontColor('255,255,255')
    .title.Text('TOTAL ATENDIMENTOS').&End.Body.Text(cqtdtotal_Atendimentos)
    .&End.Footer.Text('Quantidade total de atendimentos').&End.Shape.Icon('fas fa-dollar-sign')
    .&End.&End.&End
    { QTD DE USUARIOS DO SUPORTE }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0040ff,#0040ff,#0040ff)').DefaultFontColor('255,255,255')
    .title.Text('QTD ATENDENTES').&End.Body.Text(cQTDUsu)
    .&End.Footer.Text('qtd de pessoas no suporte').&End.Shape.Icon('fas fa-dollar-sign')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject
    { Capacidade geral do suporte em minutos }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#808080,#808080,#808080)').DefaultFontColor('255,255,255')
    .title.Text('CAPACIDADE GERAL MIN').&End.Body.Text(cCAPACIDADE_GERAL_MIN)
    .&End.Footer.Text('Capacidade geral em minutos').&End.Shape.Icon('fa fa-user').&End.&End.&End
    { Capacidade geral do suporte em quantidade }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#00264d,#00264d,#00264d)').DefaultFontColor('255,255,255')
    .title.Text('CAPACIDADE GERAL QTD').&End.Body.Text(CCAPACIDADE_GERAL_QTD)
    .&End.Footer.Text('Capacidade geral em qtd').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { Capacidade de atendimentos por atendente }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006666,#006666,#006666)').DefaultFontColor('255,255,255')
    .title.Text('CAPACIDADE POR ATENDENTE').&End.Body.Text(CCAPACIDADE_POR_ATENTENDE)
    .&End.Footer.Text('Capacidade em qtd de atendimtos').&End.Shape.Icon('fa fa-map').&End.&End.&End

    { calculo do nivel de demanda do suporte }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('NIVEL DE DEMANDA').&End.Body.Text(cPerc_nivel_Demanda_Suporte + '%')
    .&End.Footer.Text('capacidade operacional do suporte').&End.Shape.Icon('fa fa-map')
    .&End.&End.&End

    .HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject
    { CIDADES ATENDIDAS NO PERIODO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#001a66,#001a66,#001a66)').DefaultFontColor('255,255,255')
    .title.Text('CIDADES ATENDIDAS').&End.Body.Text(cCidadesAtendidas)
    .&End.Footer.Text('Cidades atendidas no per�do').&End.Shape.Icon('fas fa-dollar-sign')
    .&End.&End.&End

    { TOTAL DE CLIENTES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#001a66,#001a66,#001a66)').DefaultFontColor('255,255,255')
    .title.Text('QTD TOTAL DE CLIENTES').&End.Body.Text(cQtdclientes)
    .&End.Footer.Text('Total de clientes').&End.Shape.Icon('fas fa-dollar-sign').&End.&End.&End

    { TOTAL DE CLIENTES ATENDIDOS EM PORCENTAGEM }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#001a66,#001a66,#001a66)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES ATENDIDOS (%)').&End.Body.Text(CpercCliAtendidos + '%')
    .&End.Footer.Text('Porcentagem dos clientes atendidos').&End.Shape.Icon('fas fa-dollar-sign')
    .&End.&End.&End

    { CLIENTES ATENDIDOS NO PERIODO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES ATENDIDOS').&End.Body.Text(cUsuariosParticipantes)
    .&End.Footer.Text('Clientes atendidos no per�odo').&End.Shape.Icon('fas fa-dollar-sign')
    .&End.&End.&End

    .HTML).&End

    .Jumpline.Rows.HTML(WebGrafMP.ContinuosProject
    { CERTIFICADOS FEITOS }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4F4F4F,#4F4F4F,#4F4F4F)').DefaultFontColor('255,255,255')
    .title.Text('CERTIFICADOS EMITIDOS').&End.Body.Text(cQtdCertificados)
    .&End.Footer.Text('Certificados emitidos no per�do').&End.Shape.Icon('fa fa-map').&End.&End.&End

    { PROCEDIMENTOS EFETUADOS }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#836FFF,#836FFF,#836FFF)').DefaultFontColor('255,255,255')
    .title.Text('PROCEDIMENTOS EFETUADOS').&End.Body.Text(cQtdpROCEDIMENTOS)
    .&End.Footer.Text('Procedimentos efetuados no periodo').&End.Shape.Icon('fa fa-map')
    .&End.&End.&End

    { LIDER DE UPGRADES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#00FF00,#00FF00,#00FF00)').DefaultFontColor('0,0,0')
    .title.Text(sNomeCampeaoVendas + ' - LIDER DE UPGRADES')
    .&End.Body.Text(' R$ ' + cValorVendidoCampeao)
    .&End.Footer.Text('Campe�o de vendas via upgrade do sistema').&End.Shape.Icon('fa fa-map')
    .&End.&End.&End

    { TOTAL DE CLIENTES ATENDIDOS EM PORCENTAGEM }
    { .CardStyled
      .CardType(CardStyledIconBackground)
      .Col(3)
      .BackgroundColor('linear-gradient(#001a66,#001a66,#001a66)')
      .DefaultFontColor('255,255,255')
      .Title
      .Text('CLIENTES ATENDIDOS (%)')
      .&End
      .Body
      .Text(CpercCliAtendidos+'%')
      .&End
      .Footer
      .Text('Porcentagem dos clientes atendidos')
      .&End
      .Shape
      .Icon('fas fa-dollar-sign')
      .&End
      .&End
      .&End }

    { CLIENTES ATENDIDOS NO PERIODO }
    { .CardStyled
      .CardType(CardStyledIconBackground)
      .Col(3)
      .BackgroundColor('linear-gradient(#006600,#006600,#006600)')
      .DefaultFontColor('255,255,255')
      .Title
      .Text('CLIENTES ATENDIDOS')
      .&End
      .Body
      .Text(cUsuariosParticipantes)
      .&End
      .Footer
      .Text('Clientes atendidos no per�odo')
      .&End
      .Shape
      .Icon('fas fa-dollar-sign')
      .&End
      .&End
      .&End }

    .HTML

    ).&End

    .WebBrowser(FrmHistoricoAtendimentos.WbResultadoSuporte).CallbackJS.ClassProvider(Self)
    .&End.Generated;

end;

procedure TDM.GeraGraficoIndiceEscalabilidadeSuporte;
var
  i: Integer;
  cQtdclientes, cQtdClientesMedia, CqtdSuporteMedia: currency;
begin
  { Gera grafico de indice de escalabilidade do suporte }

  cQtdClientesMedia := 0;
  CqtdSuporteMedia := 0;
  // buscar qtd de suporte ultimos  06 meses
  with DM.FDQConsulta do
  begin
    close;
    sql.clear;
    sql.add('SELECT ' + '    YEAR(a.data_hora_atendimento) AS Ano, ' +
      '    MONTH(a.data_hora_atendimento) AS Mes, ' +
      '    COUNT(a.id_Atend) AS QuantidadeDeAtendimentos, ' + '    ( ' +
      '        SELECT COUNT(c.cod_cli) ' + '        FROM cliente c ' +
      '        WHERE YEAR(c.DATACADASTRO_CLI) = YEAR(a.data_hora_atendimento) ' +
      '        AND MONTH(c.DATACADASTRO_CLI) = MONTH(a.data_hora_atendimento) ' + '  and c.ATIVO = '
      + quotedstr('S') +
      '    AND c.COD_CLI <> 1 and       c.COD_CLI < 10000000 and       c.COD_CLI <> 7 and ' +
      '     c.COD_CLI <> 8 and       c.COD_CLI <> 6    AND c.cod_cla <>3 ' + ' ' +
      '    ) AS QuantidadeDeClientesCadastrados ' + 'FROM atendimentos a ' +
      'WHERE a.data_hora_atendimento >= DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH) ' +
      'AND a.departamento = 1 AND a.Status_Atendimento = 7 ' +
      'GROUP BY YEAR(a.data_hora_atendimento), MONTH(a.data_hora_atendimento) ' +
      'ORDER BY Ano, Mes; ');
    open;
  end;
  DM.FDQConsulta.recordcount;
  DM.CdsGraficMP.close;
  DM.CdsGraficMP.IsEmpty;
  DM.CdsGraficMP.open;

  DM.CdsGraficMP02.close;
  DM.CdsGraficMP02.IsEmpty;
  DM.CdsGraficMP02.open;

  DM.CdsGraficMP03.close;
  DM.CdsGraficMP03.IsEmpty;
  DM.CdsGraficMP03.open;

  DM.CdsGraficMP04.close;
  DM.CdsGraficMP04.IsEmpty;
  DM.CdsGraficMP04.open;

  DM.CdsGraficMP05.close;
  DM.CdsGraficMP05.IsEmpty;
  DM.CdsGraficMP05.open;
  i := 0;
  DM.FDQConsulta.first;
  while not DM.FDQConsulta.eof do
  begin
    if i = 0 then
      DM.FDQConsulta.next
    else
    begin
      cQtdClientesMedia := cQtdClientesMedia + DM.FDQConsulta.fieldbyname
        ('QuantidadeDeClientesCadastrados').ascurrency;
      CqtdSuporteMedia := CqtdSuporteMedia + DM.FDQConsulta.fieldbyname('QuantidadeDeAtendimentos')
        .ascurrency;
    end;
    inc(i);
    DM.FDQConsulta.next;
  end;
  cQtdClientesMedia := cQtdClientesMedia / 6;
  CqtdSuporteMedia := CqtdSuporteMedia / 6;

  i := 0;
  DM.FDQConsulta.first;
  while not DM.FDQConsulta.eof do
  begin
    { gera o grafico }

    if i = 0 then
      DM.FDQConsulta.next
    else
    begin
      { gera o grafico }
      cQtdclientes := strtocurr(BuscaQtdClientesPeriodo(DM.FDQConsulta.fieldbyname('MES').asstring,
        DM.FDQConsulta.fieldbyname('ANO').asstring));

      DM.CdsGraficMP.append;
      DM.CdsGraficMP.fieldbyname('LABEL').Value :=
        mesAno(DM.FDQConsulta.fieldbyname('MES').asinteger) + ' ' + DM.FDQConsulta.fieldbyname
        ('ANO').asstring;
      DM.CdsGraficMP.fieldbyname('VALUE').Value :=
        currtostrf(DM.FDQConsulta.fieldbyname('QuantidadeDeAtendimentos').ascurrency / cQtdclientes,
        ffnumber, 2);
      DM.CdsGraficMP.fieldbyname('RGB').Value := inttostr(0) + ',' + inttostr(255) + ',' +
        inttostr(127);
      DM.CdsGraficMP.Post;

      DM.CdsGraficMP02.append;
      DM.CdsGraficMP02.fieldbyname('LABEL').Value :=
        mesAno(DM.FDQConsulta.fieldbyname('MES').asinteger) + ' ' + DM.FDQConsulta.fieldbyname
        ('ANO').asstring;
      DM.CdsGraficMP02.fieldbyname('VALUE').Value :=
        currtostrf(DM.FDQConsulta.fieldbyname('QuantidadeDeAtendimentos').ascurrency, ffnumber, 2);
      DM.CdsGraficMP02.fieldbyname('RGB').Value := inttostr(128) + ',' + inttostr(0) + ',' +
        inttostr(128);
      DM.CdsGraficMP02.Post;

      DM.CdsGraficMP03.append;
      DM.CdsGraficMP03.fieldbyname('LABEL').Value :=
        mesAno(DM.FDQConsulta.fieldbyname('MES').asinteger) + ' ' + DM.FDQConsulta.fieldbyname
        ('ANO').asstring;
      DM.CdsGraficMP03.fieldbyname('VALUE').Value :=
        currtostrf(DM.FDQConsulta.fieldbyname('QuantidadeDeClientesCadastrados').ascurrency,
        ffnumber, 2);
      DM.CdsGraficMP03.fieldbyname('RGB').Value := inttostr(255) + ',' + inttostr(165) + ',' +
        inttostr(0);
      DM.CdsGraficMP03.Post;

      DM.CdsGraficMP04.append;
      DM.CdsGraficMP04.fieldbyname('LABEL').Value :=
        mesAno(DM.FDQConsulta.fieldbyname('MES').asinteger) + ' ' + DM.FDQConsulta.fieldbyname
        ('ANO').asstring;
      DM.CdsGraficMP04.fieldbyname('VALUE').Value :=
        currtostrf(((DM.FDQConsulta.fieldbyname('QuantidadeDeClientesCadastrados').ascurrency -
        cQtdClientesMedia) / cQtdClientesMedia) * 100, ffnumber, 2) + '%';
      DM.CdsGraficMP04.fieldbyname('RGB').Value := inttostr(75) + ',' + inttostr(0) + ',' +
        inttostr(130);
      DM.CdsGraficMP04.Post;

      DM.CdsGraficMP05.append;
      DM.CdsGraficMP05.fieldbyname('LABEL').Value :=
        mesAno(DM.FDQConsulta.fieldbyname('MES').asinteger) + ' ' + DM.FDQConsulta.fieldbyname
        ('ANO').asstring;
      DM.CdsGraficMP05.fieldbyname('VALUE').Value :=
        currtostrf(((DM.FDQConsulta.fieldbyname('QuantidadeDeAtendimentos').ascurrency -
        CqtdSuporteMedia) / CqtdSuporteMedia) * 100, ffnumber, 2) + '%';
      DM.CdsGraficMP05.fieldbyname('RGB').Value := inttostr(75) + ',' + inttostr(0) + ',' +
        inttostr(130);
      DM.CdsGraficMP05.Post;

    end;

    inc(i);
    DM.FDQConsulta.next;
  end;

  { grafico suporte por mes nos ultimos 06 meses }

  WebGrafMP.NewProject.Rows.title.Config.H5('...Quantidade de suporte nos ultimos 06 meses...')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(bar).Attributes.Labelling.Format('0,0.00')
  // Consultar em http://numeraljs.com/#format
    .RGBColor('0,0,0') // Cor RGB separado por Virgula
    .FontSize(10) // Tamanho da Fonte
    .FontStyle('bold') // normal, bold, italic
    .FontFamily('Tahoma') // Open Sans, Arial, Helvetica e etc..
    .Padding(5) // Numeros negativos e positivos
    .&End.Name('GeraGraficoindiceSuporte06meses').ColSpan(12)
  // .Heigth(itamanho)
  // .Title('Meu Gr�fico de Barras')
    .DataSet.textLabel('�ndice do suporte').DataSet(CdsGraficMP02).Types('line').Fill(false)
    .BorderWidth(10).BorderColor('255,0,255').&End.DataSet.textLabel('Qtd de novos clientes')
    .DataSet(CdsGraficMP02).Types('bar').&End.&End.&End.&End.WebBrowser
    (FrmHistoricoAtendimentos.WbHistoricoSuporte06Meses).Generated;

  { grafico suporte x novos clientes }
  WebGrafMP.Container(fluid) // usa o maximo de tamanho da tela
    .NewProject.Rows.title.Config.H5
    ('.t  Evolu��o dos Clientes novos x Aumento do suporte em porcentagem')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(bar).Attributes.Labelling.Format('0,0.00')
  // Consultar em http://numeraljs.com/#format
    .RGBColor('0,0,0') // Cor RGB separado por Virgula
    .FontSize(10) // Tamanho da Fonte
    .FontStyle('bold') // normal, bold, italic
    .FontFamily('Tahoma') // Open Sans, Arial, Helvetica e etc..
    .Padding(5) // Numeros negativos e positivos
    .&End.Name('GGeraGraficoindiceSuporteclientexsuporte').ColSpan(12)
  // .Heigth(200)
  { .DataSet
    .BackgroundColor('255,0,0')
    .textLabel('Evolu��es das despesas vari�veis')
    .DataSet(CdsGrafic03MP)
    .&End }
    .DataSet.textLabel('Quantidade de novos clientes(%)').DataSet(CdsGraficMP04).Types('line')
    .Fill(false).BorderWidth(4).BackgroundColor('0,255,0').BorderColor('0,128,0')
    .&End.DataSet.textLabel('Aumento do suporte(%)').DataSet(CdsGraficMP05).Types('line')
    .Fill(false).BorderWidth(4).BackgroundColor('139,0,139').BorderColor('218,112,214')
    .&End.&End.&End.&End.WebBrowser(FrmHistoricoAtendimentos.WbQtdSuporte).Generated;

  // BUSCA SUPORTE POR DIA DA SEMANA NOS ULTIMOS 06 MESES
  with DM.FDQConsulta do
  begin
    close;
    sql.clear;
    sql.add('SELECT  ' + '    DiaDaSemana, ' + '    QuantidadeDeAtendimentos, ' +
      '    ROUND((QuantidadeDeAtendimentos / TotalAtendimentos * 100), 2) AS Porcentagem ' + 'FROM '
      + '    (SELECT  ' + '         CASE DAYOFWEEK(data_hora_atendimento) ' +
      '             WHEN 1 THEN ' + quotedstr('Domingo') + '             WHEN 2 THEN ' +
      quotedstr('Segunda-feira') + '             WHEN 3 THEN ' + quotedstr('Ter�a-feira') +
      '             WHEN 4 THEN ' + quotedstr('Quarta-feira') + '             WHEN 5 THEN ' +
      quotedstr('Quinta-feira') + '             WHEN 6 THEN ' + quotedstr('Sexta-feira') +
      '             WHEN 7 THEN ' + quotedstr('S�bado') + '         END AS DiaDaSemana, ' +
      '         COUNT(id_Atend) AS QuantidadeDeAtendimentos ' + '     FROM  ' +
      '         atendimentos ' + '     WHERE  ' +
      '         data_hora_atendimento >= DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH) ' +
      '         AND departamento = 1  ' + '         AND Status_Atendimento = 7 ' + '     GROUP BY  '
      + '         DAYOFWEEK(data_hora_atendimento) ' + '    ) AS AtendimentosPorDia, ' +
      '    (SELECT  ' + '         COUNT(id_Atend) AS TotalAtendimentos ' + '     FROM  ' +
      '         atendimentos ' + '     WHERE  ' +
      '         data_hora_atendimento >= DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH) ' +
      '         AND departamento = 1  ' + '         AND Status_Atendimento = 7 ' + '    ) AS Total '
      + 'ORDER BY  ' + '    FIELD(DiaDaSemana, ' + quotedstr('Segunda-feira') + ', ' +
      quotedstr('Ter�a-feira') + quotedstr(', ') + quotedstr('Quarta-feira') + quotedstr(', ') +
      quotedstr('Quinta-feira') + quotedstr(', ') + quotedstr('Sexta-feira') + quotedstr(', ') +
      quotedstr('S�bado') + quotedstr(', ') + quotedstr('Domingo') + ') ');
    open;
  end;
  DM.FDQConsulta.first;

  DM.CdsGraficMP06.close;
  DM.CdsGraficMP06.IsEmpty;
  DM.CdsGraficMP06.open;

  while not DM.FDQConsulta.eof do
  begin
    DM.CdsGraficMP06.append;
    DM.CdsGraficMP06.fieldbyname('LABEL').Value :=
      (DM.FDQConsulta.fieldbyname('DiaDaSemana').asstring) + ' ' + DM.FDQConsulta.fieldbyname
      ('Porcentagem').asstring + '%';
    DM.CdsGraficMP06.fieldbyname('VALUE').Value :=
      currtostrf(DM.FDQConsulta.fieldbyname('QuantidadeDeAtendimentos').ascurrency, ffnumber, 2);
    DM.CdsGraficMP06.fieldbyname('RGB').Value := inttostr(72) + ',' + inttostr(61) + ',' +
      inttostr(139);
    DM.CdsGraficMP06.Post;

    DM.FDQConsulta.next;
  end;
  DM.CdsGraficMP06.first;

  { grafico  SUPORTE POR DIA DA SEMANA NOS ULTIMOS 06 MESES }
  WebGrafMP.NewProject.Rows.title.Config.H5
    ('...Quantidade de suporte por dia da semana nos ultimos 06 meses...')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(bar).Attributes.Labelling.Format('0,0.00')
  // Consultar em http://numeraljs.com/#format
    .RGBColor('0,0,0') // Cor RGB separado por Virgula
    .FontSize(10) // Tamanho da Fonte
    .FontStyle('bold') // normal, bold, italic
    .FontFamily('Tahoma') // Open Sans, Arial, Helvetica e etc..
    .Padding(5) // Numeros negativos e positivos
    .&End.Name('GeraGraficoqtdsuportediasemana').ColSpan(12)
  // .Heigth(itamanho)
  // .Title('Meu Gr�fico de Barras')
    .DataSet.textLabel('�ndice do suporte').DataSet(CdsGraficMP06).Types('line').Fill(false)
    .BorderWidth(10).BorderColor('0,0,255').&End.DataSet.textLabel('linha de suporte')
    .DataSet(CdsGraficMP06).Types('bar').&End.&End.&End.&End.WebBrowser
    (FrmHistoricoAtendimentos.WbSuporteDiaSemana).Generated;

  // BUSCA SUPORTE POR HORA DA SEMANA NOS ULTIMOS 06 MESES
  with DM.FDQConsulta do
  begin
    close;
    sql.clear;
    sql.add('SELECT  ' + '    Hora, ' + '    QuantidadeDeAtendimentos, ' +
      '    ROUND((QuantidadeDeAtendimentos / TotalAtendimentos * 100), 2) AS Porcentagem ' + 'FROM '
      + '    (SELECT  ' + '         CONCAT(LPAD(HOUR(data_hora_atendimento), 2, ' + quotedstr('0') +
      '), ' + quotedstr(':00 hs') + ') AS Hora, ' +
      '         COUNT(id_Atend) AS QuantidadeDeAtendimentos ' + '     FROM  ' +
      '         atendimentos ' + '     WHERE  ' +
      '         data_hora_atendimento >= DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH) ' +
      '         AND departamento = 1  ' + '         AND Status_Atendimento = 7 ' + '     GROUP BY  '
      + '         HOUR(data_hora_atendimento) ' + '    ) AS AtendimentosPorHora, ' + '    (SELECT  '
      + '         COUNT(id_Atend) AS TotalAtendimentos ' + '     FROM  ' + '         atendimentos '
      + '     WHERE  ' +
      '         data_hora_atendimento >= DATE_SUB(CURRENT_DATE, INTERVAL 7 MONTH) ' +
      '         AND departamento = 1  ' + '         AND Status_Atendimento = 7 ' + '    ) AS Total '
      + 'ORDER BY  ' + '    Hora; ');
    open;
  end;
  DM.FDQConsulta.first;

  DM.CdsGraficMP07.close;
  DM.CdsGraficMP07.IsEmpty;
  DM.CdsGraficMP07.open;

  while not DM.FDQConsulta.eof do
  begin
    DM.CdsGraficMP07.append;
    DM.CdsGraficMP07.fieldbyname('LABEL').Value := (DM.FDQConsulta.fieldbyname('Hora').asstring) +
      ' ' + DM.FDQConsulta.fieldbyname('Porcentagem').asstring + '%';
    DM.CdsGraficMP07.fieldbyname('VALUE').Value :=
      currtostrf(DM.FDQConsulta.fieldbyname('QuantidadeDeAtendimentos').ascurrency, ffnumber, 2);
    DM.CdsGraficMP07.fieldbyname('RGB').Value := inttostr(0) + ',' + inttostr(139) + ',' +
      inttostr(139);
    DM.CdsGraficMP07.Post;

    DM.FDQConsulta.next;
  end;
  DM.CdsGraficMP07.first;

  { grafico  SUPORTE POR HORA DA SEMANA NOS ULTIMOS 06 MESES }
  WebGrafMP.NewProject.Rows.title.Config.H5
    ('...Quantidade de suporte por hora da semana nos ultimos 06 meses...')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(bar).Attributes.Labelling.Format('0,0.00')
  // Consultar em http://numeraljs.com/#format
    .RGBColor('0,0,0') // Cor RGB separado por Virgula
    .FontSize(10) // Tamanho da Fonte
    .FontStyle('bold') // normal, bold, italic
    .FontFamily('Tahoma') // Open Sans, Arial, Helvetica e etc..
    .Padding(5) // Numeros negativos e positivos
    .&End.Name('GeraGraficoqtdsuportehora').ColSpan(12)
  // .Heigth(itamanho)
  // .Title('Meu Gr�fico de Barras')
    .DataSet.textLabel('�ndice do suporte').DataSet(CdsGraficMP07).Types('line').Fill(false)
    .BorderWidth(10).BorderColor('0,255,255').&End.DataSet.textLabel('linha de suporte')
    .DataSet(CdsGraficMP07).Types('bar').&End.&End.&End.&End.WebBrowser
    (FrmHistoricoAtendimentos.WbSuporteHora).Generated;

end;

procedure TDM.GeraGraficoNPS;
begin
  { Gera gr�fico NPS }

  { Evolu�ao DO NPS referente aos ultimos 12 meses }

  WebGrafMP.Container(fluid) // usa o maximo de tamanho da tela
    .NewProject.Rows.title.Config.H5
    ('.t Net Promoter Score NPS - Command System  dos �ltimos 12 meses')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(bar).Attributes.Labelling.Format('0,0.00')
  // Consultar em http://numeraljs.com/#format
    .RGBColor('0,0,0') // Cor RGB separado por Virgula
    .FontSize(10) // Tamanho da Fonte
    .FontStyle('bold') // normal, bold, italic
    .FontFamily('Tahoma') // Open Sans, Arial, Helvetica e etc..
    .Padding(5) // Numeros negativos e positivos
    .&End.Name('GeraGraficoNPS').ColSpan(12).Heigth(90)
  // .Title('Meu Gr�fico de Barras')
    .DataSet.textLabel('Evolu��o').DataSet(CdsGraficMP).Types('line').Fill(false).BorderWidth(4)
    .BorderColor('30,182,203').&End.DataSet.textLabel('Dados').DataSet(CdsGraficMP).Types('bar')
    .&End.&End.&End.&End.WebBrowser(frmmenu.WbNPS).Generated;

end;

procedure TDM.GeraGraficosCertificadosProxMeses(Tipo: string);
begin
  { Gera gr�fico proximos meses }
  with DM.FDQConsulta do
  begin
    close;
    sql.clear;
    sql.add(' SELECT    ' + ' EXTRACT(MONTH FROM C.DATA_VAL_CERT_DIG ) AS MES,   ' +
      ' EXTRACT(YEAR FROM C.DATA_VAL_CERT_DIG ) AS ANO,  ' + ' COUNT(C.DATA_VAL_CERT_DIG) as  QTD '
      + ' FROM certificados C        ' +
      ' WHERE C.DATA_VAL_CERT_DIG BETWEEN :DATAINI AND :DATAFIN   ');
    sql.add(' AND C.TIPO = :TIPO ');
    parambyname('TIPO').asstring := Tipo;
    parambyname('DATAINI').asdatetime := StartOfTheYear(frmmenu.EdtDataIni.date);
    parambyname('DATAFIN').asdatetime := EndOfTheYear(frmmenu.EdtDataFin.date);
    sql.add(' GROUP BY EXTRACT(MONTH FROM C.DATA_VAL_CERT_DIG )  ORDER BY C.DATA_VAL_CERT_DIG ');
    open;
  end;
  DM.FDQConsulta.recordcount;
  DM.CdsGraficMP.close;
  DM.CdsGraficMP.IsEmpty;
  DM.CdsGraficMP.open;
  DM.FDQConsulta.first;
  while not DM.FDQConsulta.eof do
  begin
    { gera o grafico }

    if DM.FDQConsulta.fieldbyname('qtd').ascurrency > 0 then
    begin
      { gera o grafico }
      DM.CdsGraficMP.append;
      DM.CdsGraficMP.fieldbyname('LABEL').Value :=
        mesAno(DM.FDQConsulta.fieldbyname('MES').asinteger) + ' ' + DM.FDQConsulta.fieldbyname
        ('ANO').asstring;
      DM.CdsGraficMP.fieldbyname('VALUE').Value :=
        currtostrf(DM.FDQConsulta.fieldbyname('QTD').ascurrency, ffnumber, 2);
      DM.CdsGraficMP.fieldbyname('RGB').Value := inttostr(0) + ',' + inttostr(119) + ',' +
        inttostr(255);
      DM.CdsGraficMP.Post;
    end;

    DM.FDQConsulta.next;
  end;

  { Evolu�ao das vendas referente aos ultimos 12 meses }

  WebGrafMP.NewProject.Rows.title.Config.H5('Certificado se vencendo nos proximos 12 meses')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(bar).Attributes.Labelling.Format('0,0.00')
  // Consultar em http://numeraljs.com/#format
    .RGBColor('0,0,0') // Cor RGB separado por Virgula
    .FontSize(10) // Tamanho da Fonte
    .FontStyle('bold') // normal, bold, italic
    .FontFamily('Tahoma') // Open Sans, Arial, Helvetica e etc..
    .Padding(5) // Numeros negativos e positivos
    .&End.Name('GeraGraficoVendasMp').ColSpan(12)
  // .Heigth(itamanho)
  // .Title('Meu Gr�fico de Barras')
    .DataSet.textLabel('Evolu��o').DataSet(CdsGraficMP).Types('line').Fill(false).BorderWidth(4)
    .BorderColor('30,182,203').&End.DataSet.textLabel('Dados').DataSet(CdsGraficMP).Types('bar')
    .&End.&End.&End.&End.WebBrowser(frmmenu.WbGraficoProxMeses).Generated;

end;

procedure TDM.GeraGraficosInstalacoes(qtdAguardInstalacao, EmInstalacao, AgendarTreinamento,
  ReagendarTreinamento, TreinamentoConcluido, Retorno, Testes, PosVenda, desistencia,
  AguardandoClienteParaInstalacao, AguardandoMigracao, PrimeiroTreinamento, SegundoTreinamento,
  EmMigracao, EmConferenciaMigracao: String);
begin
  { Grafico das instala�oes }

  WebGrafMP.Container(fluid).NewProject.Rows.title.Config.H5
    ('>>>>INFORMA��ES SOBRE AS INSTALA��ES<<<<').&End.&End.&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject
    { QTD DE CLIENTES AGUARDANDO AS INSTALACOES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#DA70D6,#DA70D6,#DA70D6)').DefaultFontColor('255,255,255')
    .title.Text('AGUARDANDO INSTALA��O').&End.Body.Text(qtdAguardInstalacao)
    .&End.Footer.Text('Quantidade de clientes aguardando a instala��o')
    .&End.Shape.Icon('fa fa-user').Style.BackgroundColor('#FF00FF').&End.&End.&End.&End
    { EM INSTALA��O }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0000FF,#0000FF,#0000FF)').DefaultFontColor('255,255,255')
    .title.Text('EM INSTALA��O').&End.Body.Text(EmInstalacao)
    .&End.Footer.Text('Clientes em processo de instala��o').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#000080').&End.&End.&End.&End
    { TREINAMENTO AGENDADO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4169E1,#4169E1,#4169E1)').DefaultFontColor('255,255,255')
    .title.Text('AGENDAR TREINAMENTO').&End.Body.Text(AgendarTreinamento)
    .&End.Footer.Text('Aguardando o agendamento').&End.Shape.Icon('fa fa-user').&End.&End.&End.HTML)
    .&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { Aguardando o cliente para instala��o }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#00BFFF,#00BFFF,#00BFFF)').DefaultFontColor('255,255,255')
    .title.Text('AGUARDANDO CLIENTE PARA INSTALA��O')
    .&End.Body.Text(AguardandoClienteParaInstalacao)
    .&End.Footer.Text('Aguardando cliente dar o ok para efetuar a instala��o')
    .&End.Shape.Icon('fa fa-user').Style.BackgroundColor('#00BFFF').&End.&End.&End.&End

    { Aguardando Migra��o }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#778899,#778899,#778899)').DefaultFontColor('255,255,255')
    .title.Text('AGUARDANDO MIGRA��O').&End.Body.Text(AguardandoMigracao)
    .&End.Footer.Text('Aguardando a migra��o do sistema').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    { Primeiro treinamento }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#2F4F4F,#2F4F4F,#2F4F4F)').DefaultFontColor('255,255,255')
    .title.Text('PRIMEIRO TREINAMENTO').&End.Body.Text(PrimeiroTreinamento)
    .&End.Footer.Text('Primeiro treinamento para o cliente').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { Segundo treinamento }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#3CB371,#3CB371,#3CB371)').DefaultFontColor('255,255,255')
    .title.Text('SEGUNDO TREINAMENTO').&End.Body.Text(SegundoTreinamento)
    .&End.Footer.Text('Segundo treinamento efetuado para o cliente').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#3CB371').&End.&End.&End.&End

    { em migra��o }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#000000,#000000,#000000)').DefaultFontColor('255,255,255')
    .title.Text('EM MIGRA��O').&End.Body.Text(EmMigracao)
    .&End.Footer.Text('Em migra��o do sistema anterior').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    { aguardando conferencia da migra��o }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#1C1C1C,#1C1C1C,#1C1C1C)').DefaultFontColor('255,255,255')
    .title.Text('AGUARDANDO CONFER�NCIA DO CLIENTE').&End.Body.Text(EmConferenciaMigracao)
    .&End.Footer.Text('Aguardando o cliente conferir a migra��o').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { TREINAMENTO REAGENDA }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8A2BE2,#8A2BE2,#8A2BE2)').DefaultFontColor('255,255,255')
    .title.Text('REAGENDAMENTO').&End.Body.Text(ReagendarTreinamento)
    .&End.Footer.Text('Treinamento reagendado').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#9932CC').&End.&End.&End.&End

    { TREINAMENTO CONCLUIDO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#008000,#008000,#008000)').DefaultFontColor('255,255,255')
    .title.Text('TREINAMENTO CONCLUIDO').&End.Body.Text(TreinamentoConcluido)
    .&End.Footer.Text('Conclus�o do treinamento').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { RETORNO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('RETORNO CS').&End.Body.Text(Retorno)
    .&End.Footer.Text('Retorno do setor de sucesso do cliente').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { TESTE DEMOSTRA��O }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4F4F4F,#4F4F4F,#4F4F4F)').DefaultFontColor('255,255,255')
    .title.Text('TESTE DEMOSTRA��O').&End.Body.Text(Testes)
    .&End.Footer.Text('Usando em domostra��o').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#000000').&End.&End.&End.&End

    { P�S VENDA }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#00FF00,#00FF00,#00FF00)').DefaultFontColor('0,0,0')
    .title.Text('P�S VENDA').&End.Body.Text(PosVenda).&End.Footer.Text('P�s venda comercial')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End

    { DESISTENCIA }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(	#DC143C,	#DC143C,	#DC143C)')
    .DefaultFontColor('255,255,255').title.Text('DESIST�NCIA').&End.Body.Text(desistencia)
    .&End.Footer.Text('Desist�ncia de uso do sistema em demostra��o').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    .HTML

    ).&End

    .WebBrowser(frmMonitorClientes.WbInstalacoes).CallbackJS.ClassProvider(Self).&End.Generated;

end;

procedure TDM.GeraGraficoVersaoAracati;
begin
  { Gera gr�fico das versoes em geral }
  WebGrafMP.NewProject.Rows.title.Config.H5
    ('Mapa das vers�es distribu�das nos clientes Command Aracati')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(horizontalBar)
    .Attributes.Name('GeraGraficoVersaoAracati').ColSpan(12).Heigth(180)
    .DataSet.textLabel('Aracati').DataSet(CdsGraficMP).&End.Options.Scales.Axes.xAxe.ScaleLabel.
    display(true).labelString('').&End.&End.yAxe.ScaleLabel.display(true).labelString('')
    .&End.&End.&End.&End.&End.&End.&End.&End.WebBrowser(frmmenu.WbVersaoAracati).Generated;
end;

procedure TDM.GeraGraficoVersaoLimoeiro;
begin
  { Gera gr�fico das versoes em geral }
  WebGrafMP.NewProject.Rows.title.Config.H5
    ('Mapa das vers�es distribu�das nos clientes Command Limoeiro do norte')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(horizontalBar)
    .Attributes.Name('GeraGraficoVersaoLimoeiro').ColSpan(12).Heigth(180)
    .DataSet.textLabel('Limoeiro do norte').DataSet(CdsGraficMP)
    .&End.Options.Scales.Axes.xAxe.ScaleLabel.display(true).labelString('')
    .&End.&End.yAxe.ScaleLabel.display(true).labelString('')
    .&End.&End.&End.&End.&End.&End.&End.&End.WebBrowser(frmmenu.WbVersaoLimoeiro).Generated;
end;

procedure TDM.GeraGraficoVersoesGeral;
begin
  { Gera gr�fico das versoes em geral }
  WebGrafMP.NewProject.Rows.title.Config.H5('Mapa das vers�es distribu�das nos clientes Command')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(horizontalBar)
    .Attributes.Name('GeraGraficoVersoesGeral').ColSpan(12).Heigth(180).DataSet.textLabel('Vers�es')
    .DataSet(CdsGraficMP).&End.Options.Scales.Axes.xAxe.ScaleLabel.display(true).labelString('')
    .&End.&End.yAxe.ScaleLabel.display(true).labelString('')
    .&End.&End.&End.&End.&End.&End.&End.&End.WebBrowser(frmmenu.WbVersaogeral).Generated;
end;

procedure TDM.GeraLembretesAutomaticosViaAgendamento(icodusu: Integer);

begin
  { Gera lembretes autom�ticos via agendamentos }

  with FDQConsulta do
  begin
    close;
    sql.clear;
    sql.add('  SELECT Mensagem,Somente_usuario_Visualizar FROM lembrete_dia_fixo_agenda d  WHERE cod_usu = :cod_usu  '
      + '  AND ( (dia_fixo = EXTRACT( day from  :dataatual ) ) OR ( d.dia_semana = :dia_semana) )   ');
    parambyname('cod_usu').asinteger := icodusu;
    parambyname('dataatual').asdatetime := date;
    parambyname('dia_semana').asinteger := DayOfTheWeek((date));
    open;
    first;
  end;
  while not FDQConsulta.eof do
  begin
    { Verifica se ja foi inserido alguma vez no banco de dados }
    with QFDQConsulta2 do
    begin
      close;
      sql.clear;
      sql.add('SELECT  a.cod_agenda  FROM  agenda a WHERE a.cod_colaborador =:cod_colaborador ' +
        ' and a.descricao = :descricao and data_agendamento = :data_agendamento ');
      parambyname('cod_colaborador').asinteger := icodusu;
      parambyname('descricao').asstring := FDQConsulta.fieldbyname('Mensagem').asstring;
      parambyname('data_agendamento').asdate := date;
      open

    end;

    if QFDQConsulta2.recordcount <= 0 then
    begin
      { insere no banco de dados }
      with FDQInsert do
      begin
        close;
        sql.clear;
        sql.add('  INSERT INTO agenda (descricao,cod_colaborador,data_agendamento, ' +
          ' data_hora_lancamento,cod_usu_lanc,hora_ini,hora_fin,cod_cli,cod_ponto_revenda,data_fin_agendamento,Somente_usuario_Visualizar) '
          + ' values  ' +
          ' (:descricao,:cod_colaborador,:data_agendamento,:data_hora_lancamento,:cod_usu_lanc,' +
          ' :hora_ini,:hora_fin,:cod_cli,:cod_ponto_revenda,:data_fin_agendamento,:Somente_usuario_Visualizar)  ');

        parambyname('cod_cli').asinteger := 0;
        parambyname('descricao').asstring :=
          UpperCase(FDQConsulta.fieldbyname('Mensagem').asstring);
        parambyname('data_agendamento').asdate := date;
        parambyname('data_fin_agendamento').asdatetime := date;
        parambyname('cod_colaborador').asinteger := icodusu;
        parambyname('cod_ponto_revenda').asinteger := DM.ipontoRevenda;
        parambyname('data_hora_lancamento').asdatetime := now;
        parambyname('cod_usu_lanc').asinteger := icodusu;
        parambyname('hora_ini').astime := strtotime('07:30:00');
        parambyname('hora_fin').astime := strtotime('17:30:00');

        parambyname('Somente_usuario_Visualizar').asstring :=
          (FDQConsulta.fieldbyname('Somente_usuario_Visualizar').asstring);

        execsql;
      end;
    end;

    FDQConsulta.next;
  end;

end;

procedure TDM.GeraListagemCertificadoMes(Tipo: string);
begin

  { Busca certificados }

  with DM.QCertificadosMes do
  begin
    close;
    sql.clear;
    sql.add('SELECT ' +
'  C.ID, ' +
'  C.RAZAO_EMP, ' +
'  C.NOME_FANTASIA, ' +
'  C.CIDADE, ' +
'  C.TELEFONE, ' +
'  C.CELULAR_CLI, ' +
'  C.EMAIL_CLI, ' +
'  C.CNPJ_CLI, ' +
'  C.TIPO, ' +
'  C.DATA_VAL_CERT_DIG, ' +
'  C.DATA_SINCR_DADOS, ' +
'  C.tipo_cliente, ' +
'  CO.NOME_COMERCIAL, ' +
'  CO.TELEFONE AS TELEFONE_CONTADOR, ' +
'  CO.EMAIL ' +
'FROM certificados C ' +
'JOIN ( ' +
'    SELECT ' +
'      CNPJ_CLI, ' +
'      MAX(CONCAT(DATE_FORMAT(DATA_VAL_CERT_DIG,' + quotedstr('%Y%m%d') + '), LPAD(ID, 12, ' + quotedstr('0') + '))) AS K ' +
'    FROM certificados ' +
'    WHERE DATA_VAL_CERT_DIG BETWEEN :DATAINI  AND :DATAFIN ' +
'    GROUP BY CNPJ_CLI ' +
') U ' +
'  ON U.CNPJ_CLI = C.CNPJ_CLI ' +
' AND U.K = CONCAT(DATE_FORMAT(C.DATA_VAL_CERT_DIG,' + quotedstr('%Y%m%d') + '), LPAD(C.ID, 12, ' + quotedstr('0') + ')) ' +
' ' +
'LEFT JOIN ( ' +
'  SELECT CNPJ_CLI, MAX(cod_cli) AS cod_cli ' +
'  FROM cliente ' +
'  GROUP BY CNPJ_CLI ' +
') CIU ON CIU.CNPJ_CLI = C.CNPJ_CLI ' +
' ' +
'LEFT JOIN ( ' +
'  SELECT CE1.* ' +
'  FROM contador_cliente CE1 ' +
'  INNER JOIN ( ' +
'    SELECT COD_CLIENTE, MAX(ID_REG) AS ID ' +
'    FROM contador_cliente ' +
'    GROUP BY COD_CLIENTE ' +
'  ) Ultimo ' +
'    ON CE1.COD_CLIENTE = Ultimo.COD_CLIENTE ' +
'   AND CE1.ID_REG     = Ultimo.ID ' +
') CE ON CE.COD_CLIENTE = CIU.cod_cli ' +
' ' +
'LEFT JOIN contador CO ON CO.ID_CONTADOR = CE.COD_CONTADOR ' +
' ' +
'ORDER BY C.DATA_VAL_CERT_DIG; '
);
      parambyname('DATAINI').asdatetime := frmmenu.EdtDataIni.date;
    parambyname('DATAFIN').asdatetime := frmmenu.EdtDataFin.date;
    open;
  end;

end;

function TDM.GetIP: string;
// --> Declare a Winsock na clausula uses da unit
var
  WSAData: TWSAData;
  HostEnt: PHostEnt;
  Name: string;
begin
  WSAStartup(2, WSAData);
  SetLength(Name, 255);
  Gethostname(Pansichar(Name), 255);
  SetLength(Name, StrLen(PChar(Name)));
  HostEnt := gethostbyname(Pansichar(Name));
  with HostEnt^ do
  begin
    Result := Format('%d.%d.%d.%d', [Byte(h_addr^[0]), Byte(h_addr^[1]), Byte(h_addr^[2]),
      Byte(h_addr^[3])]);
  end;
  WSACleanup;
end;

procedure TDM.GraficoMetaValores(ValorMeta, ValorAlcancado, ValorNovosClientes, ValorReativacao,
  ValorUpgrade, ValorFaltaMeta, cPercNovosClientes, cPercReativacoes, cUpgrades: string);
begin
  { gr�fico de valores da meta }

  WebGrafMP.Container(fluid).NewProject.Rows.title.Config.H5('>>>>INFORMA��ES SOBRE A META <<<<')
    .&End.&End.&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject
    { VALOR DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('VALOR DA META').&End.Body.Text(ValorMeta)
    .&End.Footer.Text('Valor que precisa ser obtido para a meta').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#8A2BE2').&End.&End.&End.&End

    { VALOR NOVOS CLIENTES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('NOVOS CLIENTES ' + cPercNovosClientes + '%').&End.Body.Text(ValorNovosClientes)
    .&End.Footer.Text('Valor obtido por meio de novos clientes').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#8A2BE2').&End.&End.&End.&End

    { VALOR REATIVA��O }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0000FF,#0000FF,#0000FF)').DefaultFontColor('255,255,255')
    .title.Text('REATIVA��ES ' + cPercReativacoes + '%').&End.Body.Text(ValorReativacao + '')
    .&End.Footer.Text('Valor obtido por meio de reativa��es').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { VALOR POR MEIO DE UPGRADES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('UPGRADES ' + cUpgrades + '%').&End.Body.Text(ValorUpgrade)
    .&End.Footer.Text('Valor obtido por meio de upgrades').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    { VALOR OBTIDO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('VALOR OBTIDO').&End.Body.Text(ValorAlcancado)
    .&End.Footer.Text('Valor obtido para a meta').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { VALOR QUE FALTA PARA A META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('VALOR PARA BATER A META').&End.Body.Text(ValorFaltaMeta)
    .&End.Footer.Text('VALOR QUE FALTA PARA BATER A META').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    .HTML

    ).&End

    .WebBrowser(FrmBoletimCommand.wbValoresMetas).CallbackJS.ClassProvider(Self).&End.Generated;

end;

procedure TDM.GraficoProcedimentos(cQtdClientesParaBaterMeta, idiasRestantesMeta, cPercAtigindo,
  cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta, cQtdClientesNovosMetaLimoeiro,
  cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara, cPercClientesNovosMetaAnoAnterior,
  cPercClientesPERDIDOSMetaAnoAnterior, CPercSaldoMetaAnoAnterior: string);
begin
  { Gera grafico de  boletim de metas }

  WebGrafMP.Container(fluid).NewProject.Rows.title.Config.H5('>>>>INFORMA��ES SOBRE A META <<<<')
    .&End.&End.&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject
    { QTD DE CLIENTES NECESSARIOS PARA ATINGIR A META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PARA META').&End.Body.Text(cQtdClientesParaBaterMeta)
    .&End.Footer.Text('Quantidade de clientes para atingir a meta').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#8A2BE2').&End.&End.&End.&End
    { DIAS RESTANTES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('DIAS RESTANTES ').&End.Body.Text(idiasRestantesMeta)
    .&End.Footer.Text('Dias restantes para o fim da meta').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#B22222').&End.&End.&End.&End
    { PORCENTAGEM ATINGIDA }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0000FF,#0000FF,#0000FF)').DefaultFontColor('255,255,255')
    .title.Text('PORCENTAGEM ATINGIDA').&End.Body.Text(cPercAtigindo + '%')
    .&End.Footer.Text('Porcentagem da meta j� atingida').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { CLIENTES NOVOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES NOVOS').&End.Body.Text(cQtdClientesNovosMeta)
    .&End.Footer.Text(cPercClientesNovosMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { CLIENTES PERDIDOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PERDIDOS').&End.Body.Text(cQtdClientesPERDIDOSMeta)
    .&End.Footer.Text(cPercClientesPERDIDOSMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { SALDO GANHO X PERDIDOS }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('SALDO CLIENTES').&End.Body.Text(CSaldoMeta)
    .&End.Footer.Text(CPercSaldoMetaAnoAnterior + '% Clientes referente ao periodo anterior')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End.HTML).&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject

    { CLIENTES CADASTRADOS LIMOEIRO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#7B68EE,#7B68EE,#7B68EE)').DefaultFontColor('255,255,255')
    .title.Text('LIMOEIRO').&End.Body.Text(cQtdClientesNovosMetaLimoeiro)
    .&End.Footer.Text('Clientes novos em Limoeiro durante a meta').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    { CLIENTES CADASTRADOS ARACATI }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#9370DB,#9370DB,#9370DB)').DefaultFontColor('255,255,255')
    .title.Text('ARACATI').&End.Body.Text(cQtdClientesNovosMetaAracati)
    .&End.Footer.Text('Clientes novos em Aracati durante a meta').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    { CLIENTES CADASTRADOS JERI }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#DDA0DD,#DDA0DD,#DDA0DD)').DefaultFontColor('255,255,255')
    .title.Text('JERICOACARA').&End.Body.Text(cQtdClientesNovosMetaJericoacara)
    .&End.Footer.Text('Clientes novos em Jericoacara durante a meta').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End

    .HTML

    ).&End

    .WebBrowser(FrmBoletimCommand.WbResultadoComercial).CallbackJS.ClassProvider(Self)
    .&End.Generated;
end;

procedure TDM.GraficoProcedimentosMes(cQtdClientesParaBaterMeta, idiasRestantesMeta, cPercAtigindo,
  cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta, cQtdClientesNovosMetaLimoeiro,
  cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara, cPercClientesNovosMetaAnoAnterior,
  cPercClientesPERDIDOSMetaAnoAnterior, CPercSaldoMetaAnoAnterior: string);
begin
  { Gera grafico de  boletim de metas por mes }

  WebGrafMP.Container(fluid).NewProject.Rows.title.Config.H5
    ('>>>>INFORMA��ES SOBRE A META MENSAL GERAL <<<<').&End.&End.&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject
    { QTD DE CLIENTES NECESSARIOS PARA ATINGIR A META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PARA META MENSAL').&End.Body.Text(cQtdClientesParaBaterMeta)
    .&End.Footer.Text('Quantidade de clientes para atingir a meta mensal')
    .&End.Shape.Icon('fa fa-user').Style.BackgroundColor('#8A2BE2').&End.&End.&End.&End
    { DIAS RESTANTES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('DIAS DO M�S RESTANTES ').&End.Body.Text(idiasRestantesMeta)
    .&End.Footer.Text('Dias restantes para o fim da meta mensal').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#B22222').&End.&End.&End.&End
    { PORCENTAGEM ATINGIDA }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0000FF,#0000FF,#0000FF)').DefaultFontColor('255,255,255')
    .title.Text('PORCENTAGEM ATINGIDA M�S').&End.Body.Text(cPercAtigindo + '%')
    .&End.Footer.Text('Porcentagem da meta j� atingida no m�s').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { CLIENTES NOVOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES NOVOS NO M�S').&End.Body.Text(cQtdClientesNovosMeta)
    .&End.Footer.Text(cPercClientesNovosMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { CLIENTES PERDIDOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PERDIDOS NO M�S').&End.Body.Text(cQtdClientesPERDIDOSMeta)
    .&End.Footer.Text(cPercClientesPERDIDOSMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { SALDO GANHO X PERDIDOS }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('SALDO CLIENTES NO M�S').&End.Body.Text(CSaldoMeta)
    .&End.Footer.Text(CPercSaldoMetaAnoAnterior + '% Clientes referente ao periodo anterior')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End.HTML).&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject

    { CLIENTES CADASTRADOS LIMOEIRO }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#7B68EE,#7B68EE,#7B68EE)').DefaultFontColor('255,255,255')
    .title.Text('LIMOEIRO').&End.Body.Text(cQtdClientesNovosMetaLimoeiro)
    .&End.Footer.Text('Clientes novos em Limoeiro durante a meta do m�s')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End

    { CLIENTES CADASTRADOS ARACATI }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#9370DB,#9370DB,#9370DB)').DefaultFontColor('255,255,255')
    .title.Text('ARACATI').&End.Body.Text(cQtdClientesNovosMetaAracati)
    .&End.Footer.Text('Clientes novos em Aracati durante a meta do m�s')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End

    { CLIENTES CADASTRADOS JERI }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#DDA0DD,#DDA0DD,#DDA0DD)').DefaultFontColor('255,255,255')
    .title.Text('JERICOACARA').&End.Body.Text(cQtdClientesNovosMetaJericoacara)
    .&End.Footer.Text('Clientes novos em Jericoacara durante a meta do m�s')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End

    .HTML

    ).&End

    .WebBrowser(FrmBoletimCommand.WBMetasMes).CallbackJS.ClassProvider(Self).&End.Generated;

end;

procedure TDM.GraficoProcedimentosMesAracati(cQtdClientesParaBaterMeta,

  idiasRestantesMeta, cPercAtigindo, cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta,
  cQtdClientesNovosMetaLimoeiro, cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara,
  cPercClientesNovosMetaAnoAnterior, cPercClientesPERDIDOSMetaAnoAnterior,
  CPercSaldoMetaAnoAnterior: string);
begin
  { Grafico Aracati }
  { Gera grafico de  boletim de metas por mes }

  WebGrafMP.Container(fluid).NewProject.Rows.title.Config.H5
    ('>>>>INFORMA��ES SOBRE A META ARACATI NO M�S <<<<').&End.&End.&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject
    { QTD DE CLIENTES NECESSARIOS PARA ATINGIR A META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PARA META MENSAL').&End.Body.Text(cQtdClientesParaBaterMeta)
    .&End.Footer.Text('Quantidade de clientes para atingir a meta mensal')
    .&End.Shape.Icon('fa fa-user').Style.BackgroundColor('#8A2BE2').&End.&End.&End.&End
    { DIAS RESTANTES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('DIAS DO M�S RESTANTES ').&End.Body.Text(idiasRestantesMeta)
    .&End.Footer.Text('Dias restantes para o fim da meta mensal').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#B22222').&End.&End.&End.&End
    { PORCENTAGEM ATINGIDA }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0000FF,#0000FF,#0000FF)').DefaultFontColor('255,255,255')
    .title.Text('PORCENTAGEM ATINGIDA M�S').&End.Body.Text(cPercAtigindo + '%')
    .&End.Footer.Text('Porcentagem da meta j� atingida no m�s').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { CLIENTES NOVOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES NOVOS NO M�S').&End.Body.Text(cQtdClientesNovosMeta)
    .&End.Footer.Text(cPercClientesNovosMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { CLIENTES PERDIDOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PERDIDOS NO M�S').&End.Body.Text(cQtdClientesPERDIDOSMeta)
    .&End.Footer.Text(cPercClientesPERDIDOSMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { SALDO GANHO X PERDIDOS }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('SALDO CLIENTES NO M�S').&End.Body.Text(CSaldoMeta)
    .&End.Footer.Text(CPercSaldoMetaAnoAnterior + '% Clientes referente ao periodo anterior')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End.HTML).&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject

    .HTML

    ).&End

    .WebBrowser(FrmBoletimCommand.WBMetasMesAracati).CallbackJS.ClassProvider(Self).&End.Generated;
end;

procedure TDM.GraficoProcedimentosMesLimoeiro(cQtdClientesParaBaterMeta, idiasRestantesMeta,
  cPercAtigindo, cQtdClientesNovosMeta, cQtdClientesPERDIDOSMeta, CSaldoMeta,
  cQtdClientesNovosMetaLimoeiro, cQtdClientesNovosMetaAracati, cQtdClientesNovosMetaJericoacara,
  cPercClientesNovosMetaAnoAnterior, cPercClientesPERDIDOSMetaAnoAnterior,
  CPercSaldoMetaAnoAnterior: string);
begin
  { Grafico limoeiro }
  { Gera grafico de  boletim de metas por mes }

  WebGrafMP.Container(fluid).NewProject.Rows.title.Config.H5
    ('>>>>INFORMA��ES SOBRE A META MENSAL LIMOEIRO <<<<').&End.&End.&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject
    { QTD DE CLIENTES NECESSARIOS PARA ATINGIR A META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PARA META MENSAL').&End.Body.Text(cQtdClientesParaBaterMeta)
    .&End.Footer.Text('Quantidade de clientes para atingir a meta mensal')
    .&End.Shape.Icon('fa fa-user').Style.BackgroundColor('#8A2BE2').&End.&End.&End.&End
    { DIAS RESTANTES }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('DIAS DO M�S RESTANTES ').&End.Body.Text(idiasRestantesMeta)
    .&End.Footer.Text('Dias restantes para o fim da meta mensal').&End.Shape.Icon('fa fa-user')
    .Style.BackgroundColor('#B22222').&End.&End.&End.&End
    { PORCENTAGEM ATINGIDA }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#0000FF,#0000FF,#0000FF)').DefaultFontColor('255,255,255')
    .title.Text('PORCENTAGEM ATINGIDA M�S').&End.Body.Text(cPercAtigindo + '%')
    .&End.Footer.Text('Porcentagem da meta j� atingida no m�s').&End.Shape.Icon('fa fa-user')
    .&End.&End.&End.HTML).&End.Jumpline.Rows.HTML(WebGrafMP.ContinuosProject

    { CLIENTES NOVOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#006600,#006600,#006600)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES NOVOS NO M�S').&End.Body.Text(cQtdClientesNovosMeta)
    .&End.Footer.Text(cPercClientesNovosMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { CLIENTES PERDIDOS NO PERIODO DA META }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#8B0000,#8B0000,#8B0000)').DefaultFontColor('255,255,255')
    .title.Text('CLIENTES PERDIDOS NO M�S').&End.Body.Text(cQtdClientesPERDIDOSMeta)
    .&End.Footer.Text(cPercClientesPERDIDOSMetaAnoAnterior +
    '% Clientes referente ao periodo anterior').&End.Shape.Icon('fa fa-user').&End.&End.&End

    { SALDO GANHO X PERDIDOS }
    .CardStyled.CardType(CardStyledIconBackground).Col(3)
    .BackgroundColor('linear-gradient(#4B0082,#4B0082,#4B0082)').DefaultFontColor('255,255,255')
    .title.Text('SALDO CLIENTES NO M�S').&End.Body.Text(CSaldoMeta)
    .&End.Footer.Text(CPercSaldoMetaAnoAnterior + '% Clientes referente ao periodo anterior')
    .&End.Shape.Icon('fa fa-user').&End.&End.&End.HTML).&End.Jumpline.Rows.HTML
    (WebGrafMP.ContinuosProject

    .HTML

    ).&End

    .WebBrowser(FrmBoletimCommand.WBMetasMesLimoeiro).CallbackJS.ClassProvider(Self).&End.Generated;
end;

procedure TDM.GraficoReceitasGanhasXReceitasPerdidas(Ganho, Perdido: currency);
begin
  { Gera grafico de receitas ganhas e receitas perdidas }
  DM.CdsGraficMP06.close;
  DM.CdsGraficMP06.IsEmpty;
  DM.CdsGraficMP06.open;

  while not DM.FDQConsulta.eof do
  begin
    DM.CdsGraficMP06.append;
    DM.CdsGraficMP06.fieldbyname('LABEL').Value := 'Receitas Ganhas R$ ' +
      currtostrf(Ganho, ffnumber, 2);
    DM.CdsGraficMP06.fieldbyname('VALUE').Value := currtostrf(Ganho, ffnumber, 2);
    DM.CdsGraficMP06.fieldbyname('RGB').Value := inttostr(0) + ',' + inttostr(128) + ',' +
      inttostr(0);
    DM.CdsGraficMP06.Post;

    DM.CdsGraficMP06.append;
    DM.CdsGraficMP06.fieldbyname('LABEL').Value := 'Receitas Perdidas R$ ' +
      currtostrf(Perdido, ffnumber, 2);
    DM.CdsGraficMP06.fieldbyname('VALUE').Value := currtostrf(Perdido, ffnumber, 2);
    DM.CdsGraficMP06.fieldbyname('RGB').Value := inttostr(128) + ',' + inttostr(0) + ',' +
      inttostr(0);
    DM.CdsGraficMP06.Post;

    DM.FDQConsulta.next;
  end;
  DM.CdsGraficMP06.first;

  { Gera gr�fico das versoes em geral }
  WebGrafMP.NewProject.Rows.title.Config.H5
    ('...Gr�fico das receitas ganhas x receitas perdidas durante  a meta...  ')
    .&End.&End.&End.Jumpline.Jumpline.charts._ChartType(bar)
    .Attributes.Name('Receitasganhasperdidas').ColSpan(12).Heigth(100).DataSet.textLabel('')
    .DataSet(CdsGraficMP06).&End.Options.Scales.Axes.xAxe.ScaleLabel.display(true).labelString('')
    .&End.&End.yAxe.ScaleLabel.display(true).labelString('')
    .&End.&End.&End.&End.&End.&End.&End.&End.WebBrowser(FrmBoletimCommand.WBReceitaGanhaPerdidaMeta)
    .Generated;
end;

procedure TDM.GravaIni(sArqIni, sSecao, sVariavel, sValor: string);
var
  ArqIni: tIniFile;
begin
  ArqIni := tIniFile.Create(ExtractFilePath(Application.ExeName) + '\' + sArqIni);

  try
    ArqIni.WriteString(sSecao, sVariavel, sValor);
  finally
    ArqIni.Free;
  end;
end;

procedure TDM.GravaLogdoATendimento(Observacao: string; icod_atendimento, iUsu: Integer);
begin
  with FDQInsert do
  begin
    close;
    sql.clear;
    sql.add(' INSERT INTO log_atendimento    ' +
      ' (cod_Atendimento,obs_atendimento,data_hora_log, cod_usu ) ' + ' VALUES  ' +
      ' (:cod_Atendimento,:obs_atendimento,:data_hora_log,:cod_usu)  ');
    parambyname('cod_Atendimento').asinteger := icod_atendimento;
    parambyname('obs_atendimento').asstring := UpperCase(Observacao);
    parambyname('data_hora_log').asdatetime := now;
    parambyname('cod_usu').asinteger := iUsu;
    execsql;
  end;
end;

procedure TDM.ImprimirDadosGrid(Grid: TcxGrid; DBTableView: TcxGridDBTableView; title: string);
var
  iOldDataRowHeight: Integer;
begin

  DPrnLink.Component := Grid; // liga com grid
  DPrnLink.OptionsFormatting.UseNativeStyles := true; // s� preto-branco
  DPrnLink.OptionsSize.AutoWidth := true; // ajusta � pagina
  DPrnLink.PrinterPage.MeasurementUnits := muMillimeters;
  // em milimetro (cada 1000 - 1milimetro)
  // configura visualiza��o
  with TdxGridReportLink(DPrnLink) do
  begin
    // no relat�rio
    OptionsView.Caption := false;
    OptionsView.Headers := true;
    OptionsView.Footers := true;
    OptionsView.GroupFooters := true;
    OptionsView.ExpandButtons := true;
    OptionsView.FilterBar := true;

    // em todas as p�ginas:
    OptionsOnEveryPage.Caption := true;
    OptionsOnEveryPage.Headers := true;
    OptionsOnEveryPage.Footers := false;
    OptionsOnEveryPage.FilterBar := false;
  end;

  // define tamanho da linha NA GRID
  iOldDataRowHeight := DBTableView.OptionsView.DataRowHeight;
  DBTableView.OptionsView.DataRowHeight := 15;

  // cabe�alho
  with DPrnLink.PrinterPage.PageHeader do
  begin
    LeftTitle.add('Command System ' + ' - 40.581.011/0001-27');
    LeftTitle.add(title);
    RightTitle.add(sNomeUsu + ' - ' + datetostr(date) + ' ' + TimeToStr(Time));
    LeftTextAlignY := taTop;
    RightTextAlignY := taTop;
    Font.Name := 'Times New Roman';
    Font.Size := 10;
  end;

  // rodap� de p�gina
  with DPrnLink.PrinterPage.PageFooter do
  begin
    RightTitle.add('Comamnd System');
    RightTextAlignY := taTop;
    Font.Name := 'Times New Roman';
    Font.Size := 6;
  end;

  // margens e papel
  DPrnLink.PrinterPage.Margins.Left := 7000;
  DPrnLink.PrinterPage.Margins.Right := 5000;
  DPrnLink.PrinterPage.Margins.Bottom := 10300;
  DPrnLink.PrinterPage.Margins.Top := 14800;
  DPrnLink.PrinterPage.DMPaper := DMPAPER_A4;

  // titulo do relat�rio
  CPPrinter.PreviewOptions.Caption := title;
  CPPrinter.PrintTitle := title;

  // preview
  CPPrinter.Preview;

  // volta tamanho normal
  DBTableView.OptionsView.DataRowHeight := iOldDataRowHeight;
end;

procedure TDM.InformarDesenvolvedor(codAtendimento, CodDesenvolvedor: Integer);
begin
  if CodDesenvolvedor > 0 then
  begin
    with FDQInsert do
    begin
      close;
      sql.clear;
      sql.add(' UPDATE atendimentos a SET cod_desenvolvedor = :cod_desenvolvedor  ' +
        ' WHERE a.id_Atend = :id_Atend  ');
      parambyname('id_Atend').asinteger := codAtendimento;
      parambyname('cod_desenvolvedor').asinteger := CodDesenvolvedor;
      execsql;
    end;
  end
  else
  begin
    with FDQInsert do
    begin
      close;
      sql.clear;
      sql.add(' UPDATE atendimentos a SET cod_desenvolvedor = null  ' +
        ' WHERE a.id_Atend = :id_Atend  ');
      parambyname('id_Atend').asinteger := codAtendimento;
      execsql;
    end;
  end;
end;

function TDM.IsBisexto(const ano: word): boolean;
begin
  Result := (ano mod 4 = 0) and ((ano mod 100 <> 0) or (ano mod 400 = 0));
end;

function TDM.LeIni(sArqIni, sSecao, sVariavel: string): string;
var
  ArqIni: tIniFile;
  sString: string;
begin
  ArqIni := tIniFile.Create(ExtractFilePath(Application.ExeName) + '\' + sArqIni);

  try
    Result := ArqIni.ReadString(sSecao, sVariavel, sString);
  finally
    ArqIni.Free;
  end;
end;

function TDM.Mensagem(iTipoMensagem, iTag: Integer; sMensagem, sTitulo, sBotaoFoco: string)
  : boolean;
var
  iMostrar, okCancelar: Integer;
begin
  iMostrar := 0; // Define se mostra tela de confirma��o
  okCancelar := 0; // Define qual o bot�o pressionado na �ltima vez

  Application.CreateForm(TFrmMensagemPadrao, FrmMensagemPadrao);
  FrmMensagemPadrao.Tag := iTag;

  try
    iMostrar := StrToInt(DM.LeIni('command.ini', 'NaoMostrarNovamente',
      inttostr(FrmMensagemPadrao.Tag) + '.Mostrar'));
  except
    iMostrar := 0;
  end;

  try
    okCancelar := StrToInt(DM.LeIni('command.ini', 'NaoMostrarNovamente',
      inttostr(FrmMensagemPadrao.Tag) + '.Botao'));
  except
    okCancelar := 0;
  end;

  if iMostrar = 0 then
  begin

    FrmMensagemPadrao.iTipoMensagem := iTipoMensagem;
    FrmMensagemPadrao.sMensagem := sMensagem;
    FrmMensagemPadrao.sTituloMensagem := sTitulo;
    if sBotaoFoco = '' then
      sBotaoFoco := 'S';
    // FrmMensagemPadrao.sbtnFoco := sBotaoFoco;
    FrmMensagemPadrao.ShowModal;

    Result := bConfirmar;
  end
  else
  begin
    if okCancelar = 1 then
      Result := true
    else
      Result := false;
  end;
end;

function TDM.mesAno(mes: Integer): string;
begin
  case mes of
    1:
      Result := 'JAN';
    2:
      Result := 'FEV';
    3:
      Result := 'MAR';
    4:
      Result := 'ABR';
    5:
      Result := 'MAI';
    6:
      Result := 'JUN';
    7:
      Result := 'JUL';
    8:
      Result := 'AGOS';
    9:
      Result := 'SET';
    10:
      Result := 'OUT';
    11:
      Result := 'NOV';
    12:
      Result := 'DEZ';
  end;
end;

function TDM.MinutosEmHoras(Minutos: Integer): String;

var
  HoraDecimal, HH, MM: String;
begin
  if Minutos > 1440 then
    Minutos := Minutos - 1440;
  HoraDecimal := FormatFloat('00.00', Minutos / 60);
  HH := Copy(HoraDecimal, 1, 2);
  MM := Copy(HoraDecimal, 4, 2);
  Result := HH + ':' + MM;
end;

procedure TDM.NotificacaoGEralWindowsS(Name, sTutulo, SAlerta: String);
var
  MyNotification: TNotification;
begin
  MyNotification := NotificationCenter1.CreateNotification;
  try
    MyNotification.Name := Name;
    MyNotification.title := sTutulo;
    MyNotification.AlertBody := SAlerta;

    NotificationCenter1.PresentNotification(MyNotification);

  finally
    MyNotification.Free;

  end;
end;

procedure TDM.NotificationAtendimentos(iCodAtendimento: Integer; SName, sTutulo, SAlerta: String);
var
  MyNotification: TNotification;
begin

  { Verifica se o Atendimento Foi Notificado }
  try
    if Trim(DM.LeIni('Notification.ini', 'Atendimentos', inttostr(iCodAtendimento))) = 'S' then
    begin

    end
    else
    begin
      MyNotification := NotificationCenter1.CreateNotification;
      try
        MyNotification.Name := SName;
        MyNotification.title := sTutulo;
        MyNotification.AlertBody := SAlerta;

        NotificationCenter1.PresentNotification(MyNotification);
        DM.GravaIni('Notification.ini', 'Atendimentos', inttostr(iCodAtendimento), 'S')
      finally
        MyNotification.Free;

      end;

    end;

    if Trim(DM.LeIni('Notification.ini', 'Desenvolvimento', inttostr(iCodAtendimento))) = 'S' then
    begin

    end
    else
    begin
      MyNotification := NotificationCenter1.CreateNotification;
      try
        MyNotification.Name := SName;
        MyNotification.title := sTutulo;
        MyNotification.AlertBody := SAlerta;

        NotificationCenter1.PresentNotification(MyNotification);
        DM.GravaIni('Notification.ini', 'Desenvolvimento', inttostr(iCodAtendimento), 'S')
      finally
        MyNotification.Free;

      end;

    end;

    if Trim(DM.LeIni('Notification.ini', 'Testes', inttostr(iCodAtendimento))) = 'S' then
    begin

    end
    else
    begin
      MyNotification := NotificationCenter1.CreateNotification;
      try
        MyNotification.Name := SName;
        MyNotification.title := sTutulo;
        MyNotification.AlertBody := SAlerta;

        NotificationCenter1.PresentNotification(MyNotification);
        DM.GravaIni('Notification.ini', 'Testes', inttostr(iCodAtendimento), 'S')
      finally
        MyNotification.Free;

      end;

    end;

  except

  end;

end;

procedure TDM.poClick(Sender: TObject);
begin
  DM.CopiarValorCelulaGrid(frmmenu.cxGContadorClienteDBTableView1);
end;

procedure TDM.QCertificadosMesCalcFields(DataSet: TDataSet);
begin
  if date >= QCertificadosMesDATA_VAL_CERT_DIG.asdatetime then
  begin
    QCertificadosMesCALC_DIA_CERT.asstring := 'VENCIDO - ' + RetornaMesMaisAnoPorNumeroDias
      (DaysBetween(now, QCertificadosMesDATA_VAL_CERT_DIG.asdatetime));
  end
  ELSE
  BEGIN
    QCertificadosMesCALC_DIA_CERT.asstring := 'A VENCER - ' + RetornaMesMaisAnoPorNumeroDias
      (DaysBetween(now, QCertificadosMesDATA_VAL_CERT_DIG.asdatetime));
  END;
end;

function TDM.RemoveChar(const Texto: string): string;
var
  i: Integer;
  s: string;
begin
  s := EmptyStr;

  for i := 1 to length(Texto) do
  begin
    if CharInSet(Texto[i], ['0' .. '9']) then
    begin
      s := s + Copy(Texto, i, 1);
    end;
  end;

  Result := s;
end;

function TDM.RetornaMesMaisAnoPorNumeroDias(idias: currency): string;
var
  cMes, iMes: currency;
begin
  { Retorna meses + anos de uma opera��o }
  cMes := 0;
  iMes := MONTHSBetween(date, (date - idias));

  if idias <= 30 then
  begin
    Result := currtostr(idias) + ' DIAS'
  end
  else
  begin
    If iMes <= 12 then
    begin
      if iMes = 1 then
      begin
        Result := currtostr(iMes) + ' M�S';
      end
      else
      begin
        Result := currtostr(iMes) + ' MESES';
      end;

    end
    ELSE if iMes > 12 then
    begin
      cMes := strtofloat(FormatFloat(',0.0', ((iMes) / 12)));
      Result := currtostr(cMes) + ' ANOS'
    end;
  end;
end;

function TDM.ShowAlertWindow(Titulo, Mensagem: string; ImageIndex: Integer; ProcedureClick: TProc;
  Tag, DisplayTime: Integer): TdxAlertWindow;
var
  alert: TdxAlertWindow;
begin
  alert := dxAlertWindowManager.Show(Titulo, Mensagem, ImageIndex);
  alert.OptionsBehavior.DisplayTime := DisplayTime;
  alert.RestartDisplayTimer;

  if Tag > 0 then
    alert.Tag := Tag;

  Result := alert;
end;

function TDM.ValidaCNPJ(s: string): string;
begin
  if (Trim(RemoveChar(s)) = EmptyStr) or (Trim(RemoveChar(s)) = '   .   .   -  ') then
  begin
    Result := '';
    exit;
  end
  else
  begin
    ACBrValidador.TipoDocto := docCNPJ;
    ACBrValidador.Documento := Trim(s);
    if ACBrValidador.Validar then
      Result := ''
    else
      Result := ACBrValidador.MsgErro;
  end;
end;

function TDM.ValidaCPF(num: string): string;
begin
  if (Trim(RemoveChar(num)) = EmptyStr) or (Trim(RemoveChar(num)) = '   .   .   -  ') then
  begin
    Result := '';
    exit;
  end
  else
  begin
    ACBrValidador.TipoDocto := docCPF;
    ACBrValidador.Documento := Trim(num);
    if ACBrValidador.Validar then
      Result := ''
    else
      Result := ACBrValidador.MsgErro;
  end
end;

function TDM.ValidaEmail(s: String): string;
begin
  if (Trim(RemoveChar(s)) = EmptyStr) or (Trim(RemoveChar(s)) = '   .   .   -  ') then
  begin
    Result := '';
    exit;
  end
  else
  begin
    ACBrValidador.TipoDocto := docEmail;
    ACBrValidador.Documento := Trim(s);
    if ACBrValidador.Validar then
      Result := ''
    else
      Result := ACBrValidador.MsgErro;
  end;
end;

function TDM.VerificaHoraExtra(Data: tdate; Hora: ttime): boolean;
begin
  if dayofweek(Data) = 7 then
  begin
    if (Hora >= strtotime('12:00:00')) then
      Result := true
    else
      Result := false;
  end;

  if dayofweek(Data) = 1 then
  begin
    Result := true;
  end;

  if (dayofweek(Data) > 1) and (dayofweek(Data) < 7) then
  begin
    if (Hora >= strtotime('12:00:00')) and (Hora <= strtotime('14:00:00')) then
      Result := true
    else if (Hora >= strtotime('17:30:00')) then
      Result := true
    else
      Result := false;

  end;

end;

end.
