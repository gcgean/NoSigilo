unit UFuncionalidadesPlano;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async,
  FireDAC.DApt, Data.DB, FireDAC.Comp.DataSet, FireDAC.Comp.Client, Vcl.Grids, Vcl.DBGrids;

type
  TFrmFuncionalidadesPlano = class(TForm)
    QFunc: TFDQuery;
    QFuncid: TFDAutoIncField;
    QFuncid_plano: TIntegerField;
    QFuncfuncionalidade: TStringField;
    QFuncdesc_funcionalidade: TStringField;
    QFuncdestacar: TIntegerField;
    QFuncDESC_DESTACAR: TStringField;
    DSFunc: TDataSource;
    DBGFuncionalidades: TDBGrid;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormShow(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
  public
    IDPlano: Integer;
  end;

var
  FrmFuncionalidadesPlano: TFrmFuncionalidadesPlano;

implementation

uses
  UDM;

{$R *.dfm}

procedure TFrmFuncionalidadesPlano.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
end;

procedure TFrmFuncionalidadesPlano.FormCreate(Sender: TObject);
begin
  IDPlano := 0;
end;

procedure TFrmFuncionalidadesPlano.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key = vk_escape then
    close;
end;

procedure TFrmFuncionalidadesPlano.FormShow(Sender: TObject);
begin
  Self.Align := alClient;

  QFunc.close;
  QFunc.parambyname('id_plano').asinteger := IDPlano;
  QFunc.open;
  QFunc.disablecontrols;

  try
    QFunc.last;
    QFunc.first;
  finally
    QFunc.enablecontrols;
  end;
end;

end.
