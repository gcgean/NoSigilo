unit ULogAssinaturaCliente;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, cxGraphics, cxControls, cxLookAndFeels,
  cxLookAndFeelPainters, cxStyles, cxCustomData, cxFilter, cxData, cxDataStorage, cxEdit,
  cxNavigator, dxDateRanges, cxDataControllerConditionalFormattingRulesManagerDialog, Data.DB,
  cxDBData, cxGridLevel, cxClasses, cxGridCustomView, cxGridCustomTableView, cxGridTableView,
  cxGridDBTableView, cxGrid, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async,
  FireDAC.DApt, FireDAC.Comp.DataSet, FireDAC.Comp.Client;

type
  TFrmLogAssinaturaCliente = class(TForm)
    GLog: TcxGrid;
    GLogDBTableView: TcxGridDBTableView;
    GLogLevel: TcxGridLevel;
    QLog: TFDQuery;
    QLogorigem_log: TStringField;
    QLogdata_hora: TSQLTimeStampField;
    QLogtipo: TIntegerField;
    QLogdesc_tipo: TStringField;
    QLognome_usuario: TStringField;
    QLogid_plano_anterior: TIntegerField;
    QLogdesc_plano_anterior: TStringField;
    QLogqtd_plano_anterior: TIntegerField;
    QLogvalor_plano_anterior: TFMTBCDField;
    QLogvalor_total_plano_anterior: TFMTBCDField;
    QLogvalor_assinatura_anterior: TFMTBCDField;
    QLogid_plano_atual: TIntegerField;
    QLogdesc_plano_atual: TStringField;
    QLogqtd_plano_atual: TIntegerField;
    QLogvalor_plano_atual: TFMTBCDField;
    QLogvalor_total_plano_atual: TFMTBCDField;
    QLogvalor_assinatura_atual: TFMTBCDField;
    DSLog: TDataSource;
    QLogid: TFDAutoIncField;
    GLogDBTableVieworigem_log: TcxGridDBColumn;
    GLogDBTableViewdata_hora: TcxGridDBColumn;
    GLogDBTableViewdesc_tipo: TcxGridDBColumn;
    GLogDBTableViewnome_usuario: TcxGridDBColumn;
    GLogDBTableViewdesc_plano_anterior: TcxGridDBColumn;
    GLogDBTableViewqtd_plano_anterior: TcxGridDBColumn;
    GLogDBTableViewvalor_plano_anterior: TcxGridDBColumn;
    GLogDBTableViewvalor_total_plano_anterior: TcxGridDBColumn;
    GLogDBTableViewvalor_assinatura_anterior: TcxGridDBColumn;
    GLogDBTableViewdesc_plano_atual: TcxGridDBColumn;
    GLogDBTableViewqtd_plano_atual: TcxGridDBColumn;
    GLogDBTableViewvalor_plano_atual: TcxGridDBColumn;
    GLogDBTableViewvalor_total_plano_atual: TcxGridDBColumn;
    GLogDBTableViewvalor_assinatura_atual: TcxGridDBColumn;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormShow(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
  public
    FCodigoCliente: Integer;
  end;

var
  FrmLogAssinaturaCliente: TFrmLogAssinaturaCliente;

implementation

uses
  UDM;

{$R *.dfm}

procedure TFrmLogAssinaturaCliente.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
  FrmLogAssinaturaCliente := nil;
end;

procedure TFrmLogAssinaturaCliente.FormCreate(Sender: TObject);
begin
  FCodigoCliente := 0;
end;

procedure TFrmLogAssinaturaCliente.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key = VK_ESCAPE then
    Close;
end;

procedure TFrmLogAssinaturaCliente.FormShow(Sender: TObject);
begin
  QLog.Close;
  QLog.ParamByName('ID_CLI').AsInteger := FCodigoCliente;
  QLog.Open;
  QLog.First;

  GLog.SetFocus;
end;

end.
