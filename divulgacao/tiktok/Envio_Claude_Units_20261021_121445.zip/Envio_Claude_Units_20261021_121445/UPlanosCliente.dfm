object FrmPlanosCliente: TFrmPlanosCliente
  Left = 0
  Top = 0
  Caption = 'Controle de Assinatura do Cliente'
  ClientHeight = 559
  ClientWidth = 1069
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -13
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  OnCreate = FormCreate
  OnKeyDown = FormKeyDown
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 16
  object PnCliente: TPanel
    Left = 0
    Top = 0
    Width = 1069
    Height = 41
    Align = alTop
    BevelOuter = bvNone
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
  end
  object Panel1: TPanel
    Left = 0
    Top = 412
    Width = 1069
    Height = 147
    Align = alBottom
    BevelOuter = bvNone
    TabOrder = 1
    DesignSize = (
      1069
      147)
    object Label1: TLabel
      Left = 85
      Top = 23
      Width = 97
      Height = 19
      Caption = 'Valor Total:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label2: TLabel
      Left = 16
      Top = 63
      Width = 166
      Height = 19
      Caption = 'Valor da Assinatura:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clNavy
      Font.Height = -16
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object EdtValorTotal: TcxCurrencyEdit
      Left = 192
      Top = 19
      EditValue = 0.000000000000000000
      ParentFont = False
      Properties.ReadOnly = True
      Style.Font.Charset = DEFAULT_CHARSET
      Style.Font.Color = clWindowText
      Style.Font.Height = -16
      Style.Font.Name = 'Tahoma'
      Style.Font.Style = [fsBold]
      Style.IsFontAssigned = True
      TabOrder = 0
      Width = 225
    end
    object EdtValorAssinatura: TcxCurrencyEdit
      Left = 192
      Top = 60
      EditValue = 0.000000000000000000
      ParentFont = False
      Style.Font.Charset = DEFAULT_CHARSET
      Style.Font.Color = clNavy
      Style.Font.Height = -16
      Style.Font.Name = 'Tahoma'
      Style.Font.Style = [fsBold]
      Style.IsFontAssigned = True
      TabOrder = 1
      Width = 225
    end
    object BtnOK: TButton
      Left = 840
      Top = 26
      Width = 209
      Height = 57
      Anchors = [akTop, akRight]
      Caption = 'Confirmar'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 2
      OnClick = BtnOKClick
    end
    object CheckValor: TCheckBox
      Left = 440
      Top = 24
      Width = 361
      Height = 41
      Caption = 
        'Recalcular o valor do campo "Valor da Assinatura" ao efetuar alt' +
        'era'#231#245'es nos planos/m'#243'dulos'
      TabOrder = 3
      WordWrap = True
      OnClick = CheckValorClick
    end
    object EdtObservacaoVenda: TLabeledEdit
      Left = 192
      Top = 104
      Width = 753
      Height = 24
      CharCase = ecUpperCase
      EditLabel.Width = 140
      EditLabel.Height = 16
      EditLabel.Caption = 'Observa'#231#245'es de Venda: '
      LabelPosition = lpLeft
      MaxLength = 200
      TabOrder = 4
    end
  end
  object GPlanos: TcxGrid
    Left = 0
    Top = 41
    Width = 1069
    Height = 371
    Align = alClient
    BorderStyle = cxcbsNone
    PopupMenu = PopupPlano
    TabOrder = 2
    OnEnter = GPlanosEnter
    OnExit = GPlanosExit
    LockedStateImageOptions.Text = 'Por favor aguarde...'
    LookAndFeel.Kind = lfUltraFlat
    LookAndFeel.NativeStyle = True
    LookAndFeel.ScrollbarMode = sbmDefault
    LookAndFeel.SkinName = ''
    object GPlanosDBTableView: TcxGridDBTableView
      OnKeyDown = GPlanosDBTableViewKeyDown
      Navigator.Buttons.CustomButtons = <>
      Navigator.Buttons.First.Visible = True
      Navigator.Buttons.PriorPage.Visible = False
      Navigator.Buttons.Prior.Visible = True
      Navigator.Buttons.Next.Visible = True
      Navigator.Buttons.NextPage.Visible = False
      Navigator.Buttons.Last.Visible = True
      Navigator.Buttons.Insert.Visible = False
      Navigator.Buttons.Append.Visible = False
      Navigator.Buttons.Delete.Visible = False
      Navigator.Buttons.Edit.Visible = False
      Navigator.Buttons.Post.Visible = False
      Navigator.Buttons.Cancel.Enabled = False
      Navigator.Buttons.Cancel.Visible = False
      Navigator.Buttons.Refresh.Visible = False
      Navigator.Buttons.SaveBookmark.Visible = False
      Navigator.Buttons.GotoBookmark.Visible = False
      Navigator.Buttons.Filter.Visible = True
      Navigator.InfoPanel.DisplayMask = '[RecordIndex] de [RecordCount]'
      FindPanel.InfoText = 'Digite um texto para pesquisar...'
      OnCustomDrawCell = GPlanosDBTableViewCustomDrawCell
      OnEditKeyDown = GPlanosDBTableViewEditKeyDown
      DataController.DataSource = DSPlanos
      DataController.DetailKeyFieldNames = 'None selected'
      DataController.Filter.AutoDataSetFilter = True
      DataController.KeyFieldNames = 'ID'
      DataController.Summary.DefaultGroupSummaryItems = <>
      DataController.Summary.FooterSummaryItems = <>
      DataController.Summary.SummaryGroups = <>
      FilterRow.InfoText = 'Clique aqui para definir um filtro'
      NewItemRow.InfoText = 'Clique aqui para adicionar uma nova linha'
      OptionsBehavior.ImmediateEditor = False
      OptionsCustomize.ColumnsQuickCustomization = True
      OptionsData.Deleting = False
      OptionsData.Inserting = False
      OptionsView.NoDataToDisplayInfoText = '<Nenhum registro para exibir>'
      OptionsView.GroupByBox = False
      OptionsView.HeaderFilterButtonShowMode = fbmSmartTag
      OptionsView.Indicator = True
      OptionsView.ShowColumnFilterButtons = sfbWhenSelected
      object GPlanosDBTableViewSELEC: TcxGridDBColumn
        DataBinding.FieldName = 'SELEC'
        PropertiesClassName = 'TcxCheckBoxProperties'
        Properties.ImmediatePost = True
        Properties.OnValidate = GPlanosDBTableViewSELECPropertiesValidate
        Width = 48
      end
      object GPlanosDBTableViewID: TcxGridDBColumn
        DataBinding.FieldName = 'ID'
        Options.Editing = False
        Width = 64
      end
      object GPlanosDBTableViewDESCRICAO: TcxGridDBColumn
        DataBinding.FieldName = 'DESCRICAO'
        Options.Editing = False
        Width = 250
      end
      object GPlanosDBTableViewMODULO: TcxGridDBColumn
        DataBinding.FieldName = 'MODULO'
        Options.Editing = False
        Width = 70
      end
      object GPlanosDBTableViewVALOR: TcxGridDBColumn
        DataBinding.FieldName = 'VALOR'
        PropertiesClassName = 'TcxCurrencyEditProperties'
        Properties.AssignedValues.MinValue = True
        Properties.DecimalPlaces = 2
        Properties.DisplayFormat = ',#0.00'
        Properties.OnValidate = GPlanosDBTableViewVALORPropertiesValidate
        Width = 100
      end
      object GPlanosDBTableViewVALOR_PLANO: TcxGridDBColumn
        DataBinding.FieldName = 'VALOR_PLANO'
        Options.Editing = False
        Width = 100
      end
      object GPlanosDBTableViewQTD: TcxGridDBColumn
        DataBinding.FieldName = 'QTD'
        PropertiesClassName = 'TcxCurrencyEditProperties'
        Properties.AssignedValues.DisplayFormat = True
        Properties.AssignedValues.MinValue = True
        Properties.DecimalPlaces = 0
        Properties.OnValidate = GPlanosDBTableViewQTDPropertiesValidate
        Width = 64
      end
      object GPlanosDBTableViewQTD_LIBERADA: TcxGridDBColumn
        DataBinding.FieldName = 'QTD_LIBERADA'
        PropertiesClassName = 'TcxCurrencyEditProperties'
        Properties.AssignedValues.DisplayFormat = True
        Properties.AssignedValues.MinValue = True
        Properties.DecimalPlaces = 0
        Properties.OnValidate = GPlanosDBTableViewQTD_LIBERADAPropertiesValidate
        Width = 123
      end
      object GPlanosDBTableViewVALOR_TOTAL: TcxGridDBColumn
        DataBinding.FieldName = 'VALOR_TOTAL'
        PropertiesClassName = 'TcxCurrencyEditProperties'
        Properties.AssignedValues.MinValue = True
        Properties.DecimalPlaces = 2
        Properties.DisplayFormat = ',#0.00'
        Options.Editing = False
        Width = 100
      end
      object GPlanosDBTableViewVALOR_TOTAL_PLANO: TcxGridDBColumn
        DataBinding.FieldName = 'VALOR_TOTAL_PLANO'
        Options.Editing = False
        Width = 124
      end
    end
    object GPlanosLevel: TcxGridLevel
      GridView = GPlanosDBTableView
    end
  end
  object MTPlanos: TFDMemTable
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    Left = 184
    Top = 152
    object MTPlanosSELEC: TBooleanField
      DisplayLabel = 'Selec.'
      FieldName = 'SELEC'
    end
    object MTPlanosID: TIntegerField
      DisplayLabel = 'C'#243'digo'
      FieldName = 'ID'
    end
    object MTPlanosDESCRICAO: TStringField
      DisplayLabel = 'Descri'#231#227'o'
      FieldName = 'DESCRICAO'
      Size = 255
    end
    object MTPlanosMODULO: TBooleanField
      DisplayLabel = #201' M'#243'dulo?'
      FieldName = 'MODULO'
    end
    object MTPlanosVALOR: TFMTBCDField
      DisplayLabel = 'Valor'
      FieldName = 'VALOR'
      DisplayFormat = ',#0.00'
      Precision = 18
      Size = 2
    end
    object MTPlanosQTD_ACIMA: TIntegerField
      DisplayLabel = 'Qtd. Acima'
      FieldName = 'QTD_ACIMA'
    end
    object MTPlanosVALOR_QTD: TFMTBCDField
      DisplayLabel = 'Valor Por Qtd.'
      FieldName = 'VALOR_QTD'
      DisplayFormat = ',#0.00'
      Precision = 18
      Size = 2
    end
    object MTPlanosQTD: TIntegerField
      DisplayLabel = 'Qtd.'
      FieldName = 'QTD'
    end
    object MTPlanosVALOR_TOTAL: TFMTBCDField
      DisplayLabel = 'Valor Total'
      FieldName = 'VALOR_TOTAL'
      DisplayFormat = ',#0.00'
      Precision = 18
      Size = 2
    end
    object MTPlanosVALOR_PLANO: TFMTBCDField
      DisplayLabel = 'Valor do Plano'
      FieldName = 'VALOR_PLANO'
      DisplayFormat = ',#0.00'
      Precision = 18
      Size = 2
    end
    object MTPlanosVALOR_TOTAL_PLANO: TFMTBCDField
      DisplayLabel = 'Valor Total do Plano'
      FieldName = 'VALOR_TOTAL_PLANO'
      DisplayFormat = ',#0.00'
      Precision = 18
      Size = 2
    end
    object MTPlanosTAMANHO_MAX_NUVEM: TIntegerField
      FieldName = 'TAMANHO_MAX_NUVEM'
    end
    object MTPlanosQTD_GRATIS: TIntegerField
      FieldName = 'QTD_GRATIS'
    end
    object MTPlanosQTD_LIBERADA: TIntegerField
      DisplayLabel = 'Qtd. Liberada Gr'#225'tis'
      FieldName = 'QTD_LIBERADA'
    end
  end
  object DSPlanos: TDataSource
    DataSet = MTPlanos
    Left = 248
    Top = 152
  end
  object QPlanos: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      'select'
      #9'pl.*'
      'from'
      #9'('
      #9'select'
      #9#9'false selec,'
      #9#9'p.id ,'
      #9#9'p.descricao ,'
      #9#9'p.modulo ,'#9#9#9
      #9#9'case'
      
        #9#9#9'when (coalesce((select vsp.valor from valores_segmentos_plano' +
        ' vsp '
      
        #9#9#9'where vsp.id_plano = p.id and vsp.segmento = (select dgc.SEGU' +
        'IMENTO from dados_gerais_clientes dgc '
      #9#9#9'where dgc.COD_CLI = :id_cli'
      #9#9#9'order by dgc.DATA_SINCR_DADOS desc'
      #9#9#9'limit 1) limit 1), 0) > 0) then (('
      #9#9#9'select'
      #9#9#9#9'vsp.valor'
      #9#9#9'from'
      #9#9#9#9'valores_segmentos_plano vsp'
      #9#9#9'where'
      #9#9#9#9'vsp.id_plano = p.id'
      #9#9#9#9'and vsp.segmento = ('
      #9#9#9#9'select'
      #9#9#9#9#9'dgc.SEGUIMENTO'
      #9#9#9#9'from'
      #9#9#9#9#9'dados_gerais_clientes dgc'
      #9#9#9#9'where'
      #9#9#9#9#9'dgc.COD_CLI = :id_cli'
      #9#9#9#9'order by'
      #9#9#9#9#9'dgc.DATA_SINCR_DADOS desc'
      #9#9#9#9'limit 1)'
      #9#9#9'limit 1))'
      #9#9#9'else (p.valor)'
      #9#9'end valor,'
      #9#9'case'
      
        #9#9#9'when (coalesce((select vsp.valor from valores_segmentos_plano' +
        ' vsp '
      
        #9#9#9'where vsp.id_plano = p.id and vsp.segmento = (select dgc.SEGU' +
        'IMENTO from dados_gerais_clientes dgc '
      #9#9#9'where dgc.COD_CLI = :id_cli'
      #9#9#9'order by dgc.DATA_SINCR_DADOS desc'
      #9#9#9'limit 1) limit 1), 0) > 0) then (('
      #9#9#9'select'
      #9#9#9#9'vsp.valor'
      #9#9#9'from'
      #9#9#9#9'valores_segmentos_plano vsp'
      #9#9#9'where'
      #9#9#9#9'vsp.id_plano = p.id'
      #9#9#9#9'and vsp.segmento = ('
      #9#9#9#9'select'
      #9#9#9#9#9'dgc.SEGUIMENTO'
      #9#9#9#9'from'
      #9#9#9#9#9'dados_gerais_clientes dgc'
      #9#9#9#9'where'
      #9#9#9#9#9'dgc.COD_CLI = :id_cli'
      #9#9#9#9'order by'
      #9#9#9#9#9'dgc.DATA_SINCR_DADOS desc'
      #9#9#9#9'limit 1)'
      #9#9#9'limit 1))'
      #9#9#9'else (p.valor)'
      #9#9'end valor_plano,'
      #9#9'coalesce(p.qtd_acima, 0) qtd_acima,'
      #9#9'coalesce(p.valor_qtd, 0.00) valor_qtd,'
      #9#9'0 qtd,'
      #9#9'coalesce(p.qtd_gratis, 0) qtd_liberada,'
      #9#9'0.00 valor_total,'#9#9
      #9#9'0.00 valor_total_plano,'
      #9#9'p.tamanho_max_nuvem,'
      #9#9'p.qtd_gratis'
      #9'from'
      #9#9'planos p'
      #9'where'
      #9#9'p.ativo = true'
      #9#9'and '
      #9#9'p.id not in ('
      #9#9'select'
      #9#9#9'cp.id_plano'
      #9#9'from'
      #9#9#9'cliente_planos cp'
      #9#9'where'
      #9#9#9'cp.id_cli = :id_cli)'
      'union all'
      #9'select'
      #9#9'true selec,'
      #9#9'cp2.id_plano ,'
      #9#9'p2.descricao ,'
      #9#9'p2.modulo ,'
      #9#9'cp2.valor ,'
      #9#9'p2.valor valor_plano,'
      #9#9'coalesce(p2.qtd_acima, 0) qtd_acima,'
      #9#9'coalesce(p2.valor_qtd, 0.00) valor_qtd,'
      #9#9'cp2.qtd,'
      #9#9'cp2.qtd_liberada,'
      #9#9'cp2.valor_total,'#9#9
      #9#9'(cp2.qtd * (case '
      #9#9#9'when (cp2.qtd >= coalesce(p2.qtd_acima, 0)) then (case'
      #9#9#9#9'when (coalesce(p2.valor_qtd, 0.00) > 0) then (p2.valor_qtd)'
      #9#9#9#9'else (p2.valor)'
      #9#9#9'end)'
      #9#9#9'else (p2.valor)'
      #9#9'end)) valor_total_plano,'
      #9#9'p2.tamanho_max_nuvem,'
      #9#9'p2.qtd_gratis'
      #9'from'
      #9#9'cliente_planos cp2'
      #9'inner join planos p2 on'
      #9#9'(cp2.id_plano = p2.id)'
      #9'where'
      #9#9'cp2.id_cli = :id_cli'
      #9') pl'
      'order by'
      #9'pl.modulo,'
      #9'pl.id')
    Left = 120
    Top = 152
    ParamData = <
      item
        Name = 'ID_CLI'
        ParamType = ptInput
      end>
  end
  object QAux: TFDQuery
    Connection = Dm.FDConexao
    Left = 120
    Top = 216
  end
  object PopupPlano: TPopupMenu
    Left = 320
    Top = 152
    object V1: TMenuItem
      Caption = 'Ver as funcionialidades deste plano'
      OnClick = V1Click
    end
    object V2: TMenuItem
      Caption = 'Ver os valores por plano atual deste plano'
      OnClick = V2Click
    end
  end
  object QPlanosOld: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      'select'
      #9'cp.id_plano,'
      #9'p.modulo ,'
      #9'cp.qtd ,'
      #9'cp.valor_total ,'
      #9'cp.valor'
      'from'
      #9'cliente_planos cp'
      'inner join planos p on'
      #9'(cp.id_plano = p.id)'
      'where'
      #9'cp.id_cli = :id_cli')
    Left = 120
    Top = 328
    ParamData = <
      item
        Name = 'ID_CLI'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end>
  end
  object MTPlanosOld: TFDMemTable
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    Left = 200
    Top = 328
    object MTPlanosOldid_plano: TIntegerField
      FieldName = 'id_plano'
      Origin = 'id_plano'
      Required = True
    end
    object MTPlanosOldmodulo: TBooleanField
      AutoGenerateValue = arDefault
      FieldName = 'modulo'
      Origin = 'modulo'
      ProviderFlags = []
    end
    object MTPlanosOldqtd: TIntegerField
      FieldName = 'qtd'
      Origin = 'qtd'
      Required = True
    end
    object MTPlanosOldvalor_total: TFMTBCDField
      FieldName = 'valor_total'
      Origin = 'valor_total'
      Required = True
      Precision = 18
      Size = 2
    end
    object MTPlanosOldvalor: TFMTBCDField
      FieldName = 'valor'
      Origin = 'valor'
      Required = True
      Precision = 18
      Size = 2
    end
    object MTPlanosOldalterado: TBooleanField
      FieldName = 'alterado'
    end
    object MTPlanosOldremovido: TBooleanField
      FieldName = 'removido'
    end
  end
  object MTPlanosNew: TFDMemTable
    FetchOptions.AssignedValues = [evMode]
    FetchOptions.Mode = fmAll
    ResourceOptions.AssignedValues = [rvSilentMode]
    ResourceOptions.SilentMode = True
    UpdateOptions.AssignedValues = [uvCheckRequired, uvAutoCommitUpdates]
    UpdateOptions.CheckRequired = False
    UpdateOptions.AutoCommitUpdates = True
    Left = 288
    Top = 328
    object MTPlanosNewid_plano: TIntegerField
      FieldName = 'id_plano'
      Origin = 'id_plano'
      Required = True
    end
    object MTPlanosNewmodulo: TBooleanField
      AutoGenerateValue = arDefault
      FieldName = 'modulo'
      Origin = 'modulo'
      ProviderFlags = []
    end
    object MTPlanosNewqtd: TIntegerField
      FieldName = 'qtd'
      Origin = 'qtd'
      Required = True
    end
    object MTPlanosNewvalor_total: TFMTBCDField
      FieldName = 'valor_total'
      Origin = 'valor_total'
      Required = True
      Precision = 18
      Size = 2
    end
    object MTPlanosNewvalor: TFMTBCDField
      FieldName = 'valor'
      Origin = 'valor'
      Required = True
      Precision = 18
      Size = 2
    end
    object MTPlanosNewincluido: TBooleanField
      FieldName = 'incluido'
    end
  end
  object QLog: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      'INSERT INTO cliente_log_plano'
      
        '(id_cli, tipo, nome_usuario, id_usu, id_plano_anterior, qtd_plan' +
        'o_anterior, valor_plano_anterior, valor_total_plano_anterior, va' +
        'lor_assinatura_anterior, id_plano_atual, qtd_plano_atual, valor_' +
        'plano_atual, valor_total_plano_atual, valor_assinatura_atual)'
      'values'
      
        '(:id_cli, :tipo, :nome_usuario, :id_usu, :id_plano_anterior, :qt' +
        'd_plano_anterior, :valor_plano_anterior, :valor_total_plano_ante' +
        'rior, :valor_assinatura_anterior, :id_plano_atual, :qtd_plano_at' +
        'ual, :valor_plano_atual, :valor_total_plano_atual, :valor_assina' +
        'tura_atual)')
    Left = 360
    Top = 328
    ParamData = <
      item
        Name = 'ID_CLI'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end
      item
        Name = 'TIPO'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end
      item
        Name = 'NOME_USUARIO'
        DataType = ftString
        FDDataType = dtAnsiString
        ParamType = ptInput
      end
      item
        Name = 'ID_USU'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end
      item
        Name = 'ID_PLANO_ANTERIOR'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end
      item
        Name = 'QTD_PLANO_ANTERIOR'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end
      item
        Name = 'VALOR_PLANO_ANTERIOR'
        DataType = ftCurrency
        FDDataType = dtCurrency
        ParamType = ptInput
      end
      item
        Name = 'VALOR_TOTAL_PLANO_ANTERIOR'
        DataType = ftCurrency
        FDDataType = dtCurrency
        ParamType = ptInput
      end
      item
        Name = 'VALOR_ASSINATURA_ANTERIOR'
        DataType = ftCurrency
        FDDataType = dtCurrency
        ParamType = ptInput
      end
      item
        Name = 'ID_PLANO_ATUAL'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end
      item
        Name = 'QTD_PLANO_ATUAL'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end
      item
        Name = 'VALOR_PLANO_ATUAL'
        DataType = ftCurrency
        FDDataType = dtCurrency
        ParamType = ptInput
      end
      item
        Name = 'VALOR_TOTAL_PLANO_ATUAL'
        DataType = ftCurrency
        FDDataType = dtCurrency
        ParamType = ptInput
      end
      item
        Name = 'VALOR_ASSINATURA_ATUAL'
        DataType = ftCurrency
        FDDataType = dtCurrency
        ParamType = ptInput
      end>
  end
end
