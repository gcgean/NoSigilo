object FrmGerarLicenca: TFrmGerarLicenca
  Left = 0
  Top = 0
  Caption = 'Gerar licen'#231'a do software'
  ClientHeight = 213
  ClientWidth = 679
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnClose = FormClose
  OnKeyDown = FormKeyDown
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 679
    Height = 213
    Align = alClient
    BevelOuter = bvNone
    TabOrder = 0
    object Label1: TLabel
      Left = 272
      Top = 96
      Width = 81
      Height = 13
      Caption = 'Data Vencimento'
    end
    object Label2: TLabel
      Left = 408
      Top = 16
      Width = 81
      Height = 13
      Caption = 'Chave de licen'#231'a'
    end
    object DBGrid1: TDBGrid
      Left = 0
      Top = 0
      Width = 249
      Height = 213
      Align = alLeft
      DataSource = DSSistema
      Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
      TabOrder = 0
      TitleFont.Charset = DEFAULT_CHARSET
      TitleFont.Color = clWindowText
      TitleFont.Height = -11
      TitleFont.Name = 'Tahoma'
      TitleFont.Style = []
      Columns = <
        item
          Expanded = False
          FieldName = 'descricao'
          Title.Alignment = taCenter
          Title.Caption = 'SISTEMA'
          Visible = True
        end>
    end
    object EdtQuant: TLabeledEdit
      Left = 272
      Top = 32
      Width = 121
      Height = 24
      EditLabel.Width = 81
      EditLabel.Height = 13
      EditLabel.Caption = 'Qtd. Dispositivos'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = []
      ParentFont = False
      TabOrder = 1
      Visible = False
    end
    object CheckValidade: TCheckBox
      Left = 272
      Top = 70
      Width = 97
      Height = 17
      Caption = 'Possui validade?'
      TabOrder = 2
    end
    object EdtValidade: TcxDateEdit
      Left = 272
      Top = 112
      TabOrder = 3
      Width = 121
    end
    object BtnChave: TButton
      Left = 272
      Top = 152
      Width = 393
      Height = 41
      Caption = 'GERAR CHAVE DE LICEN'#199'A'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -13
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 4
      OnClick = BtnChaveClick
    end
    object MemoChave: TMemo
      Left = 408
      Top = 32
      Width = 257
      Height = 101
      TabOrder = 5
    end
  end
  object QSistema: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      'select * from sistema')
    Left = 104
    Top = 72
    object QSistemaid: TFDAutoIncField
      FieldName = 'id'
      Origin = 'id'
      ProviderFlags = [pfInWhere, pfInKey]
      ReadOnly = True
    end
    object QSistemadescricao: TStringField
      FieldName = 'descricao'
      Origin = 'descricao'
      Required = True
      Size = 100
    end
  end
  object DSSistema: TDataSource
    AutoEdit = False
    DataSet = QSistema
    Left = 112
    Top = 128
  end
  object QChave: TFDQuery
    Connection = Dm.FDConexao
    Left = 176
    Top = 56
  end
end
