unit UAssinaturaCliente;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, cxGraphics, cxControls, cxLookAndFeels,
  cxLookAndFeelPainters, cxContainer, cxEdit, cxTextEdit, cxCurrencyEdit, Vcl.StdCtrls,
  Vcl.ComCtrls, Vcl.Mask, FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf, FireDAC.Stan.Async,
  FireDAC.DApt, Data.DB, FireDAC.Comp.DataSet, FireDAC.Comp.Client, System.StrUtils,
  System.Math;

type
  TFrmAssinaturaCliente = class(TForm)
    PnCliente: TPanel;
    Label2: TLabel;
    EdtValor: TcxCurrencyEdit;
    Label1: TLabel;
    EdtVencimento: TDateTimePicker;
    Label4: TLabel;
    ComboForma: TComboBox;
    PCAssinatura: TPageControl;
    TabDados: TTabSheet;
    Label3: TLabel;
    MemoDescricao: TMemo;
    TabCartao: TTabSheet;
    EdtNumeroCartao: TLabeledEdit;
    EdtNomeCartao: TLabeledEdit;
    Label5: TLabel;
    EdtVencimentoCartao: TMaskEdit;
    EdtCodigoSegurancaCartao: TLabeledEdit;
    Label6: TLabel;
    EdtNomeTitularCartao: TLabeledEdit;
    Label8: TLabel;
    EdtCPFCNPJTitularCartao: TLabeledEdit;
    EdtEnderecoTitularCartao: TLabeledEdit;
    EdtNumeroTitularCartao: TLabeledEdit;
    EdtBairroTitularCartao: TLabeledEdit;
    EdtCEPTitularCartao: TLabeledEdit;
    EdtComplementoTitularCartao: TLabeledEdit;
    EdtEmailTitularCartao: TLabeledEdit;
    EdtTelefoneTitularCartao: TLabeledEdit;
    EdtCelularTitularCartao: TLabeledEdit;
    BtnOK: TButton;
    Query: TFDQuery;
    BtnGerarArquivo: TButton;
    DlgSave: TSaveDialog;
    BtnImportarDados: TButton;
    dlgOpen: TOpenDialog;
    Label7: TLabel;
    ComboPeriodicidade: TComboBox;
    CheckAtualizarMensalidadesExistentes: TCheckBox;
    RGTipoAlteracao: TRadioGroup;
    CheckAlterarAssinaturaPlataformaCobranca: TCheckBox;
    CheckReceberCarneImpresso: TCheckBox;
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure ComboFormaChange(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure BtnOKClick(Sender: TObject);
    procedure BtnGerarArquivoClick(Sender: TObject);
    procedure BtnImportarDadosClick(Sender: TObject);
    procedure CheckAlterarAssinaturaPlataformaCobrancaClick(Sender: TObject);
    procedure RGTipoAlteracaoClick(Sender: TObject);
  private
    CNPJCliente: String;
    ValorMensalidadeCliente: Currency;
    AssinaturaExistente: Boolean;
    OldValorMensalidadeCliente: Currency;

    procedure BuscarCliente;
    procedure CarregarAssinatura;
    function FormatarCEP(Value: string): string;
  public
    CodigoCliente: Integer;
  end;

var
  FrmAssinaturaCliente: TFrmAssinaturaCliente;

implementation

uses
  UDM, System.JSON, RestRequest4D, Rest.Types, UAssinatura, Rest.JSON, UServicoContratado,
  UCustomJSON;

{$R *.dfm}

procedure TFrmAssinaturaCliente.BtnGerarArquivoClick(Sender: TObject);
var
  arq: TextFile;
  nomeArq: String;
begin
  if DlgSave.Execute then
    nomeArq := DlgSave.FileName;

  if nomeArq.Trim = EmptyStr then
    exit;

  AssignFile(arq, nomeArq);
  Rewrite(arq);

  Writeln(arq, DM.Crypt('C', EdtNumeroCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtNomeCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtVencimentoCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtCodigoSegurancaCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtNomeTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtCPFCNPJTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtEnderecoTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtNumeroTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtBairroTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtCEPTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtComplementoTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtEmailTitularCartao.Text));
  Writeln(arq, DM.Crypt('C', EdtTelefoneTitularCartao.Text));
  Write(arq, DM.Crypt('C', EdtCelularTitularCartao.Text));

  CloseFile(arq);
end;

procedure TFrmAssinaturaCliente.BtnImportarDadosClick(Sender: TObject);
var
  arq: TextFile;
  nomeArq: String;
  linha: String;
  I: Integer;
begin
  if dlgOpen.Execute then
    nomeArq := dlgOpen.FileName;

  if nomeArq.Trim = EmptyStr then
    exit;

  AssignFile(arq, nomeArq);
  Reset(arq);
  I := 0;

  while not Eof(arq) do
  begin
    Inc(I);
    readln(arq, linha);

    case I of
      1:
        EdtNumeroCartao.Text := DM.Crypt('D', linha);
      2:
        EdtNomeCartao.Text := DM.Crypt('D', linha);
      3:
        EdtVencimentoCartao.Text := DM.Crypt('D', linha);
      4:
        EdtCodigoSegurancaCartao.Text := DM.Crypt('D', linha);
      5:
        EdtNomeTitularCartao.Text := DM.Crypt('D', linha);
      6:
        EdtCPFCNPJTitularCartao.Text := DM.Crypt('D', linha);
      7:
        EdtEnderecoTitularCartao.Text := DM.Crypt('D', linha);
      8:
        EdtNumeroTitularCartao.Text := DM.Crypt('D', linha);
      9:
        EdtBairroTitularCartao.Text := DM.Crypt('D', linha);
      10:
        EdtCEPTitularCartao.Text := DM.Crypt('D', linha);
      11:
        EdtComplementoTitularCartao.Text := DM.Crypt('D', linha);
      12:
        EdtEmailTitularCartao.Text := DM.Crypt('D', linha);
      13:
        EdtTelefoneTitularCartao.Text := DM.Crypt('D', linha);
      14:
        EdtCelularTitularCartao.Text := DM.Crypt('D', linha);
    end;
  end;

  CloseFile(arq);
end;

procedure TFrmAssinaturaCliente.BtnOKClick(Sender: TObject);
var
  JSON: String;
  JSONCartao: String;
  JSONTitularCartao: String;
  LCustomJSON: ICustomJSON;
  LValor: Currency;
begin
  BtnOK.Enabled := False;

  try
    if EdtValor.Value <= 0 then
    begin
      ShowMessage('Informe o valor da assinatura!');
      EdtValor.SetFocus;
      exit;
    end;

    if TabCartao.TabVisible then
    begin
      if Trim(EdtNumeroCartao.Text).Length < 16 then
      begin
        ShowMessage('Informe o n�mero do cart�o corretamente!');
        PCAssinatura.ActivePage := TabCartao;
        EdtNumeroCartao.SetFocus;
        exit;
      end;

      if Trim(EdtNomeCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o nome que est� impresso no cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtNomeCartao.SetFocus;
        exit;
      end;

      if Trim(DM.RemoveChar(EdtVencimentoCartao.Text)) = EmptyStr then
      begin
        ShowMessage('Informe vencimento do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtVencimentoCartao.SetFocus;
        exit;
      end;

      if Trim(EdtCodigoSegurancaCartao.Text).Length < 3 then
      begin
        ShowMessage('Informe o c�digo de seguran�a do cart�o corretamente!');
        PCAssinatura.ActivePage := TabCartao;
        EdtCodigoSegurancaCartao.SetFocus;
        exit;
      end;

      if Trim(EdtNomeTitularCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o nome completo do titular do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtNomeTitularCartao.SetFocus;
        exit;
      end;

      if Trim(EdtCPFCNPJTitularCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o CNPJ/CPF do titular do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtCPFCNPJTitularCartao.SetFocus;
        exit;
      end
      else if Trim(EdtCPFCNPJTitularCartao.Text).Length = 14 then
      begin
        if DM.ValidaCNPJ(Trim(EdtCPFCNPJTitularCartao.Text)).Trim <> EmptyStr then
        begin
          ShowMessage('O CNPJ do titular do cart�o � inv�lido!');
          PCAssinatura.ActivePage := TabCartao;
          EdtCPFCNPJTitularCartao.SetFocus;
          exit;
        end;
      end
      else if DM.ValidaCPF(Trim(EdtCPFCNPJTitularCartao.Text)).Trim <> EmptyStr then
      begin
        ShowMessage('O CPF do titular do cart�o � inv�lido!');
        PCAssinatura.ActivePage := TabCartao;
        EdtCPFCNPJTitularCartao.SetFocus;
        exit;
      end;

      if Trim(EdtEnderecoTitularCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o endere�o do titular do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtEnderecoTitularCartao.SetFocus;
        exit;
      end;

      if Trim(EdtNumeroTitularCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o n�mero do endere�o do titular do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtNumeroTitularCartao.SetFocus;
        exit;
      end;

      if Trim(EdtBairroTitularCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o bairro do titular do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtBairroTitularCartao.SetFocus;
        exit;
      end;

      if Trim(EdtCEPTitularCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o CEP do titular do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtCEPTitularCartao.SetFocus;
        exit;
      end;

      if Trim(EdtEmailTitularCartao.Text) = EmptyStr then
      begin
        ShowMessage('Informe o e-mail do titular do cart�o!');
        PCAssinatura.ActivePage := TabCartao;
        EdtEmailTitularCartao.SetFocus;
        exit;
      end;
    end;

    with Query do
    begin
      Close;
      SQL.Clear;
      SQL.Text := 'update CLIENTE set RECEBER_CARNE_IMPRESSO = :RECEBER_CARNE_IMPRESSO ' +
        'where COD_CLI = ' + CodigoCliente.ToString;
      ParamByName('RECEBER_CARNE_IMPRESSO').AsString := IfThen(CheckReceberCarneImpresso.Checked,
        'S', 'N');
      ExecSQL;
    end;

    if TabCartao.TabVisible then
    begin
      JSONCartao := TCustomJSON.New //
        .AddString('nome', Trim(EdtNomeCartao.Text)) //
        .AddString('numero', Trim(EdtNumeroCartao.Text)) //
        .AddInteger('mes', StrToIntDef(Copy(EdtVencimentoCartao.Text, 1, 2), 0)) //
        .AddInteger('ano', StrToIntDef('20' + Copy(EdtVencimentoCartao.Text, 4, 2), 0)) //
        .AddString('codSeg', Trim(EdtCodigoSegurancaCartao.Text)) //
        .ToJsonString;

      JSONTitularCartao := TCustomJSON.New //
        .AddString('nome', Trim(EdtNomeTitularCartao.Text)) //
        .AddString('email', Trim(EdtEmailTitularCartao.Text)) //
        .AddString('cpfCnpj', DM.FormataCNPJ(EdtCPFCNPJTitularCartao.Text)) //
        .AddString('endereco', Trim(EdtEnderecoTitularCartao.Text)) //
        .AddString('numero', Trim(EdtNumeroTitularCartao.Text)) //
        .AddString('bairro', Trim(EdtBairroTitularCartao.Text)) //
        .AddString('cep', FormatarCEP(EdtCEPTitularCartao.Text)) //
        .AddString('complemento', Trim(EdtComplementoTitularCartao.Text)) //
        .AddString('telefone', Trim(EdtTelefoneTitularCartao.Text)) //
        .AddString('celular', Trim(EdtCelularTitularCartao.Text)) //
        .ToJsonString;
    end;

    LCustomJSON := TCustomJSON.New //
      .AddInteger('formaPagamento', ComboForma.ItemIndex) //
      .AddCurrency('valor', DM.ABNTRound(EdtValor.Value, 2)) //
      .AddInteger('diaVencimento', StrToIntDef(FormatDateTime('dd', EdtVencimento.Date), 0)) //
      .AddString('dataVencimentoProximaCobranca', DateToStr(EdtVencimento.Date)) //
      .AddInteger('periodicidade', ComboPeriodicidade.ItemIndex) //
      .AddString('descricao', Trim(MemoDescricao.Text)) //
      .AddBoolean('alterarCobrancasPendentes', CheckAtualizarMensalidadesExistentes.Checked) //
      .AddJson('dadosCartao', JSONCartao) //
      .AddJson('dadosTitularCartao', JSONTitularCartao);

    if AssinaturaExistente then
      LCustomJSON.AddBoolean('alterarPlataformaCobrancas',
        CheckAlterarAssinaturaPlataformaCobranca.Checked) //
        .AddInteger('tipoAlteracao', RGTipoAlteracao.ItemIndex);

    JSON := LCustomJSON.ToJsonString;

    if AssinaturaExistente then
    begin
      try
        DM.ExecutarRequestAPICommand(TRequest.New.BaseURL('/assinaturas/' + CNPJCliente)
          .AddBody(JSON).ContentType('application/json;charset=UTF-8'), rmPUT);
      except
        on E: Exception do
        begin
          ShowMessage('Falha ao atualizar a assinatura do cliente: ' + E.Message);
          exit;
        end;
      end;
    end
    else
    begin
      try
        DM.ExecutarRequestAPICommand(TRequest.New.BaseURL('/assinaturas/' + CNPJCliente)
          .AddBody(JSON).ContentType('application/json;charset=UTF-8'), rmPOST);
      except
        on E: Exception do
        begin
          ShowMessage('Falha ao inserir a assinatura do cliente: ' + E.Message);
          exit;
        end;
      end;
    end;

    case ComboPeriodicidade.ItemIndex of
      1:
        LValor := RoundTo(EdtValor.Value / 3, -2);
      2:
        LValor := RoundTo(EdtValor.Value / 6, -2);
      3:
        LValor := RoundTo(EdtValor.Value / 12, -2);
    else
      LValor := EdtValor.Value;
    end;

    if LValor <> OldValorMensalidadeCliente then
    begin
      try
        DM.ExecutarRequestAPICommand(TRequest.New.BaseURL('/clientes/' + CNPJCliente +
          '/mensalidade') //
          .AddBody( //
          TCustomJSON.New.AddCurrency('valorMensalidade', LValor) //
          .ToJsonString //
          ).ContentType('application/json;charset=UTF-8'), rmPATCH);
      except
        on E: Exception do
        begin
          ShowMessage('Falha ao atualizar o valor da mensalidade do cliente: ' + E.Message);
          exit;
        end;
      end;
    end;

    ShowMessage('Assinatura registrada com sucesso!');
  finally
    BtnOK.Enabled := True;
  end;

  Close;
end;

procedure TFrmAssinaturaCliente.BuscarCliente;
begin
  with Query do
  begin
    Close;
    SQL.Clear;
    SQL.Text := 'select NOME_FANTASIA, NOME_CLI, CNPJ_CLI, VALOR_MENSALIDADE, ENDRES_CLI, ' +
      'NUMERORES_CLI, BAIRES_CLI, CEPRES_CLI, PONTO_REFERENCIA, EMAIL_CLI, TELRES_CLI, ' +
      'CELULAR_CLI, RECEBER_CARNE_IMPRESSO from CLIENTE where COD_CLI = ' + CodigoCliente.ToString;
    Open;

    PnCliente.Caption := CodigoCliente.ToString + ' - ' + FieldByName('NOME_FANTASIA').AsString;
    CNPJCliente := Trim(DM.RemoveChar(FieldByName('CNPJ_CLI').AsString));
    ValorMensalidadeCliente := FieldByName('VALOR_MENSALIDADE').AsCurrency;
    OldValorMensalidadeCliente := ValorMensalidadeCliente;

    EdtNomeTitularCartao.Text := FieldByName('NOME_CLI').AsString;
    EdtCPFCNPJTitularCartao.Text := DM.RemoveChar(FieldByName('CNPJ_CLI').AsString).Trim;
    EdtEnderecoTitularCartao.Text := FieldByName('ENDRES_CLI').AsString;
    EdtNumeroTitularCartao.Text := FieldByName('NUMERORES_CLI').AsString;
    EdtBairroTitularCartao.Text := FieldByName('BAIRES_CLI').AsString;
    EdtCEPTitularCartao.Text := DM.RemoveChar(FieldByName('CEPRES_CLI').AsString).Trim;
    EdtComplementoTitularCartao.Text := FieldByName('PONTO_REFERENCIA').AsString;
    EdtEmailTitularCartao.Text := FieldByName('EMAIL_CLI').AsString.ToLower;
    EdtTelefoneTitularCartao.Text := FieldByName('TELRES_CLI').AsString;
    EdtCelularTitularCartao.Text := FieldByName('CELULAR_CLI').AsString;

    CheckReceberCarneImpresso.Checked := FieldByName('RECEBER_CARNE_IMPRESSO')
      .AsString.Trim.Equals('S');
  end;
end;

procedure TFrmAssinaturaCliente.CarregarAssinatura;
var
  Response: IResponse;
  JsonArray: TJsonArray;
  JsonObj: TJsonObject;
  Assinatura: TAssinatura;
  ServicoContratado: TServicoContratado;
  I: Integer;
  LPossuiAssinatura: Boolean;
  TotalRegistros: Integer;
begin
  LPossuiAssinatura := False;

  try
    Response := DM.ExecutarRequestAPICommand
      (TRequest.New.BaseURL('/assinaturas/' + CNPJCliente), rmGET);
    LPossuiAssinatura := True;
  except
  end;

  if LPossuiAssinatura then
  begin
    JsonObj := TJsonObject.ParseJSONValue(TEncoding.UTF8.GetBytes(Response.Content), 0)
      as TJsonObject;

    try
      Assinatura := TJson.JsonToObject<TAssinatura>(JsonObj);

      try
        AssinaturaExistente := True;
        // EdtValor.Value := Assinatura.Valor;
        EdtValor.Value := ValorMensalidadeCliente;
        Label1.Caption := 'Vencimento Pr�xima Cobran�a';
        CheckAlterarAssinaturaPlataformaCobranca.Visible := True;
        CheckAlterarAssinaturaPlataformaCobranca.Checked := True;
        RGTipoAlteracao.Visible := True;
        RGTipoAlteracao.ItemIndex := 1;
        CheckAtualizarMensalidadesExistentes.Visible := True;
        CheckAtualizarMensalidadesExistentes.Checked := True;
        // EdtVencimento.Date := Assinatura.DataPrimeiroVencimento;

        // if EdtVencimento.Date <= StrToDate('01/01/2000') then
        // EdtVencimento.Date := StrToDate(DM.FormataStringD(Assinatura.DiaVencimento.ToString, '2',
        // '0') + '/' + FormatDateTime('mm/yyyy', IncMonth(Date, 1)));

        if StrToIntDef(FormatDateTime('dd', Date), 1) < Assinatura.DiaVencimento then
          EdtVencimento.Date := StrToDate(DM.FormataStringD(Assinatura.DiaVencimento.ToString, '2',
            '0') + '/' + FormatDateTime('mm/yyyy', Date))
        else
          EdtVencimento.Date := StrToDate(DM.FormataStringD(Assinatura.DiaVencimento.ToString, '2',
            '0') + '/' + FormatDateTime('mm/yyyy', IncMonth(Date, 1)));

        if Assinatura.FormaPagamento = fpaBoleto then
          ComboForma.ItemIndex := 0
        else
          ComboForma.ItemIndex := 1;

        ComboPeriodicidade.ItemIndex := Integer(Assinatura.Periodicidade);
        MemoDescricao.Text := Assinatura.Descricao;
      finally
        if Assigned(Assinatura) then
          Assinatura.DisposeOf;
      end;
    finally
      if Assigned(JsonObj) then
        JsonObj.DisposeOf;
    end;
  end
  else
  begin
    EdtValor.Value := ValorMensalidadeCliente;
    Label1.Caption := 'Vencimento Primeira Cobran�a';
    CheckAlterarAssinaturaPlataformaCobranca.Visible := False;
    RGTipoAlteracao.Visible := False;
    CheckAtualizarMensalidadesExistentes.Visible := False;
    CheckAtualizarMensalidadesExistentes.Checked := False;
    EdtVencimento.Date := IncMonth(Date, 1);
    ComboForma.ItemIndex := 0;
    ComboPeriodicidade.ItemIndex := 0;
  end;

  Response := DM.ExecutarRequestAPICommand(TRequest.New.BaseURL('/clientes/' + CNPJCliente +
    '/servicosContratados').AddParam('limit', '1000', pkGETorPOST).AddParam('page', '1',
    pkGETorPOST).AddHeader('X-Paginate', 'true'), rmGET);

  JsonObj := TJsonObject.ParseJSONValue(TEncoding.UTF8.GetBytes(Response.Content), 0)
    as TJsonObject;
  MemoDescricao.Clear;

  TotalRegistros := 0;
  JsonObj.TryGetValue('totalCount', TotalRegistros);

  if TotalRegistros > 0 then
  begin
    try
      if JsonObj.Get('data') = nil then
        JsonArray := TJsonArray.Create
      else
        JsonArray := TJsonObject.ParseJSONValue
          (TEncoding.UTF8.GetBytes(JsonObj.GetValue<TJsonArray>('data').ToString), 0) as TJsonArray;
    finally
      if Assigned(JsonObj) then
        JsonObj.DisposeOf;
    end;

    try
      for I := 0 to JsonArray.Count - 1 do
      begin
        JsonObj := TJsonObject.ParseJSONValue(TEncoding.UTF8.GetBytes(JsonArray.Items[I].ToString),
          0) as TJsonObject;

        try
          ServicoContratado := TJson.JsonToObject<TServicoContratado>(JsonObj);

          try
            if ServicoContratado.Plano.Modulo then
              MemoDescricao.Lines.Add(ServicoContratado.Qtd.ToString + 'x ' +
                ServicoContratado.Plano.Descricao.Trim)
            else
              MemoDescricao.Lines.Add('Plano ' + ServicoContratado.Plano.Descricao.Trim);
          finally
            if Assigned(ServicoContratado) then
              ServicoContratado.DisposeOf;
          end;
        finally
          if Assigned(JsonObj) then
            JsonObj.DisposeOf;
        end;
      end;
    finally
      if Assigned(JsonArray) then
        JsonArray.DisposeOf;
    end;
  end
  else if Assigned(JsonObj) then
    JsonObj.DisposeOf;
end;

procedure TFrmAssinaturaCliente.CheckAlterarAssinaturaPlataformaCobrancaClick(Sender: TObject);
begin
  RGTipoAlteracao.Enabled := CheckAlterarAssinaturaPlataformaCobranca.Checked;
  CheckAtualizarMensalidadesExistentes.Enabled := (RGTipoAlteracao.Enabled) and
    (RGTipoAlteracao.ItemIndex = 0);
end;

procedure TFrmAssinaturaCliente.ComboFormaChange(Sender: TObject);
begin
  TabCartao.TabVisible := ComboForma.ItemIndex = 1;
end;

function TFrmAssinaturaCliente.FormatarCEP(Value: string): string;
begin
  Value := Trim(DM.RemoveChar(Value));
  Result := Copy(Value, 1, 5) + '-' + Copy(Value, 6, 3);
  Result := Result.Trim;
end;

procedure TFrmAssinaturaCliente.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
  FrmAssinaturaCliente := nil;
end;

procedure TFrmAssinaturaCliente.FormCreate(Sender: TObject);
begin
  CodigoCliente := 0;
  ValorMensalidadeCliente := 0;
  OldValorMensalidadeCliente := 0;
  AssinaturaExistente := False;
end;

procedure TFrmAssinaturaCliente.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key = vk_escape then
    Close;
end;

procedure TFrmAssinaturaCliente.FormKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    SelectNext(ActiveControl, True, True);
  end;
end;

procedure TFrmAssinaturaCliente.FormShow(Sender: TObject);
begin
  BuscarCliente;
  CarregarAssinatura;

  ComboFormaChange(ComboForma);
  EdtVencimento.SetFocus;
end;

procedure TFrmAssinaturaCliente.RGTipoAlteracaoClick(Sender: TObject);
begin
  CheckAtualizarMensalidadesExistentes.Enabled := (RGTipoAlteracao.Enabled) and
    (RGTipoAlteracao.ItemIndex = 0);
end;

end.
