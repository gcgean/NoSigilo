unit UMonitorClientes;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, ClipBrd,
  System.StrUtils, System.JSON,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, cxGraphics, cxControls, cxLookAndFeels,
  cxLookAndFeelPainters, cxStyles, cxCustomData, cxFilter, cxData,
  cxDataStorage, cxEdit, cxNavigator, dxDateRanges,
  cxDataControllerConditionalFormattingRulesManagerDialog, Data.DB, cxDBData,
  dxPSGlbl, dxPSUtl, dxPSEngn, dxPrnPg, dxBkgnd, dxWrap, dxPrnDev,
  dxPSCompsProvider, dxPSFillPatterns, dxPSEdgePatterns, dxPSPDFExportCore,
  dxPSPDFExport, cxDrawTextUtils, dxPSPrVwStd, dxPSPrVwAdv, dxPSPrVwRibbon,
  dxPScxPageControlProducer, dxPScxGridLnk, dxPScxGridLayoutViewLnk,
  dxPScxEditorProducers, dxPScxExtEditorProducers, dxPSCore, dxPScxCommon,
  cxClasses, cxGridLevel, cxGridCustomTableView, cxGridTableView,
  cxGridDBTableView, cxGridCustomView, cxGrid, Vcl.StdCtrls, Vcl.Buttons,
  Vcl.ExtCtrls, Vcl.ComCtrls, FireDAC.Stan.Intf, FireDAC.Stan.Option,
  FireDAC.Stan.Param, FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf,
  FireDAC.DApt.Intf, FireDAC.Stan.Async, FireDAC.DApt, FireDAC.Comp.DataSet,
  FireDAC.Comp.Client,
  dxPSContainerLnk, DateUtils, cxGridExportLink,
  Winapi.ShellAPI,
  dxSkinsCore, dxSkinsDefaultPainters, Vcl.Menus, RxCtrls, Vcl.Grids,
  Vcl.DBGrids, AdvGlowButton, AlignEdit, Vcl.Mask, Vcl.DBCtrls, MemDS,
  VirtualTable, cyRadioGroup, cxContainer, cxGroupBox, cxTextEdit,
  cxCurrencyEdit, RzPrgres, dxCore, cxDateUtils, cxMaskEdit, cxDropDownEdit,
  cxCalendar, cxLabel, cxCheckBox, VclTee.TeeGDIPlus, VclTee.TeEngine,
  VclTee.Series, VclTee.TeeProcs, VclTee.Chart, VclTee.DBChart, cxBlobEdit,
  DataSet.Serialize,
  DataSet.Serialize.Utils, System.TypInfo, RestRequest4D, Rest.Types, cxButtons,
  frxClass, frxDBSet, cxCheckGroup, dxBarBuiltInMenu, Vcl.OleCtrls, SHDocVw,
  cxPC;

type
  TfrmMonitorClientes = class(TForm)
    StatusBar1: TStatusBar;
    pgDados: TPageControl;
    tsTabClieSemAtualizacao: TTabSheet;
    Panel10: TPanel;
    btnVisGrid: TBitBtn;
    BitBtn2: TBitBtn;
    cxGDRClientesArquivosGerados: TcxGrid;
    cxGDRClientesArquivosGeradosDBTableView1: TcxGridDBTableView;
    cxGDRClientesArquivosGeradosDBTableView1NOME_CLI: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1cod_cli1: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1NOME_FANTASIA1: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1CNPJ_CLI1: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosLevel1: TcxGridLevel;
    dsComponentPrinter: TdxComponentPrinter;
    DPrnLink: TdxGridReportLink;
    SaveDialog: TSaveDialog;
    FDQCliArquivosGerados: TFDQuery;
    dsCliArquivosGerados: TDataSource;
    tabDadosGerais: TTabSheet;
    Panel1: TPanel;
    btnDadosGerais: TBitBtn;
    BitBtn8: TBitBtn;
    FDqDadosGeraisCli: TFDQuery;
    DsDadosGeraisCli: TDataSource;
    FDqDadosGeraisClicod_cli: TIntegerField;
    FDqDadosGeraisCliNOME_FANTASIA: TStringField;
    FDqDadosGeraisCliNOME_CLI: TStringField;
    FDqDadosGeraisCliCNPJ_CLI: TStringField;
    FDqDadosGeraisCliCIDRES_CLI: TStringField;
    FDqDadosGeraisClidescricao: TStringField;
    FDqDadosGeraisCliPASTA_BACKUP_FTP: TStringField;
    FDqDadosGeraisCliVERSAO: TStringField;
    FDqDadosGeraisCliDATA_ULT_FTP: TDateTimeField;
    FDqDadosGeraisCliDATA_ULT_BACKUP: TDateTimeField;
    FDqDadosGeraisCliQTD_CONEXOES_SIMUTANEAS: TIntegerField;
    FDqDadosGeraisCliQTD_CAIXAS_ATIVOS: TIntegerField;
    FDqDadosGeraisCliQTD_USUARIOS_ATIVOS: TIntegerField;
    FDqDadosGeraisCliDATA_ULT_ENT_NOTA: TDateField;
    FDqDadosGeraisCliDATA_ULT_CUPOM: TDateTimeField;
    FDqDadosGeraisCliDATA_HORA_ULT_NFE: TDateField;
    FDqDadosGeraisCliDATA_HORA_ULT_VENDA: TDateTimeField;
    FDqDadosGeraisCliseguimento: TStringField;
    FDqDadosGeraisCliUSU_LOGADO: TStringField;
    FDqDadosGeraisCliDATA_SINCR_DADOS: TDateTimeField;
    FDqDadosGeraisClicod_emp: TIntegerField;
    FDqDadosGeraisCliDATA_VAL_CERT_DIG: TDateField;
    FDqDadosGeraisCliDIAS_ULT_FTP: TStringField;
    FDqDadosGeraisCliDIAS_ULT_BACKUP: TStringField;
    FDqDadosGeraisCliDIAS_ULT_ENTRADA: TStringField;
    FDqDadosGeraisCliDIAS_ULT_NFE: TStringField;
    FDqDadosGeraisCliDIAS_ULT_VENDA: TStringField;
    FDqDadosGeraisCliDIAS_ULT_CUPOM: TStringField;
    FDqDadosGeraisCliDIAS_ULT_SICRONIZACAO: TStringField;
    cxGDRDadosGerais: TcxGrid;
    cxGDRDadosGeraisDBTableView1: TcxGridDBTableView;
    cxGDRDadosGeraisDBTableView1NOME_CLI1: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1CIDRES_CLI1: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1COD_EMP: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1cod_cli: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1NOME_FANTASIA: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1CNPJ_CLI: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1descricao: TcxGridDBColumn;
    cxGDRDadosGeraisLevel1: TcxGridLevel;
    cxGDRDadosGeraisDBTableView1PASTA_BACKUP_FTP: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1VERSAO: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_ULT_FTP: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_ULT_BACKUP: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1QTD_CAIXAS_ATIVOS: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1QTD_CONEXOES_SIMUTANEAS: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1QTD_USUARIOS_ATIVOS: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_HORA_ULT_NFE: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_ULT_ENT_NOTA: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_HORA_ULT_VENDA: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_ULT_CUPOM: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1seguimento: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_SINCR_DADOS: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1USU_LOGADO: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DATA_VAL_CERT_DIG: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_ULT_FTP: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_ULT_BACKUP: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_ULT_ENTRADA: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_ULT_NFE: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_ULT_VENDA: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_ULT_CUPOM: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_ULT_SICRONIZACAO: TcxGridDBColumn;
    FDqDadosGeraisCliDIAS_VENC_CERTIFICADO: TStringField;
    cxGDRDadosGeraisDBTableView1DIAS_VENC_CERTIFICADO1: TcxGridDBColumn;
    FDqDadosGeraisCliDATACADASTRO_CLI: TDateField;
    FDqDadosGeraisCliDIAS_DATA_CADASTRO: TStringField;
    cxGDRDadosGeraisDBTableView1DATACADASTRO_CLI: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DIAS_DATA_CADASTRO: TcxGridDBColumn;
    tsDadosCaixas: TTabSheet;
    FDQClientesCaixa: TFDQuery;
    IntegerField1: TIntegerField;
    StringField1: TStringField;
    StringField2: TStringField;
    StringField3: TStringField;
    StringField4: TStringField;
    StringField5: TStringField;
    DsClienteCaixa: TDataSource;
    FDQClientesCaixaCOD_CAI: TIntegerField;
    FDQClientesCaixaDESC_CAI: TStringField;
    FDQClientesCaixaCOD_EMP: TIntegerField;
    FDQClientesCaixaNUMERO_SERIE_SAT: TIntegerField;
    FDQClientesCaixaOFF_LINE: TStringField;
    FDQClientesCaixaDATA_ULT_ENVIO_ARQ: TDateTimeField;
    FDQClientesCaixaSTATUS_REDE_SAT: TStringField;
    FDQClientesCaixaDATA_HORA_ULT_ENVIO_SAT: TDateTimeField;
    FDQClientesCaixaDATA_HORA_ULT_SEFAZ_SAT: TDateTimeField;
    FDQClientesCaixaESTADO_OPERACAO_SAT: TStringField;
    FDQClientesCaixaULTIMO_CFE_SAT: TStringField;
    FDQClientesCaixaTIPO_CAIXA: TStringField;
    FDQClientesCaixaTEF_CAI: TStringField;
    FDQClientesCaixaDATA_HORA_ULT_VENDA: TDateTimeField;
    FDQClientesCaixadata_hora_sicronizacao: TDateTimeField;
    FDQClientesCaixaPASTA_BACKUP_FTP: TStringField;
    Panel4: TPanel;
    btnDadosCaixa: TBitBtn;
    BitBtn14: TBitBtn;
    cxGDRPDadosCaixa: TcxGrid;
    cxGDRPDadosCaixaDBTableView1: TcxGridDBTableView;
    cxGDRPDadosCaixaLevel1: TcxGridLevel;
    cxGDRPDadosCaixaDBTableView1cod_cli1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1NOME_FANTASIA1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1NOME_CLI1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1CNPJ_CLI1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1CIDRES_CLI1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1descricao1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1COD_CAI1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DESC_CAI1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1COD_EMP1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1NUMERO_SERIE_SAT1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1OFF_LINE1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DATA_ULT_ENVIO_ARQ1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1STATUS_REDE_SAT1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DATA_HORA_ULT_ENVIO_SAT1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DATA_HORA_ULT_SEFAZ_SAT1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1ESTADO_OPERACAO_SAT1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1ULTIMO_CFE_SAT1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1TIPO_CAIXA1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1TEF_CAI1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DATA_HORA_ULT_VENDA1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1data_hora_sicronizacao1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1PASTA_BACKUP_FTP1: TcxGridDBColumn;
    TabSheet1: TTabSheet;
    cxGQuebraSequencia: TcxGrid;
    cxGridDBTableView1: TcxGridDBTableView;
    cxGridLevel1: TcxGridLevel;
    Panel2: TPanel;
    btnQuebraSeq: TBitBtn;
    BitBtn20: TBitBtn;
    FDQCliQuebraSeq: TFDQuery;
    DsCliQuebraSeq: TDataSource;
    FDQCliQuebraSeqcod_cli: TIntegerField;
    FDQCliQuebraSeqNOME_FANTASIA: TStringField;
    FDQCliQuebraSeqNOME_CLI: TStringField;
    FDQCliQuebraSeqCNPJ_CLI: TStringField;
    FDQCliQuebraSeqCIDRES_CLI: TStringField;
    FDQCliQuebraSeqdescricao: TStringField;
    FDQCliQuebraSeqcod_emp: TIntegerField;
    FDQCliQuebraSeqNumero_Cupom_Falta: TStringField;
    FDQCliQuebraSeqnumero_serie_mfe: TStringField;
    FDQCliQuebraSeqdata_hora_sicronizacao: TDateTimeField;
    FDQCliQuebraSeqPASTA_BACKUP_FTP: TStringField;
    cxGridDBTableView1cod_cli: TcxGridDBColumn;
    cxGridDBTableView1NOME_FANTASIA: TcxGridDBColumn;
    cxGridDBTableView1NOME_CLI: TcxGridDBColumn;
    cxGridDBTableView1CNPJ_CLI: TcxGridDBColumn;
    cxGridDBTableView1CIDRES_CLI: TcxGridDBColumn;
    cxGridDBTableView1descricao: TcxGridDBColumn;
    cxGridDBTableView1cod_emp: TcxGridDBColumn;
    cxGridDBTableView1Numero_Cupom_Falta: TcxGridDBColumn;
    cxGridDBTableView1numero_serie_mfe: TcxGridDBColumn;
    cxGridDBTableView1data_hora_sicronizacao: TcxGridDBColumn;
    cxGridDBTableView1PASTA_BACKUP_FTP: TcxGridDBColumn;
    tsClientesOnline: TTabSheet;
    Panel3: TPanel;
    btnVisualizar: TBitBtn;
    BitBtn26: TBitBtn;
    DsBloqueioCli: TDataSource;
    FDQBloqueioCli: TFDQuery;
    FDQClientesCaixadias_Ult_Envio_xml_cont: TStringField;
    FDQClientesCaixaDIAS_DT_ULT_CUPOM: TStringField;
    FDQClientesCaixaDIAS_ULT_ENVIO_SEFAZ: TStringField;
    FDQClientesCaixaDIAS_ULT_VENDA: TStringField;
    cxGDRPDadosCaixaDBTableView1dias_Ult_Envio_xml_cont: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DIAS_DT_ULT_CUPOM: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DIAS_ULT_ENVIO_SEFAZ: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1DIAS_ULT_VENDA: TcxGridDBColumn;
    popClientesCaixa: TPopupMenu;
    MenuItem1: TMenuItem;
    popQuebraSeq: TPopupMenu;
    MenuItem2: TMenuItem;
    PopOnline: TPopupMenu;
    MenuItem3: TMenuItem;
    pa: TTabSheet;
    Panel6: TPanel;
    btnListagemContadores: TBitBtn;
    BitBtn28: TBitBtn;
    FDQConsCli: TFDQuery;
    FDQConsClicod_cli: TIntegerField;
    FDQConsCliNOME_FANTASIA: TStringField;
    FDQConsCliNOME_CLI: TStringField;
    FDQConsCliCNPJ_CLI: TStringField;
    FDQConsCliCIDRES_CLI: TStringField;
    FDQConsCliATIVO: TStringField;
    FDQConsCliBLOQUEADO_CLI: TStringField;
    FDQConsCliEMAIL_CLI: TStringField;
    FDQConsCliTELRES_CLI: TStringField;
    FDQConsClidescricao: TStringField;
    FDQConsClicod_ponto_revenda: TIntegerField;
    FDQConsClivalor_mensalidade: TBCDField;
    popFinanceiro: TPopupMenu;
    FDQConsCliInformado_financeiro: TStringField;
    pnContatoCliente: TPanel;
    pnl4: TPanel;
    lbl1: TLabel;
    lbl2: TLabel;
    lbl3: TLabel;
    lbl4: TLabel;
    edtNomeContatoCham: TAlignEdit;
    edtNumeroContatoCham: TAlignEdit;
    btnSalvaContataCham: TAdvGlowButton;
    edtEmailContatoCham: TAlignEdit;
    edtSetorContatoCham: TAlignEdit;
    pnlTClienteContato: TPanel;
    dbgrdContatoChamadio: TDBGrid;
    Panel32: TPanel;
    Panel8: TPanel;
    GroupBox2: TGroupBox;
    GroupBox3: TGroupBox;
    MedtTelefone: TMaskEdit;
    MeditCelular: TMaskEdit;
    btnSairS: TAdvGlowButton;
    edtCodcli: TAlignEdit;
    dsContatoCli: TDataSource;
    PopDeletaContato: TPopupMenu;
    MenuItem4: TMenuItem;
    tabGerenciamentoCli: TTabSheet;
    cxGrid2: TcxGrid;
    cxGridDBTableView3: TcxGridDBTableView;
    cxGridDBTableView3cod_cli: TcxGridDBColumn;
    cxGridDBTableView3NOME_FANTASIA: TcxGridDBColumn;
    cxGridDBTableView3NOME_CLI: TcxGridDBColumn;
    cxGridDBTableView3CNPJ_CLI: TcxGridDBColumn;
    cxGridDBTableView3CIDRES_CLI: TcxGridDBColumn;
    cxGridDBTableView3descricao: TcxGridDBColumn;
    cxGridDBTableView3NOME_COMERCIAL: TcxGridDBColumn;
    cxGridLevel4: TcxGridLevel;
    Panel7: TPanel;
    btnVisContador: TBitBtn;
    BitBtn33: TBitBtn;
    FDQClientesContador: TFDQuery;
    DsClientesContador: TDataSource;
    FDQClientesContadorNOME_COMERCIAL: TStringField;
    popInfContador: TPopupMenu;
    I2: TMenuItem;
    pnContador: TPanel;
    pnTitContadorCli: TPanel;
    BtnOK: TAdvGlowButton;
    BtnCancelar: TAdvGlowButton;
    EdtContadorCliente: TEdit;
    FDQClientesContadorcod_cli: TIntegerField;
    FDQClientesContadorNOME_FANTASIA: TStringField;
    FDQClientesContadorNOME_CLI: TStringField;
    FDQClientesContadorCNPJ_CLI: TStringField;
    FDQClientesContadorCIDRES_CLI: TStringField;
    FDQClientesContadordescricao: TStringField;
    R2: TMenuItem;
    FDQClientesContadorID_CONTADOR: TIntegerField;
    TabSheet2: TTabSheet;
    cxGridPainelProb: TcxGrid;
    cxGridDBTableViewprob: TcxGridDBTableView;
    cxGridDBTableViewprobcod_cli: TcxGridDBColumn;
    cxGridDBTableViewprobNOME_CLI: TcxGridDBColumn;
    cxGridDBTableViewprobCNPJ_CLI: TcxGridDBColumn;
    cxGridDBTableViewprobCIDRES_CLI: TcxGridDBColumn;
    cxGridDBTableViewprobDATA_SINCR_DADOS: TcxGridDBColumn;
    cxGridLevel5: TcxGridLevel;
    Panel9: TPanel;
    btnGeraProblemas: TBitBtn;
    BitBtn38: TBitBtn;
    FDQConsCliProb: TFDQuery;
    DsConsCliProb: TDataSource;
    FdQAux: TFDQuery;
    DsProblemas: TDataSource;
    cxGridDBTableViewprobDESCRICAO_PROBLEMA: TcxGridDBColumn;
    cxGridDBTableViewprobNOME_FANTASIA1: TcxGridDBColumn;
    PopPanelProb: TPopupMenu;
    G1: TMenuItem;
    N1: TMenuItem;
    G2: TMenuItem;
    FDQClientesContadorChave_Cliente: TStringField;
    cxGridDBTableView3Chave_Cliente1: TcxGridDBColumn;
    FDQClientesContadorDATACADASTRO_CLI: TDateField;
    cxGridDBTableView3DATACADASTRO_CLI1: TcxGridDBColumn;
    TabMetaCommand: TTabSheet;
    cxd: TcxGroupBox;
    cxGroupBox2: TcxGroupBox;
    cxGroupBox3: TcxGroupBox;
    EdtQtdAtual: TLabeledEdit;
    EdtQtdMeta: TLabeledEdit;
    EdtFatAtual: TcxCurrencyEdit;
    EdtFatMeta: TcxCurrencyEdit;
    Label18: TLabel;
    Label1: TLabel;
    AdvGlowButton1: TAdvGlowButton;
    edtTicktMedio: TcxCurrencyEdit;
    Label2: TLabel;
    edtQtdDia: TLabeledEdit;
    EdtTicktDia: TcxCurrencyEdit;
    Label3: TLabel;
    PageControl1: TPageControl;
    TabSheet4: TTabSheet;
    GbQtdClientesFaltam: TcxGroupBox;
    PBQtdClientes: TRzProgressBar;
    GbValorMeta: TcxGroupBox;
    PBTotalClientes: TRzProgressBar;
    GbDiasMeta: TcxGroupBox;
    pbDiasMeta: TRzProgressBar;
    TabSheet5: TTabSheet;
    cxGroupBox1: TcxGroupBox;
    PbQtdClientesFuturo: TRzProgressBar;
    lbMetaFuturaClientes: TcxLabel;
    cxGroupBox8: TcxGroupBox;
    PbFaturamentoClientesFuturo: TRzProgressBar;
    lbMetaFuturaClientesFaturamento: TcxLabel;
    FDqDadosGeraisCliDATA_ULT_SINC_PDC: TDateTimeField;
    FDqDadosGeraisCliversao_exe_retaguarda: TStringField;
    FDqDadosGeraisCliversao_exe_pdv: TStringField;
    FDqDadosGeraisCliversao_exe_connection: TStringField;
    cxGDRDadosGeraisDBTableView1DATA_ULT_SINC_PDC1: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1versao_exe_retaguarda1: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1versao_exe_pdv1: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1versao_exe_connection1: TcxGridDBColumn;
    FDQProblemas: TFDQuery;
    FDQProblemasCOD_CLI: TIntegerField;
    FDQProblemasDESCRICAO_PROBLEMA: TStringField;
    FDQProblemasNOME_CLI: TStringField;
    FDQProblemasNOME_FANTASIA: TStringField;
    FDQProblemasDATA_SINCR_DADOS: TDateTimeField;
    FDQProblemasPASTA_BACKUP_FTP: TStringField;
    FDQProblemasDATACADASTRO_CLI: TDateField;
    FDQProblemasCNPJ_CLI: TStringField;
    FDQProblemasdescricao: TStringField;
    FDQProblemasCIDRES_CLI: TStringField;
    FDQAux2: TFDQuery;
    cxGridDBTableViewprobPASTA_BACKUP_FTP: TcxGridDBColumn;
    cxGridDBTableViewprobDATACADASTRO_CLI: TcxGridDBColumn;
    cxGridDBTableViewprobdescricao: TcxGridDBColumn;
    R3: TMenuItem;
    FDQProblemascod_emp: TIntegerField;
    Panel11: TPanel;
    CbCentral: TComboBox;
    N2: TMenuItem;
    B1: TMenuItem;
    FDQClientesContadorbloquear: TIntegerField;
    FDQClientesContadordata_de_bloqueio: TDateField;
    FDQClientesContadornumero_parcelas: TStringField;
    FDQClientesContadorvalor_total_parcelas: TStringField;
    FDQClientesContadordata_desbloq_conf: TDateField;
    cxGridDBTableView3DESC_BLOQ: TcxGridDBColumn;
    cxGridDBTableView3data_de_bloqueio: TcxGridDBColumn;
    FDQClientesContadorDESC_BLOQ: TStringField;
    FDQCliArquivosGeradoscod_cli: TIntegerField;
    FDQCliArquivosGeradosCNPJ_CLI: TStringField;
    FDQCliArquivosGeradosNOME_CLI: TStringField;
    FDQCliArquivosGeradosNOME_FANTASIA: TStringField;
    FDQCliArquivosGeradosenviado_pdc: TStringField;
    FDQCliArquivosGeradosmes_mov_fiscal: TIntegerField;
    FDQCliArquivosGeradosano_mov_fiscal: TIntegerField;
    FDQCliArquivosGeradosinconsistencias_mov_fiscal: TStringField;
    FDQCliArquivosGeradosenviado_email_mov_fiscal: TStringField;
    FDQCliArquivosGeradosdata_hora_email_mov_fiscal: TSQLTimeStampField;
    FDQCliArquivosGeradosdata_hora_email_mov_fiscal_1: TSQLTimeStampField;
    FDQCliArquivosGeradosenviado_email_xml: TStringField;
    FDQCliArquivosGeradosdata_hora_email_xml: TSQLTimeStampField;
    FDQCliArquivosGeradosponto_revenda: TStringField;
    cxGDRClientesArquivosGeradosDBTableView1ponto_revenda: TcxGridDBColumn;
    FDQAux3: TFDQuery;
    FDQBloqueioClicod_cli: TIntegerField;
    FDQBloqueioCliCNPJ_CLI: TStringField;
    FDQBloqueioCliNOME_CLI: TStringField;
    FDQBloqueioCliNOME_FANTASIA: TStringField;
    FDQBloqueioCliponto_revenda: TStringField;
    FDQBloqueioCliBLOQUEAR: TIntegerField;
    FDQBloqueioCliMENSAGEM: TBlobField;
    FDQBloqueioClibloquear_auto: TStringField;
    FDQBloqueioCliBOL_FIN_IMP: TIntegerField;
    FDQBloqueioCliCONF_BLOQUEIO: TIntegerField;
    FDQBloqueioCliDATA_DE_BLOQUEIO: TDateField;
    FDQBloqueioCliDATA_DO_BLOQUEIO: TStringField;
    cxBloqueioCli: TcxGrid;
    cxGridDBBloqueioCli: TcxGridDBTableView;
    cxGridDBBloqueioClicod_cli: TcxGridDBColumn;
    cxGridDBBloqueioCliNOME_CLI: TcxGridDBColumn;
    cxGridDBBloqueioCliNOME_FANTASIA: TcxGridDBColumn;
    cxGridDBBloqueioCliCNPJ_CLI: TcxGridDBColumn;
    cxGridDBBloqueioCliponto_revenda: TcxGridDBColumn;
    cxGridLevel2: TcxGridLevel;
    cxGridDBBloqueioCliBLOQUEAR: TcxGridDBColumn;
    cxGridDBBloqueioClibloquear_auto: TcxGridDBColumn;
    cxGridDBBloqueioCliBOL_FIN_IMP: TcxGridDBColumn;
    cxGridDBBloqueioCliCONF_BLOQUEIO: TcxGridDBColumn;
    cxGridDBBloqueioCliDATA_DE_BLOQUEIO: TcxGridDBColumn;
    cxGridDBBloqueioCliDATA_DO_BLOQUEIO: TcxGridDBColumn;
    FDQProblemasversao_exe_retaguarda: TStringField;
    FDQProblemasversao_exe_pdv: TStringField;
    FDQProblemasversao_exe_connection: TStringField;
    FDQProblemasVERSAO: TStringField;
    cxGridDBTableViewprobcod_emp: TcxGridDBColumn;
    cxGridDBTableViewprobversao_exe_retaguarda: TcxGridDBColumn;
    cxGridDBTableViewprobversao_exe_pdv: TcxGridDBColumn;
    cxGridDBTableViewprobversao_exe_connection: TcxGridDBColumn;
    cxGridDBTableViewprobVERSAO: TcxGridDBColumn;
    FDQCliArquivosGeradoscod_emp: TIntegerField;
    FDQCliArquivosGeradosversao_exe_retaguarda: TStringField;
    FDQCliArquivosGeradosversao_exe_pdv: TStringField;
    FDQCliArquivosGeradosversao_exe_connection: TStringField;
    FDQCliArquivosGeradosVERSAO: TStringField;
    cxGDRClientesArquivosGeradosDBTableView1cod_emp: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1versao_exe_retaguarda: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1versao_exe_pdv: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1versao_exe_connection: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1VERSAO: TcxGridDBColumn;
    FDQBloqueioClicod_emp: TIntegerField;
    FDQBloqueioCliversao_exe_retaguarda: TStringField;
    FDQBloqueioCliversao_exe_pdv: TStringField;
    FDQBloqueioCliversao_exe_connection: TStringField;
    FDQBloqueioCliVERSAO: TStringField;
    cxGridDBBloqueioClicod_emp: TcxGridDBColumn;
    cxGridDBBloqueioCliversao_exe_retaguarda: TcxGridDBColumn;
    cxGridDBBloqueioCliversao_exe_pdv: TcxGridDBColumn;
    cxGridDBBloqueioCliversao_exe_connection: TcxGridDBColumn;
    cxGridDBBloqueioCliVERSAO: TcxGridDBColumn;
    FDQListaContador: TFDQuery;
    DsListaContador: TDataSource;
    FDQListaContadorID_CONTADOR: TFDAutoIncField;
    FDQListaContadorRAZAO_SOCIAL: TStringField;
    FDQListaContadorNOME_COMERCIAL: TStringField;
    FDQListaContadorCNPJ_CPF: TStringField;
    FDQListaContadorEMAIL: TStringField;
    FDQListaContadorTELEFONE: TStringField;
    FDQListaContadorDESCRICAO_ESCRITORIO: TStringField;
    FDQListaContadorPERFIL_CONTADOR: TStringField;
    FDQProblemasDATA_ULT_FTP: TDateTimeField;
    cxGridDBTableViewprobDATA_ULT_FTP: TcxGridDBColumn;
    cxGroupBox7: TcxGroupBox;
    EdtDataMeta: TcxDateEdit;
    edtDataIniMeta: TcxDateEdit;
    edtQtdMes: TLabeledEdit;
    edtFatMes: TcxCurrencyEdit;
    Label4: TLabel;
    FDMCrescimento: TFDMemTable;
    FDMCrescimentoMES: TStringField;
    FDMCrescimentoANO: TStringField;
    FDMCrescimentoQTD: TIntegerField;
    FDMCrescimentoTOTAL: TFloatField;
    FDMCrescimentoACUM_FATURAMENTO: TFloatField;
    FDMCrescimentoPERC_CRESCIMENTO: TFloatField;
    TabSheet6: TTabSheet;
    cxGrid1: TcxGrid;
    cxGridDBTableView2: TcxGridDBTableView;
    cxGridDBTableView2MES: TcxGridDBColumn;
    cxGridDBTableView2QTD: TcxGridDBColumn;
    cxGridDBTableView2ANO: TcxGridDBColumn;
    cxGridDBTableView2TOTAL: TcxGridDBColumn;
    cxGridDBTableView2ACUM_FATURAMENTO: TcxGridDBColumn;
    cxGridDBTableView2PERC_CRESCIMENTO: TcxGridDBColumn;
    cxGridLevel6: TcxGridLevel;
    DSCrescimento: TDataSource;
    FDQConsCliCELULAR_CLI: TStringField;
    FDQBloqueioCliCIDRES_CLI: TStringField;
    cxGridDBBloqueioCliCIDRES_CLI1: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1enviado_pdc: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1data_hora_ultimo_mov_fiscal: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1mes_mov_fiscal: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1ano_mov_fiscal: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1inconsistencias_mov_fiscal: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1enviado_email_mov_fiscal: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1data_hora_email_mov_fiscal: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1enviado_email_xml: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1data_hora_email_xml: TcxGridDBColumn;
    TabCliExternos: TTabSheet;
    cxGClientesExternos: TcxGrid;
    cxGridDbClientesExternosView4: TcxGridDBTableView;
    cxGridDbClientesExternosView4cod_cli1: TcxGridDBColumn;
    cxGridDbClientesExternosView4NOME_FANTASIA1: TcxGridDBColumn;
    cxGridDbClientesExternosView4NOME_CLI1: TcxGridDBColumn;
    cxGridDbClientesExternosView4CNPJ_CLI1: TcxGridDBColumn;
    cxGridDbClientesExternosView4CIDRES_CLI1: TcxGridDBColumn;
    cxGridDbClientesExternosView4descricao1: TcxGridDBColumn;
    cxGridDbClientesExternosView4DATACADASTRO_CLI1: TcxGridDBColumn;
    cxGridLevel7: TcxGridLevel;
    FDClientesSemAtualizacaoInicial: TFDQuery;
    DsClientesSemAtualizacaoInicial: TDataSource;
    FDClientesSemAtualizacaoInicialcod_cli: TIntegerField;
    FDClientesSemAtualizacaoInicialNOME_FANTASIA: TStringField;
    FDClientesSemAtualizacaoInicialNOME_CLI: TStringField;
    FDClientesSemAtualizacaoInicialCNPJ_CLI: TStringField;
    FDClientesSemAtualizacaoInicialCIDRES_CLI: TStringField;
    FDClientesSemAtualizacaoInicialdescricao: TStringField;
    FDClientesSemAtualizacaoInicialDATACADASTRO_CLI: TDateField;
    PbSicronizacao: TProgressBar;
    Panel5: TPanel;
    btnClientesSemAtualizacao: TBitBtn;
    BitBtn3: TBitBtn;
    TabAgendamento: TTabSheet;
    MTAgendamentoAtualizacao: TFDMemTable;
    DSAgendamentoAtualizacao: TDataSource;
    QAgendamentoAtualizacao: TFDQuery;
    QAgendamentoAtualizacaocod_cli: TIntegerField;
    QAgendamentoAtualizacaoNOME_FANTASIA: TStringField;
    QAgendamentoAtualizacaoNOME_CLI: TStringField;
    QAgendamentoAtualizacaoCNPJ_CLI: TStringField;
    QAgendamentoAtualizacaoCIDRES_CLI: TStringField;
    QAgendamentoAtualizacaodescricao: TStringField;
    QAgendamentoAtualizacaoDATACADASTRO_CLI: TDateField;
    QAgendamentoAtualizacaoPASTA_BACKUP_FTP: TStringField;
    QAgendamentoAtualizacaoDATA_SINCR_DADOS: TDateTimeField;
    QAgendamentoAtualizacaoversao_exe_retaguarda: TStringField;
    QAgendamentoAtualizacaoult_versao_exe_retaguarda: TStringField;
    QAgendamentoAtualizacaoversao_exe_retaguarda_download: TStringField;
    QAgendamentoAtualizacaodata_hora_download_versao_exe_retaguarda: TDateTimeField;
    QAgendamentoAtualizacaoversao_exe_pdv: TStringField;
    QAgendamentoAtualizacaoult_versao_exe_pdv: TStringField;
    QAgendamentoAtualizacaoversao_exe_pdv_download: TStringField;
    QAgendamentoAtualizacaodata_hora_download_versao_exe_pdv: TDateTimeField;
    QAgendamentoAtualizacaoversao_exe_connection: TStringField;
    QAgendamentoAtualizacaoult_versao_exe_connection: TStringField;
    QAgendamentoAtualizacaoversao_exe_connection_download: TStringField;
    QAgendamentoAtualizacaodata_hora_download_versao_exe_connection: TDateTimeField;
    QAgendamentoAtualizacaodata_hora_ult_agend: TDateTimeField;
    QAgendamentoAtualizacaorealizada_ult_agend: TLargeintField;
    QAgendamentoAtualizacaodesc_realizada_ult_agend: TStringField;
    MTAgendamentoAtualizacaocod_cli: TIntegerField;
    MTAgendamentoAtualizacaoNOME_FANTASIA: TStringField;
    MTAgendamentoAtualizacaoNOME_CLI: TStringField;
    MTAgendamentoAtualizacaoCNPJ_CLI: TStringField;
    MTAgendamentoAtualizacaoCIDRES_CLI: TStringField;
    MTAgendamentoAtualizacaodescricao: TStringField;
    MTAgendamentoAtualizacaoDATACADASTRO_CLI: TDateField;
    MTAgendamentoAtualizacaoPASTA_BACKUP_FTP: TStringField;
    MTAgendamentoAtualizacaoDATA_SINCR_DADOS: TDateTimeField;
    MTAgendamentoAtualizacaoversao_exe_retaguarda: TStringField;
    MTAgendamentoAtualizacaoult_versao_exe_retaguarda: TStringField;
    MTAgendamentoAtualizacaoversao_exe_retaguarda_download: TStringField;
    MTAgendamentoAtualizacaodata_hora_download_versao_exe_retaguarda: TDateTimeField;
    MTAgendamentoAtualizacaoversao_exe_pdv: TStringField;
    MTAgendamentoAtualizacaoult_versao_exe_pdv: TStringField;
    MTAgendamentoAtualizacaoversao_exe_pdv_download: TStringField;
    MTAgendamentoAtualizacaodata_hora_download_versao_exe_pdv: TDateTimeField;
    MTAgendamentoAtualizacaoversao_exe_connection: TStringField;
    MTAgendamentoAtualizacaoult_versao_exe_connection: TStringField;
    MTAgendamentoAtualizacaoversao_exe_connection_download: TStringField;
    MTAgendamentoAtualizacaodata_hora_download_versao_exe_connection: TDateTimeField;
    MTAgendamentoAtualizacaodata_hora_ult_agend: TDateTimeField;
    MTAgendamentoAtualizacaorealizada_ult_agend: TLargeintField;
    MTAgendamentoAtualizacaodesc_realizada_ult_agend: TStringField;
    QAgendamentoAtualizacaoSELEC: TIntegerField;
    MTAgendamentoAtualizacaoSELEC: TIntegerField;
    QAgendamentoAtualizacaocod_emp: TIntegerField;
    MTAgendamentoAtualizacaocod_emp: TIntegerField;
    TabSheet8: TTabSheet;
    DBChart1: TDBChart;
    Series1: TBarSeries;
    R4: TMenuItem;
    PCAgendamentos: TPageControl;
    TabAgendamentoAtualizacao: TTabSheet;
    GAgendamentoAtualizacao: TcxGrid;
    GAgendamentoAtualizacaoDBTableView: TcxGridDBTableView;
    GAgendamentoAtualizacaoDBTableViewSELEC: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewcod_cli: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewNOME_FANTASIA: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewNOME_CLI: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewCNPJ_CLI: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewCIDRES_CLI: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewdescricao: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewdata_hora_ult_agend: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewdata_hora_download_versao_exe_connection: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewdesc_realizada_ult_agend: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewrealizada_ult_agend: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewDATACADASTRO_CLI: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewPASTA_BACKUP_FTP: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewDATA_SINCR_DADOS: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewversao_exe_retaguarda: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewult_versao_exe_retaguarda: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewversao_exe_retaguarda_download: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewdata_hora_download_versao_exe_retaguarda: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewversao_exe_pdv: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewult_versao_exe_pdv: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewversao_exe_pdv_download: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewdata_hora_download_versao_exe_pdv: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewversao_exe_connection: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewult_versao_exe_connection: TcxGridDBColumn;
    GAgendamentoAtualizacaoDBTableViewversao_exe_connection_download: TcxGridDBColumn;
    GAgendamentoAtualizacaoLevel: TcxGridLevel;
    Panel12: TPanel;
    Label5: TLabel;
    BtnVisualizarAgendamentoAtualizacao: TBitBtn;
    BtnAgendarAtualizacao: TBitBtn;
    BtnCancelarAgendamento: TBitBtn;
    BitBtn1: TBitBtn;
    BtnDesselecionarAgendamentoAtualizacao: TBitBtn;
    TabAgendamentoTarefas: TTabSheet;
    Panel13: TPanel;
    Label6: TLabel;
    BtnVisualizarTarefas: TBitBtn;
    BitBtn6: TBitBtn;
    BtnCancelarTarefa: TBitBtn;
    cxGrid4: TcxGrid;
    cxGridDBTableView5: TcxGridDBTableView;
    cxGridDBColumn2: TcxGridDBColumn;
    cxGridDBColumn3: TcxGridDBColumn;
    cxGridDBColumn4: TcxGridDBColumn;
    cxGridDBColumn5: TcxGridDBColumn;
    cxGridDBColumn6: TcxGridDBColumn;
    cxGridDBColumn7: TcxGridDBColumn;
    cxGridDBColumn13: TcxGridDBColumn;
    cxGridLevel8: TcxGridLevel;
    QAgendamentoTarefa: TFDQuery;
    DSAgendamentoTarefa: TDataSource;
    QAgendamentoTarefaid: TFDAutoIncField;
    QAgendamentoTarefacod_cli: TIntegerField;
    QAgendamentoTarefapasta_backup_ftp: TStringField;
    QAgendamentoTarefacod_emp: TIntegerField;
    QAgendamentoTarefaNOME_FANTASIA: TStringField;
    QAgendamentoTarefaNOME_CLI: TStringField;
    QAgendamentoTarefaCNPJ_CLI: TStringField;
    QAgendamentoTarefaCIDRES_CLI: TStringField;
    QAgendamentoTarefadescricao: TStringField;
    QAgendamentoTarefadata_hora: TDateTimeField;
    QAgendamentoTarefarealizada: TIntegerField;
    QAgendamentoTarefadesc_realizada: TStringField;
    QAgendamentoTarefatipo_tarefa: TIntegerField;
    QAgendamentoTarefasucesso: TIntegerField;
    QAgendamentoTarefadesc_sucesso: TStringField;
    cxGridDBTableView5Column1: TcxGridDBColumn;
    QAgendamentoTarefadesc_tipo_tarefa: TStringField;
    cxGridDBTableView5Column2: TcxGridDBColumn;
    cxGridDBTableView5Column3: TcxGridDBColumn;
    cxGridDBTableView5Column5: TcxGridDBColumn;
    cxGridDBTableView5Column6: TcxGridDBColumn;
    cxGridDBTableView5Column4: TcxGridDBColumn;
    QAgendamentoTarefaretorno: TBlobField;
    PopupTarefa: TPopupMenu;
    C1: TMenuItem;
    N5: TMenuItem;
    C2: TMenuItem;
    QAgendamentoTarefainstrucao: TBlobField;
    VerretornodeSQL1: TMenuItem;
    ptnAgendarprob: TBitBtn;
    Copiarclula2: TMenuItem;
    Exportardados2: TMenuItem;
    Imprimirdados2: TMenuItem;
    TabSheet9: TTabSheet;
    cxGVersaoMin: TcxGrid;
    cxGVersaoMinDBTableView6: TcxGridDBTableView;
    cxGVersaoMinDBTableView6cod_cli: TcxGridDBColumn;
    cxGVersaoMinDBTableView6NOME_FANTASIA: TcxGridDBColumn;
    cxGVersaoMinDBTableView6NOME_CLI: TcxGridDBColumn;
    cxGVersaoMinDBTableView6CNPJ_CLI: TcxGridDBColumn;
    cxGVersaoMinDBTableView6CIDRES_CLI: TcxGridDBColumn;
    cxGVersaoMinDBTableView6descricao: TcxGridDBColumn;
    cxGVersaoMinDBTableView6PASTA_BACKUP_FTP: TcxGridDBColumn;
    cxGVersaoMinDBTableView6versao_exe_connection: TcxGridDBColumn;
    cxGridLevel9: TcxGridLevel;
    MTCliSemVersMin: TFDMemTable;
    DsConsCli: TDataSource;
    DsCliSemVersMin: TDataSource;
    MTCliSemVersMincod_cli: TIntegerField;
    MTCliSemVersMinpasta_backup_ftp: TStringField;
    MTCliSemVersMinNOME_FANTASIA: TStringField;
    MTCliSemVersMinNOME_CLI: TStringField;
    MTCliSemVersMinCNPJ_CLI: TStringField;
    MTCliSemVersMinCIDRES_CLI: TStringField;
    MTCliSemVersMindescricao: TStringField;
    MTCliSemVersMinversao_exe_connection: TStringField;
    MTCliSemVersMinDATA_SINCR_DADOS: TDateTimeField;
    cxGVersaoMinDBTableView6DATA_SINCR_DADOS1: TcxGridDBColumn;
    Panel14: TPanel;
    lbVersaoMinRecomendada: TLabel;
    BtnVisualizarCliVersMin: TBitBtn;
    btncloseVersMin: TBitBtn;
    PopVersaoMin: TPopupMenu;
    MenuItem5: TMenuItem;
    Agendaratualizao1: TMenuItem;
    Agendartarefa1: TMenuItem;
    MTCliSemVersMincod_emp: TIntegerField;
    FDQProblemasERROS_BACKUP: TStringField;
    cxGridDBTableViewprobERROS_BACKUP: TcxGridDBColumn;
    FDQProblemasTIPO_ERRO: TStringField;
    cxGridDBTableViewprobTIPO_ERRO: TcxGridDBColumn;
    PCGerenciamentoClientes: TPageControl;
    TabGerenciamentoClientes: TTabSheet;
    TabGerenciamentoPlanos: TTabSheet;
    Panel15: TPanel;
    BtnVerTodosPlanos: TButton;
    MTPlanos: TFDMemTable;
    DSPlanos: TDataSource;
    MTPlanosdescricao: TStringField;
    MTPlanosativo: TBooleanField;
    MTPlanosvalor: TFMTBCDField;
    MTPlanosmodulo: TBooleanField;
    GPlano: TcxGrid;
    GPlanoDBTableView: TcxGridDBTableView;
    GPlanoLevel: TcxGridLevel;
    GPlanoDBTableViewid: TcxGridDBColumn;
    GPlanoDBTableViewdescricao: TcxGridDBColumn;
    GPlanoDBTableViewvalor: TcxGridDBColumn;
    GPlanoDBTableViewativo: TcxGridDBColumn;
    GPlanoDBTableViewmodulo: TcxGridDBColumn;
    MTPlanosid: TIntegerField;
    BtnNovoPlano: TButton;
    BtnAlterarPlano: TButton;
    PopupPlanos: TPopupMenu;
    D1: TMenuItem;
    MTPlanosidAPI: TStringField;
    MTPlanosqtdAcima: TIntegerField;
    MTPlanosvalorQtd: TFMTBCDField;
    P2: TMenuItem;
    FDQClientesContadorvalor_mensalidade: TBCDField;
    MTPlanosidSistema: TIntegerField;
    Label7: TLabel;
    TabClientesExternos: TTabSheet;
    Panel16: TPanel;
    EdtDataIni: TDateTimePicker;
    cxLabel14: TcxLabel;
    EdtDataFin: TDateTimePicker;
    cxLabel1: TcxLabel;
    btnVisCertExterno: TcxButton;
    GRelExternos: TcxGrid;
    cxGRelExternosTableView1: TcxGridDBTableView;
    cxGRelExternosTableView1DATA_VAL_CERT_DIG: TcxGridDBColumn;
    cxGRelExternosTableView1ID: TcxGridDBColumn;
    cxGRelExternosTableView1RAZAO_EMP: TcxGridDBColumn;
    cxGRelExternosTableView1NOME_FANTASIA: TcxGridDBColumn;
    cxGRelExternosTableView1CIDADE: TcxGridDBColumn;
    cxGRelExternosTableView1TELEFONE: TcxGridDBColumn;
    cxGRelExternosTableView1CELULAR_CLI: TcxGridDBColumn;
    cxGRelExternosTableView1EMAIL_CLI: TcxGridDBColumn;
    cxGRelExternosTableView1CNPJ_CLI: TcxGridDBColumn;
    cxGRelExternosTableView1TIPO: TcxGridDBColumn;
    cxGRelExternosTableView1DATA_SINCR_DADOS: TcxGridDBColumn;
    cxGridLevel10: TcxGridLevel;
    PnObsCliente: TPanel;
    pnTituloObs: TPanel;
    btnSalvarObsCli: TAdvGlowButton;
    AdvGlowButton2: TAdvGlowButton;
    gbReclamacao: TGroupBox;
    MDadosAtendimento: TMemo;
    Observaocliente1: TMenuItem;
    FDQProblemasOBS_CLI: TStringField;
    cxGridDBTableViewprobOBS_CLI1: TcxGridDBColumn;
    BtnNovoContador: TButton;
    BtnAlterarContador: TButton;
    BtnLancarIndicacao: TButton;
    Lanarindicao1: TMenuItem;
    Novocontador1: TMenuItem;
    Alterarcontador1: TMenuItem;
    PGMenu: TPageControl;
    TabCertificado: TTabSheet;
    TabSheet3: TTabSheet;
    cxGxPerfilContador: TcxGrid;
    cxGridDBfINANCEIROView3: TcxGridDBTableView;
    cxGridDBfINANCEIROView3ID_CONTADOR: TcxGridDBColumn;
    cxGridDBfINANCEIROView3RAZAO_SOCIAL: TcxGridDBColumn;
    cxGridDBfINANCEIROView3NOME_COMERCIAL: TcxGridDBColumn;
    cxGridDBfINANCEIROView3CNPJ_CPF: TcxGridDBColumn;
    cxGridDBfINANCEIROView3EMAIL: TcxGridDBColumn;
    cxGridDBfINANCEIROView3TELEFONE: TcxGridDBColumn;
    cxGridDBfINANCEIROView3DESCRICAO_ESCRITORIO: TcxGridDBColumn;
    cxGridDBfINANCEIROView3PERFIL_CONTADOR: TcxGridDBColumn;
    cxGridLevel3: TcxGridLevel;
    GRelComissaoIndicador: TcxGrid;
    GRelComissaoIndicadorDBTableView: TcxGridDBTableView;
    GRelComissaoIndicadorDBTableViewid: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewdata_hora_lanc: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewdata_indicacao: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewid_contador: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewDESCRICAO_ESCRITORIO: TcxGridDBColumn;
    cxGridLevel13: TcxGridLevel;
    QGerenciadorComissoes: TFDQuery;
    DsGerenciadorComissoes: TDataSource;
    QGerenciadorComissoesid: TFDAutoIncField;
    QGerenciadorComissoesdata_hora_lanc: TSQLTimeStampField;
    QGerenciadorComissoesdata_indicacao: TDateField;
    QGerenciadorComissoesid_contador: TIntegerField;
    QGerenciadorComissoesDESCRICAO_ESCRITORIO: TStringField;
    QGerenciadorComissoesNOME_RESP: TStringField;
    QGerenciadorComissoesid_cliente: TIntegerField;
    QGerenciadorComissoesNOME_CLI: TStringField;
    QGerenciadorComissoesNOME_FANTASIA: TStringField;
    QGerenciadorComissoestipo: TIntegerField;
    QGerenciadorComissoesvalor: TFMTBCDField;
    QGerenciadorComissoescomissao_valor: TFMTBCDField;
    QGerenciadorComissoesid_usu_lanc: TIntegerField;
    QGerenciadorComissoesNOME_USU: TStringField;
    QGerenciadorComissoesCALC_TIPO_COMISSAO: TStringField;
    GRelComissaoIndicadorDBTableViewNOME_RESP: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewid_cliente: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewNOME_CLI: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewNOME_FANTASIA: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewtipo: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewvalor: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewcomissao_valor: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewid_usu_lanc: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewNOME_USU: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewCALC_TIPO_COMISSAO: TcxGridDBColumn;
    Panel17: TPanel;
    EdtDatainiComissao: TDateTimePicker;
    EdtDataFinComissao: TDateTimePicker;
    cxLabel4: TcxLabel;
    BtnVisualizarAgenda: TAdvGlowButton;
    EdtNomeContador: TAlignEdit;
    DBGContador: TDBGrid;
    EdtContador: TAlignEdit;
    QGerenciadorComissoesNOME_COMERCIAL: TStringField;
    GRelComissaoIndicadorDBTableViewNOME_COMERCIAL: TcxGridDBColumn;
    QGerenciadorComissoesCALC_PERC_COMISSAO: TFloatField;
    GRelComissaoIndicadorDBTableViewCALC_PERC_COMISSAO: TcxGridDBColumn;
    PopGerenciadorComissoes: TPopupMenu;
    MenuItem6: TMenuItem;
    Alterarindicao1: TMenuItem;
    BtnImprimir: TButton;
    pnTotais: TPanel;
    PnTotalGeral: TPanel;
    cxLabel2: TcxLabel;
    cxLabel7: TcxLabel;
    EdtComissao: TcxLabel;
    pntroco: TPanel;
    cxLabel10: TcxLabel;
    EdtOperacao: TcxLabel;
    cxLabel12: TcxLabel;
    frRelComprovanteInd: TfrxReport;
    frxDBRelComprovanteInd: TfrxDBDataset;
    Excluirlanamento2: TMenuItem;
    QGerenciadorComissoesCHAVE_PIX: TStringField;
    QGerenciadorComissoesEMAIL: TStringField;
    QGerenciadorComissoesTELEFONE: TStringField;
    GRelComissaoIndicadorDBTableViewCHAVE_PIX1: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewEMAIL1: TcxGridDBColumn;
    GRelComissaoIndicadorDBTableViewTELEFONE1: TcxGridDBColumn;
    CopiarClula3: TMenuItem;
    Exportarparaexcel1: TMenuItem;
    Imprimirtela1: TMenuItem;
    TabGerenciadorInstalacao: TTabSheet;
    FDQProblemasdata_versao_banco: TDateField;
    cxGridDBTableViewprobdata_versao_banco: TcxGridDBColumn;
    QInstalacao: TFDQuery;
    DsInstalacao: TDataSource;
    QInstalacaocod_cli: TIntegerField;
    QInstalacaoNOME_CLI: TStringField;
    QInstalacaoNOME_FANTASIA: TStringField;
    QInstalacaoCIDRES_CLI: TStringField;
    QInstalacaoOBS_CLI: TStringField;
    QInstalacaoTELRES_CLI: TStringField;
    QInstalacaoCELULAR_CLI: TStringField;
    QInstalacaoEMAIL_CLI: TStringField;
    QInstalacaoTECNICO: TStringField;
    QInstalacaoDATACADASTRO_CLI: TDateField;
    QInstalacaoTEMPO_CADASTRO: TStringField;
    QInstalacaoCALC_STATUS_INSTAL: TStringField;
    PopInstalacao: TPopupMenu;
    MenuItem7: TMenuItem;
    MenuItem9: TMenuItem;
    MenuItem10: TMenuItem;
    MenuItem11: TMenuItem;
    MenuItem12: TMenuItem;
    MenuItem13: TMenuItem;
    AlterarObservao1: TMenuItem;
    Abriragenda1: TMenuItem;
    FDQCliArquivosGeradosdata_hora_ultimo_mov_fiscal: TDateTimeField;
    PopArqFiscaisGerados: TPopupMenu;
    PopClientesSemAtualizacao: TPopupMenu;
    MenuItem8: TMenuItem;
    FDQCliArquivosGeradosPASTA_BACKUP_FTP: TStringField;
    AguardandoInstalao1: TMenuItem;
    EmInstalao1: TMenuItem;
    Retorno1: TMenuItem;
    Concluido1: TMenuItem;
    ContatodoclienteContatodocliente1: TMenuItem;
    Contatosdocliente1: TMenuItem;
    Contatosdocliente2: TMenuItem;
    FDClientesSemAtualizacaoInicialTEMPO_CADASTRO: TStringField;
    FDClientesSemAtualizacaoInicialOBS_CLI: TStringField;
    cxGridDbClientesExternosView4TEMPO_CADASTRO: TcxGridDBColumn;
    cxGridDbClientesExternosView4OBS_CLI: TcxGridDBColumn;
    cxGridDbClientesExternosView4OBS_VENDA: TcxGridDBColumn;
    MenuItem19: TMenuItem;
    MenuItem20: TMenuItem;
    MenuItem21: TMenuItem;
    MenuItem22: TMenuItem;
    PNStatus: TPanel;
    N6: TMenuItem;
    C3: TMenuItem;
    R5: TMenuItem;
    TabGerenciamentoAssinaturas: TTabSheet;
    PopupAssinaturas: TPopupMenu;
    DSAssinaturas: TDataSource;
    MTAssinaturas: TFDMemTable;
    R6: TMenuItem;
    A2: TMenuItem;
    GAssinaturas: TcxGrid;
    GAssinaturasDBTableView: TcxGridDBTableView;
    GAssinaturasLevel: TcxGridLevel;
    Panel19: TPanel;
    BtnVerAssinaturas: TButton;
    BtnAlterarAssinatura: TButton;
    BtnRemoverAssinatura: TButton;
    MTAssinaturasid_api: TStringField;
    MTAssinaturasid_cli: TIntegerField;
    MTAssinaturasdata_hora_criacao: TDateTimeField;
    MTAssinaturasforma_pagamento: TIntegerField;
    MTAssinaturasvalor: TFMTBCDField;
    MTAssinaturasdia_vencimento: TIntegerField;
    MTAssinaturasperiodicidade: TIntegerField;
    MTAssinaturasdescricao: TStringField;
    MTAssinaturasdata_primeiro_vencimento: TDateField;
    MTAssinaturasultimos_quatro_digitos_cartao: TIntegerField;
    MTAssinaturasbandeira_cartao: TStringField;
    MTAssinaturastoken_cartao: TStringField;
    MTAssinaturasNOME_CLI: TStringField;
    MTAssinaturasNOME_FANTASIA: TStringField;
    MTAssinaturasCNPJ_CLI: TStringField;
    MTAssinaturasdesc_forma_pagamento: TStringField;
    MTAssinaturasdesc_periodicidade: TStringField;
    MTAssinaturasid: TIntegerField;
    GAssinaturasDBTableViewid: TcxGridDBColumn;
    GAssinaturasDBTableViewdata_hora_criacao: TcxGridDBColumn;
    GAssinaturasDBTableViewid_cli: TcxGridDBColumn;
    GAssinaturasDBTableViewNOME_CLI: TcxGridDBColumn;
    GAssinaturasDBTableViewNOME_FANTASIA: TcxGridDBColumn;
    GAssinaturasDBTableViewCNPJ_CLI: TcxGridDBColumn;
    GAssinaturasDBTableViewdia_vencimento: TcxGridDBColumn;
    GAssinaturasDBTableViewvalor: TcxGridDBColumn;
    GAssinaturasDBTableViewdesc_forma_pagamento: TcxGridDBColumn;
    GAssinaturasDBTableViewdesc_periodicidade: TcxGridDBColumn;
    GAssinaturasDBTableViewdescricao: TcxGridDBColumn;
    Query: TFDQuery;
    MTAssinaturascod_cli: TIntegerField;
    FDQClientesContadorpossui_assinatura: TStringField;
    FDQClientesContadorpossui_plano: TStringField;
    cxGridDBTableView3possui_assinatura: TcxGridDBColumn;
    cxGridDBTableView3possui_plano: TcxGridDBColumn;
    N7: TMenuItem;
    InformarAlterarPlanoeMdulos1: TMenuItem;
    MTAssinaturasvalor_mensalidade: TCurrencyField;
    FDQClientesContadordesc_plano: TStringField;
    FDQClientesContadorcalc_valor_mensalidade: TFMTBCDField;
    cxGridDBTableView3valor_mensalidade: TcxGridDBColumn;
    cxGridDBTableView3desc_plano: TcxGridDBColumn;
    cxGridDBTableView3calc_valor_mensalidade: TcxGridDBColumn;
    FDQClientesContadormensalidade_dif: TStringField;
    cxGridDBTableView3mensalidade_dif: TcxGridDBColumn;
    InserirAlterarClientenaAsaas1: TMenuItem;
    FDQClientesContadordif_mensalidade: TFMTBCDField;
    cxGridDBTableView3dif_mensalidade: TcxGridDBColumn;
    FDQClientesContadorSTATUS_MENSALIDADE: TStringField;
    cxGridDBTableView3STATUS_MENSALIDADE1: TcxGridDBColumn;
    CGFiltroStatusMensalidade: TcxCheckGroup;
    checkTodos: TcxCheckBox;
    EdtCliente: TLabeledEdit;
    TabNuvem: TTabSheet;
    Panel20: TPanel;
    QNuvem: TFDQuery;
    DsNuvem: TDataSource;
    QNuvemid_grupo: TFDAutoIncField;
    QNuvemdescricao: TStringField;
    QNuvemvalor_pago_nuvem: TSingleField;
    QNuvemporta_principal: TIntegerField;
    QNuvemporta_Arquivos: TIntegerField;
    QNuvemporta_aplicativos: TIntegerField;
    QNuvemservidor: TStringField;
    QNuvemtamanho: TBCDField;
    BtnVisualizarNuvem: TBitBtn;
    BtnSairNuvem: TBitBtn;
    QNuvemCALC_PLANO_ATUAL: TStringField;
    QNuvemESTOUROU_PLANO: TStringField;
    PnAlteraValorNuvem: TPanel;
    Panel22: TPanel;
    PopNuvem: TPopupMenu;
    MenuItem15: TMenuItem;
    MenuItem18: TMenuItem;
    MenuItem23: TMenuItem;
    MenuItem24: TMenuItem;
    MenuItem25: TMenuItem;
    AlterarValor1: TMenuItem;
    edtValorNuvem: TcxCurrencyEdit;
    Label11: TLabel;
    btnSalvarNuven: TAdvGlowButton;
    AdvGlowButton4: TAdvGlowButton;
    QInstalacaoSTATUS_INSTAL: TLargeintField;
    Contatosdocliente3: TMenuItem;
    EdtClientesAgendamento: TLabeledEdit;
    EdtClientePainelProb: TLabeledEdit;
    EdtClientesArquivosFiscais: TLabeledEdit;
    EdtDadosGeraisCliente: TLabeledEdit;
    EdtDescricaoNuvem: TLabeledEdit;
    QNuvemversao_fb: TIntegerField;
    QNuvemhora_fecha_caixa: TTimeField;
    EdtCodCliObs: TAlignEdit;
    edtVersaoFirebird: TAlignEdit;
    Label8: TLabel;
    BtnAgendarTarefa: TBitBtn;
    FDQProblemasSITUACAO_FINANCEIRA_CLI: TStringField;
    cxGridDBTableViewprobSITUACAO_FINANCEIRA_CLI: TcxGridDBColumn;
    QNuvemdata_hora_ultimo_acesso: TSQLTimeStampField;
    QNuvemcreated_at: TSQLTimeStampField;
    QNuvemupdated_at: TSQLTimeStampField;
    QNuvemversao: TStringField;
    QNuvemcod_cli: TIntegerField;
    QNuvemNOME_FANTASIA: TStringField;
    Desativar1: TMenuItem;
    GBDadosNuvem: TcxGroupBox;
    Label9: TLabel;
    EdtValorPago: TcxCurrencyEdit;
    EdtValorRecebido: TcxCurrencyEdit;
    Label10: TLabel;
    EdtValorLucro: TcxCurrencyEdit;
    Label12: TLabel;
    EdtLucroPerc: TcxCurrencyEdit;
    Label13: TLabel;
    QNuvempasta_backup_ftp: TStringField;
    QNuvemobservacao: TStringField;
    G3: TMenuItem;
    TabCurvaABC: TTabSheet;
    cxGroupBox4: TcxGroupBox;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    EdtCurvaA: TEdit;
    EdtCurvaB: TEdit;
    EdtCurvaC: TEdit;
    cxGCurvaABC: TcxGrid;
    cxGCurvaABCDBTableView4: TcxGridDBTableView;
    cxGCurvaABCDBTableView4descricao: TcxGridDBColumn;
    cxGCurvaABCDBTableView4id_titular: TcxGridDBColumn;
    cxGCurvaABCDBTableView4Lucro: TcxGridDBColumn;
    cxGCurvaABCDBTableView4perc_rep: TcxGridDBColumn;
    cxGCurvaABCDBTableView4classe: TcxGridDBColumn;
    cxGCurvaABCDBTableView4mensalidade_custo: TcxGridDBColumn;
    cxGridLevel11: TcxGridLevel;
    DsRelABC: TDataSource;
    QrelABC: TFDQuery;
    QrelABCid_titular: TFDAutoIncField;
    QrelABCdescricao: TStringField;
    QrelABCLucro: TFMTBCDField;
    QrelABCperc_rep: TFMTBCDField;
    QrelABCclasse: TStringField;
    QrelABCmensalidade_custo: TFMTBCDField;
    Panel21: TPanel;
    BtnVisABC: TBitBtn;
    BitBtn5: TBitBtn;
    EdtDescABC: TLabeledEdit;
    QrelABCmensalidade_venda: TFMTBCDField;
    QrelABCCALC_PERC_LUCRO: TFloatField;
    cxGCurvaABCDBTableView4mensalidade_venda1: TcxGridDBColumn;
    cxGCurvaABCDBTableView4CALC_PERC_LUCRO1: TcxGridDBColumn;
    FDQCliArquivosGeradosRAZAO_SOCIAL: TStringField;
    FDQCliArquivosGeradosNOME_COMERCIAL: TStringField;
    FDQCliArquivosGeradosDESCRICAO_ESCRITORIO: TStringField;
    cxGDRClientesArquivosGeradosDBTableView1RAZAO_SOCIAL1: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1NOME_COMERCIAL1: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1DESCRICAO_ESCRITORIO1: TcxGridDBColumn;
    cxGDRClientesArquivosGeradosDBTableView1PASTA_BACKUP_FTP1: TcxGridDBColumn;
    FDqDadosGeraisCliRAZAO_SOCIAL: TStringField;
    FDqDadosGeraisCliNOME_COMERCIAL: TStringField;
    FDqDadosGeraisCliDESCRICAO_ESCRITORIO: TStringField;
    cxGDRDadosGeraisDBTableView1RAZAO_SOCIAL: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1NOME_COMERCIAL: TcxGridDBColumn;
    cxGDRDadosGeraisDBTableView1DESCRICAO_ESCRITORIO: TcxGridDBColumn;
    mniN9: TMenuItem;
    C4: TMenuItem;
    QrelABCCALC_MENSALIDADE_IDEAL: TFloatField;
    QrelABCDEFICIT: TFloatField;
    cxGCurvaABCDBTableView4CALC_MENSALIDADE_IDEAL1: TcxGridDBColumn;
    cxGCurvaABCDBTableView4DEFICIT1: TcxGridDBColumn;
    PopDadosGerais: TPopupMenu;
    mniAlternarVersaoBeta: TMenuItem;
    mniSeparadorVersaoBeta: TMenuItem;
    A1: TMenuItem;
    Contatoscliente1: TMenuItem;
    N4: TMenuItem;
    R1: TMenuItem;
    N3: TMenuItem;
    CopiarClula1: TMenuItem;
    ExportarDados1: TMenuItem;
    ImprimirDados1: TMenuItem;
    FDQClientesContadorUSAR_VERSAO_BETA: TIntegerField;
    FDQClientesContadorUSAR_VERSAO_BETA_DESC: TStringField;
    cxGridDBTableView3CLIENTE_BETA: TcxGridDBColumn;
    TabMensalidadeDifCadastro: TTabSheet;
    cxGMensDifCad: TcxGrid;
    cxGMensDifCadDBTableView4: TcxGridDBTableView;
    cxGMensDifCadDBTableView4cod_cli: TcxGridDBColumn;
    cxGMensDifCadDBTableView4NOME_FANTASIA: TcxGridDBColumn;
    cxGMensDifCadDBTableView4NOME_CLI: TcxGridDBColumn;
    cxGMensDifCadDBTableView4CNPJ_CLI: TcxGridDBColumn;
    cxGMensDifCadDBTableView4valor_assinatura: TcxGridDBColumn;
    cxGMensDifCadDBTableView4valor_mensalidade: TcxGridDBColumn;
    cxGridLevel12: TcxGridLevel;
    QMensalidadeDifCadastro: TFDQuery;
    DsMensalidadeDifCadastro: TDataSource;
    QMensalidadeDifCadastrocod_cli: TIntegerField;
    QMensalidadeDifCadastroNOME_CLI: TStringField;
    QMensalidadeDifCadastroNOME_FANTASIA: TStringField;
    QMensalidadeDifCadastroCNPJ_CLI: TStringField;
    QMensalidadeDifCadastrovalor_mensalidade: TBCDField;
    QMensalidadeDifCadastrovalor_assinatura: TFMTBCDField;
    Panel23: TPanel;
    BitBtn4: TBitBtn;
    BitBtn9: TBitBtn;
    BitBtn10: TBitBtn;
    FDQClientesContadorreceber_carne_impresso: TStringField;
    FDQClientesContadorcalc_receber_carne_impresso: TStringField;
    cxGridDBTableView3calc_receber_carne_impresso: TcxGridDBColumn;
    c5: TMenuItem;
    BtnReajustarAssinaturas: TButton;
    BtnVincularTitular: TBitBtn;
    GPlanoDBTableViewColumn1: TcxGridDBColumn;
    MTPlanosdescSistema: TStringField;
    A3: TMenuItem;
    PnAlterarDadosNuvem: TPanel;
    Panel25: TPanel;
    BtnSalvarDadosNuvem: TAdvGlowButton;
    BtnSairDadosNuvem: TAdvGlowButton;
    edtDescricaoDadosNuvem: TEdit;
    Label17: TLabel;
    edtServidorDadosNuvem: TEdit;
    Lbl5: TLabel;
    edtPortaPrincipalDadosNuvem: TEdit;
    Lbl6: TLabel;
    edtPortaArquivosDadosNuvem: TEdit;
    Lbl7: TLabel;
    edtPortaAplicativosDadosNuvem: TEdit;
    Lbl8: TLabel;
    TabSheet7: TTabSheet;
    Panel24: TPanel;
    BtnClientesDispositivos: TBitBtn;
    BitBtn12: TBitBtn;
    EdtClienteDispositivos: TLabeledEdit;
    DsClientesDispositivos: TDataSource;
    QClientesDispositivos: TFDQuery;
    QClientesDispositivoscod_cli: TIntegerField;
    QClientesDispositivosNOME_CLI: TStringField;
    QClientesDispositivosNOME_FANTASIA: TStringField;
    QClientesDispositivosCIDRES_CLI: TStringField;
    QClientesDispositivosCNPJ_CLI: TStringField;
    QClientesDispositivosQTD_COMPUTADORES: TLargeintField;
    QClientesDispositivosCS_PEDIDOS: TLargeintField;
    QClientesDispositivosCS_CONTROLE: TLargeintField;
    cxGrid3: TcxGrid;
    cxGridDBTableView4: TcxGridDBTableView;
    cxGridDBTableView4cod_cli: TcxGridDBColumn;
    cxGridDBTableView4NOME_FANTASIA: TcxGridDBColumn;
    cxGridDBTableView4NOME_CLI: TcxGridDBColumn;
    cxGridDBTableView4CNPJ_CLI: TcxGridDBColumn;
    cxGridDBTableView4CIDRES_CLI: TcxGridDBColumn;
    cxGridDBTableView4QTD_COMPUTADORES: TcxGridDBColumn;
    cxGridLevel14: TcxGridLevel;
    cxGridDBTableView4CS_PEDIDOS: TcxGridDBColumn;
    cxGridDBTableView4CS_CONTROLE: TcxGridDBColumn;
    QAgendamentoAtualizacaoVERSAO: TStringField;
    MTAgendamentoAtualizacaoVERSAO: TStringField;
    GAgendamentoAtualizacaoDBTableViewVERSAO1: TcxGridDBColumn;
    pgNuvem: TPageControl;
    TabListNuvemCompleta: TTabSheet;
    PbExcel: TProgressBar;
    TabListNuvemSimples: TTabSheet;
    TabListResumidaNuvem: TTabSheet;
    GNuvem: TcxGrid;
    GNuvemDBTableView: TcxGridDBTableView;
    GNuvemDBTableViewid_grupo1: TcxGridDBColumn;
    GNuvemDBTableViewdescricao1: TcxGridDBColumn;
    GNuvemDBTableViewvalor_pago_nuvem1: TcxGridDBColumn;
    GNuvemDBTableViewtamanho1: TcxGridDBColumn;
    GNuvemDBTableViewESTOUROU_PLANO: TcxGridDBColumn;
    GNuvemDBTableViewporta_principal1: TcxGridDBColumn;
    GNuvemDBTableViewporta_Arquivos1: TcxGridDBColumn;
    GNuvemDBTableViewporta_aplicativos1: TcxGridDBColumn;
    GNuvemDBTableViewservidor1: TcxGridDBColumn;
    GNuvemDBTableViewversao_fb: TcxGridDBColumn;
    GNuvemDBTableViewhora_fecha_caixa: TcxGridDBColumn;
    GNuvemDBTableViewversao1: TcxGridDBColumn;
    GNuvemDBTableViewdata_hora_ultimo_acesso1: TcxGridDBColumn;
    GNuvemDBTableViewcod_cli1: TcxGridDBColumn;
    GNuvemDBTableViewNOME_FANTASIA1: TcxGridDBColumn;
    GNuvemDBTableViewpasta_backup_ftp1: TcxGridDBColumn;
    GNuvemDBTableViewcreated_at1: TcxGridDBColumn;
    GNuvemDBTableViewupdated_at1: TcxGridDBColumn;
    GNuvemDBTableViewobservacao1: TcxGridDBColumn;
    GNuvemLevel: TcxGridLevel;
    DsNuvemResumi: TDataSource;
    FDMNuvemResumida: TFDMemTable;
    FDMNuvemResumidaid_server_nuvem: TIntegerField;
    FDMNuvemResumidadescricao_nuvem: TStringField;
    FDMNuvemResumidavalor_nuvem: TSingleField;
    FDMNuvemResumidavalor_recebido: TFloatField;
    FDMNuvemResumidaQtd_conections: TLargeintField;
    FDMNuvemResumidaconsumo_medio_ram: TIntegerField;
    FDMNuvemResumidadata_ult_consulta_consumo: TDateField;
    FDMNuvemResumidalucro_valor: TFloatField;
    FDMNuvemResumidaporcentagem_lucro: TFloatField;
    FDMNuvemResumidalucro_min_ideal: TFloatField;
    FDMNuvemResumidaFalta_para_lucro_ideal: TFloatField;
    FDMNuvemResumidacusto_por_conection: TFloatField;
    FDMNuvemResumidavalor_Venda_min_conection: TFloatField;
    FDMNuvemResumidaQtd_MB_Utilizado: TIntegerField;
    FDMNuvemResumidaQtd_mb_por_conection: TIntegerField;
    cxGrid5: TcxGrid;
    cxGridDBTableView7: TcxGridDBTableView;
    cxGridDBTableView7id_server_nuvem: TcxGridDBColumn;
    cxGridDBTableView7descricao_nuvem: TcxGridDBColumn;
    cxGridDBTableView7valor_nuvem: TcxGridDBColumn;
    cxGridDBTableView7valor_recebido: TcxGridDBColumn;
    cxGridDBTableView7Qtd_conections: TcxGridDBColumn;
    cxGridDBTableView7consumo_medio_ram: TcxGridDBColumn;
    cxGridDBTableView7data_ult_consulta_consumo: TcxGridDBColumn;
    cxGridDBTableView7lucro_valor: TcxGridDBColumn;
    cxGridDBTableView7porcentagem_lucro: TcxGridDBColumn;
    cxGridDBTableView7lucro_min_ideal: TcxGridDBColumn;
    cxGridDBTableView7Falta_para_lucro_ideal: TcxGridDBColumn;
    cxGridDBTableView7custo_por_conection: TcxGridDBColumn;
    cxGridDBTableView7valor_Venda_min_conection: TcxGridDBColumn;
    cxGridDBTableView7Qtd_MB_Utilizado: TcxGridDBColumn;
    cxGridDBTableView7Qtd_mb_por_conection: TcxGridDBColumn;
    cxGridLevel16: TcxGridLevel;
    QNuvemResumida: TFDQuery;
    QQtdConectionResumido: TFDQuery;
    QNuvemid_plano_nuvem: TLargeintField;
    QNuvemdesc_plano_nuvem: TStringField;
    GNuvemDBTableViewdesc_plano_nuvem: TcxGridDBColumn;
    cxGrid6: TcxGrid;
    cxGridDBTableView6: TcxGridDBTableView;
    cxGridDBTableView6id_grupo: TcxGridDBColumn;
    cxGridDBTableView6descricao: TcxGridDBColumn;
    cxGridDBTableView6desc_plano_nuvem: TcxGridDBColumn;
    cxGridDBTableView6tamanho: TcxGridDBColumn;
    cxGridDBTableView6ESTOUROU_PLANO: TcxGridDBColumn;
    cxGridDBTableView6porta_principal: TcxGridDBColumn;
    cxGridDBTableView6porta_Arquivos: TcxGridDBColumn;
    cxGridDBTableView6porta_aplicativos: TcxGridDBColumn;
    cxGridDBTableView6servidor: TcxGridDBColumn;
    cxGridDBTableView6versao_fb: TcxGridDBColumn;
    cxGridDBTableView6hora_fecha_caixa: TcxGridDBColumn;
    cxGridDBTableView6versao: TcxGridDBColumn;
    cxGridDBTableView6data_hora_ultimo_acesso: TcxGridDBColumn;
    cxGridDBTableView6cod_cli: TcxGridDBColumn;
    cxGridDBTableView6NOME_FANTASIA: TcxGridDBColumn;
    cxGridDBTableView6pasta_backup_ftp: TcxGridDBColumn;
    cxGridDBTableView6created_at: TcxGridDBColumn;
    cxGridDBTableView6updated_at: TcxGridDBColumn;
    cxGridDBTableView6observacao: TcxGridDBColumn;
    cxGridLevel15: TcxGridLevel;
    FDMCrescimentoTICKET_MEDIO: TFloatField;
    cxGridDBTableView2TICKET_MEDIO: TcxGridDBColumn;
    a4: TMenuItem;
    R7: TMenuItem;
    T1: TMenuItem;
    QAgendamentoAtualizacaodesc_periodicidade: TStringField;
    GAgendamentoAtualizacaoDBTableViewdesc_periodicidade: TcxGridDBColumn;
    MTAgendamentoAtualizacaodesc_periodicidade: TStringField;
    FDQListaContadorEMAIL_RESP: TStringField;
    FDQListaContadorNOME_RESP: TStringField;
    FDQListaContadorCHAVE_PIX: TStringField;
    FDQListaContadorSISTEMA_CONTADOR: TStringField;
    FDQListaContadorEMAIL_ENVIO_ARQUIVOS: TStringField;
    FDQListaContadorMELHOR_DIA_ENVIO_ARQUIVOS: TIntegerField;
    FDQListaContadorUSA_PLATAFORMA_DO_CONTADOR: TStringField;
    FDQListaContadorCPF_CONTADOR: TStringField;
    FDQListaContadorCRC_CONTADOR: TStringField;
    CbSemContabilidade: TcxCheckBox;
    DBGContadorCliente: TDBGrid;
    EdtNomeContadorCliente: TAlignEdit;
    FDQListaContadorCliente: TFDQuery;
    DsListaContadorCliente: TDataSource;
    FDQListaContadorClienteID_CONTADOR: TFDAutoIncField;
    FDQListaContadorClienteRAZAO_SOCIAL: TStringField;
    FDQListaContadorClienteNOME_COMERCIAL: TStringField;
    FDQListaContadorClienteCNPJ_CPF: TStringField;
    FDQListaContadorClienteEMAIL: TStringField;
    FDQListaContadorClienteTELEFONE: TStringField;
    FDQListaContadorClienteDESCRICAO_ESCRITORIO: TStringField;
    FDQListaContadorClientePERFIL_CONTADOR: TStringField;
    FDQListaContadorClienteEMAIL_RESP: TStringField;
    FDQListaContadorClienteNOME_RESP: TStringField;
    FDQListaContadorClienteCHAVE_PIX: TStringField;
    FDQListaContadorClienteSISTEMA_CONTADOR: TStringField;
    FDQListaContadorClienteEMAIL_ENVIO_ARQUIVOS: TStringField;
    FDQListaContadorClienteMELHOR_DIA_ENVIO_ARQUIVOS: TIntegerField;
    FDQListaContadorClienteUSA_PLATAFORMA_DO_CONTADOR: TStringField;
    FDQListaContadorClienteCPF_CONTADOR: TStringField;
    FDQListaContadorClienteCRC_CONTADOR: TStringField;
    EdtCodCliContador: TEdit;
    PGInstalacoes: TcxPageControl;
    TabDashboard: TcxTabSheet;
    TabListagem: TcxTabSheet;
    Panel18: TPanel;
    RGStatusOP: TRadioGroup;
    cxGerenciadoInstalacoes: TcxGrid;
    cxGerenciadoInstalacoesDBTableView: TcxGridDBTableView;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewCALC_STATUS_INSTAL: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewSTATUS_INSTAL: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewcod_cli: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewNOME_CLI: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewNOME_FANTASIA: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewCIDRES_CLI: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDATACADASTRO_CLI: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewTEMPO_CADASTRO: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewTECNICO: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewOBS_CLI: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewCELULAR_CLI: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewTELRES_CLI: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewOBS_VENDA: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewEMAIL_CLI: TcxGridDBColumn;
    cxGere: TcxGridLevel;
    WbInstalacoes: TWebBrowser;
    pninstalacoes: TPanel;
    BtnInstalacoes: TBitBtn;
    BitBtn7: TBitBtn;
    EdtCliInstalacao: TLabeledEdit;
    TabSheet10: TTabSheet;
    GServidores: TcxGrid;
    GServidoresDBTableView: TcxGridDBTableView;
    GServidoresLevel: TcxGridLevel;
    DSServidores: TDataSource;
    GServidoresDBTableViewid_server_nuvem1: TcxGridDBColumn;
    GServidoresDBTableViewdescricao_nuvem1: TcxGridDBColumn;
    GServidoresDBTableViewporta_api_servidor1: TcxGridDBColumn;
    GServidoresDBTableViewSTATUS1: TcxGridDBColumn;
    pnServidores: TPanel;
    btnVisualizaServidores: TBitBtn;
    BitBtn13: TBitBtn;
    MTServidores: TFDMemTable;
    MTServidoresdescricao_nuvem: TStringField;
    MTServidoresdns: TStringField;
    MTServidoresvalor_nuvem: TSingleField;
    MTServidoresconsumo_medio_ram: TIntegerField;
    MTServidoresdata_ult_consulta_consumo: TDateField;
    MTServidoresdisponivel: TBooleanField;
    MTServidoresporta_teste_conexao: TIntegerField;
    MTServidoresdatabase_teste_conexao: TStringField;
    MTServidoresusuario_teste_conexao: TStringField;
    MTServidoressenha_teste_conexao: TStringField;
    MTServidoresselect_teste_conexao: TStringField;
    MTServidoresnumero_servidor: TIntegerField;
    MTServidoresporta_api_servidor: TIntegerField;
    MTServidoresSTATUS: TStringField;
    MTServidoresid_server_nuvem: TIntegerField;
    TabSheet11: TTabSheet;
    DsCommandZap: TDataSource;
    CDSCommandZap: TFDMemTable;
    CDSCommandZapCOD_EMP: TIntegerField;
    CDSCommandZapNOME_EMP: TStringField;
    CDSCommandZapQTD: TIntegerField;
    CDSCommandZapULT_MENSAGEM: TDateTimeField;
    Panel26: TPanel;
    BtnBuscaClientesZap: TBitBtn;
    BTNSairZap: TBitBtn;
    GCommandZap: TcxGrid;
    cxGCommandzapDBTableView8: TcxGridDBTableView;
    cxGCommandzapDBTableView8COD_EMP1: TcxGridDBColumn;
    cxGCommandzapDBTableView8NOME_EMP1: TcxGridDBColumn;
    cxGCommandzapDBTableView8QTD1: TcxGridDBColumn;
    cxGCommandzapDBTableView8ULT_MENSAGEM1: TcxGridDBColumn;
    cxGridLevel17: TcxGridLevel;
    QrelABCranking: TFloatField;
    cxGCurvaABCDBTableView4ranking: TcxGridDBColumn;
    CDSCommandZapData_Vencimento: TDateField;
    cxGCommandzapDBTableView8Data_Vencimento1: TcxGridDBColumn;
    CDSCommandZapDias: TStringField;
    cxGCommandzapDBTableView8prim_mensagem: TcxGridDBColumn;
    cxGCommandzapDBTableView8Dias: TcxGridDBColumn;
    CDSCommandZapprim_mensagem: TDateTimeField;
    BtnGerarSubDominio: TBitBtn;
    T2: TMenuItem;
    P1: TMenuItem;
    D2: TMenuItem;
    BtnAplicarQuantidadeMaquinasGratuitasPadrao: TButton;
    QInstalacaotipo_instalacao: TStringField;
    QInstalacaoqtd_maquinas: TStringField;
    QInstalacaotipo_servidor: TStringField;
    QInstalacaoqtd_sistemas: TStringField;
    QInstalacaotipo_doc_fiscal: TStringField;
    QInstalacaobalanca_integrada: TStringField;
    QInstalacaoqtd_impressoras_comp: TStringField;
    QInstalacaoimp_comp_compart: TStringField;
    QInstalacaoqtd_impressoras_etq: TStringField;
    QInstalacaoimp_etq_compart: TStringField;
    QInstalacaoqtd_balancas_etq: TStringField;
    QInstalacaocertificado_digital: TStringField;
    QInstalacaotipo_treinamento: TStringField;
    QInstalacaoqtd_pessoas_treinamento: TStringField;
    QInstalacaosetores_treinamento: TStringField;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewtipo_instalacao: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewqtd_maquinas: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewtipo_servidor: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewqtd_sistemas: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewtipo_doc_fiscal: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewbalanca_integrada: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewqtd_impressoras_comp: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewimp_comp_compart: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewqtd_impressoras_etq: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewimp_etq_compart: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewqtd_balancas_etq: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewcertificado_digital: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewtipo_treinamento: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewqtd_pessoas_treinamento: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewsetores_treinamento: TcxGridDBColumn;
    guardandooclienteparainstalao1: TMenuItem;
    AguardandoMigrao1: TMenuItem;
    Primeirotreinamento1: TMenuItem;
    Segundotreinamento1: TMenuItem;
    E1dd: TMenuItem;
    E1: TMenuItem;
    QInstalacaoSTATUS_PRIM_PGTO: TStringField;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewSTATUS_PRIM_PGTO: TcxGridDBColumn;
    VerificarStatuspagmento1: TMenuItem;
    FDQClientesContadorchave_possui_vencimento: TStringField;
    FDQClientesContadorvencimento_chave: TDateField;
    cxGridDBTableView3chave_possui_vencimento: TcxGridDBColumn;
    cxGridDBTableView3vencimento_chave: TcxGridDBColumn;
    MTAssinaturasvencimento_licenca: TDateField;
    GAssinaturasDBTableViewvencimento_licenca: TcxGridDBColumn;
    QInstalacaonome_vendedor: TStringField;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewnome_vendedor: TcxGridDBColumn;
    QInstalacaoobservacao_negocio: TStringField;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewobservacao_negocio: TcxGridDBColumn;
    FDQuery1: TFDQuery;
    QInstalacaoULTIMA_VENDA: TDateTimeField;
    QInstalacaoTEMPO_ULT_VENDA: TStringField;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewTEMPO_ULT_VENDA: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewULTIMA_VENDA: TcxGridDBColumn;
    QInstalacaodt_primeiro_pgto: TDateField;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewdt_primeiro_pgto: TcxGridDBColumn;
    dtfldQInstalacaoDT_Aguard_instalacao: TDateField;
    dtfldQInstalacaoDT_Aguardandocliente_p_instal: TDateField;
    dtfldQInstalacaoDT_Teste_demo: TDateField;
    dtfldQInstalacaoDT_aguardando_migracao: TDateField;
    dtfldQInstalacaoDt_em_migracao: TDateField;
    dtfldQInstalacaoDt_em_conf_migracao: TDateField;
    dtfldQInstalacaoDT_em_instalacao: TDateField;
    dtfldQInstalacaoDT_agendar_treinamento: TDateField;
    dtfldQInstalacaoDT_prim_treinamento: TDateField;
    dtfldQInstalacaoDt_Seg_treinamento: TDateField;
    dtfldQInstalacaoDt_reagendar_Treinamento: TDateField;
    dtfldQInstalacaoDt_treinamento_concluido: TDateField;
    dtfldQInstalacaoDt_retorno_cs: TDateField;
    dtfldQInstalacaoDt_pos_venda: TDateField;
    dtfldQInstalacaoDt_concluido: TDateField;
    dtfldQInstalacaoDt_desistencia: TDateField;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDT_Aguard_instalacao: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDT_Aguardandocliente_p_instal: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDT_Teste_demo: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDT_aguardando_migracao: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_em_migracao: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_em_conf_migracao: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDT_em_instalacao: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDT_agendar_treinamento: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDT_prim_treinamento: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_Seg_treinamento: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_reagendar_Treinamento: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_treinamento_concluido: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_retorno_cs: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_pos_venda: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_concluido: TcxGridDBColumn;
    cxgrdbclmnGerenciadoInstalacoesDBTableViewDt_desistencia: TcxGridDBColumn;
    G4: TMenuItem;
    N8: TMenuItem;
    MTServidoresanydesk: TStringField;
    MTServidoresuso_cpu: TFMTBCDField;
    MTServidoresuso_memoria: TFMTBCDField;
    MTServidoresdrive_disco: TStringField;
    MTServidoresespaco_total_disco: TFMTBCDField;
    MTServidoresespaco_livre_disco: TFMTBCDField;
    GServidoresDBTableViewnumero_servidor: TcxGridDBColumn;
    GServidoresDBTableViewanydesk: TcxGridDBColumn;
    GServidoresDBTableViewuso_cpu: TcxGridDBColumn;
    GServidoresDBTableViewuso_memoria: TcxGridDBColumn;
    GServidoresDBTableViewdrive_disco: TcxGridDBColumn;
    GServidoresDBTableViewespaco_total_disco: TcxGridDBColumn;
    GServidoresDBTableViewespaco_livre_disco: TcxGridDBColumn;
    cxgrdbclmnGDRPDadosCaixaDBTableView1Column1: TcxGridDBColumn;
    cxGDRPDadosCaixaDBTableView1Column1: TcxGridDBColumn;
    FDQClientesCaixaNOME_COMERCIAL: TStringField;
    FDQClientesCaixaDESCRICAO_ESCRITORIO: TStringField;
    QGerenciadorComissoesdescricao_certificadora: TStringField;
    GRelComissaoIndicadorDBTableViewColumn1: TcxGridDBColumn;
    TabqtdContador: TTabSheet;
    cxGrid7: TcxGrid;
    cxGridDBTableView8: TcxGridDBTableView;
    cxGridDBTableView8ID_CONTADOR: TcxGridDBColumn;
    cxGridDBTableView8NOME_COMERCIAL: TcxGridDBColumn;
    cxGridDBTableView8DESCRICAO_ESCRITORIO: TcxGridDBColumn;
    cxGridDBTableView8qtd_indicacoes: TcxGridDBColumn;
    cxGridLevel18: TcxGridLevel;
    QServidores: TFDQuery;
    QServidoresid_server_nuvem: TFDAutoIncField;
    QServidoresdescricao_nuvem: TStringField;
    QServidoresdns: TStringField;
    QServidoresvalor_nuvem: TSingleField;
    QServidoresconsumo_medio_ram: TIntegerField;
    QServidoresdata_ult_consulta_consumo: TDateField;
    QServidoresdisponivel: TBooleanField;
    QServidoresporta_teste_conexao: TIntegerField;
    QServidoresdatabase_teste_conexao: TStringField;
    QServidoresusuario_teste_conexao: TStringField;
    QServidoressenha_teste_conexao: TStringField;
    QServidoresselect_teste_conexao: TStringField;
    QServidoresnumero_servidor: TIntegerField;
    QServidoresporta_api_servidor: TIntegerField;
    QServidoresdesativado: TBooleanField;
    strngfldQServidoresanydesk: TStringField;
    QServidoresuso_cpu: TFMTBCDField;
    QServidoresuso_memoria: TFMTBCDField;
    strngfldQServidoresdrive_disco: TStringField;
    QServidoresespaco_total_disco: TFMTBCDField;
    QServidoresespaco_livre_disco: TFMTBCDField;
    QtdIndContador: TFDQuery;
    QtdIndContadorID_CONTADOR: TIntegerField;
    QtdIndContadorDESCRICAO_ESCRITORIO: TStringField;
    QtdIndContadorNOME_RESP: TStringField;
    QtdIndContadorNOME_COMERCIAL: TStringField;
    QtdIndContadorCIDADE: TStringField;
    QtdIndContadorqtd_indicacoes: TLargeintField;
    QtdIndContadortotal_valor: TFMTBCDField;
    QtdIndContadortotal_comissao: TFMTBCDField;
    QtdIndContadorpercentual_comissao: TFMTBCDField;
    DsQtdIndContador: TDataSource;
    cxGridDBTableView8total_valor: TcxGridDBColumn;
    cxGridDBTableView8percentual_comissao: TcxGridDBColumn;
    cxGridDBTableView8total_comissao: TcxGridDBColumn;
    cxGridDBTableView8NOME_RESP: TcxGridDBColumn;
    cxGridDBTableView8CIDADE: TcxGridDBColumn;
    TabComissao: TTabSheet;
    cxGrid8: TcxGrid;
    cxGridDBTableView9: TcxGridDBTableView;
    cxGridDBTableView9NOME_USU1: TcxGridDBColumn;
    cxGridDBTableView9descricao_certificadora1: TcxGridDBColumn;
    cxGridDBTableView9valor_total_emitido_certificadora1: TcxGridDBColumn;
    cxGridDBTableView9percentual_aplicado1: TcxGridDBColumn;
    cxGridDBTableView9valor_total_comissao1: TcxGridDBColumn;
    cxGridLevel19: TcxGridLevel;
    QComissaoAgente: TFDQuery;
    DsComissaoAgente: TDataSource;
    QComissaoAgenteid_usuario: TIntegerField;
    QComissaoAgenteNOME_USU: TStringField;
    QComissaoAgenteid_certificadora: TIntegerField;
    QComissaoAgentedescricao_certificadora: TStringField;
    QComissaoAgentevalor_total_emitido_certificadora: TFMTBCDField;
    QComissaoAgentepercentual_aplicado: TBCDField;
    QComissaoAgentevalor_total_comissao: TFMTBCDField;
    edtiniAgendamentoTarefa: TDateTimePicker;
    edtFinAgendamentoTarefa: TDateTimePicker;
    etDataFinAtualizacao: TDateTimePicker;
    etDataINIAtualizacao: TDateTimePicker;
    CopiarCelula1: TMenuItem;
    CBBuscarDataAgendamento: TCheckBox;
    CbBuscarDataTarefa: TCheckBox;
    QServidoresmedia_uso_memoria: TFMTBCDField;
    QServidoresmedia_uso_cpu: TFMTBCDField;
    QServidoresmedia_latencia: TFMTBCDField;
    QServidoresultima_latencia: TFMTBCDField;
    QServidoresdata_ultima_consulta: TSQLTimeStampField;
    MTServidoresmedia_uso_memoria: TFMTBCDField;
    MTServidoresmedia_uso_cpu: TFMTBCDField;
    MTServidoresmedia_latencia: TFMTBCDField;
    MTServidoresultima_latencia: TFMTBCDField;
    MTServidoresdata_ultima_consulta: TSQLTimeStampField;
    GServidoresDBTableViewColumn1: TcxGridDBColumn;
    GServidoresDBTableViewColumn2: TcxGridDBColumn;
    GServidoresDBTableViewColumn3: TcxGridDBColumn;
    GServidoresDBTableViewColumn4: TcxGridDBColumn;
    GServidoresDBTableViewColumn5: TcxGridDBColumn;
    C6: TMenuItem;
    N9: TMenuItem;
    FDQClientesContadoremail_cli: TStringField;
    E2: TMenuItem;
    FDClientesSemAtualizacaoInicialOBS_VENDA: TMemoField;
    QInstalacaoOBS_VENDA: TMemoField;
    QComissaoAgenteqtd_certificados_individual: TLargeintField;
    QComissaoAgenteqtd_certificados_equipe: TLargeintField;
    cxGridDBTableView9qtd_certificados_individual: TcxGridDBColumn;
    cxGridDBTableView9qtd_certificados_equipe: TcxGridDBColumn;
    procedure btnVisGridClick(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure BtnGridClick(Sender: TObject);
    procedure BitBtn3Click(Sender: TObject);
    procedure btnResetarClick(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure btnDadosGeraisClick(Sender: TObject);
    procedure FDqDadosGeraisCliCalcFields(DataSet: TDataSet);
    procedure btnDadosCaixaClick(Sender: TObject);
    procedure btnQuebraSeqClick(Sender: TObject);
    procedure pgDadosChange(Sender: TObject);
    procedure FDQClientesCaixaCalcFields(DataSet: TDataSet);
    procedure BitBtn11Click(Sender: TObject);
    procedure BitBtn17Click(Sender: TObject);
    procedure BitBtn6Click(Sender: TObject);
    procedure BitBtn12Click(Sender: TObject);
    procedure BitBtn18Click(Sender: TObject);
    procedure BitBtn19Click(Sender: TObject);
    procedure BitBtn7Click(Sender: TObject);
    procedure BitBtn13Click(Sender: TObject);
    procedure BtnSairNuvemClick(Sender: TObject);
    procedure BTNSairZapClick(Sender: TObject);
    procedure BitBtn21Click(Sender: TObject);
    procedure R1Click(Sender: TObject);
    procedure MenuItem1Click(Sender: TObject);
    procedure MenuItem2Click(Sender: TObject);
    procedure tsTabClieSemAtualizacaoEnter(Sender: TObject);
    procedure tabDadosGeraisEnter(Sender: TObject);
    procedure tsDadosCaixasEnter(Sender: TObject);
    procedure TabSheet1Enter(Sender: TObject);
    procedure tsClientesOnlineEnter(Sender: TObject);
    procedure BitBtn28Click(Sender: TObject);
    procedure btnListagemContadoresClick(Sender: TObject);
    procedure P1Click(Sender: TObject);
    procedure MarcarComoInformadoFinanceiro1Click(Sender: TObject);
    procedure I1Click(Sender: TObject);
    procedure pnContatoClienteMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure btnSairSClick(Sender: TObject);
    procedure btnSalvaContataChamClick(Sender: TObject);
    procedure LimpaContato;
    procedure BuscaCrescimentoEmpresa;
    procedure MenuItem4Click(Sender: TObject);
    procedure dbgrdContatoChamadioDrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure GroupBox3MouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure GroupBox2MouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure pnlTClienteContatoMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure dbgrdContatoChamadioMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Panel32MouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure btnVisContadorClick(Sender: TObject);
    procedure BitBtn33Click(Sender: TObject);
    procedure cxGridDBTableView3CustomDrawCell(Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
      AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure pnTitContadorCliMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure pnContadorMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure BtnCancelarClick(Sender: TObject);
    procedure I2Click(Sender: TObject);
    procedure BtnOKClick(Sender: TObject);
    procedure R2Click(Sender: TObject);
    procedure BitBtn38Click(Sender: TObject);
    procedure VerificaoutrosDadosClienteAtendimento(icodclicons: Integer;
      PASTABACKUPFTP, SNaoGeraMovFiscal, SNaoVerificaBackup: string);
    procedure btnverProblemasClick(Sender: TObject);
    procedure BitBtn36Click(Sender: TObject);
    procedure cxGridDBTableViewprobCustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure G1Click(Sender: TObject);
    procedure G2Click(Sender: TObject);
    procedure M1Click(Sender: TObject);
    procedure InserePainelProblemas(icod_cli: Integer; sDescricao, sPastaBackup, sErrosBackup,
      sTipoProb: string);
    procedure R3Click(Sender: TObject);
    procedure B1Click(Sender: TObject);
    procedure cxGDRClientesArquivosGeradosDBTableView1CustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure btnVisualizarClick(Sender: TObject);
    procedure cxGridDBBloqueioCliCustomDrawCell(Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
      AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure btnClientesSemAtualizacaoClick(Sender: TObject);
    procedure TabSheet19Enter(Sender: TObject);
    procedure TabSheet20Enter(Sender: TObject);
    procedure AdvGlowButton1Click(Sender: TObject);
    procedure btnGeraProblemasClick(Sender: TObject);
    procedure cxGClientesExternosEnter(Sender: TObject);
    procedure paEnter(Sender: TObject);
    procedure BtnVisualizarAgendamentoAtualizacaoClick(Sender: TObject);
    procedure GAgendamentoAtualizacaoDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure BtnAgendarAtualizacaoClick(Sender: TObject);
    procedure BtnCancelarAgendamentoClick(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure BtnDesselecionarAgendamentoAtualizacaoClick(Sender: TObject);
    procedure GAgendamentoAtualizacaoDBTableViewDblClick(Sender: TObject);
    procedure GAgendamentoAtualizacaoDBTableViewSELECPropertiesValidate(Sender: TObject;
      var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
    procedure R4Click(Sender: TObject);
    procedure CopiarClula1Click(Sender: TObject);
    procedure ExportarDados1Click(Sender: TObject);
    procedure ImprimirDados1Click(Sender: TObject);
    procedure A1Click(Sender: TObject);
    procedure mniAlternarVersaoBetaClick(Sender: TObject);
    procedure BtnVisualizarTarefasClick(Sender: TObject);
    procedure BtnCancelarTarefaClick(Sender: TObject);
    procedure cxGridDBTableView5CustomDrawCell(Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
      AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure C1Click(Sender: TObject);
    procedure C2Click(Sender: TObject);
    procedure VerretornodeSQL1Click(Sender: TObject);
    procedure Copiarclula2Click(Sender: TObject);
    procedure Exportardados2Click(Sender: TObject);
    procedure Imprimirdados2Click(Sender: TObject);
    procedure VisualizarClientesComVersaoAbaixoDaMinima;
    procedure btncloseVersMinClick(Sender: TObject);
    procedure BtnVisualizarCliVersMinClick(Sender: TObject);
    procedure Agendaratualizao1Click(Sender: TObject);
    procedure Agendartarefa1Click(Sender: TObject);
    procedure MenuItem5Click(Sender: TObject);
    procedure BtnVerTodosPlanosClick(Sender: TObject);
    procedure BtnNovoPlanoClick(Sender: TObject);
    procedure BtnAlterarPlanoClick(Sender: TObject);
    procedure GPlanoDBTableViewDblClick(Sender: TObject);
    procedure PopupPlanosPopup(Sender: TObject);
    procedure D1Click(Sender: TObject);
    procedure GPlanoDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
      AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure P2Click(Sender: TObject);
    procedure btnVisCertExternoClick(Sender: TObject);
    procedure TabClientesExternosEnter(Sender: TObject);
    procedure AdvGlowButton2Click(Sender: TObject);
    procedure Observaocliente1Click(Sender: TObject);
    procedure PnObsClienteMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure MDadosAtendimentoMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure pnTituloObsMouseDown(Sender: TObject; Button: TMouseButton; Shift: TShiftState;
      X, Y: Integer);
    procedure btnSalvarClick(Sender: TObject);
    procedure BtnNovoContadorClick(Sender: TObject);
    procedure BtnAlterarContadorClick(Sender: TObject);
    procedure cxGridDBfINANCEIROView3DblClick(Sender: TObject);
    procedure BtnLancarIndicacaoClick(Sender: TObject);
    procedure QGerenciadorComissoesCalcFields(DataSet: TDataSet);
    procedure EdtNomeContadorChange(Sender: TObject);
    procedure EdtNomeContadorEnter(Sender: TObject);
    procedure EdtNomeContadorExit(Sender: TObject);
    procedure DBGContadorDblClick(Sender: TObject);
    procedure DBGContadorDrawColumnCell(Sender: TObject; const Rect: TRect; DataCol: Integer;
      Column: TColumn; State: TGridDrawState);
    procedure DBGContadorExit(Sender: TObject);
    procedure DBGContadorKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure DBGContadorKeyPress(Sender: TObject; var Key: Char);
    procedure GRelComissaoIndicadorDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure Alterarindicao1Click(Sender: TObject);
    procedure BtnImprimirClick(Sender: TObject);
    procedure Excluirlanamento2Click(Sender: TObject);
    procedure BtnVisualizarAgendaClick(Sender: TObject);
    procedure CopiarClula3Click(Sender: TObject);
    procedure Exportarparaexcel1Click(Sender: TObject);
    procedure Imprimirtela1Click(Sender: TObject);
    procedure QInstalacaoCalcFields(DataSet: TDataSet);
    procedure BtnInstalacoesClick(Sender: TObject);
    procedure cxGerenciadoInstalacoesDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure MenuItem11Click(Sender: TObject);
    procedure MenuItem12Click(Sender: TObject);
    procedure MenuItem13Click(Sender: TObject);
    procedure MenuItem8Click(Sender: TObject);
    procedure Abriragenda1Click(Sender: TObject);
    procedure AguardandoInstalao1Click(Sender: TObject);
    procedure EmInstalao1Click(Sender: TObject);
    procedure Retorno1Click(Sender: TObject);
    procedure Concluido1Click(Sender: TObject);
    procedure ContatodoclienteContatodocliente1Click(Sender: TObject);
    procedure Contatosdocliente1Click(Sender: TObject);
    procedure Contatoscliente1Click(Sender: TObject);
    procedure Contatosdocliente2Click(Sender: TObject);
    procedure FDClientesSemAtualizacaoInicialCalcFields(DataSet: TDataSet);
    procedure MenuItem19Click(Sender: TObject);
    procedure MenuItem20Click(Sender: TObject);
    procedure MenuItem21Click(Sender: TObject);
    procedure MenuItem22Click(Sender: TObject);
    procedure C3Click(Sender: TObject);
    procedure R5Click(Sender: TObject);
    procedure BtnRemoverAssinaturaClick(Sender: TObject);
    procedure BtnAlterarAssinaturaClick(Sender: TObject);
    procedure BtnVerAssinaturasClick(Sender: TObject);
    procedure GAssinaturasDBTableViewDblClick(Sender: TObject);
    procedure InformarAlterarPlanoeMdulos1Click(Sender: TObject);
    procedure InserirAlterarClientenaAsaas1Click(Sender: TObject);
    procedure FDQClientesContadorCalcFields(DataSet: TDataSet);
    procedure checkTodosClick(Sender: TObject);
    procedure CGFiltroStatusMensalidadePropertiesChange(Sender: TObject);
    procedure EdtClienteEnter(Sender: TObject);
    procedure BtnVisualizarNuvemClick(Sender: TObject);
    procedure QNuvemCalcFields(DataSet: TDataSet);
    procedure MenuItem23Click(Sender: TObject);
    procedure MenuItem24Click(Sender: TObject);
    procedure MenuItem25Click(Sender: TObject);
    procedure MenuItem15Click(Sender: TObject);
    procedure AdvGlowButton4Click(Sender: TObject);
    procedure AlterarValor1Click(Sender: TObject);
    procedure Contatosdocliente3Click(Sender: TObject);
    procedure EdtClientesAgendamentoEnter(Sender: TObject);
    procedure EdtClientePainelProbChange(Sender: TObject);
    procedure EdtClientePainelProbEnter(Sender: TObject);
    procedure EdtClientesArquivosFiscaisEnter(Sender: TObject);
    procedure EdtDadosGeraisClienteEnter(Sender: TObject);
    procedure BtnInstalacoesEnter(Sender: TObject);
    procedure btnSalvarNuvenClick(Sender: TObject);
    procedure btnSalvarObsCliClick(Sender: TObject);
    procedure BtnAgendarTarefaClick(Sender: TObject);
    procedure TabAgendamentoTarefasEnter(Sender: TObject);
    procedure TabAgendamentoEnter(Sender: TObject);
    procedure Desativar1Click(Sender: TObject);
    procedure G3Click(Sender: TObject);
    procedure BtnVisABCClick(Sender: TObject);
    procedure EdtDescABCEnter(Sender: TObject);
    procedure cxGCurvaABCDBTableView4CustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure QrelABCCalcFields(DataSet: TDataSet);
    procedure C4Click(Sender: TObject);
    procedure BitBtn10Click(Sender: TObject);
    procedure popInfContadorPopup(Sender: TObject);
    procedure c5Click(Sender: TObject);
    procedure BtnReajustarAssinaturasClick(Sender: TObject);
    procedure BitBtn4Click(Sender: TObject);
    procedure BtnVincularTitularClick(Sender: TObject);
    procedure E1ddClick(Sender: TObject);
    procedure A3Click(Sender: TObject);
    procedure BtnSairDadosNuvemClick(Sender: TObject);
    procedure BtnSalvarDadosNuvemClick(Sender: TObject);
    procedure BtnClientesDispositivosClick(Sender: TObject);
    procedure GNuvemDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
      AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure cxGridDBTableView6CustomDrawGroupCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableCellViewInfo; var ADone: Boolean);
    procedure a4Click(Sender: TObject);
    procedure R7Click(Sender: TObject);
    procedure T1Click(Sender: TObject);
    procedure EdtNomeContadorClienteChange(Sender: TObject);
    procedure EdtNomeContadorClienteExit(Sender: TObject);
    procedure DBGContadorClienteDblClick(Sender: TObject);
    procedure DBGContadorClienteDrawColumnCell(Sender: TObject; const Rect: TRect; DataCol: Integer;
      Column: TColumn; State: TGridDrawState);
    procedure DBGContadorClienteExit(Sender: TObject);
    procedure DBGContadorClienteKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure DBGContadorClienteKeyPress(Sender: TObject; var Key: Char);
    procedure btnVisualizaServidoresClick(Sender: TObject);
    procedure GServidoresDBTableViewDblClick(Sender: TObject);
    procedure BtnBuscaClientesZapClick(Sender: TObject);
    procedure AlterarObservao1Click(Sender: TObject);
    procedure BtnGerarSubDominioClick(Sender: TObject);
    procedure T2Click(Sender: TObject);
    procedure D2Click(Sender: TObject);
    procedure BtnAplicarQuantidadeMaquinasGratuitasPadraoClick(Sender: TObject);
    procedure guardandooclienteparainstalao1Click(Sender: TObject);
    procedure AguardandoMigrao1Click(Sender: TObject);
    procedure Primeirotreinamento1Click(Sender: TObject);
    procedure Segundotreinamento1Click(Sender: TObject);
    procedure E1Click(Sender: TObject);
    procedure VerificarStatuspagmento1Click(Sender: TObject);
    procedure G4Click(Sender: TObject);
    procedure GServidoresDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
    procedure CopiarCelula1Click(Sender: TObject);
    procedure CbBuscarDataTarefaClick(Sender: TObject);
    procedure CBBuscarDataAgendamentoClick(Sender: TObject);
    procedure C6Click(Sender: TObject);
    procedure E2Click(Sender: TObject);
  private
    FIdNuvem: Integer;

    function RemoveChar(const Texto: string): string;
    procedure AbrirTelaPlanoCliente;
    procedure AbrirTelaAssinaturaCliente(CodigoCliente: Integer);
    procedure BuscaIndicacoes(indice: Integer);
    procedure RemoverAssinatura(DataSet: TDataSet);
    procedure CriarAlterarAssinatura(DataSet: TDataSet; const AAlteracao: Boolean = False);
    function GerarNomeSubdominio(const NomeCliente: string): string;
    procedure GeraqtdImndicacoesContador;
    procedure GeraComissaoAgente;
    function GerarSenha: string;

  var
    cTotalpagoNuvem: Currency;

    IcodClienteContador: Integer;
  public
    { Public declarations }
  end;

var
  frmMonitorClientes: TfrmMonitorClientes;

implementation

uses
  Udm, uGerarLicenca, uBloquearCliente, UAgendamentoAtualizacao,
  UAgendamentoTarefa, UReajusteAssinatura, SmartTefIntegrator,
  URetornoSQLTarefa, UCadPlanos, UCustomJSON, UPlanosCliente, UCadContador,
  UIndicacaoContador, UAPICilosContadorProvider,
  UAgenda, UContatoClientes, UGeraAtendimento, UAssinaturaCliente,
  UListagemClientesPorTitular, uConnections, UObservacao, Zenith.Jsons;

{$R *.dfm}

procedure TfrmMonitorClientes.btnDadosCaixaClick(Sender: TObject);
begin

  { BUSCA CLIENTES SEM ATUALIZACAO }
  WITH FDQClientesCaixa do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT  ' + '    c.cod_cli, ' + '    c.NOME_FANTASIA, ' + '    c.NOME_CLI, ' +
      '    c.CNPJ_CLI, ' + '    c.CIDRES_CLI, ' + '    P.descricao, ' + '    ca.COD_CAI, ' +
      '    ca.DESC_CAI, ' + '    ca.COD_EMP, ' + '    ca.NUMERO_SERIE_SAT, ' + '    ca.OFF_LINE, ' +
      '    ca.DATA_ULT_ENVIO_ARQ, ' + '    ca.STATUS_REDE_SAT, ' +
      '    ca.DATA_HORA_ULT_ENVIO_SAT, ' + '    ca.DATA_HORA_ULT_SEFAZ_SAT, ' +
      '    ca.ESTADO_OPERACAO_SAT, ' + '    ca.ULTIMO_CFE_SAT, ' + '    ca.TIPO_CAIXA, ' +
      '    ca.TEF_CAI, ' + '    ca.DATA_HORA_ULT_VENDA, ' + '    ca.data_hora_sicronizacao, ' +
      '    ca.PASTA_BACKUP_FTP, ' + '    ct.NOME_COMERCIAL, ' + '    ct.DESCRICAO_ESCRITORIO ' +
      'FROM cliente c ' + 'LEFT JOIN ponto_revenda P  ' +
      '       ON P.cod_ponto = c.cod_ponto_revenda ' + 'INNER JOIN clientes_caixas ca  ' +
      '       ON ca.cod_cli = c.cod_cli ' + 'LEFT JOIN contador_cliente cc  ' +
      '       ON cc.COD_CLIENTE = c.cod_cli ' + 'LEFT JOIN contador ct  ' +
      '       ON ct.ID_CONTADOR = cc.COD_CONTADOR ' + 'WHERE  ' + '      c.ATIVO = ' +
      quotedstr('S') + '  AND c.CNPJ_CLI NOT LIKE ' + quotedstr('% .   .   - %') +
      '  AND c.COD_CON <> 13 ' + '  AND (c.cod_cli NOT IN (0,1,6,7,8) AND c.cod_cla <> 30) ');
    if dm.ipontoRevenda > 1 then
    begin
      SQL.Add(' and (cod_ponto_revenda  = :COD_PONTO ) ');
      parambyname('COD_PONTO').asstring := INTTOSTR(dm.ipontoRevenda);
    end;

    SQL.Add(' GROUP BY    c.cod_cli,ca.COD_CAI');
    open;
  end;
end;

procedure TfrmMonitorClientes.A1Click(Sender: TObject);
begin
  if FDqDadosGeraisCli.Isempty then
    exit;

  Application.CreateForm(TFrmAgendamentoTarefa, FrmAgendamentoTarefa);
  FrmAgendamentoTarefa.tag := 3;
  with FrmAgendamentoTarefa do
  begin
    CodigoCliente := FDqDadosGeraisClicod_cli.asinteger;
    NomeCliente := trim(FDqDadosGeraisCliNOME_FANTASIA.asstring);
    CodigoEmpresa := FDqDadosGeraisClicod_emp.asinteger;
    PASTABACKUPFTP := trim(FDqDadosGeraisCliPASTA_BACKUP_FTP.asstring);
  end;

  FrmAgendamentoTarefa.ShowModal;
end;

procedure TfrmMonitorClientes.mniAlternarVersaoBetaClick(Sender: TObject);
var
  iCodCli, iNovoValor: Integer;
  sAcao: string;
begin
  if FDQClientesContador.IsEmpty then
    exit;

  iCodCli := FDQClientesContadorcod_cli.AsInteger;
  if FDQClientesContadorUSAR_VERSAO_BETA.AsInteger = 1 then
  begin
    iNovoValor := 0;
    sAcao := 'retirar o cliente do beta';
  end
  else
  begin
    iNovoValor := 1;
    sAcao := 'colocar o cliente em beta';
  end;

  if MessageDlg('Deseja realmente ' + sAcao + '?', mtConfirmation, [mbYes, mbNo], 0) <> mrYes then
    exit;

  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add('UPDATE cliente SET usar_versao_beta = :usar_versao_beta WHERE cod_cli = :cod_cli');
    ParamByName('usar_versao_beta').AsInteger := iNovoValor;
    ParamByName('cod_cli').AsInteger := iCodCli;
    ExecSQL;
  end;

  btnVisContadorClick(btnVisContador);
  FDQClientesContador.Locate('cod_cli', iCodCli, []);
end;
procedure TfrmMonitorClientes.A3Click(Sender: TObject);
begin
  PnAlterarDadosNuvem.Left := (frmMonitorClientes.ClientWidth div 2) -
    (PnAlterarDadosNuvem.Width div 2);
  PnAlterarDadosNuvem.Top := (frmMonitorClientes.ClientHeight div 2) -
    (PnAlterarDadosNuvem.Height div 2);

  FIdNuvem := QNuvemid_grupo.asinteger;
  edtDescricaoDadosNuvem.Text := QNuvemdescricao.asstring;
  edtServidorDadosNuvem.Text := QNuvemservidor.asstring;
  edtPortaPrincipalDadosNuvem.Text := QNuvemporta_principal.asinteger.tostring;
  edtPortaArquivosDadosNuvem.Text := QNuvemporta_Arquivos.asinteger.tostring;
  edtPortaAplicativosDadosNuvem.Text := QNuvemporta_aplicativos.asinteger.tostring;
  PnAlterarDadosNuvem.visible := true;
  PnAlterarDadosNuvem.bringtofront;
  edtDescricaoDadosNuvem.setfocus;
end;

procedure TfrmMonitorClientes.a4Click(Sender: TObject);
begin
  with FdQAux do
  begin

    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 3  , DT_Aguard_instalacao = :DT_agendar_treinamento     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('DT_agendar_treinamento').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.Abriragenda1Click(Sender: TObject);
begin
  Application.CreateForm(Tfrmagenda, frmagenda);
  frmagenda.tag := 2;
  frmagenda.edtCodcli.Text := QInstalacaocod_cli.asstring;
  frmagenda.edtNomeCli.Text := QInstalacaoNOME_CLI.asstring;
  frmagenda.ShowModal;
end;

procedure TfrmMonitorClientes.AbrirTelaAssinaturaCliente(CodigoCliente: Integer);
begin
  Application.CreateForm(TFrmAssinaturaCliente, FrmAssinaturaCliente);
  FrmAssinaturaCliente.CodigoCliente := CodigoCliente;
  FrmAssinaturaCliente.ShowModal;
end;

procedure TfrmMonitorClientes.AbrirTelaPlanoCliente;
begin
  if dm.RemoveChar(FDQClientesContadorCNPJ_CLI.asstring).trim = EmptyStr then
  begin
    showmessage('Este cliente est� sem CNPJ!');
    exit;
  end;

  Application.CreateForm(TFrmPlanosCliente, FrmPlanosCliente);
  FrmPlanosCliente.iCodigoCliente := FDQClientesContadorcod_cli.asinteger;
  FrmPlanosCliente.sNomeCliente := FDQClientesContadorNOME_FANTASIA.asstring;
  FrmPlanosCliente.sCNPJCliente := FDQClientesContadorCNPJ_CLI.asstring;
  FrmPlanosCliente.EdtValorAssinatura.value := FDQClientesContadorvalor_mensalidade.ascurrency;
  FrmPlanosCliente.ShowModal;
end;

procedure TfrmMonitorClientes.AdvGlowButton1Click(Sender: TObject);
var
  cQtdClientes, cQtdClientesPeriodo, cTotalClientes, cTotalClientesPeriodo, cTotalAux: Currency;
  idiasDifMeta, idiasAtual, ipercclientes: Integer;
  DataAux: tdate;
begin
  cQtdClientes := 0;
  cTotalClientes := 0;
  cTotalAux := 0;
  cQtdClientesPeriodo := 0;
  cTotalClientesPeriodo := 0;
  if edtDataIniMeta.date > date then
  begin
    showmessage('A data inicial nao pode ser maior que a data atual');
    edtDataIniMeta.setfocus;
    exit;
  end;

  { Busca clientes sem mensalidade }
  { with FdQAux do
    begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT c.cod_cli,c.NOME_CLI FROM cliente c  ' +
    ' WHERE c.valor_mensalidade <=0   and ' + ' c.cod_cli <> 1 AND  ' +
    ' c.cod_cli <> 7  ' + ' AND  c.cod_cli <> 8 ' + ' AND  c.cod_cli <> 6   '
    + ' and c.ATIVO = ' + #39 + 'S' + #39 + ' ');
    if CbCentral.itemindex > 0 then
    begin
    SQL.Add('  and  c.COD_CON = :COD_CON   ');
    parambyname('COD_CON').asinteger := CbCentral.itemindex;
    end;
    open;
    end;
    if FdQAux.recordcount > 0 then
    begin
    showmessage(FdQAux.fieldbyname('cod_cli').asstring + ' - ' +
    FdQAux.fieldbyname('NOME_CLI').asstring +
    ' EST� SEM MENSALIDADE CADASTRADA');
    exit;
    abort;
    end; }

  { Busca qtd de Clientes }
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT count(c.cod_cli)  as qtd FROM cliente c   ' + ' WHERE c.cod_cli <> 1 AND    ' +
      ' c.cod_cli <> 7  and c.cod_cla <>30  ' +
      ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6 and c.cod_cli < 10000000   and c.ATIVO =  ' + #39 +
      'S' + #39 + '  AND c.cod_cla <>30 AND COALESCE(c.STATUS_INSTAL,0) <> 8  ');
    if CbCentral.itemindex > 0 then
    begin
      SQL.Add('  and  c.COD_CON = :COD_CON   ');
      parambyname('COD_CON').asinteger := CbCentral.itemindex;
    end;
    open;
  end;
  cQtdClientes := FdQAux.fieldbyname('qtd').asinteger;
  PBQtdClientes.Percent := TRUNC((cQtdClientes / strtoint(EdtQtdMeta.Text)) * 100);
  EdtQtdAtual.Text := currtostr(cQtdClientes);
  GbQtdClientesFaltam.caption := 'Faltam ' + currtostr(strtoint(EdtQtdMeta.Text) - cQtdClientes) +
    ' Clientes para atingirmos a meta';

  { Busca qtd de no per�odo }
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT count(c.cod_cli)  as qtd FROM cliente c   ' + ' WHERE c.cod_cli <> 1 AND    ' +
      ' c.cod_cli <> 7  and c.cod_cla <>30  ' +
      ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6 and c.cod_cli < 10000000   and c.ATIVO =  ' + #39 +
      'S' + #39 + ' AND c.cod_cla <>30 AND COALESCE(c.STATUS_INSTAL,0) <> 8  ');
    if CbCentral.itemindex > 0 then
    begin
      SQL.Add('  and  c.COD_CON = :COD_CON   ');
      parambyname('COD_CON').asinteger := CbCentral.itemindex;
    end;
    SQL.Add('AND DATACADASTRO_CLI BETWEEN :DATAINI AND :DATAFIN ');
    parambyname('DATAINI').asdatetime := date - 180;
    parambyname('DATAFIN').asdatetime := date;
    open;

  end;
  cQtdClientesPeriodo := FdQAux.fieldbyname('qtd').asinteger;

  { Busca Total de Clientes }
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT sum(c.valor_mensalidade)as valor FROM cliente c ' +
      '     WHERE c.cod_cli <> 1 AND    c.cod_cli <> 7 and c.cod_cla <>30  ' +
      '      AND  c.cod_cli <> 8  and c.cod_cli < 10000000 and c.cod_cli <> 6 and c.ATIVO =  ' + #39
      + 'S' + #39 + ' AND c.cod_cla <>30 AND COALESCE(c.STATUS_INSTAL,0) <> 8  ');
    if CbCentral.itemindex > 0 then
    begin
      SQL.Add('  and  c.COD_CON = :COD_CON   ');
      parambyname('COD_CON').asinteger := CbCentral.itemindex;
    end;
    open;
  end;
  cTotalClientes := FdQAux.fieldbyname('valor').ascurrency;
  PBTotalClientes.Percent := TRUNC((cTotalClientes / EdtFatMeta.value) * 100);
  EdtFatAtual.value := cTotalClientes;
  GbValorMeta.caption := 'Faltam R$ ' + FormatFloat('#,##0.00', (EdtFatMeta.value - cTotalClientes))
    + ' para atingirmos a meta';

  { Busca Tickt M�dio }
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT avg(c.valor_mensalidade)as valor FROM cliente c ' +
      '   WHERE c.cod_cli <> 1 and c.cod_cli < 10000000  and c.cod_cla <>30 AND    c.cod_cli <> 7   '
      + '     AND  c.cod_cli <> 8 AND  c.cod_cli <> 6  and c.ATIVO =  ' + #39'S' +
      #39'  AND c.cod_cla <>30 AND COALESCE(c.STATUS_INSTAL,0) <> 8 ');
    if CbCentral.itemindex > 0 then
    begin
      SQL.Add('  and  c.COD_CON = :COD_CON   ');
      parambyname('COD_CON').asinteger := CbCentral.itemindex;
    end;
    open;
  end;
  edtTicktMedio.Text := FormatFloat('#,##0.00', FdQAux.fieldbyname('valor').ascurrency);

  { Busca Meta em dias }
  idiasDifMeta := DaysBetween((EdtDataMeta.date), edtDataIniMeta.date);
  idiasAtual := DaysBetween(date, edtDataIniMeta.date);
  ipercclientes := TRUNC((idiasAtual / idiasDifMeta) * 100);
  pbDiasMeta.Percent := (ipercclientes - 100) * -1;
  GbDiasMeta.caption := 'Faltam ' + dm.RetornaMesMaisAnoPorNumeroDias
    (DaysBetween(EdtDataMeta.date, date)) + ' para acabar o prazo da meta';

  { Calcula Quantidade de clientes por dia }

  edtQtdDia.Text := currtostrf(strtocurr(StringReplace(currtostrf((cQtdClientes / idiasAtual),
    ffnumber, 1), '.', '', [rfReplaceAll])), ffnumber, 1);

  edtQtdMes.Text := currtostrf(strtocurr(StringReplace(currtostrf((strtocurr(edtQtdDia.Text) * 30),
    ffnumber, 1), '.', '', [rfReplaceAll])), ffnumber, 1);

  // INTTOSTR(TRUNC(cQtdClientes / idiasAtual));
  EdtTicktDia.Text := FormatFloat('#,##0.00', (cTotalClientes / idiasAtual));
  edtFatMes.Text := FormatFloat('#,##0.00', (strtocurr(EdtTicktDia.Text) * 30));

  // ============================== PROJE��O FUTURA================================
  { proje��o do numero de clientes clientes }
  cTotalAux := strtoint(EdtQtdAtual.Text);
  DataAux := date;
  repeat
    cTotalAux := cTotalAux + strtocurr(edtQtdDia.Text);
    DataAux := DataAux + 1;
    ;
  until cTotalAux >= strtocurr(EdtQtdMeta.Text);
  lbMetaFuturaClientes.caption := 'Prov�vel dia da meta atingida: ' + datetostr(DataAux) +
    ' caso continue nesse ritimo dia ' + datetostr(EdtDataMeta.date) + ' teremos ' +
    currtostr((strtocurr(edtQtdDia.Text) * ((idiasDifMeta - idiasAtual))) +
    strtocurr(EdtQtdAtual.Text)) + ' Clientes';
  PbQtdClientesFuturo.Percent :=
    TRUNC((((strtocurr(edtQtdDia.Text) * ((idiasDifMeta - idiasAtual))) +
    strtocurr(EdtQtdAtual.Text)) / strtocurr(EdtQtdMeta.Text)) * 100);

  { proje��o de faturamento  clientes }
  cTotalAux := (EdtFatAtual.value);
  DataAux := date;
  repeat
    cTotalAux := cTotalAux + EdtTicktDia.value;
    DataAux := DataAux + 1;
    ;
  until cTotalAux >= (EdtFatMeta.value);
  lbMetaFuturaClientesFaturamento.caption := 'Prov�vel dia da meta atingida: ' + datetostr(DataAux)
    + ' caso continue nesse ritimo dia ' + datetostr(EdtDataMeta.date) + ' teremos ' +
    FormatFloat('#,##0.00', (((EdtTicktDia.value) * ((idiasDifMeta - idiasAtual))) +
    (EdtFatAtual.value))) + ' de faturamento de Clientes';
  PbFaturamentoClientesFuturo.Percent :=
    TRUNC(((((EdtTicktDia.value) * ((idiasDifMeta - idiasAtual))) + (EdtFatAtual.value)) /
    (EdtFatMeta.value)) * 100);
  BuscaCrescimentoEmpresa;
end;

procedure TfrmMonitorClientes.AdvGlowButton2Click(Sender: TObject);
begin
  PnObsCliente.visible := False;
  PnObsCliente.SendToBack;
end;

procedure TfrmMonitorClientes.AdvGlowButton4Click(Sender: TObject);
begin
  PnAlteraValorNuvem.visible := False;

end;

procedure TfrmMonitorClientes.Agendaratualizao1Click(Sender: TObject);
var
  bOK: Boolean;
  versao: Integer;
begin
  bOK := False;

  if MTCliSemVersMin.Isempty then
    exit;

  versao := strtointdef(trim(RemoveChar(MTCliSemVersMinversao_exe_connection.asstring)), 0);

  if versao < 2000 then
  begin
    showmessage
      ('S� � poss�vel agendar uma tarefa se a vers�o do Connection for igual ou acima da 2.0.0.0!');
    exit;
  end;

  with MTCliSemVersMin do
  begin
    try
      DisableControls;

      if MTCliSemVersMin.Isempty then
      begin
        showmessage('selecione pelo menos um cliente para agendar a atualiza��o!');
        exit;
      end;

      Application.CreateForm(TFrmAgendamentoAtualizacao, FrmAgendamentoAtualizacao);
      FrmAgendamentoAtualizacao.tag := 1;
      FrmAgendamentoAtualizacao.ShowModal;

      bOK := true;
    finally
      EnableControls;
    end;
  end;

  if bOK then
    BtnVisualizarAgendamentoAtualizacao.Click;

  cxGVersaoMin.setfocus;
end;

procedure TfrmMonitorClientes.Agendartarefa1Click(Sender: TObject);
begin
  if FDQProblemas.Isempty then
    exit;

  Application.CreateForm(TFrmAgendamentoTarefa, FrmAgendamentoTarefa);

  with FrmAgendamentoTarefa do
  begin
    CodigoCliente := FDQProblemasCOD_CLI.asinteger;
    NomeCliente := trim(FDQProblemasNOME_FANTASIA.asstring);
    CodigoEmpresa := FDQProblemascod_emp.asinteger;
    PASTABACKUPFTP := trim(FDQProblemasPASTA_BACKUP_FTP.asstring);
  end;

  FrmAgendamentoTarefa.ShowModal;
end;

procedure TfrmMonitorClientes.AguardandoInstalao1Click(Sender: TObject);

begin

  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 1, DT_Aguard_instalacao = :DT_Aguard_instalacao     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('DT_Aguard_instalacao').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;

end;

procedure TfrmMonitorClientes.AguardandoMigrao1Click(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 12 , DT_Aguard_instalacao = :DT_aguardando_migracao     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('DT_aguardando_migracao').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.EdtNomeContadorClienteChange(Sender: TObject);
begin

  if (EdtNomeContadorCliente.focused) then
  begin
    if (trim(EdtNomeContadorCliente.Text) <> '') and (EdtNomeContadorCliente.focused) then
    begin
      with FDQListaContadorCliente do
      begin
        Close;
        SQL.Clear;
        SQL.Add('  SELECT *  FROM contador C ');
        SQL.Add(' where  NOME_COMERCIAL like ' + #39 + '%' + trim(EdtNomeContadorCliente.Text) + '%'
          + #39 + '  or  DESCRICAO_ESCRITORIO like ' + #39 + '%' + trim(EdtNomeContadorCliente.Text)
          + '%' + #39 + ' ' + '  or  RAZAO_SOCIAL like ' + #39 + '%' +
          trim(EdtNomeContadorCliente.Text) + '%' + #39 + ' ');
        open;
      end;

      if FDQListaContadorCliente.recordcount <= 0 then
      begin

      end
      else
      begin
        DBGContadorCliente.enabled := true;
        DBGContadorCliente.bringtofront;

      end;

    end;
  end;

end;

procedure TfrmMonitorClientes.EdtNomeContadorClienteExit(Sender: TObject);
begin
  if (DBGContadorCliente.enabled = true) and (DBGContadorCliente.focused) then
    DBGContadorCliente.setfocus;

  if trim(EdtNomeContadorCliente.Text) = '' then
    EdtContadorCliente.Clear;

  if FDQListaContadorCliente.recordcount <= 0 then
  begin
    FDQListaContadorCliente.Close;
    EdtContadorCliente.Clear;
    EdtNomeContadorCliente.Clear;
  end;
end;

procedure TfrmMonitorClientes.Alterarindicao1Click(Sender: TObject);
begin
  if FDQListaContador.Isempty then
    exit;

  Application.CreateForm(TFrmIndicacaoContador, FrmIndicacaoContador);
  FrmIndicacaoContador.tag := 2;
  FrmIndicacaoContador.ShowModal;
  BtnVisualizarAgenda.Click;
end;

procedure TfrmMonitorClientes.AlterarObservao1Click(Sender: TObject);
begin
  Application.CreateForm(TFrmObservacao, FrmObservacao);
  FrmObservacao.tag := 2;
  FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
  FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;
  FrmObservacao.ShowModal;
  BtnInstalacoes.Click;

end;

procedure TfrmMonitorClientes.AlterarValor1Click(Sender: TObject);
begin
  PnAlteraValorNuvem.Left := (frmMonitorClientes.ClientWidth div 2) -
    (PnAlteraValorNuvem.Width div 2);
  PnAlteraValorNuvem.Top := (frmMonitorClientes.ClientHeight div 2) -
    (PnAlteraValorNuvem.Height div 2);

  edtValorNuvem.value := QNuvemvalor_pago_nuvem.ascurrency;
  edtVersaoFirebird.Text := QNuvemversao_fb.asstring;
  PnAlteraValorNuvem.visible := true;
  PnAlteraValorNuvem.bringtofront;
  edtValorNuvem.setfocus;
end;

procedure TfrmMonitorClientes.B1Click(Sender: TObject);
var
  Codigo: Integer;
begin
  cxGrid2.enabled := False;
  Application.CreateForm(TFrmBloquearCliente, FrmBloquearCliente);
  with FrmBloquearCliente do
  begin
    FrmBloquearCliente.PnCliente.caption := FDQClientesContadorcod_cli.asstring + ' - ' +
      FDQClientesContadorNOME_FANTASIA.asstring;
  end;
  FrmBloquearCliente.ShowModal;
  cxGrid2.enabled := true;

  FDQClientesContador.DisableControls;

  try
    Codigo := FDQClientesContadorcod_cli.asinteger;
    btnVisContador.Click;

    FDQClientesContador.Locate('cod_cli', Codigo, []);
  finally
    FDQClientesContador.EnableControls;
  end;
end;

procedure TfrmMonitorClientes.BitBtn10Click(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM agendamento_tarefas WHERE realizada = 0 ');
    execsql;
  end;
  BtnVisualizarTarefas.Click;
end;

procedure TfrmMonitorClientes.BitBtn11Click(Sender: TObject);
var
  stipoRegime: string;
begin

  // ATENCAO, antes de imprimir � necess�rio abrir o dsComponentPrinter com um duplo-clique e colocar

  // um subcomponente do tipo dxGridReportLink aqui abaixo ele ser� chamado de DPrnLink:

  DPrnLink.Component := cxGDRPDadosCaixa; // liga com grid

  DPrnLink.OptionsFormatting.UseNativeStyles := true; // s� preto-branco

  DPrnLink.OptionsSize.AutoWidth := true; // ajusta � pagina

  DPrnLink.PrinterPage.MeasurementUnits := muMillimeters;
  // em milimetro (cada 1000 - 1milimetro)



  // configura visualiza��o

  with TdxGridReportLink(DPrnLink) do

  begiN
    // no relat�rio
    OptionsView.caption := False;
    OptionsView.Headers := true;
    OptionsView.Footers := true;
    OptionsView.GroupFooters := true;
    OptionsView.ExpandButtons := true;
    OptionsView.FilterBar := true;
    // em todas as p�ginas:
    OptionsOnEveryPage.caption := true;
    OptionsOnEveryPage.Headers := true;
    OptionsOnEveryPage.Footers := False;
    OptionsOnEveryPage.FilterBar := False;
  end;
  // define tamanho da linha NA GRID

  cxGDRPDadosCaixaDBTableView1.OptionsView.DataRowHeight := 15;
  // cabe�alho

  with DPrnLink.PrinterPage.PageHeader do

  begin

    LeftTitle.Add(' DADOS CAIXAS CLIENTES ');

    RightTitle.Add(datetostr(date) + ' ' + timetostr(time));
    // RightTitle.add('P�gina[P�gina # de #]');
    // ('[User Name] - [Data & Time Printed] - P�gina[P�gina # de #]');

    LeftTextAlignY := taTop;

    RightTextAlignY := taTop;

    Font.Name := 'Times New Roman';

    Font.Size := 10;

  end;



  // rodap� de p�gina

  with DPrnLink.PrinterPage.PageFooter do

  begin

    RightTitle.Add('SI Tecnologias: (88) 3423-5757');

    RightTextAlignY := taTop;

    Font.Name := 'Times New Roman';

    Font.Size := 6;

  end;



  // margens e papel

  DPrnLink.PrinterPage.Margins.Left := 7000;

  DPrnLink.PrinterPage.Margins.Right := 5000;

  DPrnLink.PrinterPage.Margins.Bottom := 10300;

  DPrnLink.PrinterPage.Margins.Top := 14800;

  DPrnLink.PrinterPage.DMPaper := DMPAPER_A4;



  // titulo do relat�rio

  dsComponentPrinter.PrintTitle := 'IMPRESS�O DO RELAT�RIO';



  // preview

  dsComponentPrinter.Preview;



  // volta tamanho normal

  cxGDRPDadosCaixaDBTableView1.OptionsView.DataRowHeight := 0;
end;

procedure TfrmMonitorClientes.BitBtn12Click(Sender: TObject);
VAR
  FileExt: String;
begin

  // salva o arquivo com os dados do CXGrid
  SaveDialog.Filter :=
    'Excel (*.xls) |*.xls|BrOffice (*.ods) |*.ods|XML (*.xml) |*.xml|Arquivo Texto (*.txt) |*.txt|P�gina Web (*.html)|*.html';
  SaveDialog.Title := 'Exportar Dados';
  SaveDialog.DefaultExt := 'xls';
  if SaveDialog.Execute then
  begin
    FileExt := LowerCase(ExtractFileExt(SaveDialog.FileName));
    if FileExt = '.xls' then
      ExportGridToExcel(SaveDialog.FileName, cxGDRPDadosCaixa, False)
    else if FileExt = '.xml' then
      ExportGridToXML(SaveDialog.FileName, cxGDRPDadosCaixa, False)
    else if FileExt = '.txt' then
      ExportGridToText(SaveDialog.FileName, cxGDRPDadosCaixa, False)
    else if FileExt = '.html' then
      ExportGridToHTML(SaveDialog.FileName, cxGDRPDadosCaixa, False)
    else if FileExt = '.ods' then
      ExportGridToExcel(SaveDialog.FileName, cxGDRPDadosCaixa, False);
    ShellExecute(Handle, 'open', pchar(SaveDialog.FileName), nil, nil, SW_SHOW);
  end;

end;

procedure TfrmMonitorClientes.BitBtn13Click(Sender: TObject);
begin
  { grava grid desenvolvimento }
  cxGDRPDadosCaixaDBTableView1.StoreToIniFile(ExtractFilePath(Application.ExeName) +
    '/frmMonitorClientes.cxGDRPDadosCaixa.ini', true, [gsoUseFilter, gsoUseSummary]);
end;

procedure TfrmMonitorClientes.BTNSairZapClick(Sender: TObject);
begin
  DeleteFile(pchar(ExtractFilePath(Application.ExeName) +
    '\frmMonitorClientes.cxGDRPDadosCaixa.ini'));

  { Carrega Grid Desenvolvimento }
  try
    cxGDRPDadosCaixaDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName) +
      '/frmMonitorClientes.cxGDRPDadosCaixa.ini', true, False, [gsoUseFilter, gsoUseSummary]);
  except

  end;
end;

procedure TfrmMonitorClientes.btnQuebraSeqClick(Sender: TObject);
begin
  { BUSCA CLIENTES SEM ATUALIZACAO }
  WITH FDQCliQuebraSeq do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT c.cod_cli,c.NOME_FANTASIA,c.NOME_CLI,c.CNPJ_CLI,c.CIDRES_CLI,P.descricao,  ' +
      ' q.cod_emp,q.Numero_Cupom_Falta,q.numero_serie_mfe,q.data_hora_sicronizacao,q.PASTA_BACKUP_FTP    '
      + '  FROM cliente c       ' + ' INNER JOIN ponto_revenda P  ' +
      ' ON P.cod_ponto= c.cod_ponto_revenda  ' + ' inner join clientes_cupom_quebra_seq q ' +
      ' on q.cod_cli = c.cod_cli  ' + ' WHERE c.ATIVO =  ' + #39 + 'S' + #39 + ' ' +
      ' AND c.CNPJ_CLI   not LIKE ' + #39 + '% .   .   - %' + #39 + ' ' + '  ' +
      '   and ( c.cod_cli <> 1 and c.cod_cli <> 0 and  c.cod_cli <> 7 ' +
      ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6  and c.cod_cla <>30 )  ');

    open;
  end;

end;

procedure TfrmMonitorClientes.BtnReajustarAssinaturasClick(Sender: TObject);
begin
  Application.CreateForm(TFrmReajusteAssinatura, FrmReajusteAssinatura);
  FrmReajusteAssinatura.tag := 0;
  FrmReajusteAssinatura.ShowModal;
end;

procedure TfrmMonitorClientes.BtnRemoverAssinaturaClick(Sender: TObject);
begin
  RemoverAssinatura(MTAssinaturas);
  BtnVerAssinaturasClick(BtnRemoverAssinatura);
end;

procedure TfrmMonitorClientes.BitBtn17Click(Sender: TObject);
var
  stipoRegime: string;
begin

  // ATENCAO, antes de imprimir � necess�rio abrir o dsComponentPrinter com um duplo-clique e colocar

  // um subcomponente do tipo dxGridReportLink aqui abaixo ele ser� chamado de DPrnLink:

  DPrnLink.Component := cxGQuebraSequencia; // liga com grid
  DPrnLink.OptionsFormatting.UseNativeStyles := true; // s� preto-branco
  DPrnLink.OptionsSize.AutoWidth := true; // ajusta � pagina
  DPrnLink.PrinterPage.MeasurementUnits := muMillimeters;
  // em milimetro (cada 1000 - 1milimetro)
  // configura visualiza��o
  with TdxGridReportLink(DPrnLink) do
  begin

    // no relat�rio
    OptionsView.caption := False;
    OptionsView.Headers := true;
    OptionsView.Footers := true;
    OptionsView.GroupFooters := true;
    OptionsView.ExpandButtons := true;
    OptionsView.FilterBar := true;
    // em todas as p�ginas:
    OptionsOnEveryPage.caption := true;
    OptionsOnEveryPage.Headers := true;
    OptionsOnEveryPage.Footers := False;
    OptionsOnEveryPage.FilterBar := False;
  end;
  // define tamanho da linha NA GRID
  cxGridDBTableView1.OptionsView.DataRowHeight := 15;
  // cabe�alho
  with DPrnLink.PrinterPage.PageHeader do
  begin
    LeftTitle.Add(' QUEBRA DE SEQU�NCIA ');
    // RightTitle.add('P�gina[P�gina # de #]');
    // ('[User Name] - [Data & Time Printed] - P�gina[P�gina # de #]');
    LeftTextAlignY := taTop;
    RightTextAlignY := taTop;
    Font.Name := 'Times New Roman';
    Font.Size := 10;
  end;
  // rodap� de p�gina
  with DPrnLink.PrinterPage.PageFooter do
  begin
    RightTitle.Add('SI Tecnologias: (88) 3423-5757');
    RightTextAlignY := taTop;
    Font.Name := 'Times New Roman';
    Font.Size := 6;
  end;

  // margens e papel
  DPrnLink.PrinterPage.Margins.Left := 7000;
  DPrnLink.PrinterPage.Margins.Right := 5000;
  DPrnLink.PrinterPage.Margins.Bottom := 10300;
  DPrnLink.PrinterPage.Margins.Top := 14800;
  DPrnLink.PrinterPage.DMPaper := DMPAPER_A4;
  // titulo do relat�rio
  dsComponentPrinter.PrintTitle := 'IMPRESS�O DO RELAT�RIO';
  // preview
  dsComponentPrinter.Preview;
  // volta tamanho normal
  cxGridDBTableView1.OptionsView.DataRowHeight := 0;
end;

procedure TfrmMonitorClientes.BitBtn18Click(Sender: TObject);
VAR
  FileExt: String;
begin

  // salva o arquivo com os dados do CXGrid
  SaveDialog.Filter :=
    'Excel (*.xls) |*.xls|BrOffice (*.ods) |*.ods|XML (*.xml) |*.xml|Arquivo Texto (*.txt) |*.txt|P�gina Web (*.html)|*.html';
  SaveDialog.Title := 'Exportar Dados';
  SaveDialog.DefaultExt := 'xls';
  if SaveDialog.Execute then
  begin
    FileExt := LowerCase(ExtractFileExt(SaveDialog.FileName));
    if FileExt = '.xls' then
      ExportGridToExcel(SaveDialog.FileName, cxGQuebraSequencia, False)
    else if FileExt = '.xml' then
      ExportGridToXML(SaveDialog.FileName, cxGQuebraSequencia, False)
    else if FileExt = '.txt' then
      ExportGridToText(SaveDialog.FileName, cxGQuebraSequencia, False)
    else if FileExt = '.html' then
      ExportGridToHTML(SaveDialog.FileName, cxGQuebraSequencia, False)
    else if FileExt = '.ods' then
      ExportGridToExcel(SaveDialog.FileName, cxGQuebraSequencia, False);
    ShellExecute(Handle, 'open', pchar(SaveDialog.FileName), nil, nil, SW_SHOW);
  end;

end;

procedure TfrmMonitorClientes.BitBtn19Click(Sender: TObject);
begin
  { grava grid desenvolvimento }
  cxGridDBTableView1.StoreToIniFile(ExtractFilePath(Application.ExeName) +
    '/frmMonitorClientes.cxGQuebraSequencia.ini', true, [gsoUseFilter, gsoUseSummary]);
end;

procedure TfrmMonitorClientes.BitBtn1Click(Sender: TObject);
begin
  if MTAgendamentoAtualizacao.Isempty then
    exit;

  with MTAgendamentoAtualizacao do
  begin
    try
      DisableControls;
      first;

      while not eof do
      begin
        Edit;
        fieldbyname('selec').asinteger := 1;
        Post;

        next;
      end;

      first;
    finally
      EnableControls;
    end;
  end;

  GAgendamentoAtualizacao.setfocus;
end;

procedure TfrmMonitorClientes.btnVisContadorClick(Sender: TObject);
begin

  { Busca clientes Contador }
  with FDQClientesContador do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select ' + '  dados.*, ' + '  case ' +
      '    when coalesce(dados.valor_mensalidade,0) <> coalesce(dados.calc_valor_mensalidade,0) then '
      + quotedstr('SIM') + '    else ' + quotedstr('N�O') + '  end as mensalidade_dif, ' +
      '  (coalesce(dados.calc_valor_mensalidade,0) - coalesce(dados.valor_mensalidade,0)) as dif_mensalidade '
      + 'from ( ' + '  select ' + '    c.cod_cli, ' + '    c.usar_versao_beta, ' +
      '    case when coalesce(c.usar_versao_beta, 0) = 1 then ' + quotedstr('SIM') +
      ' else ' + quotedstr('N' + #195 + 'O') + ' end as USAR_VERSAO_BETA_DESC, ' +
      '    c.NOME_FANTASIA, c.email_cli, ' +
      '    c.NOME_CLI, ' + '    c.CNPJ_CLI, ' + '    c.CIDRES_CLI, ' + '    pr.descricao, ' +
      '    ct.NOME_COMERCIAL, ' + '    ct.ID_CONTADOR, ' + '    c.DATACADASTRO_CLI, ' +
      '    c.COD_CON, ' + '    c.cod_cla, ' + ' ' + '    li.chave as Chave_Cliente, ' +
      '    if(li.vencimento is null,' + quotedstr('NAO') + ', ' + quotedstr('SIM') +
      ' ) as chave_possui_vencimento, ' + '    li.vencimento as vencimento_chave, ' + ' ' +
      '    c.bloquear, ' + '    c.data_de_bloqueio, ' + '    c.numero_parcelas, ' +
      '    c.valor_total_parcelas, ' + '    c.data_desbloq_conf, ' + '    c.valor_mensalidade, ' +
      ' ' + '    case when c.bloquear = 1 then ' + quotedstr('SIM') + ' else ' + quotedstr('N�O') +
      ' end as DESC_BLOQ, ' + '    case when ca.id is not null then ' + quotedstr('SIM') + ' else '
      + quotedstr('N�O') + ' end as possui_assinatura, ' +
      '    case when cp_main.id_plano is not null then ' + quotedstr('SIM') + ' else ' +
      quotedstr('N�O') + ' end as possui_plano, ' + '    upper(cp_main.desc_plano) as desc_plano, '
      + ' ' + '    sum( ' + '      cp2.qtd * ( ' + '        case ' +
      '          when (cp2.qtd >= coalesce(pl2.qtd_acima,0)) ' +
      '            then (case when coalesce(pl2.valor_qtd,0.00) > 0 then pl2.valor_qtd else pl2.valor end) '
      + '          else pl2.valor ' + '        end ' + '      ) ' +
      '    ) as calc_valor_mensalidade, ' + ' ' + '    c.receber_carne_impresso, ' +
      '    case coalesce(c.receber_carne_impresso,' + quotedstr('') + ') when ' + quotedstr('S') +
      ' then ' + quotedstr('SIM') + ' else ' + quotedstr('N�O') +
      ' end as calc_receber_carne_impresso ' + ' ' + '  from cliente c ' +
      '  inner join ponto_revenda pr on pr.cod_ponto = c.COD_CON ' +
      '  left join contador_cliente cc on cc.COD_CLIENTE = c.cod_cli ' +
      '  left join contador ct on ct.ID_CONTADOR = cc.COD_CONTADOR ' + ' ' + '  left join ( ' +
      '    select ' + '      l.cnpj, ' + '      max(l.chave) as chave, ' +
      '      max(l.vencimento) as vencimento ' + '    from licencas l ' +
      '    where l.sistema_id = 1 ' + '    group by l.cnpj ' + '  ) li on li.cnpj = c.CNPJ_CLI ' +
      ' ' + '  left join ( ' + '    select ca.id_cli, max(ca.id) as id ' +
      '    from cliente_assinaturas ca ' + '    group by ca.id_cli ' +
      '  ) ca on ca.id_cli = c.cod_cli ' + ' ' + '  left join ( ' + '    select ' +
      '      cp.id_cli, ' + '      max(cp.id_plano) as id_plano, ' +
      '      max(pl.descricao) as desc_plano ' + '    from cliente_planos cp ' +
      '    inner join planos pl on pl.id = cp.id_plano ' + '    where pl.modulo = 0 ' +
      '    group by cp.id_cli ' + '  ) cp_main on cp_main.id_cli = c.cod_cli ' + ' ' +
      '  left join cliente_planos cp2 on cp2.id_cli = c.cod_cli ' +
      '  left join planos pl2 on pl2.id = cp2.id_plano ' + ' ' + '  where c.ATIVO = ' +
      quotedstr('S') + '    and c.CNPJ_CLI not like ' + quotedstr('%.%.-%') +
      '    and c.COD_CON <> 13 ' + '    and c.cod_cli < 10000000 ' + '    and c.cod_cla <> 30 ' +
      '  group by c.cod_cli ' + ') dados ' + 'where dados.valor_mensalidade > 0 ' +
      '  and dados.CNPJ_CLI not like ' + quotedstr('%.%.-%') + '  and dados.COD_CON <> 13 ' +
      '  and dados.cod_cli < 10000000 ' + '  and dados.cod_cla <>30 ');

    SQL.Add('and dados.CNPJ_CLI not like   ' + quotedstr('% .   .   - %') +
      '       	and dados.COD_CON <> 13   ' +
      '        	and dados.cod_cli <10000000  and dados.cod_cla <>30     ');

    if CGFiltroStatusMensalidade.States[0] = cbsChecked then
    begin
      SQL.Add(' and (   (coalesce(dados.calc_valor_mensalidade, 0) - coalesce(dados.valor_mensalidade, 0))  > 0) ')
    end;
    if CGFiltroStatusMensalidade.States[1] = cbsChecked then
    begin
      SQL.Add(' and (  (coalesce(dados.calc_valor_mensalidade, 0) - coalesce(dados.valor_mensalidade, 0))   = 0) ')
    end;
    if CGFiltroStatusMensalidade.States[2] = cbsChecked then
    begin
      SQL.Add(' and ( (coalesce(dados.calc_valor_mensalidade, 0) - coalesce(dados.valor_mensalidade, 0))  < 0) ')
    end;

    SQL.Add(' and (   dados.nome_cli like ' + #39 + '%' + trim(EdtCliente.Text) + '%' + #39 +
      '  or  dados.nome_fantasia like ' + #39 + '%' + trim(EdtCliente.Text) + '%' + #39 + ' )');

    if CbSemContabilidade.checked = true then
    begin
      SQL.Add(' and (dados.cod_cli NOT IN (SELECT cc.COD_CLIENTE FROM contador_cliente cc))');
    end;

    open;
  end;

end;

procedure TfrmMonitorClientes.btnListagemContadoresClick(Sender: TObject);

begin

  with FDQListaContador do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  SELECT *  FROM contador C ');
    open;
  end;

end;

procedure TfrmMonitorClientes.btnDadosGeraisClick(Sender: TObject);
begin
  { BUSCA DADOS GERAIS CLIENTES }
  WITH FDqDadosGeraisCli do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT c.cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI,CIDRES_CLI,P.descricao,   ' +
      ' da.PASTA_BACKUP_FTP,da.VERSAO,da.DATA_ULT_FTP,da.DATA_ULT_BACKUP,          ' +
      ' da.QTD_CONEXOES_SIMUTANEAS,da.QTD_CAIXAS_ATIVOS,da.QTD_USUARIOS_ATIVOS,da.DATA_ULT_ENT_NOTA,  '
      + ' da.DATA_ULT_CUPOM,da.DATA_HORA_ULT_NFE,da.DATA_HORA_ULT_VENDA,               ' +
      ' se.descricao AS seguimento ,da.USU_LOGADO,da.DATA_SINCR_DADOS,da.cod_emp,da.DATA_VAL_CERT_DIG, '
      + ' c.DATACADASTRO_CLI,da.DATA_ULT_SINC_PDC,          ' +
      ' da.versao_exe_retaguarda,da.versao_exe_pdv,da.versao_exe_connection,    ' +
      '   co.RAZAO_SOCIAL,co.NOME_COMERCIAL,co.DESCRICAO_ESCRITORIO  ' +
      ' FROM cliente c           ' + ' INNER JOIN ponto_revenda P    ' +
      ' ON P.cod_ponto= c.cod_ponto_revenda  ' + ' LEFT  JOIN dados_gerais_clientes da   ' +
      ' ON (da.COD_CLI = c.cod_cli)        ' + ' INNER JOIN segmento_software se     ' +
      ' ON se.cod_seg_sof = da.SEGUIMENTO   ' + '	left join contador_cliente CC on   ' +
      '		CC.COD_CLIENTE = c.cod_cli      ' + '	left join contador co on            ' +
      '		co.ID_CONTADOR = CC.COD_CONTADOR   ' + ' WHERE c.ATIVO =  ' + #39 + 'S' + #39 + ' ' +
      ' AND c.CNPJ_CLI   not LIKE ' + #39 + '% .   .   - %' + #39 + ' ' + '  ' +
      '    and ( c.cod_cli <> 1 and c.cod_cli <> 0 AND c.cod_cli <> 7 and c.cod_cla <>30  ' +
      ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6 ) AND C.cod_cli <10000000 ');

    SQL.Add(' and (   c.nome_cli like ' + #39 + '%' + trim(EdtDadosGeraisCliente.Text) + '%' + #39 +
      '  or  c.nome_fantasia like ' + #39 + '%' + trim(EdtDadosGeraisCliente.Text) + '%' + #39 +
      '   or  da.PASTA_BACKUP_FTP like ' + #39 + '%' + trim(EdtDadosGeraisCliente.Text) + '%' +
      #39 + ' )');

    open;

  end;

end;

procedure TfrmMonitorClientes.BtnDesselecionarAgendamentoAtualizacaoClick(Sender: TObject);
begin
  if MTAgendamentoAtualizacao.Isempty then
    exit;

  with MTAgendamentoAtualizacao do
  begin
    try
      DisableControls;
      first;

      while not eof do
      begin
        Edit;
        fieldbyname('selec').asinteger := 0;
        Post;

        next;
      end;

      first;
    finally
      EnableControls;
    end;
  end;

  GAgendamentoAtualizacao.setfocus;
end;

procedure TfrmMonitorClientes.btnGeraProblemasClick(Sender: TObject);
begin
  { deleta dados que nao  s�o usados faz muito tempo }

  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' delete FROM clientes_caixas  ' + ' WHERE PASTA_BACKUP_FTP NOT IN                 ' +
      ' (SELECT PASTA_BACKUP_FTP FROM   dados_gerais_clientes d)   ');
    execsql;
  end;

  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM faturamento_cliente   ' +
      ' WHERE PASTA_BACKUP_FTP NOT IN                   ' +
      ' (SELECT PASTA_BACKUP_FTP FROM   dados_gerais_clientes d)  ');
    execsql;
  end;

  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM painel_problemas    ' + ' WHERE COD_CLI >0   ');
    execsql;
  end;

  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT  d.PASTA_BACKUP_FTP FROM dados_gerais_clientes d  ' + ' INNER JOIN cliente c '
      + ' ON c.cod_cli = d.COD_CLI ' + ' WHERE c.ATIVO = ' + #39 + 'S' + #39 + ' ' +
      ' and d.DATA_SINCR_DADOS <= :DATA_SINCR_DADOS  ');
    parambyname('DATA_SINCR_DADOS').asdatetime := date - 60;
    open;
    first;
  end;
  FdQAux.recordcount;
  while not FdQAux.eof do
  begin
    with dm.fdqinsert do
    begin
      Close;
      SQL.Clear;
      SQL.Add(' DELETE FROM dados_gerais_clientes    ' +
        ' WHERE PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP   ');
      parambyname('PASTA_BACKUP_FTP').asstring := FdQAux.fieldbyname('PASTA_BACKUP_FTP').asstring;
      execsql;
    end;

    with dm.fdqinsert do
    begin
      Close;
      SQL.Clear;
      SQL.Add(' DELETE FROM clientes_caixas    ' +
        ' WHERE PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP   ');
      parambyname('PASTA_BACKUP_FTP').asstring := FdQAux.fieldbyname('PASTA_BACKUP_FTP').asstring;
      execsql;
    end;

    with dm.fdqinsert do
    begin
      Close;
      SQL.Clear;
      SQL.Add(' DELETE FROM clientes_cupom_quebra_seq    ' +
        ' WHERE PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP   ');
      parambyname('PASTA_BACKUP_FTP').asstring := FdQAux.fieldbyname('PASTA_BACKUP_FTP').asstring;
      execsql;
    end;

    with dm.fdqinsert do
    begin
      Close;
      SQL.Clear;
      SQL.Add(' DELETE FROM usuarios_online    ' +
        ' WHERE PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP   ');
      parambyname('PASTA_BACKUP_FTP').asstring := FdQAux.fieldbyname('PASTA_BACKUP_FTP').asstring;
      execsql;
    end;

    Application.ProcessMessages;
    FdQAux.next;
  end;

  PbSicronizacao.max := 0;
  PbSicronizacao.position := 0;
  PbSicronizacao.visible := true;

  { Lista os clientes }
  PNStatus.visible := true;
  PNStatus.caption := ' Lista os clientes';
  PNStatus.refresh;
  with FDQConsCliProb do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT c.cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI,NOME_FANTASIA,d.PASTA_BACKUP_FTP,  '
      + ' Nao_gera_arquivos_fiscais,Nao_Verificar_Backup,   CIDRES_CLI,c.ATIVO,BLOQUEADO_CLI,EMAIL_CLI,CELULAR_CLI,TELRES_CLI, '
      + '    c.EMAIL_CLI,d.DATA_ULT_FTP, p.descricao AS NOME_PONTO_REVENDA,   ' + '    d.*  ' +
      '	FROM cliente c  ' + '    INNER JOIN ponto_revenda p   ON p.cod_ponto = c.cod_ponto_revenda '
      + '   	 INNER JOIN dados_gerais_clientes d      ' + '   ON d.COD_CLI=c.cod_cli  ' +
      '   WHERE  c.cod_cli <> 1 and  c.cod_cli <> 0 and c.cod_cli <> 7 and c.cod_cla <>30 ' +
      ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6 and valor_mensalidade >0   AND C.cod_cli <10000000   '
      + '  and c.ATIVO = ' + #39 + 'S' + #39 + ' and c.BLOQUEADO_CLI <> ' + #39 + 'S' + #39 + ' ');
    open;
    last;
    first;
  end;
  PbSicronizacao.max := FDQConsCliProb.recordcount;

  while not FDQConsCliProb.eof do
  begin
    VerificaoutrosDadosClienteAtendimento(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
      FDQConsCliProb.fieldbyname('PASTA_BACKUP_FTP').asstring,
      FDQConsCliProb.fieldbyname('Nao_gera_arquivos_fiscais').asstring,
      FDQConsCliProb.fieldbyname('Nao_Verificar_Backup').asstring);
    Application.ProcessMessages;
    PbSicronizacao.position := PbSicronizacao.position + 1;
    FDQConsCliProb.next;
  end;

  { Busca cliente sem a atualiza��o de coleta de dados }

  { WITH FDQAux3 do
    begin
    CLOSE;
    sql.clear;
    sql.Add(' SELECT cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI,CIDRES_CLI,P.descricao,c.DATACADASTRO_CLI FROM cliente c   '
    + '  INNER JOIN ponto_revenda P       ' +
    ' ON P.cod_ponto= c.cod_ponto_revenda   ' + ' WHERE c.ATIVO =  ' + #39 +
    'S' + #39 + ' ' + ' AND c.CNPJ_CLI   not LIKE ' + #39 + '% .   .   - %' +
    #39 + ' ' + '  ' + ' AND c.cod_cli NOT IN ' +
    ' ( SELECT cod_cli  FROM dados_gerais_clientes d )  and ( c.cod_cli <> 1 and c.cod_cli <> 0 AND c.cod_cli <> 7  '
    + ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6 )  ' + '   ');
    open;
    last;
    first;
    end;
    while not FDQAux3.eof do
    begin
    if FDQAux3.recordcount > 0 then
    begin
    InserePainelProblemas(FDQAux3.fieldbyname('cod_cli').asinteger,
    ' O CLIENTE EST� SEM A ATUALIZA��O INICIAL DE COLETA DE DADOS');
    end;
    FDQAux3.next;
    end; }

  { lista dados problemas }
  with FDQProblemas do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  SELECT p.COD_CLI,p.DESCRICAO_PROBLEMA,c.NOME_CLI,c.NOME_FANTASIA, ' +
      '   d.DATA_SINCR_DADOS,d.PASTA_BACKUP_FTP,d.DATA_ULT_FTP ,     ' +
      '  c.DATACADASTRO_CLI,c.CNPJ_CLI,po.descricao,         ' +
      '   c.CIDRES_CLI,d.cod_emp,d.versao_exe_retaguarda,d.versao_exe_pdv,d.versao_exe_connection,  '
      + '   d.VERSAO,p.ERROS_BACKUP,p.TIPO_ERRO,c.OBS_CLI,c.SITUACAO_FINANCEIRA_CLI,   ' +
      ' bv.data data_versao_banco          ' + '		  FROM painel_problemas p        ' +
      '     INNER JOIN cliente c  ON c.cod_cli = p.COD_CLI  ' +
      '      LEFT JOIN dados_gerais_clientes d        ' +
      '      ON d.PASTA_BACKUP_FTP = p.PASTA_BACKUP_FTP   ' +
      '     INNER JOIN ponto_revenda po   ON po.cod_ponto = c.COD_CON   ' +
      '		left join banco_versoes bv on (d.VERSAO = bv.versao and bv.banco_id = 1)    ');

    SQL.Add(' and (   c.nome_cli like ' + #39 + '%' + trim(EdtClientePainelProb.Text) + '%' + #39 +
      '  or  c.nome_fantasia like ' + #39 + '%' + trim(EdtClientePainelProb.Text) + '%' +
      #39 + ' )');

    SQL.Add('     GROUP BY            ' +
      '      p.COD_CLI,p.DESCRICAO_PROBLEMA,c.NOME_CLI,c.NOME_FANTASIA, ' +
      '     d.DATA_SINCR_DADOS,d.PASTA_BACKUP_FTP,    ' +
      '     c.DATACADASTRO_CLI,c.CNPJ_CLI,po.descricao,  ' +
      '      c.CIDRES_CLI,d.cod_emp,d.versao_exe_retaguarda,d.versao_exe_pdv,d.versao_exe_connection,  '
      + '     d.VERSAO,c.OBS_CLI ');
    open;
  end;

  PbSicronizacao.visible := False;
  PNStatus.visible := False;
end;

procedure TfrmMonitorClientes.BitBtn21Click(Sender: TObject);
begin
  DeleteFile(pchar(ExtractFilePath(Application.ExeName) +
    '\frmMonitorClientes.cxGQuebraSequencia.ini'));

  { Carrega Grid Desenvolvimento }
  try
    cxGridDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName) +
      '/frmMonitorClientes.cxGQuebraSequencia.ini', true, False, [gsoUseFilter, gsoUseSummary]);
  except

  end;
end;

procedure TfrmMonitorClientes.btnVisCertExternoClick(Sender: TObject);
begin
  { Busca certificados }

  with dm.QCertificadosMes do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT C.*,CO.NOME_COMERCIAL,CO.TELEFONE AS TELEFONE_CONTADOR ,CO.EMAIL   ' +
      ' FROM certificados C ' + ' LEFT JOIN cliente CI ON CI.CNPJ_CLI = C.CNPJ_CLI  ' +
      ' LEFT JOIN contador_cliente CE ON  CE.COD_CLIENTE = CI.cod_cli ' +
      ' LEFT JOIN contador CO ON CO.ID_CONTADOR =CE.COD_CONTADOR ' +
      ' WHERE C.DATA_VAL_CERT_DIG BETWEEN :DATAINI AND :DATAFIN   ');
    parambyname('DATAINI').asdatetime := EdtDataIni.date;
    parambyname('DATAFIN').asdatetime := EdtDataFin.date;
    SQL.Add(' AND C.TIPO = :TIPO ');
    parambyname('TIPO').asstring := 'E';
    SQL.Add(' order by C.DATA_VAL_CERT_DIG ');
    open;
  end;
end;

procedure TfrmMonitorClientes.cxGDRClientesArquivosGeradosDBTableView1CustomDrawCell
  (Sender: TcxCustomGridTableView; ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo;
  var ADone: Boolean);
var
  enviado_pdc, email_mov_fiscal, inconsistencias_mov_fiscal, enviado_email_xml: string;
begin
  { Pinta de Acordo com o Valor }

  enviado_pdc := '';
  email_mov_fiscal := '';
  inconsistencias_mov_fiscal := '';
  enviado_email_xml := '';
  { verifica se a grid  nao esta na coluna selecionada }
  if not AViewInfo.Selected then
  begin
    { verifica se existe algum registro na grid }
    if FDQCliArquivosGeradoscod_cli.asstring <> '' then
    begin
      { verifica se o index da grid � maior que 0 }
      if (AViewInfo.Item.Index >= 0) then
      begin
        { PINTA STATUS DESENVOLVIMENTO }
        try
          enviado_pdc := VarAsType(cxGDRClientesArquivosGeradosDBTableView1.ViewData.Records
            [AViewInfo.GridRecord.Index].Values[cxGDRClientesArquivosGeradosDBTableView1enviado_pdc.
            Index], varString);
        except
          enviado_pdc := '';
        end;

        try
          email_mov_fiscal := VarAsType(cxGDRClientesArquivosGeradosDBTableView1.ViewData.Records
            [AViewInfo.GridRecord.Index].Values
            [cxGDRClientesArquivosGeradosDBTableView1enviado_email_mov_fiscal.Index], varString);
        except
          email_mov_fiscal := '';
        end;

        try
          inconsistencias_mov_fiscal :=
            VarAsType(cxGDRClientesArquivosGeradosDBTableView1.ViewData.Records
            [AViewInfo.GridRecord.Index].Values
            [cxGDRClientesArquivosGeradosDBTableView1inconsistencias_mov_fiscal.Index], varString);
        except
          inconsistencias_mov_fiscal := '';
        end;
        try
          enviado_email_xml := VarAsType(cxGDRClientesArquivosGeradosDBTableView1.ViewData.Records
            [AViewInfo.GridRecord.Index].Values
            [cxGDRClientesArquivosGeradosDBTableView1enviado_email_xml.Index], varString);
        except
          enviado_email_xml := '';
        end;

        { PINTA DESCRI��O DO PROBLEMA }
        if (AViewInfo.Item.Index = cxGDRClientesArquivosGeradosDBTableView1enviado_pdc.Index) then
        begin
          if (trim(enviado_pdc) = 'S') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clgreen;
            ACanvas.Font.Style := [fsBold];
          end
          ELSE if (trim(enviado_pdc) = 'N') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := CLRED;
            ACanvas.Font.Style := [fsBold];
          end;

        end;

        if (AViewInfo.Item.Index = cxGDRClientesArquivosGeradosDBTableView1enviado_email_mov_fiscal.
          Index) then
        begin
          if (trim(email_mov_fiscal) = 'S') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clgreen;
            ACanvas.Font.Style := [fsBold];
          end
          ELSE if (trim(email_mov_fiscal) = 'N') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := CLRED;
            ACanvas.Font.Style := [fsBold];
          end;

        end;

        if (AViewInfo.Item.
          Index = cxGDRClientesArquivosGeradosDBTableView1inconsistencias_mov_fiscal.Index) then
        begin
          if (trim(inconsistencias_mov_fiscal) = 'N') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clgreen;
            ACanvas.Font.Style := [fsBold];
          end
          ELSE if (trim(inconsistencias_mov_fiscal) = 'S') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := CLRED;
            ACanvas.Font.Style := [fsBold];
          end;

        end;

        if (AViewInfo.Item.Index = cxGDRClientesArquivosGeradosDBTableView1enviado_email_xml.Index)
        then
        begin
          if (trim(enviado_email_xml) = 'S') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clgreen;
            ACanvas.Font.Style := [fsBold];
          end
          ELSE if (trim(enviado_email_xml) = 'N') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := CLRED;
            ACanvas.Font.Style := [fsBold];
          end;

        end;

        if (AViewInfo.Item.Index = cxGDRClientesArquivosGeradosDBTableView1mes_mov_fiscal.Index)
        then
        begin
          ACanvas.Font.Style := [fsBold];
        end;

      end;

    end;

  end;

end;

procedure TfrmMonitorClientes.cxGerenciadoInstalacoesDBTableViewCustomDrawCell
  (Sender: TcxCustomGridTableView; ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo;
  var ADone: Boolean);
var
  Codigo: string;
begin
  { Pinta de Acordo com o Valor }

  Codigo := '';
  { verifica se a grid  nao esta na coluna selecionada }
  if not AViewInfo.Selected then
  begin
    { verifica se existe algum registro na grid }
    if QInstalacaocod_cli.asstring <> '' then
    begin
      { verifica se o index da grid � maior que 0 }
      if (AViewInfo.Item.Index >= 0) then
      begin
        { PINTA STATUS DESENVOLVIMENTO }
        try
          Codigo := VarAsType(cxGerenciadoInstalacoesDBTableView.ViewData.Records
            [AViewInfo.GridRecord.Index].Values
            [cxgrdbclmnGerenciadoInstalacoesDBTableViewSTATUS_INSTAL.Index], varString);
        except
          Codigo := '';
        end;

        if ((trim(Codigo) = '0') or (trim(Codigo) = '1')) then
        begin
          { Aguardando Instala��o }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color := $00FF80FF;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color := $00FF80FF;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '2') then
        begin
          { Em Instala��o }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color := $00FF8000;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color := $00FF8000;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '3') then
        begin
          { Agendar treinamento }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color := $00400040;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color := $00400040;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '4') then
        begin
          { Reagendar treinamento }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color := clBlue;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color := clBlue;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '5') then
        begin
          { treinamento concluido }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color := $00005500;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color := $00005500;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '6') then
        begin
          { Retorno }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color := $00808040;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color := $00808040;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '7') then
        begin
          { Concluido }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end

        else if (trim(Codigo) = '8') then
        begin
          { Concluido }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end

        else if (trim(Codigo) = '9') then
        begin
          { Concluido }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '10') then
        begin
          { Concluido }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '11') then
        begin
          { AguardandoClienteParaInstalacao }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '12') then
        begin
          { AguardandoMigracao }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '13') then
        begin
          { PrimeiroTreinamento }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '14') then
        begin
          { SegundoTreinamento }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '15') then
        begin
          { EmMigracao }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end
        else if (trim(Codigo) = '16') then
        begin
          { EmConferenciaMigracao }
          if not AViewInfo.Selected then
          begin
            ACanvas.Font.Style := [fsBold];
            // ACanvas.Font.Color :=clGreen;
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            // ACanvas.Brush.Color :=clGreen;
            ACanvas.Font.Style := [fsBold];
          end;
        end;

        { PINTA DESCRI��O DO PROBLEMA }
        if (AViewInfo.Item.Index = cxgrdbclmnGerenciadoInstalacoesDBTableViewCALC_STATUS_INSTAL.
          Index) then
        begin
          if ((trim(Codigo) = '0') or (trim(Codigo) = '1')) then
          begin
            { 1 Aguardando Instala��o }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $008000FF;
            ACanvas.Font.Style := [fsBold];
          end;
          if (trim(Codigo) = '2') then
          begin
            { 2 Em Instala��o }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clBlue;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '3') then
          begin
            { 3 Agendar treinamento }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $00C08000;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '4') then
          begin
            { 4 Reagendar treinamento }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $00FF8080;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '5') then
          begin
            { 5 treinamento concluido }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clgreen;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '6') then
          begin
            { 6 Retorno }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clPurple;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '7') then
          begin
            { 7 Concluido }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $00004000;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '8') then
          begin
            { 8 em teste }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $007F7F7F;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '9') then
          begin
            { 9 pos venda }
            ACanvas.Font.Color := clBLACK;
            ACanvas.Brush.Color := clLime;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '10') then
          begin
            { desistencia }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := CLRED;
            ACanvas.Font.Style := [fsBold];
          end;
          if (trim(Codigo) = '11') then
          begin
            { AguardandoClienteParaInstalacao }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $00FFBF00;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '12') then
          begin
            { AguardandoMigracao }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $00998877;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '13') then
          begin
            { PrimeiroTreinamento }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $004F4F2F;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '14') then
          begin
            { SegundoTreinamento }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $0071B33C;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '15') then
          begin
            { 1EmMigracao }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clBLACK;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = '16') then
          begin
            { EmConferenciaMigracao }
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $001C1C1C;
            ACanvas.Font.Style := [fsBold];
          end;

        end;

      end;

    end;

  end;
  Codigo := '';
end;

procedure TfrmMonitorClientes.cxGClientesExternosEnter(Sender: TObject);
begin
  btnClientesSemAtualizacao.Click;
end;

procedure TfrmMonitorClientes.cxGCurvaABCDBTableView4CustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  Codigo: string;
begin
  { Pinta de Acordo com o Valor }

  Codigo := '';
  { verifica se a grid  nao esta na coluna selecionada }
  if not AViewInfo.Selected then
  begin
    {
      if strtocurr(Codigo) > 0 then verifica se existe algum registro na grid }

    { verifica se o index da grid � maior que 0 }
    if (AViewInfo.Item.Index >= 0) then
    begin
      try
        Codigo := VarAsType(cxGCurvaABCDBTableView4.ViewData.Records[AViewInfo.GridRecord.Index]
          .Values[cxGCurvaABCDBTableView4DEFICIT1.Index], varString);
      except
        Codigo := '0';
      end;

      if (AViewInfo.Item.Index = cxGCurvaABCDBTableView4DEFICIT1.Index) and (strtocurr(Codigo) > 0)
      then
      begin

        begin
          ACanvas.Font.Color := clBLACK;
          ACanvas.Brush.Color := clyellow;
          ACanvas.Font.Style := [fsBold];
        end;

      end;

    end;

  end;

  ACanvas.Font.Style := [fsBold];
end;

procedure TfrmMonitorClientes.cxGridDBBloqueioCliCustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  Codigo: string;
begin
  { Pinta de Acordo com o Valor }

  Codigo := '';
  { verifica se a grid  nao esta na coluna selecionada }
  if not AViewInfo.Selected then
  begin
    { verifica se existe algum registro na grid }
    if FDQBloqueioClicod_cli.asstring <> '' then
    begin
      { verifica se o index da grid � maior que 0 }
      if (AViewInfo.Item.Index >= 0) then
      begin

        ACanvas.Font.Color := clwhite;
        ACanvas.Brush.Color := CLRED;
        ACanvas.Font.Style := [fsBold];
      end;

    end;

  end;
  Codigo := '';
end;

procedure TfrmMonitorClientes.cxGridDBfINANCEIROView3DblClick(Sender: TObject);
begin
  BtnAlterarContador.Click;
end;

procedure TfrmMonitorClientes.cxGridDBTableView3CustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  Codigo: string;
  Bloq: String;
  Possui: String;
  ValorDif: string;
begin
  { Pinta de Acordo com o Valor }

  Codigo := '';
  Bloq := '';
  Possui := '';
  ValorDif := '';

  { verifica se a grid  nao esta na coluna selecionada }
  if not AViewInfo.Selected then
  begin
    { verifica se existe algum registro na grid }
    if FDQClientesContadorNOME_CLI.asstring <> '' then
    begin
      { verifica se o index da grid � maior que 0 }
      if (AViewInfo.Item.Index >= 0) then
      begin
        try
          if VarAsType(cxGridDBTableView3.ViewData.Records[AViewInfo.GridRecord.Index].Values
            [cxGridDBTableView3NOME_COMERCIAL.Index], varNull) = Null then
            Codigo := ''
          else
            Codigo := VarAsType(cxGridDBTableView3.ViewData.Records[AViewInfo.GridRecord.Index]
              .Values[cxGridDBTableView3NOME_COMERCIAL.Index], varString);
        except
          Codigo := '';
        end;

        try
          Bloq := VarAsType(cxGridDBTableView3.ViewData.Records[AViewInfo.GridRecord.Index].Values
            [cxGridDBTableView3DESC_BLOQ.Index], varString);
        except
          Bloq := '';
        end;

        if trim(Bloq) = 'SIM' then
        begin
          ACanvas.Font.Color := clwhite;
          ACanvas.Brush.Color := CLRED;
          ACanvas.Font.Style := [fsBold];
        end
        else if (trim(Codigo) <> '') then
        begin
          ACanvas.Font.Color := clwhite;
          ACanvas.Brush.Color := $000060BF;
        end;

        if (AViewInfo.Item.Index = cxGridDBTableView3possui_assinatura.Index) then
        begin
          try
            Possui := VarAsType(cxGridDBTableView3.ViewData.Records[AViewInfo.GridRecord.Index]
              .Values[cxGridDBTableView3possui_assinatura.Index], varString);
          except
            Possui := '';
          end;

          ACanvas.Font.Style := [fsBold];
          ACanvas.Font.Color := clwhite;

          if Possui = 'SIM' then
            ACanvas.Brush.Color := clgreen
          else
            ACanvas.Brush.Color := clNavy;
        end;

        Possui := '';

        if (AViewInfo.Item.Index = cxGridDBTableView3possui_plano.Index) then
        begin
          try
            Possui := VarAsType(cxGridDBTableView3.ViewData.Records[AViewInfo.GridRecord.Index]
              .Values[cxGridDBTableView3possui_plano.Index], varString);
          except
            Possui := '';
          end;

          ACanvas.Font.Style := [fsBold];
          ACanvas.Font.Color := clwhite;

          if Possui = 'SIM' then
            ACanvas.Brush.Color := clgreen
          else
            ACanvas.Brush.Color := clNavy;
        end;

        if (AViewInfo.Item.Index = cxGridDBTableView3valor_mensalidade.Index) or
          (AViewInfo.Item.Index = cxGridDBTableView3calc_valor_mensalidade.Index) or
          (AViewInfo.Item.Index = cxGridDBTableView3dif_mensalidade.Index) then
        begin
          ACanvas.Font.Style := [fsBold];
        end;

        Possui := '';

        if (AViewInfo.Item.Index = cxGridDBTableView3mensalidade_dif.Index) or
          (AViewInfo.Item.Index = cxGridDBTableView3STATUS_MENSALIDADE1.Index) then
        begin
          try
            Possui := VarAsType(cxGridDBTableView3.ViewData.Records[AViewInfo.GridRecord.Index]
              .Values[cxGridDBTableView3mensalidade_dif.Index], varString);
          except
            Possui := '';
          end;

          try
            ValorDif := VarAsType(cxGridDBTableView3.ViewData.Records[AViewInfo.GridRecord.Index]
              .Values[cxGridDBTableView3dif_mensalidade.Index], varString);
          except
            ValorDif := '0';
          end;

          ACanvas.Font.Style := [fsBold];
          ACanvas.Font.Color := clwhite;

          if (AViewInfo.Item.Index = cxGridDBTableView3mensalidade_dif.Index) then
          begin
            if Possui = 'SIM' then
              ACanvas.Brush.Color := clgreen
            else
              ACanvas.Brush.Color := clNavy;
          end;

          if (AViewInfo.Item.Index = cxGridDBTableView3STATUS_MENSALIDADE1.Index) then
          begin
            if strtocurr(ValorDif) < 0 then
              ACanvas.Brush.Color := clgreen
            else if strtocurr(ValorDif) = 0 then
              ACanvas.Brush.Color := clBlue
            else if strtocurr(ValorDif) > 0 then
              ACanvas.Brush.Color := CLRED;
          end;

        end;
      end;
    end;
  end;

  Codigo := '';
  Bloq := '';
  Possui := '';
end;

procedure TfrmMonitorClientes.cxGridDBTableView5CustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  Realizado: String;
  Sucesso: String;
begin
  Realizado := '';
  Sucesso := '';

  if not AViewInfo.Selected then
  begin
    if trim(QAgendamentoTarefaNOME_CLI.asstring) <> '' then
    begin
      if (AViewInfo.Item.Index >= 0) then
      begin
        try
          Realizado := VarAsType(cxGridDBTableView5.ViewData.Records[AViewInfo.GridRecord.Index]
            .Values[cxGridDBTableView5Column3.Index], varString);
        except
          Realizado := '';
        end;

        try
          Sucesso := VarAsType(cxGridDBTableView5.ViewData.Records[AViewInfo.GridRecord.Index]
            .Values[cxGridDBTableView5Column6.Index], varString);
        except
          Sucesso := '';
        end;

        if trim(Realizado) = 'SIM' then
        begin
          if (trim(Sucesso) = 'SIM') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := clgreen;
            ACanvas.Font.Style := [fsBold];
          end
          else
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := CLRED;
            ACanvas.Font.Style := [fsBold];
          end;
        end;
      end;
    end;
  end;

  Realizado := '';
  Sucesso := '';
end;

procedure TfrmMonitorClientes.cxGridDBTableView6CustomDrawGroupCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableCellViewInfo; var ADone: Boolean);
var
  sdados: string;
begin
  if not AViewInfo.Selected then
  begin
    ACanvas.Font.Style := [fsBold];
    ACanvas.Font.Color := $00502F12;
  end
  else
  begin
    ACanvas.Font.Color := clwhite;
    ACanvas.Brush.Color := $00C15B00;
    ACanvas.Font.Style := [fsBold];
  end;

end;

procedure TfrmMonitorClientes.cxGridDBTableViewprobCustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  Codigo: string;
begin
  { Pinta de Acordo com o Valor }

  Codigo := '';
  { verifica se a grid  nao esta na coluna selecionada }
  if not AViewInfo.Selected then
  begin
    { verifica se existe algum registro na grid }
    if FDQProblemasCOD_CLI.asstring <> '' then
    begin
      { verifica se o index da grid � maior que 0 }
      if (AViewInfo.Item.Index >= 0) then
      begin
        { PINTA STATUS DESENVOLVIMENTO }
        try
          Codigo := VarAsType(cxGridDBTableViewprob.ViewData.Records[AViewInfo.GridRecord.Index]
            .Values[cxGridDBTableViewprobTIPO_ERRO.Index], varString);
        except
          Codigo := '';
        end;

        { PINTA DESCRI��O DO PROBLEMA }
        if (AViewInfo.Item.Index = cxGridDBTableViewprobDESCRICAO_PROBLEMA.Index) or
          (AViewInfo.Item.Index = cxGridDBTableViewprobTIPO_ERRO.Index) then
        begin
          if (trim(Codigo) = 'BAIXO') then
          begin
            ACanvas.Font.Color := clBLACK;
            ACanvas.Brush.Color := $009191FF;
            ACanvas.Font.Style := [fsBold];
          end;
          if (trim(Codigo) = 'MEDIO') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $000000F9;
            ACanvas.Font.Style := [fsBold];
          end;

          if (trim(Codigo) = 'GRAVE') then
          begin
            ACanvas.Font.Color := clwhite;
            ACanvas.Brush.Color := $00000093;
            ACanvas.Font.Style := [fsBold];
          end;

        end;

      end;

    end;

  end;
  Codigo := '';
end;

procedure TfrmMonitorClientes.D1Click(Sender: TObject);
var
  LEndPoint: String;
begin
  if MTPlanosativo.asboolean then
    LEndPoint := '/desativar'
  else
    LEndPoint := '/ativar';

  dm.ExecutarRequestAPICommand(TRequest.New.BaseURL('/planos/' + MTPlanosidAPI.asstring +
    LEndPoint), rmPOST);

  BtnVerTodosPlanos.Click;
end;

procedure TfrmMonitorClientes.D2Click(Sender: TObject);
begin
  { desistencia }
  with FdQAux do
  begin

    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 10     , DT_Aguard_instalacao = :Dt_desistencia     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_desistencia').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.DBGContadorDblClick(Sender: TObject);
begin
  if FDQListaContadorID_CONTADOR.asstring <> '' then
  begin
    EdtContador.Text := FDQListaContadorID_CONTADOR.asstring;
    EdtNomeContador.Text := QGerenciadorComissoesNOME_COMERCIAL.asstring;
    DBGContador.enabled := False;
  end;
end;

procedure TfrmMonitorClientes.DBGContadorDrawColumnCell(Sender: TObject; const Rect: TRect;
  DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin
  { Muda a Cor da Linha Caso Esteja Selecionada e Deixa a Grid com Cor Zebrada }
  if Odd(FDQListaContador.RecNo) then
    TDBGrid(Sender).Canvas.Brush.Color := clInactiveCaption { Primeira Cor da Linha }
  else
    TDBGrid(Sender).Canvas.Brush.Color := clBtnFace; { Segunda Cor da Linha }

  TDBGrid(Sender).Canvas.Font.Color := clBLACK; { Cor da Fonte }

  if gdSelected in State then
  begin
    with (Sender as TDBGrid).Canvas do
    begin
      Brush.Color := clScrollBar; { Aqui � Definido a Cor de Fundo }
      FillRect(Rect);
    end;
  end;

  TDBGrid(Sender).DefaultDrawDataCell(Rect, TDBGrid(Sender).columns[DataCol].Field, State);
end;

procedure TfrmMonitorClientes.DBGContadorExit(Sender: TObject);
begin
  if FDQListaContadorID_CONTADOR.asstring <> '' then
  begin
    EdtContador.Text := FDQListaContadorID_CONTADOR.asstring;
    EdtNomeContador.Text := QGerenciadorComissoesNOME_COMERCIAL.asstring;
    DBGContador.enabled := False;

    with FDQListaContador do
    begin
      Close;
      SQL.Clear;
      SQL.Add('  SELECT *  FROM contador C ');
      SQL.Add(' where ID_CONTADOR = ' + trim(EdtContador.Text) + '');
      open;
    end;
    DBGContador.visible := False;
    BtnVisualizarAgenda.Click;
  end;
end;

procedure TfrmMonitorClientes.DBGContadorKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if (Key = vk_escape) then
    DBGContador.enabled := False;
end;

procedure TfrmMonitorClientes.DBGContadorKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    if FDQListaContadorID_CONTADOR.asstring <> '' then
    begin
      EdtContador.Text := FDQListaContadorID_CONTADOR.asstring;
      EdtNomeContador.Text := QGerenciadorComissoesNOME_COMERCIAL.asstring;
      DBGContador.enabled := False;

    end;

  end;
end;

procedure TfrmMonitorClientes.dbgrdContatoChamadioDrawColumnCell(Sender: TObject; const Rect: TRect;
  DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin
  { Muda a Cor da Linha Caso Esteja Selecionada e Deixa a Grid com Cor Zebrada }
  if Odd(dm.FDQContatoCli.RecNo) then
    TDBGrid(Sender).Canvas.Brush.Color := clInactiveCaption { Primeira Cor da Linha }
  else
    TDBGrid(Sender).Canvas.Brush.Color := clBtnFace;
  { Segunda Cor da Linha }

  TDBGrid(Sender).Canvas.Font.Color := clBLACK; { Cor da Fonte }

  if gdSelected in State then
  begin
    with (Sender as TDBGrid).Canvas do
    begin
      Brush.Color := clScrollBar;
      { Aqui � Definido a Cor de Fundo }
      FillRect(Rect);
    end;
  end;

  TDBGrid(Sender).DefaultDrawDataCell(Rect, TDBGrid(Sender).columns[DataCol].Field, State);
end;

procedure TfrmMonitorClientes.dbgrdContatoChamadioMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContatoCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.DBGContadorClienteDblClick(Sender: TObject);
begin
  if FDQListaContadorClienteID_CONTADOR.asstring <> '' then
  begin
    EdtContadorCliente.Text := FDQListaContadorClienteID_CONTADOR.asstring;
    EdtNomeContadorCliente.Text := FDQListaContadorClienteNOME_COMERCIAL.asstring;
    DBGContadorCliente.enabled := False;
  end;
end;

procedure TfrmMonitorClientes.DBGContadorClienteDrawColumnCell(Sender: TObject; const Rect: TRect;
  DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin
  { Muda a Cor da Linha Caso Esteja Selecionada e Deixa a Grid com Cor Zebrada }
  if Odd(FDQListaContadorCliente.RecNo) then
    TDBGrid(Sender).Canvas.Brush.Color := clInactiveCaption { Primeira Cor da Linha }
  else
    TDBGrid(Sender).Canvas.Brush.Color := clBtnFace; { Segunda Cor da Linha }

  TDBGrid(Sender).Canvas.Font.Color := clBLACK; { Cor da Fonte }

  if gdSelected in State then
  begin
    with (Sender as TDBGrid).Canvas do
    begin
      Brush.Color := clScrollBar; { Aqui � Definido a Cor de Fundo }
      FillRect(Rect);
    end;
  end;

  TDBGrid(Sender).DefaultDrawDataCell(Rect, TDBGrid(Sender).columns[DataCol].Field, State);
end;

procedure TfrmMonitorClientes.DBGContadorClienteExit(Sender: TObject);
begin
  if FDQListaContadorClienteID_CONTADOR.asstring <> '' then
  begin
    EdtContadorCliente.Text := FDQListaContadorClienteID_CONTADOR.asstring;
    EdtNomeContadorCliente.Text := FDQListaContadorClienteNOME_COMERCIAL.asstring;
    DBGContadorCliente.enabled := False;

    with FDQListaContadorCliente do
    begin
      Close;
      SQL.Clear;
      SQL.Add('  SELECT *  FROM contador C ');
      SQL.Add(' where ID_CONTADOR = ' + trim(EdtContadorCliente.Text) + '');
      open;
    end;

  end;
end;

procedure TfrmMonitorClientes.DBGContadorClienteKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if (Key = vk_escape) then
    DBGContadorCliente.enabled := False;
end;

procedure TfrmMonitorClientes.DBGContadorClienteKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    if FDQListaContadorClienteID_CONTADOR.asstring <> '' then
    begin
      EdtContadorCliente.Text := FDQListaContadorClienteID_CONTADOR.asstring;
      EdtNomeContadorCliente.Text := FDQListaContadorClienteNOME_COMERCIAL.asstring;
      DBGContadorCliente.enabled := False;
    end;

  end;

end;

procedure TfrmMonitorClientes.Desativar1Click(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE grupo_clientes C SET C.ativo = ' + quotedstr('N') + ' ' +
      ' WHERE C.id_grupo  = :id_grupo ');
    parambyname('id_grupo').asinteger := QNuvemid_grupo.asinteger;
    execsql;
  end;
  BtnVisualizarNuvem.Click;
end;

procedure TfrmMonitorClientes.E1Click(Sender: TObject);
begin
  with FdQAux do
  begin

    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 16 , DT_Aguard_instalacao = :Dt_em_conf_migracao     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_em_conf_migracao').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.E1ddClick(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 15 , DT_Aguard_instalacao = :Dt_em_migracao     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_em_migracao').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.E2Click(Sender: TObject);
var
  LDados: String;
begin
  if FDQClientesContador.Isempty then
    exit;

  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select con.* from aplicacoes_clientes ac ' +
      'inner join connections con on (ac.id_aplicacao = con.id_aplicacao) ' +
      'inner join grupo_clientes gc on (con.id_nuvem = gc.id_grupo) ' +
      'where ac.id_cliente = :id_cliente order by con.id desc limit 1');
    parambyname('id_cliente').asinteger := FDQClientesContadorcod_cli.asinteger;
    open;

    if FdQAux.Isempty then
    begin
      showmessage('este cliente n�o possui dados do servidor mapeados!');
      exit;
    end;

    LDados := 'Habilitado Servi�o Principal (Banco de Dados): ' + //
      IfThen(fieldbyname('habilitado_servico_principal').asboolean, 'SIM', 'N�O') + sLineBreak + //
      'Host Servi�o Principal (Banco de Dados): ' + //
      fieldbyname('host_servico_principal').asstring.trim + sLineBreak + //
      'Porta Servi�o Principal (Banco de Dados): ' + //
      fieldbyname('porta_servico_principal').asstring + sLineBreak + sLineBreak + //
    //
      'Habilitado Servi�o de Arquivos: ' + //
      IfThen(fieldbyname('habilitado_servico_arquivos').asboolean, 'SIM', 'N�O') + sLineBreak + //
      'Host Servi�o Arquivos: ' + //
      fieldbyname('host_servico_arquivos').asstring.trim + sLineBreak + //
      'Porta Servi�o Arquivos: ' + //
      fieldbyname('porta_servico_arquivos').asstring + sLineBreak + sLineBreak + //
    //
      'Habilitado Servi�o de Aplicativos: ' + //
      IfThen(fieldbyname('habilitado_servico_aplicativos').asboolean, 'SIM', 'N�O') + sLineBreak +
      'Host Servi�o Aplicativos: ' + //
      fieldbyname('host_servico_aplicativos').asstring.trim + sLineBreak + //
      'Porta Servi�o Aplicativos: ' + //
      fieldbyname('porta_servico_aplicativos').asstring + sLineBreak + sLineBreak + //
    //
      'Connection do Servi�o Principal (Banco de Dados) em Nuvem: ' + //
      IfThen(fieldbyname('servico_principal_nuvem').asboolean, 'SIM', 'N�O') + sLineBreak + //
      'Connection do Servi�o de Arquivos em Nuvem: ' + //
      IfThen(fieldbyname('servico_arquivos_nuvem').asboolean, 'SIM', 'N�O') + sLineBreak +
      sLineBreak + //
    //
      'ID da Nuvem: ' + fieldbyname('id_nuvem').asstring;

    ClipBoard.AsText := LDados;

    showmessage
      ('Os dados abaixo foram copiados para a �rea de transfer�ncia! Basta dar um Ctrl + V para colar.'
      + sLineBreak + sLineBreak + LDados);
  end;
end;

procedure TfrmMonitorClientes.EdtClienteEnter(Sender: TObject);
begin
  EdtCliente.selectall;
end;

procedure TfrmMonitorClientes.EdtClientePainelProbChange(Sender: TObject);
begin
  with FDQProblemas do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  SELECT p.COD_CLI,p.DESCRICAO_PROBLEMA,c.NOME_CLI,c.NOME_FANTASIA, ' +
      '   d.DATA_SINCR_DADOS,d.PASTA_BACKUP_FTP,d.DATA_ULT_FTP ,     ' +
      '  c.DATACADASTRO_CLI,c.CNPJ_CLI,po.descricao,         ' +
      '   c.CIDRES_CLI,d.cod_emp,d.versao_exe_retaguarda,d.versao_exe_pdv,d.versao_exe_connection,  '
      + '   d.VERSAO,p.ERROS_BACKUP,p.TIPO_ERRO,c.OBS_CLI,   ' +
      ' bv.data data_versao_banco          ' + '		  FROM painel_problemas p        ' +
      '     INNER JOIN cliente c  ON c.cod_cli = p.COD_CLI  ' +
      '      LEFT JOIN dados_gerais_clientes d        ' +
      '      ON d.PASTA_BACKUP_FTP = p.PASTA_BACKUP_FTP   ' +
      '     INNER JOIN ponto_revenda po   ON po.cod_ponto = c.COD_CON   ' +
      '		left join banco_versoes bv on (d.VERSAO = bv.versao and bv.banco_id = 1)    ');

    SQL.Add(' where (   c.nome_cli like ' + #39 + '%' + trim(EdtClientePainelProb.Text) + '%' + #39
      + '  or  c.nome_fantasia like ' + #39 + '%' + trim(EdtClientePainelProb.Text) + '%' +
      #39 + ' )');

    SQL.Add('     GROUP BY            ' +
      '      p.COD_CLI,p.DESCRICAO_PROBLEMA,c.NOME_CLI,c.NOME_FANTASIA, ' +
      '     d.DATA_SINCR_DADOS,d.PASTA_BACKUP_FTP,    ' +
      '     c.DATACADASTRO_CLI,c.CNPJ_CLI,po.descricao,  ' +
      '      c.CIDRES_CLI,d.cod_emp,d.versao_exe_retaguarda,d.versao_exe_pdv,d.versao_exe_connection,  '
      + '     d.VERSAO,c.OBS_CLI ');
    open;
  end;
end;

procedure TfrmMonitorClientes.EdtClientePainelProbEnter(Sender: TObject);
begin
  EdtClientePainelProb.selectall;
end;

procedure TfrmMonitorClientes.EdtClientesAgendamentoEnter(Sender: TObject);
begin
  EdtClientesAgendamento.selectall;
end;

procedure TfrmMonitorClientes.EdtClientesArquivosFiscaisEnter(Sender: TObject);
begin
  EdtClientesArquivosFiscais.selectall;
end;

procedure TfrmMonitorClientes.EdtDadosGeraisClienteEnter(Sender: TObject);
begin
  EdtDescricaoNuvem.selectall;
end;

procedure TfrmMonitorClientes.EdtDescABCEnter(Sender: TObject);
begin
  EdtDescABC.selectall;
end;

procedure TfrmMonitorClientes.EdtNomeContadorChange(Sender: TObject);
begin

  if (EdtNomeContador.focused) then
  begin
    if (trim(EdtNomeContador.Text) <> '') and (EdtNomeContador.focused) then
    begin
      with FDQListaContador do
      begin
        Close;
        SQL.Clear;
        SQL.Add('  SELECT *  FROM contador C ');
        SQL.Add(' where  NOME_COMERCIAL like ' + #39 + '%' + trim(EdtNomeContador.Text) + '%' + #39
          + '  or  DESCRICAO_ESCRITORIO like ' + #39 + '%' + trim(EdtNomeContador.Text) + '%' + #39
          + ' ' + '  or  RAZAO_SOCIAL like ' + #39 + '%' + trim(EdtNomeContador.Text) + '%' +
          #39 + ' ');
        open;
      end;

      if FDQListaContador.recordcount <= 0 then
      begin

      end
      else
      begin
        DBGContador.enabled := true;
        DBGContador.bringtofront;

      end;

    end;
  end;
end;

procedure TfrmMonitorClientes.EdtNomeContadorEnter(Sender: TObject);
begin
  EdtNomeContador.selectall;
  DBGContador.visible := true;
end;

procedure TfrmMonitorClientes.EdtNomeContadorExit(Sender: TObject);
begin
  if DBGContador.enabled = true then
    DBGContador.setfocus;

  if trim(EdtNomeContador.Text) = '' then
    EdtContador.Clear;

  if FDQListaContador.recordcount <= 0 then
  begin
    FDQListaContador.Close;
    EdtContador.Clear;
    EdtNomeContador.Clear;
  end;
end;

procedure TfrmMonitorClientes.EmInstalao1Click(Sender: TObject);
begin
  with FdQAux do
  begin

    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 2 , DT_Aguard_instalacao = :DT_em_instalacao     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('DT_em_instalacao').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;

end;

procedure TfrmMonitorClientes.Excluirlanamento2Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM indicacao_contador WHERE id = :ID ');
    parambyname('ID').asinteger := QGerenciadorComissoesid.asinteger;
    execsql;
  end;
  BtnVisualizarAgenda.Click;
end;

procedure TfrmMonitorClientes.ExportarDados1Click(Sender: TObject);
begin
  if pgDados.activepage = tabDadosGerais then
  begin
    dm.ExportarDadosGrid(cxGDRDadosGerais);
  end
  else if pgDados.activepage = TabAgendamentoAtualizacao then
  begin
    dm.ExportarDadosGrid(GAgendamentoAtualizacao);
  end
  else if pgDados.activepage = TabClientesExternos then
  begin
    dm.ExportarDadosGrid(GRelExternos);
  end
  else if pgDados.activepage = TabNuvem then
  begin
    dm.ExportarDadosGrid(GNuvem);
  end
  else if pgDados.activepage = TabCurvaABC then
  begin
    dm.ExportarDadosGrid(cxGCurvaABC);
  end;

end;

procedure TfrmMonitorClientes.Exportardados2Click(Sender: TObject);
begin
  dm.ExportarDadosGrid(cxGridPainelProb);
end;

procedure TfrmMonitorClientes.Exportarparaexcel1Click(Sender: TObject);
begin
  dm.ExportarDadosGrid(GRelComissaoIndicador);
end;

procedure TfrmMonitorClientes.BitBtn28Click(Sender: TObject);
begin
  Close;
end;

procedure TfrmMonitorClientes.BitBtn2Click(Sender: TObject);
begin
  Close;
end;

procedure TfrmMonitorClientes.BitBtn33Click(Sender: TObject);
begin
  Close;
end;

procedure TfrmMonitorClientes.btnverProblemasClick(Sender: TObject);
var
  stipoRegime: string;
begin

  // ATENCAO, antes de imprimir � necess�rio abrir o dsComponentPrinter com um duplo-clique e colocar

  // um subcomponente do tipo dxGridReportLink aqui abaixo ele ser� chamado de DPrnLink:

  DPrnLink.Component := cxGridPainelProb; // liga com grid

  DPrnLink.OptionsFormatting.UseNativeStyles := true; // s� preto-branco

  DPrnLink.OptionsSize.AutoWidth := true; // ajusta � pagina

  DPrnLink.PrinterPage.MeasurementUnits := muMillimeters;
  // em milimetro (cada 1000 - 1milimetro)
  // configura visualiza��o

  with TdxGridReportLink(DPrnLink) do

  begin

    // no relat�rio

    OptionsView.caption := False;

    OptionsView.Headers := true;

    OptionsView.Footers := true;

    OptionsView.GroupFooters := true;

    OptionsView.ExpandButtons := true;

    OptionsView.FilterBar := true;

    // em todas as p�ginas:

    OptionsOnEveryPage.caption := true;

    OptionsOnEveryPage.Headers := true;

    OptionsOnEveryPage.Footers := False;

    OptionsOnEveryPage.FilterBar := False;

  end;
  // define tamanho da linha NA GRID
  cxGridDBTableViewprob.OptionsView.DataRowHeight := 15;
  // cabe�alho

  with DPrnLink.PrinterPage.PageHeader do

  begin

    LeftTitle.Add(' PAINEL DE PROBLEMAS DO CLIENTE - IMPRESSO EM ' + datetostr(date));
    // RightTitle.add('P�gina[P�gina # de #]');
    // ('[User Name] - [Data & Time Printed] - P�gina[P�gina # de #]');

    LeftTextAlignY := taTop;

    RightTextAlignY := taTop;

    Font.Name := 'Times New Roman';

    Font.Size := 10;

  end;
  // rodap� de p�gina

  with DPrnLink.PrinterPage.PageFooter do

  begin

    RightTitle.Add('SI Tecnologias: (88) 3423-5757');

    RightTextAlignY := taTop;

    Font.Name := 'Times New Roman';

    Font.Size := 6;

  end;
  // margens e papel
  DPrnLink.PrinterPage.Margins.Left := 7000;
  DPrnLink.PrinterPage.Margins.Right := 5000;
  DPrnLink.PrinterPage.Margins.Bottom := 10300;
  DPrnLink.PrinterPage.Margins.Top := 14800;
  DPrnLink.PrinterPage.DMPaper := DMPAPER_A4;
  // titulo do relat�rio
  dsComponentPrinter.PrintTitle := 'IMPRESS�O DO RELAT�RIO';
  // preview
  dsComponentPrinter.Preview;
  // volta tamanho normal
  cxGridDBTableViewprob.OptionsView.DataRowHeight := 0;
end;

procedure TfrmMonitorClientes.BtnVerTodosPlanosClick(Sender: TObject);
var
  Response: IResponse;
begin
  Response := dm.ExecutarRequestAPICommand(TRequest.New.BaseURL('/planos'), rmGET);

  if not(MTPlanos.Active) then
    MTPlanos.open;

  MTPlanos.EmptyDataSet;
  MTPlanos.LoadFromJSON(Response.Content);

  MTPlanos.DisableControls;

  try
    MTPlanos.first;

    while not MTPlanos.eof do
    begin
      MTPlanos.Edit;

      case MTPlanosidSistema.asinteger of
        1:
          MTPlanosdescSistema.asstring := 'Command Server';
        2:
          MTPlanosdescSistema.asstring := 'CSPDV';
        3:
          MTPlanosdescSistema.asstring := 'Command Food';
        4:
          MTPlanosdescSistema.asstring := 'Command Connection';
        5:
          MTPlanosdescSistema.asstring := 'CS Pedidos';
        6:
          MTPlanosdescSistema.asstring := 'CS Invent�rio';
        7:
          MTPlanosdescSistema.asstring := 'CS Controle';
        8:
          MTPlanosdescSistema.asstring := 'Command DF-e';
        9:
          MTPlanosdescSistema.asstring := 'Command Backup';
        12:
          MTPlanosdescSistema.asstring := 'Command Sync';
        13:
          MTPlanosdescSistema.asstring := 'Command Zap';
      else
        MTPlanosdescSistema.asstring := 'Command System';
      end;

      MTPlanos.Post;
      MTPlanos.next;
    end;
  finally
    MTPlanos.first;
    MTPlanos.EnableControls;
  end;
end;

procedure TfrmMonitorClientes.BtnVincularTitularClick(Sender: TObject);
begin
  Application.CreateForm(TFrmListagemDeClientesPorTitular, FrmListagemDeClientesPorTitular);
  FrmListagemDeClientesPorTitular.tag := 0;
  FrmListagemDeClientesPorTitular.ShowModal;
end;

procedure TfrmMonitorClientes.BtnVisABCClick(Sender: TObject);
begin

  { busca CURVA A }
  with dm.FDQConsulta do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT    ' + ' count(t.id_titular)AS QTD ' + '  FROM titular t       ' +
      ' WHERE t.classe = ' + quotedstr('A') + ' ');
    open;
    EdtCurvaA.Text := dm.FDQConsulta.fieldbyname('QTD').asstring;
  end;

  { busca CURVA B }
  with dm.FDQConsulta do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT    ' + ' count(t.id_titular)AS QTD ' + '  FROM titular t       ' +
      ' WHERE t.classe = ' + quotedstr('B') + ' ');
    open;
    EdtCurvaB.Text := dm.FDQConsulta.fieldbyname('QTD').asstring;
  end;

  { busca CURVA C }
  with dm.FDQConsulta do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT    ' + ' count(t.id_titular)AS QTD ' + '  FROM titular t       ' +
      ' WHERE t.classe = ' + quotedstr('C') + ' ');
    open;
    EdtCurvaC.Text := dm.FDQConsulta.fieldbyname('QTD').asstring;
  end;

  { busca clientes  abc }
  with QrelABC do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT  ' + '  @rownum := @rownum + 1 AS ranking,  ' +
      '   t.id_titular, t.descricao, t.Lucro, t.perc_rep, t.classe, t.mensalidade_custo, t.mensalidade_venda  '
      + ' FROM titular t, (SELECT @rownum := 0) r ');
    SQL.Add(' where   t.descricao like ' + #39 + '%' + trim(EdtDescABC.Text) + '%' + #39 + ' ');

    SQL.Add('  ORDER BY t.Lucro DESC ');
    open;
  end;
end;

procedure TfrmMonitorClientes.BitBtn36Click(Sender: TObject);
VAR
  FileExt: String;
begin
  // salva o arquivo com os dados do CXGrid
  SaveDialog.Filter :=
    'Excel (*.xls) |*.xls|BrOffice (*.ods) |*.ods|XML (*.xml) |*.xml|Arquivo Texto (*.txt) |*.txt|P�gina Web (*.html)|*.html';
  SaveDialog.Title := 'Exportar Dados';
  SaveDialog.DefaultExt := 'xls';

  if SaveDialog.Execute then
  begin
    FileExt := LowerCase(ExtractFileExt(SaveDialog.FileName));
    if FileExt = '.xls' then
      ExportGridToExcel(SaveDialog.FileName, cxGridPainelProb, False)
    else if FileExt = '.xml' then
      ExportGridToXML(SaveDialog.FileName, cxGridPainelProb, False)
    else if FileExt = '.txt' then
      ExportGridToText(SaveDialog.FileName, cxGridPainelProb, False)
    else if FileExt = '.html' then
      ExportGridToHTML(SaveDialog.FileName, cxGridPainelProb, False)
    else if FileExt = '.ods' then
      ExportGridToExcel(SaveDialog.FileName, cxGridPainelProb, False);

    ShellExecute(Handle, 'open', pchar(SaveDialog.FileName), nil, nil, SW_SHOW);
  end;
end;

procedure TfrmMonitorClientes.BitBtn38Click(Sender: TObject);
begin
  Close;
end;

procedure TfrmMonitorClientes.BitBtn3Click(Sender: TObject);
VAR
  FileExt: String;
begin
  // salva o arquivo com os dados do CXGrid
  SaveDialog.Filter :=
    'Excel (*.xls) |*.xls|BrOffice (*.ods) |*.ods|XML (*.xml) |*.xml|Arquivo Texto (*.txt) |*.txt|P�gina Web (*.html)|*.html';
  SaveDialog.Title := 'Exportar Dados';
  SaveDialog.DefaultExt := 'xls';

  if SaveDialog.Execute then
  begin
    FileExt := LowerCase(ExtractFileExt(SaveDialog.FileName));
    if FileExt = '.xls' then
      ExportGridToExcel(SaveDialog.FileName, cxGDRClientesArquivosGerados, False)
    else if FileExt = '.xml' then
      ExportGridToXML(SaveDialog.FileName, cxGDRClientesArquivosGerados, False)
    else if FileExt = '.txt' then
      ExportGridToText(SaveDialog.FileName, cxGDRClientesArquivosGerados, False)
    else if FileExt = '.html' then
      ExportGridToHTML(SaveDialog.FileName, cxGDRClientesArquivosGerados, False)
    else if FileExt = '.ods' then
      ExportGridToExcel(SaveDialog.FileName, cxGDRClientesArquivosGerados, False);

    ShellExecute(Handle, 'open', pchar(SaveDialog.FileName), nil, nil, SW_SHOW);
  end;
end;

procedure TfrmMonitorClientes.BitBtn4Click(Sender: TObject);
begin

  with QMensalidadeDifCadastro do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select ' + '	c.cod_cli, ' + '	c.NOME_CLI , ' + '	c.NOME_FANTASIA , ' +
      '	c.CNPJ_CLI , ' + '	c.valor_mensalidade, ' +
      '	coalesce((select ca.valor from cliente_assinaturas ca where ca.id_cli = c.cod_cli limit 1), 0) valor_assinatura '
      + 'from ' + '	cliente c ' + 'where ' + '	c.ATIVO = ' + quotedstr('S') +
      '	and c.cod_cli < 100000 ' + '	and c.cod_cli <> 1   AND c.cod_cla <>30 ' +
      '	and	coalesce(c.valor_mensalidade , 0) > coalesce((select ca.valor from cliente_assinaturas ca where ca.id_cli = c.cod_cli limit 1), 0) and '
      + '	coalesce((select ca.valor from cliente_assinaturas ca where ca.id_cli = c.cod_cli limit 1), 0) > 0 ');

    open;
  end;
end;

procedure TfrmMonitorClientes.BtnAgendarTarefaClick(Sender: TObject);
var
  bOK: Boolean;
begin
  bOK := False;

  if MTAgendamentoAtualizacao.Isempty then
    exit;

  with MTAgendamentoAtualizacao do
  begin
    try
      DisableControls;

      if MTAgendamentoAtualizacao.Isempty then
      begin
        showmessage('selecione pelo menos um cliente para agendar uma tarefa!');
        exit;
      end;

      Application.CreateForm(TFrmAgendamentoTarefa, FrmAgendamentoTarefa);
      FrmAgendamentoTarefa.tag := 2;
      FrmAgendamentoTarefa.ShowModal;

      bOK := true;
    finally
      EnableControls;
    end;
  end;

  if bOK then
    BtnVisualizarAgendamentoAtualizacao.Click;
end;

procedure TfrmMonitorClientes.BtnVisualizarNuvemClick(Sender: TObject);
var
  cTotalRecebido: Currency;
begin
  cTotalRecebido := 0;
  { busca nuvem }
  with QNuvem do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select ' + '  nuvem.*, ' + '  p.descricao desc_plano_nuvem ' + 'from ' + '  ( ' +
      '  select ' + '    gu.id_grupo, ' + '    gu.descricao, ' + '    gu.valor_pago_nuvem, ' +
      '    gu.porta_principal, ' + '    gu.porta_arquivos, ' + '    gu.porta_aplicativos, ' +
      '    gu.servidor, ' + '    gu.versao_fb, ' + '    gu.hora_fecha_caixa, ' +
      '    a.data_hora_ultimo_acesso, ' + '    a.created_at, ' + '    a.updated_at, ' +
      '    a.versao, ' + '    c.cod_cli, ' + '    c.NOME_FANTASIA, ' + '    pasta_backup_ftp , ' +
      '    observacao, ' + '    ( ' + '    select ' +
      '      avg(d.tamanho_banco + d.tamanho_arquivos) as tamanho ' + '    from ' +
      '      grupo_clientes_dados_gerais GG ' + '    left join grupo_clientes ge on ' +
      '      ge.id_grupo = gg.id_grupo ' + '    left join dados_gerais_clientes d on ' +
      '      d.PASTA_BACKUP_FTP = gg.pasta_backup_ftp ' + '    where ' +
      '      GG.id_grupo = gu.id_grupo) as tamanho, ' + '    ( ' + '    select ' +
      '      cp.id_plano ' + '    from ' + '      cliente_planos cp ' +
      '    inner join planos p on ' + '      (cp.id_plano = p.id) ' + '    where ' +
      '      cp.id_Cli = c.cod_Cli ' + '      and coalesce(p.tamanho_max_nuvem, 0) > 0 ' +
      '    order by ' + '      cp.id ' + '    limit 1) id_plano_nuvem ' + '  from ' +
      '    grupo_clientes gu ' + '  left join grupo_clientes_dados_gerais gc on ' +
      '    gc.id_grupo = gu.id_grupo ' + '  left join aplicacoes_clientes ap on ' +
      '    ap.id_cliente = gc.cod_cli ' + '  left join aplicacoes a on ' +
      '    a.id = ap.id_aplicacao ' + '  left join cliente c on ' + '    c.cod_cli = ap.id_cliente '
      + '  where ' + '    c.ATIVO = ' + quotedstr('S') + '    and coalesce(gu.ativo, ' +
      quotedstr('') + ') <> ' + quotedstr('N') + '  ' + ' and (   gu.descricao like ' + #39 + '%' +
      trim(EdtDescricaoNuvem.Text) + '%' + #39 + ') group by  ' + '    1, ' + '    2) nuvem ' +
      'left join planos p on ' + '  (nuvem.id_plano_nuvem = p.id) ');
    open;
  end;

  QNuvem.first;
  while not QNuvem.eof do
  begin

    cTotalRecebido := cTotalRecebido + QNuvemvalor_pago_nuvem.ascurrency;

    QNuvem.next;
  end;

  EdtValorPago.value := cTotalpagoNuvem;
  EdtValorRecebido.value := cTotalRecebido;
  EdtValorLucro.value := cTotalRecebido - cTotalpagoNuvem;
  EdtLucroPerc.value := ((cTotalRecebido - cTotalpagoNuvem) / cTotalRecebido) * 100;

  { Calcula nuvem resumida }
  FDMNuvemResumida.Close;
  FDMNuvemResumida.Isempty;
  FDMNuvemResumida.open;
  with QNuvemResumida do
  begin
    Close;
    open;
  end;
  QNuvemResumida.first;

  while not QNuvemResumida.eof do
  begin

    FDMNuvemResumida.Append;

    FDMNuvemResumidaid_server_nuvem.asstring :=
      QNuvemResumida.fieldbyname('id_server_nuvem').asstring;
    FDMNuvemResumidadescricao_nuvem.asstring :=
      QNuvemResumida.fieldbyname('descricao_nuvem').asstring;
    FDMNuvemResumidavalor_recebido.ascurrency := QNuvemResumida.fieldbyname('valor_recebido')
      .ascurrency;
    FDMNuvemResumidavalor_nuvem.ascurrency := QNuvemResumida.fieldbyname('valor_nuvem').ascurrency;
    FDMNuvemResumidaQtd_conections.asstring := QNuvemResumida.fieldbyname('Qtd_conections')
      .asstring;
    FDMNuvemResumidaconsumo_medio_ram.ascurrency := QNuvemResumida.fieldbyname('consumo_medio_ram')
      .ascurrency;
    FDMNuvemResumidadata_ult_consulta_consumo.asstring :=
      QNuvemResumida.fieldbyname('data_ult_consulta_consumo').asstring;
    FDMNuvemResumidalucro_valor.ascurrency := QNuvemResumida.fieldbyname('lucro_valor').ascurrency;
    FDMNuvemResumidaporcentagem_lucro.ascurrency := QNuvemResumida.fieldbyname('porcentagem_lucro')
      .ascurrency;
    FDMNuvemResumidalucro_min_ideal.ascurrency := QNuvemResumida.fieldbyname('lucro_min_ideal')
      .ascurrency;
    FDMNuvemResumidaFalta_para_lucro_ideal.ascurrency :=
      QNuvemResumida.fieldbyname('Falta_para_lucro_ideal').ascurrency;
    FDMNuvemResumidacusto_por_conection.ascurrency :=
      QNuvemResumida.fieldbyname('custo_por_conection').ascurrency;
    FDMNuvemResumidavalor_Venda_min_conection.ascurrency :=
      QNuvemResumida.fieldbyname('valor_Venda_min_conection').ascurrency;

    with QQtdConectionResumido do
    begin
      Close;
      parambyname('descricao').asstring := FDMNuvemResumidadescricao_nuvem.asstring;
      open;
    end;

    FDMNuvemResumidaQtd_MB_Utilizado.asinteger := QQtdConectionResumido.fieldbyname('tamanho')
      .asinteger;
    FDMNuvemResumidaQtd_mb_por_conection.ascurrency :=
      (FDMNuvemResumidaQtd_MB_Utilizado.ascurrency / FDMNuvemResumidaQtd_conections.ascurrency);

    FDMNuvemResumida.Post;
    QNuvemResumida.next;
  end;
  QNuvemResumida.Close;
  QQtdConectionResumido.Close;
end;

procedure TfrmMonitorClientes.BtnVisualizarCliVersMinClick(Sender: TObject);
begin
  BtnVisualizarCliVersMin.enabled := False;
  VisualizarClientesComVersaoAbaixoDaMinima;
  BtnVisualizarCliVersMin.enabled := true;
end;

procedure TfrmMonitorClientes.btnClientesSemAtualizacaoClick(Sender: TObject);
begin
  { Busca cliente sem a atualiza��o de coleta de dados }

  WITH FDClientesSemAtualizacaoInicial do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI,CIDRES_CLI,P.descricao,c.DATACADASTRO_CLI,  '
      + ' c.OBS_VENDA,c.OBS_CLI FROM cliente c   ' + '  INNER JOIN ponto_revenda P       ' +
      ' ON P.cod_ponto= c.cod_ponto_revenda   ' + ' WHERE c.ATIVO =  ' + #39 + 'S' + #39 + ' ' +
      ' AND c.CNPJ_CLI   not LIKE ' + #39 + '% .   .   - %' + #39 + ' ' + '  ' +
      ' AND c.cod_cli NOT IN ' +
      ' ( SELECT cod_cli  FROM dados_gerais_clientes d )  and ( c.cod_cli <> 1 and c.cod_cli <> 0 AND c.cod_cli <> 7  '
      + ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6  and c.cod_cla <>30 )  AND C.cod_cli <10000000  '
      + ' and c.ATIVO =  ' + #39 + 'S' + #39 + ' ');
    open;
  end;
end;

procedure TfrmMonitorClientes.btncloseVersMinClick(Sender: TObject);
begin
  Close;
end;

procedure TfrmMonitorClientes.BitBtn6Click(Sender: TObject);
VAR
  FileExt: String;
begin

  // salva o arquivo com os dados do CXGrid
  SaveDialog.Filter :=
    'Excel (*.xls) |*.xls|BrOffice (*.ods) |*.ods|XML (*.xml) |*.xml|Arquivo Texto (*.txt) |*.txt|P�gina Web (*.html)|*.html';
  SaveDialog.Title := 'Exportar Dados';
  SaveDialog.DefaultExt := 'xls';
  if SaveDialog.Execute then
  begin
    FileExt := LowerCase(ExtractFileExt(SaveDialog.FileName));
    if FileExt = '.xls' then
      ExportGridToExcel(SaveDialog.FileName, cxGDRDadosGerais, False)
    else if FileExt = '.xml' then
      ExportGridToXML(SaveDialog.FileName, cxGDRDadosGerais, False)
    else if FileExt = '.txt' then
      ExportGridToText(SaveDialog.FileName, cxGDRDadosGerais, False)
    else if FileExt = '.html' then
      ExportGridToHTML(SaveDialog.FileName, cxGDRDadosGerais, False)
    else if FileExt = '.ods' then
      ExportGridToExcel(SaveDialog.FileName, cxGDRDadosGerais, False);
    ShellExecute(Handle, 'open', pchar(SaveDialog.FileName), nil, nil, SW_SHOW);
  end;

end;

procedure TfrmMonitorClientes.BitBtn7Click(Sender: TObject);
begin
  { grava grid desenvolvimento }
  cxGDRDadosGeraisDBTableView1.StoreToIniFile(ExtractFilePath(Application.ExeName) +
    '/frmMonitorClientes.cxGDRDadosGerais.ini', true, [gsoUseFilter, gsoUseSummary]);
end;

procedure TfrmMonitorClientes.BtnSairDadosNuvemClick(Sender: TObject);
begin
  FIdNuvem := 0;
  PnAlterarDadosNuvem.visible := False;
  PnAlterarDadosNuvem.SendToBack;
end;

procedure TfrmMonitorClientes.BtnSairNuvemClick(Sender: TObject);
begin
  DeleteFile(pchar(ExtractFilePath(Application.ExeName) +
    '\frmMonitorClientes.cxGDRDadosGerais.ini'));

  { Carrega Grid Desenvolvimento }
  try
    cxGDRDadosGeraisDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName) +
      '/frmMonitorClientes.cxGDRDadosGerais.ini', true, False, [gsoUseFilter, gsoUseSummary]);
  except

  end;

  Close;
end;

procedure TfrmMonitorClientes.BtnAgendarAtualizacaoClick(Sender: TObject);
var
  bOK: Boolean;
begin
  bOK := False;

  if MTAgendamentoAtualizacao.Isempty then
    exit;

  with MTAgendamentoAtualizacao do
  begin
    try
      DisableControls;

      if MTAgendamentoAtualizacao.Isempty then
      begin
        showmessage('selecione pelo menos um cliente para agendar a atualiza��o!');
        exit;
      end;

      first;

      while not eof do
      begin
        if fieldbyname('selec').asinteger = 1 then
          if (trim(MTAgendamentoAtualizacaoversao_exe_retaguarda.asstring)
            = trim(MTAgendamentoAtualizacaoult_versao_exe_retaguarda.asstring)) and
            (trim(MTAgendamentoAtualizacaoversao_exe_pdv.asstring)
            = trim(MTAgendamentoAtualizacaoult_versao_exe_pdv.asstring)) and
            (trim(MTAgendamentoAtualizacaoversao_exe_connection.asstring)
            = trim(MTAgendamentoAtualizacaoult_versao_exe_connection.asstring)) then
          begin
            showmessage('O cliente "' + MTAgendamentoAtualizacaoNOME_CLI.asstring +
              '", da pasta do backup FTP "' + MTAgendamentoAtualizacaoPASTA_BACKUP_FTP.asstring +
              '", j� est� nas �ltimas vers�es de todos os softwares! Sendo assim, desmarque-o.');
            exit;
          end
          else if (not MTAgendamentoAtualizacaodata_hora_ult_agend.IsNull) and
            (MTAgendamentoAtualizacaorealizada_ult_agend.asinteger <= 0) then
          begin
            showmessage('O cliente "' + MTAgendamentoAtualizacaoNOME_CLI.asstring +
              '", da pasta do backup FTP "' + MTAgendamentoAtualizacaoPASTA_BACKUP_FTP.asstring +
              '", j� possui um agendamento de atualiza��o que n�o foi realizado ainda! ' +
              'Sendo assim, desmarque-o.');
            exit;
          end;

        next;
      end;

      first;

      Application.CreateForm(TFrmAgendamentoAtualizacao, FrmAgendamentoAtualizacao);
      FrmAgendamentoAtualizacao.ShowModal;

      bOK := true;
    finally
      EnableControls;
    end;
  end;

  if bOK then
    BtnVisualizarAgendamentoAtualizacao.Click;

  GAgendamentoAtualizacao.setfocus;
end;

procedure TfrmMonitorClientes.BtnAlterarAssinaturaClick(Sender: TObject);
begin
  CriarAlterarAssinatura(MTAssinaturas);
end;

procedure TfrmMonitorClientes.BtnAlterarContadorClick(Sender: TObject);
var
  iCodigo: Integer;
begin
  if FDQListaContador.Isempty then
    exit;

  iCodigo := FDQListaContadorID_CONTADOR.asinteger;

  Application.CreateForm(TFrmCadContador, FrmCadContador);
  FrmCadContador.Codigo := FDQListaContadorID_CONTADOR.asinteger;
  FrmCadContador.ShowModal;

  btnListagemContadores.Click;

  FDQListaContador.Locate('ID_CONTADOR', iCodigo, []);
end;

procedure TfrmMonitorClientes.BtnAlterarPlanoClick(Sender: TObject);
var
  Codigo: Integer;
begin
  Application.CreateForm(TFrmCadPlanos, FrmCadPlanos);
  FrmCadPlanos.iCodigo := MTPlanosid.asinteger;
  FrmCadPlanos.sIdApi := MTPlanosidAPI.asstring;
  FrmCadPlanos.EdtDescricao.Text := MTPlanosdescricao.asstring;
  FrmCadPlanos.edtvalor.value := MTPlanosvalor.ascurrency;
  FrmCadPlanos.CheckModulo.checked := MTPlanosmodulo.asboolean;
  FrmCadPlanos.iCodigoSistema := MTPlanosidSistema.asinteger;
  FrmCadPlanos.ShowModal;

  MTPlanos.DisableControls;

  try
    Codigo := MTPlanosid.asinteger;
    BtnVerTodosPlanos.Click;

    MTPlanos.Locate('id', Codigo, []);
  finally
    MTPlanos.EnableControls;
  end;
end;

procedure TfrmMonitorClientes.BtnAplicarQuantidadeMaquinasGratuitasPadraoClick(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Text := 'select x.* from (select cp.*,  ' +
      '                                                  coalesce((select cp2.qtd from cliente_planos cp2 where cp2.id_cli = cp.id_cli and cp2.id_plano = 34), -1) qtd_maquinas, '
      + '                                                  (select p2.qtd_maquinas from planos p2 where p2.id = cp.id_plano) qtd_maquinas_plano '
      + '                                           from cliente_planos cp  ' +
      '                                           inner join planos p on (cp.id_plano = p.id) ' +
      '                                           where p.modulo = false and ' +
      '                                                 cp.id_cli < 10000000 ' +
      '                                           order by cp.id_cli) x ' +
      '                     where x.qtd_maquinas < x.qtd_maquinas_plano and ' +
      '                     x.qtd_maquinas_plano > 0 ';
    open;
    first;
  end;

  while not FdQAux.eof do
  begin
    with FDQAux2 do
    begin
      Close;
      SQL.Clear;

      if FdQAux.fieldbyname('qtd_maquinas').asinteger = -1 then
        SQL.Text := 'INSERT INTO cliente_planos(id_cli, id_plano, qtd, qtd_liberada, ' +
          'valor_total, valor, data_plano) VALUES(:id_cli, 34, :qtd, :qtd, 0, 9.9, current_date)'
      else
        SQL.Text := 'update cliente_planos cliplan  ' + 'set cliplan.qtd = :qtd, ' +
          '    cliplan.qtd_liberada = :qtd, ' + '    cliplan.valor_total = 0, ' +
          '    cliplan.valor = 9.9    ' + 'where cliplan.id_cli = :id_cli and ' +
          '      cliplan.id_plano = 34 ';

      parambyname('qtd').asinteger := FdQAux.fieldbyname('qtd_maquinas_plano').asinteger;
      parambyname('id_cli').asinteger := FdQAux.fieldbyname('id_cli').asinteger;
      execsql;
    end;

    FdQAux.next;
  end;

  FdQAux.Close;
  FDQAux2.Close;

  showmessage('Show papai!');
end;

procedure TfrmMonitorClientes.BtnBuscaClientesZapClick(Sender: TObject);
begin

  { Buscar dados do banco da plataforma }
  dm.ConectaBancoChatBot;

  with dm.QConsultaPG do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT     ' + '    tt."companyId" AS cod_emp,    ' + '    CO."name" AS nome_emp,    '
      + '    CO."dueDate" AS Data_vencimento, ' +
      '    CO."dueDate" - CURRENT_DATE AS dias_restantes, ' + '    COUNT(tt."id") AS qtd,     ' +
      '    MAX(tt."finishedAt") AS ult_mensagem,   ' + '    MAX(tt."startedAt") AS prim_mensagem  '
      + 'FROM     ' + '    "TicketTraking" tt    ' + 'LEFT JOIN     ' +
      '    "Users" u ON u.id = tt."userId"    ' + 'LEFT JOIN     ' +
      '    "Tickets" t ON t.id = tt."ticketId"    ' + 'LEFT JOIN     ' +
      '    "Contacts" c ON c.id = t."contactId"    ' + 'LEFT JOIN     ' +
      '    "Companies" CO ON CO.id = tt."companyId"    ' + 'GROUP BY     ' +
      '    tt."companyId",    ' + '    CO."name",    ' + '    CO."dueDate"     ' + 'ORDER BY     ' +
      '    tt."companyId"; ');
    open;
    last;
    first;

  end;
  CDSCommandZap.Close;
  CDSCommandZap.Isempty;
  CDSCommandZap.open;
  while not dm.QConsultaPG.eof do
  begin
    CDSCommandZap.Append;
    CDSCommandZapCOD_EMP.asstring := dm.QConsultaPG.fieldbyname('cod_emp').asstring;
    CDSCommandZapNOME_EMP.asstring := dm.QConsultaPG.fieldbyname('nome_emp').asstring;
    CDSCommandZapData_Vencimento.asstring := dm.QConsultaPG.fieldbyname('Data_vencimento').asstring;
    CDSCommandZapQTD.asstring := dm.QConsultaPG.fieldbyname('qtd').asstring;
    CDSCommandZapULT_MENSAGEM.asstring := dm.QConsultaPG.fieldbyname('ult_mensagem').asstring;
    CDSCommandZapprim_mensagem.asstring := dm.QConsultaPG.fieldbyname('prim_mensagem').asstring;
    CDSCommandZapDias.asstring := dm.QConsultaPG.fieldbyname('dias_restantes').asstring;
    CDSCommandZap.Post;
    dm.QConsultaPG.next;
  end;

end;

procedure TfrmMonitorClientes.BtnCancelarAgendamentoClick(Sender: TObject);
begin
  if MTAgendamentoAtualizacao.Isempty then
    exit;

  with MTAgendamentoAtualizacao do
  begin
    try
      DisableControls;

      if MTAgendamentoAtualizacao.Isempty then
      begin
        showmessage('selecione pelo menos um cliente para cancelar o agendamento!');
        exit;
      end;

      first;

      while not eof do
      begin
        if fieldbyname('selec').asinteger = 1 then
          if (not fieldbyname('data_hora_ult_agend').IsNull) and
            (fieldbyname('realizada_ult_agend').asinteger = 0) then
          begin
            FdQAux.Close;
            FdQAux.SQL.Clear;
            FdQAux.SQL.Text := 'delete from agendamento_atualizacao where ' +
              'PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP and COD_CLI = :cod_cli ' +
              'and cod_emp = :cod_emp and coalesce(realizada, 0) <= 0';
            FdQAux.parambyname('PASTA_BACKUP_FTP').asstring :=
              trim(fieldbyname('PASTA_BACKUP_FTP').asstring);
            FdQAux.parambyname('COD_CLI').asinteger := fieldbyname('COD_CLI').asinteger;
            FdQAux.parambyname('cod_emp').asinteger := fieldbyname('cod_emp').asinteger;
            FdQAux.execsql;
          end;

        next;
      end;

      first;
    finally
      EnableControls;
    end;
  end;

  showmessage('Cancelamento de agendamento efetuado com sucesso!');

  BtnVisualizarAgendamentoAtualizacao.Click;
  GAgendamentoAtualizacao.setfocus;
end;

procedure TfrmMonitorClientes.BtnCancelarClick(Sender: TObject);
begin
  EdtNomeContadorCliente.Clear;
  FDQListaContadorCliente.Close;
  pnContador.visible := False;
end;

procedure TfrmMonitorClientes.BtnCancelarTarefaClick(Sender: TObject);
begin
  if QAgendamentoTarefa.Isempty then
    exit;

  if QAgendamentoTarefarealizada.asinteger = 1 then
  begin
    showmessage('esta tarefa n�o pode ser cancelada pois j� foi realizada!');
    exit;
  end;

  if MessageDlg('tem certeza que deseja remover a tarefa agendada deste cliente?', mtConfirmation,
    [mbYes, mbNo], 0) = mrYes then
  begin
    FdQAux.Close;
    FdQAux.SQL.Clear;
    FdQAux.SQL.Text := 'delete from agendamento_tarefas where id = :id';
    FdQAux.parambyname('id').asinteger := QAgendamentoTarefaid.asinteger;
    FdQAux.execsql;

    BtnVisualizarTarefas.Click;
    cxGrid4.setfocus;
  end;
end;

procedure TfrmMonitorClientes.BtnClientesDispositivosClick(Sender: TObject);
begin
  { BUSCA quantidade de dispositivos CLIENTES }
  WITH QClientesDispositivos do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT  ' + '    D1.cod_cli, ' + '    D1.NOME_CLI, ' + '    D1.NOME_FANTASIA, ' +
      '    D1.CIDRES_CLI, ' + '    D1.CNPJ_CLI, ' +
      '    COALESCE(D1.QTD_COMPUTADORES, 0) AS QTD_COMPUTADORES, ' +
      '    COALESCE(D1.CS_PEDIDOS, 0) AS CS_PEDIDOS, ' +
      '    COALESCE(D1.CS_CONTROLE, 0) AS CS_CONTROLE ' + 'FROM ( ' + '    SELECT ' +
      '        c.cod_cli, ' + '        c.NOME_CLI, ' + '        c.NOME_FANTASIA, ' +
      '        c.CIDRES_CLI, ' + '        c.CNPJ_CLI, ' + '        (SELECT cp.qtd  ' +
      '         FROM cliente_planos cp  ' +
      '         WHERE cp.id_plano = 34 AND cp.id_cli = c.cod_cli  ' +
      '         LIMIT 1) AS QTD_COMPUTADORES, ' + '        (SELECT cp.qtd  ' +
      '         FROM cliente_planos cp  ' +
      '         WHERE cp.id_plano = 6 AND cp.id_cli = c.cod_cli  ' +
      '         LIMIT 1) AS CS_PEDIDOS, ' + '        (SELECT cp.qtd  ' +
      '         FROM cliente_planos cp  ' +
      '         WHERE cp.id_plano = 8 AND cp.id_cli = c.cod_cli  ' +
      '         LIMIT 1) AS CS_CONTROLE ' + '    FROM cliente c ' + '    WHERE c.ATIVO = ' +
      quotedstr('S') + '      AND c.cod_cli NOT IN (1, 0, 7, 8, 6) ' + '      AND c.cod_cla <> 30 '
      + '      AND c.cod_cli < 10000000 ');

    SQL.Add(' and (   c.nome_cli like ' + #39 + '%' + trim(EdtClienteDispositivos.Text) + '%' + #39
      + '  or  c.nome_fantasia like ' + #39 + '%' + trim(EdtClienteDispositivos.Text) + '%' + #39 +
      ' ) ) AS D1 ');

    open;

  end;
end;

procedure TfrmMonitorClientes.BtnGerarSubDominioClick(Sender: TObject);
var
  LDNS: String;
  LSubdominio: String;
  LIdServidor: Integer;
  LJsonString: String;
  LJson: TJsonZ;
begin
  if Pos('ciloscloud.com.br', QNuvemservidor.asstring.trim.ToLower) > 0 then
    LDNS := QNuvemservidor.asstring.trim.ToLower
  else
    LDNS := InputBox('DNS do servidor', 'Digite o DNS do Servidor:', '').ToLower.trim;

  if LDNS.Isempty then
  begin
    showmessage('Informe o DNS do servidor para gerar o subdom�nio!');
    exit;
  end;

  if QNuvemdescricao.asstring.trim.Isempty then
  begin
    showmessage('Esta nuvem est� sem descri��o!');
    exit;
  end;

  LSubdominio := GerarNomeSubdominio(QNuvemdescricao.asstring.trim);

  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select id_server_nuvem from servidor_nuvem where dns = :dns');
    parambyname('dns').asstring := LDNS;
    open;

    LIdServidor := fieldbyname('id_server_nuvem').asinteger;
  end;

  if LIdServidor <= 0 then
  begin
    showmessage('Servidor da nuvem n�o encontrado na base de dados de servidores!');
    exit;
  end;

  LJsonString := TCustomJSON.New.AddString('nome', LSubdominio).ToJsonString;

  LJsonString := dm.ExecutarRequestAPICommand(TRequest.New //
    .BaseURL('/nuvens/servidores/' + LIdServidor.tostring + '/subdominio') //
    .AddBody(LJsonString) //
    , rmPOST).Content;

  LJson := TJsonZ.Create;

  try
    LJson.Parse(LJsonString);

    LSubdominio := LJson['subdominio'].asstring.trim;
  finally
    FreeAndNil(LJson);
  end;

  if LSubdominio.Isempty then
  begin
    showmessage('Ocorreu uma falha ao gerar o subdom�nio da nuvem!');
    exit;
  end;

  ClipBoard.AsText := LSubdominio;
  showmessage('O subdom�nio "' + LSubdominio + '" foi gerado com sucesso! Basta dar um Ctrl + V ' +
    'para colar!');
end;

procedure TfrmMonitorClientes.BtnGridClick(Sender: TObject);

var
  stipoRegime: string;
begin

  // ATENCAO, antes de imprimir � necess�rio abrir o dsComponentPrinter com um duplo-clique e colocar

  // um subcomponente do tipo dxGridReportLink aqui abaixo ele ser� chamado de DPrnLink:

  DPrnLink.Component := cxGDRClientesArquivosGerados; // liga com grid

  DPrnLink.OptionsFormatting.UseNativeStyles := true; // s� preto-branco

  DPrnLink.OptionsSize.AutoWidth := true; // ajusta � pagina

  DPrnLink.PrinterPage.MeasurementUnits := muMillimeters;
  // em milimetro (cada 1000 - 1milimetro)



  // configura visualiza��o

  with TdxGridReportLink(DPrnLink) do

  begin

    // no relat�rio

    OptionsView.caption := False;

    OptionsView.Headers := true;

    OptionsView.Footers := true;

    OptionsView.GroupFooters := true;

    OptionsView.ExpandButtons := true;

    OptionsView.FilterBar := true;

    // em todas as p�ginas:

    OptionsOnEveryPage.caption := true;

    OptionsOnEveryPage.Headers := true;

    OptionsOnEveryPage.Footers := False;

    OptionsOnEveryPage.FilterBar := False;

  end;



  // define tamanho da linha NA GRID

  cxGDRClientesArquivosGeradosDBTableView1.OptionsView.DataRowHeight := 15;



  // cabe�alho

  with DPrnLink.PrinterPage.PageHeader do

  begin

    LeftTitle.Add(' RELAT�RIO DE CLIENTES SEM ATUALIZA��O');

    RightTitle.Add(datetostr(date) + ' ' + timetostr(time));
    // RightTitle.add('P�gina[P�gina # de #]');
    // ('[User Name] - [Data & Time Printed] - P�gina[P�gina # de #]');

    LeftTextAlignY := taTop;

    RightTextAlignY := taTop;

    Font.Name := 'Times New Roman';

    Font.Size := 10;

  end;



  // rodap� de p�gina

  with DPrnLink.PrinterPage.PageFooter do

  begin

    RightTitle.Add('SI Tecnologias: (88) 3423-5757');

    RightTextAlignY := taTop;

    Font.Name := 'Times New Roman';

    Font.Size := 6;

  end;



  // margens e papel

  DPrnLink.PrinterPage.Margins.Left := 7000;

  DPrnLink.PrinterPage.Margins.Right := 5000;

  DPrnLink.PrinterPage.Margins.Bottom := 10300;

  DPrnLink.PrinterPage.Margins.Top := 14800;

  DPrnLink.PrinterPage.DMPaper := DMPAPER_A4;



  // titulo do relat�rio

  dsComponentPrinter.PrintTitle := 'IMPRESS�O DO RELAT�RIO';



  // preview

  dsComponentPrinter.Preview;



  // volta tamanho normal

  cxGDRClientesArquivosGeradosDBTableView1.OptionsView.DataRowHeight := 0;
end;

procedure TfrmMonitorClientes.BtnImprimirClick(Sender: TObject);
begin
  BuscaIndicacoes(1);
  frRelComprovanteInd.PreviewOptions.Buttons := [pbPrint, pbExport, pbZoom, pbFind, pbOutline,
    pbPageSetup, pbTools, pbNavigator, pbCopy, pbSelection];

  frRelComprovanteInd.Variables['sRazaoEmp'] := quotedstr(trim('Command System'));
  frRelComprovanteInd.Variables['sFantasiaEmp'] := quotedstr(trim('Command System'));
  frRelComprovanteInd.Variables['sCNPJEmp'] := quotedstr('40.581.011/0001-27');
  frRelComprovanteInd.Variables['sNomeRel'] :=
    quotedstr('COMPROVANTE DE PAGAMENTODO DE COMISS�ES - COMMAND SYSTEM');

  frRelComprovanteInd.Variables['sEmailEmp'] := quotedstr(trim('Contato@commandsystem.com.br'));

  frRelComprovanteInd.Variables['sSite'] := quotedstr(trim('www.commandsystem.com.br'));

  frRelComprovanteInd.Variables['sWhatsappEmp'] := quotedstr(trim('(88)99733-7701'));

  frRelComprovanteInd.Variables['sTelEmp'] := quotedstr(trim('(88)2142-2227'));
  frRelComprovanteInd.ShowReport;

end;

procedure TfrmMonitorClientes.BtnInstalacoesClick(Sender: TObject);
var
  qtdAguardInstalacao, EmInstalacao, AgendarTreinamento, ReagendarTreinamento, TreinamentoConcluido,
    Retorno, Testes, PosVenda, desistencia, AguardandoClienteParaInstalacao, AguardandoMigracao,
    PrimeiroTreinamento, SegundoTreinamento, EmMigracao, EmConferenciaMigracao: Integer;
begin

  if PGInstalacoes.activepage = TabDashboard then
  begin
    qtdAguardInstalacao := 0;
    EmInstalacao := 0;
    AgendarTreinamento := 0;
    ReagendarTreinamento := 0;
    TreinamentoConcluido := 0;
    Testes := 0;
    PosVenda := 0;
    Retorno := 0;
    desistencia := 0;
    { Busca dados da Dashboard }
    with dm.FDQConsulta do
    begin
      Close;
      SQL.Clear;
      SQL.Add('SELECT  ' + '    COALESCE(STATUS_INSTAL, 0) AS STATUS_INSTAL, ' +
        '    COUNT(*) AS QTD_REGISTROS ' + 'FROM cliente C ' + 'WHERE C.ATIVO = ' + quotedstr('S') +
        '  AND C.cod_cli NOT IN (1, 0, 7, 8, 6) ' + '  AND C.cod_cli < 10000000 ' +
        '  AND C.cod_cla <> 30 ' + 'GROUP BY COALESCE(STATUS_INSTAL, 0) ');
      open;
      last;
      first;
      while not dm.FDQConsulta.eof do
      begin

        if ((dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 0) or
          (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 1)) then
        begin
          qtdAguardInstalacao := qtdAguardInstalacao + dm.FDQConsulta.fieldbyname('QTD_REGISTROS')
            .asinteger;
        end;
        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 2) then
        begin
          EmInstalacao := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 3) then
        begin
          AgendarTreinamento := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 4) then
        begin
          ReagendarTreinamento := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 5) then
        begin
          TreinamentoConcluido := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 6) then
        begin
          Retorno := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 8) then
        begin
          Testes := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 9) then
        begin
          PosVenda := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;
        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 10) then
        begin
          desistencia := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 10) then
        begin
          desistencia := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 11) then
        begin
          AguardandoClienteParaInstalacao := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 12) then
        begin
          AguardandoMigracao := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 13) then
        begin
          PrimeiroTreinamento := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 14) then
        begin
          SegundoTreinamento := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 15) then
        begin
          EmMigracao := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        if (dm.FDQConsulta.fieldbyname('STATUS_INSTAL').asinteger = 16) then
        begin
          EmConferenciaMigracao := dm.FDQConsulta.fieldbyname('QTD_REGISTROS').asinteger;
        end;

        dm.FDQConsulta.next;
      end;

      dm.GeraGraficosInstalacoes(INTTOSTR(qtdAguardInstalacao), INTTOSTR(EmInstalacao),
        INTTOSTR(AgendarTreinamento), INTTOSTR(ReagendarTreinamento),
        INTTOSTR(TreinamentoConcluido), INTTOSTR(Retorno), INTTOSTR(Testes), INTTOSTR(PosVenda),
        INTTOSTR(desistencia), INTTOSTR(AguardandoClienteParaInstalacao),
        INTTOSTR(AguardandoMigracao), INTTOSTR(PrimeiroTreinamento), INTTOSTR(SegundoTreinamento),
        INTTOSTR(EmMigracao), INTTOSTR(EmConferenciaMigracao));
    end;
  end
  else
  begin

    with QInstalacao do
    begin
      Close;
      SQL.Clear;
      SQL.Add('select ' + '	C.cod_cli, ' + '	C.NOME_CLI, ' + '	C.NOME_FANTASIA,  ' + '	(SELECT  ' +
        '    D.DATA_HORA_ULT_VENDA  ' + ' FROM dados_gerais_clientes D   ' +
        ' WHERE D.COD_CLI = C.cod_cli   ' + ' ORDER BY D.DATA_HORA_ULT_VENDA DESC ' +
        ' LIMIT 1      ' + ' ) AS ULTIMA_VENDA,   ' + '	C.CIDRES_CLI, ' + '	C.OBS_CLI, ' +
        '	C.TELRES_CLI, ' + '	C.CELULAR_CLI, ' +
        '	C.OBS_VENDA, C.STATUS_PRIM_PGTO,		C.dt_primeiro_pgto,  ' +
        '	C.DT_Aguard_instalacao,    ' + ' C.DT_Aguardandocliente_p_instal,   ' +
        ' C.DT_Teste_demo,           ' + ' C.DT_aguardando_migracao,  ' + ' C.Dt_em_migracao,      '
        + ' C.Dt_em_conf_migracao,  ' + ' C.DT_em_instalacao,     ' + ' C.DT_agendar_treinamento,  '
        + ' C.DT_prim_treinamento,  ' + ' C.Dt_Seg_treinamento,    ' +
        ' C.Dt_reagendar_Treinamento,  ' + ' C.Dt_treinamento_concluido,  ' +
        ' C.Dt_retorno_cs,            ' + ' C.Dt_pos_venda,     ' + ' C.Dt_concluido,    ' +
        ' C.Dt_desistencia,    ' + '	C.EMAIL_CLI, ' +
        '	coalesce(STATUS_INSTAL, 0)as STATUS_INSTAL, ' + '	( ' + '	select ' + '		U.NOME_USU ' +
        '	from ' + '		agenda A ' + '	inner join usuario U            ' + '         on ' +
        '		U.COD_USU = A.cod_colaborador ' + '	where ' + '		A.cod_cli = C.cod_cli ' + '	order by '
        + '		A.cod_agenda desc ' + '	limit 1) as TECNICO, ' + '	C.DATACADASTRO_CLI, ' +
        '	(select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 1) tipo_instalacao, '
        + '	(select dipi.desc_outro from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and ip.id_pergunta = 2) qtd_maquinas, '
        + '	(select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 3) tipo_servidor, '
        + '	(select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 4) qtd_sistemas, '
        + '	(select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 5) tipo_doc_fiscal, '
        + '	(select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 6) balanca_integrada, '
        + '    (select dipi.desc_outro from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and ip.id_pergunta = 7) qtd_impressoras_comp, '
        + '    (select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 8) imp_comp_compart, '
        + '    (select dipi.desc_outro from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and ip.id_pergunta = 9) qtd_impressoras_etq, '
        + '    (select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 10) imp_etq_compart, '
        + '    (select dipi.desc_outro from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and ip.id_pergunta = 11) qtd_balancas_etq, '
        + '    (select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 12) certificado_digital, '
        + '    (select ip.descricao from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and	ip.id_pergunta = 13) tipo_treinamento, '
        + '    (select dipi.desc_outro from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and ip.id_pergunta = 14) qtd_pessoas_treinamento, '
        + '    (select group_concat(ip.descricao separator ' + quotedstr(', ') +
        ') from dados_instalacao_processo_implantacao dipi inner join itens_pergunta ip on (dipi.id_item_pergunta = ip.id) where dipi.id_processo = pi.id and ip.id_pergunta = 15) setores_treinamento, '
        + '(select u.NOME_USUARIO_COMPLETO from processo_implantacao_comercial pic inner join usuario u on (pic.id_usu_dados = u.COD_USU) where pic.id_processo = pi.id) nome_vendedor, '
        + '(select n.descricao from negocios n where n.id = pi.id_negocio) observacao_negocio ' +
        'from ' + '	cliente C ' + 'left join processo_implantacao pi on (c.cod_cli = pi.id_cli) ' +
        'where ' + '	c.ATIVO = ' + quotedstr('S') + '	and c.CNPJ_CLI not like ' +
        quotedstr('% .   .   - %') + '	and ( c.cod_cli <> 1 ' + '		and c.cod_cli <> 0 ' +
        '		and c.cod_cli <> 7 ' + '		and c.cod_cli <> 8 ' + '		and c.cod_cli <> 6 ) ' +
        '	and C.cod_cli <10000000 ' + '	and c.cod_cla <> 30 ');

      if RGStatusOP.itemindex = 1 then
        SQL.Add('AND (( COALESCE(STATUS_INSTAL,0) = 0) or ( COALESCE(STATUS_INSTAL,0) = 1)) ')
      else if RGStatusOP.itemindex = 2 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =2')
      else if RGStatusOP.itemindex = 3 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =3')
      else if RGStatusOP.itemindex = 4 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =4')
      else if RGStatusOP.itemindex = 5 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =5')
      else if RGStatusOP.itemindex = 6 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =6')
      else if RGStatusOP.itemindex = 7 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =7')
      else if RGStatusOP.itemindex = 8 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =8')
      else if RGStatusOP.itemindex = 9 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =9')
      else if RGStatusOP.itemindex = 10 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =10')
      else if RGStatusOP.itemindex = 11 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =11')
      else if RGStatusOP.itemindex = 12 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =12')
      else if RGStatusOP.itemindex = 13 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =13')
      else if RGStatusOP.itemindex = 14 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =14')
      else if RGStatusOP.itemindex = 15 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =15')
      else if RGStatusOP.itemindex = 16 then
        SQL.Add(' AND COALESCE(STATUS_INSTAL,0) =16');

      SQL.Add(' and (   C.nome_cli like ' + #39 + '%' + trim(EdtCliInstalacao.Text) + '%' + #39 +
        '  or  C.nome_fantasia like ' + #39 + '%' + trim(EdtCliInstalacao.Text) + '%' + #39 + ' )');

      SQL.Add('ORDER BY C.cod_cli');
      open;
    end;
  end;

end;

procedure TfrmMonitorClientes.BtnInstalacoesEnter(Sender: TObject);
begin
  EdtCliInstalacao.selectall;
end;

procedure TfrmMonitorClientes.BtnLancarIndicacaoClick(Sender: TObject);
begin
  if FDQListaContador.Isempty then
    exit;

  Application.CreateForm(TFrmIndicacaoContador, FrmIndicacaoContador);
  FrmIndicacaoContador.ShowModal;
  BuscaIndicacoes(0);

end;

procedure TfrmMonitorClientes.BtnNovoContadorClick(Sender: TObject);
begin
  Application.CreateForm(TFrmCadContador, FrmCadContador);
  FrmCadContador.ShowModal;

  btnListagemContadores.Click;
end;

procedure TfrmMonitorClientes.BtnNovoPlanoClick(Sender: TObject);
begin
  Application.CreateForm(TFrmCadPlanos, FrmCadPlanos);
  FrmCadPlanos.ShowModal;

  BtnVerTodosPlanos.Click;
end;

procedure TfrmMonitorClientes.BtnOKClick(Sender: TObject);
var
  LBaseURL: String;
  LToken: String;
  LCNPJCliente: String;
  LCNPJContador: String;
begin
  if strtointdef(EdtContadorCliente.Text, 0) <= 0 then
  begin
    showmessage('Informe o contador!');
    exit;
  end;

  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' INSERT INTO contador_cliente (COD_CONTADOR,COD_CLIENTE)  ' +
      '          VALUES(:COD_CONTADOR,:COD_CLIENTE )    ' + '	  ON DUPLICATE KEY update  ' +
      '     COD_CONTADOR = :COD_CONTADOR,COD_CLIENTE = :COD_CLIENTE ');
    parambyname('COD_CONTADOR').asstring := EdtContadorCliente.Text;
    parambyname('COD_CLIENTE').asinteger := IcodClienteContador;
    execsql;
  end;

  try
    with dm.fdqinsert do
    begin
      Close;
      SQL.Clear;
      SQL.Text := 'select ativo, base_url, client_id from integracoes_contabilidade where id = 2';
      open;

      if fieldbyname('ativo').asboolean then
      begin
        LBaseURL := fieldbyname('base_url').asstring;
        LToken := fieldbyname('client_id').asstring;

        Close;
        SQL.Clear;
        SQL.Text := 'select cnpj_cli from cliente where cod_cli = ' + IcodClienteContador.tostring;
        open;

        LCNPJCliente := fieldbyname('cnpj_cli').asstring;

        Close;
        SQL.Clear;
        SQL.Text := 'select cnpj_cpf from contador where id_contador = ' + EdtContadorCliente.Text;
        open;

        LCNPJContador := fieldbyname('cnpj_cpf').asstring;

        TAPICilosContadorProvider.New(TAPICilosContadorConfig.New(LBaseURL, LToken))
          .VincularClienteContador(LCNPJCliente, LCNPJContador);
      end;

      Close;
    end;
  except
    on E: Exception do
      showmessage('Ocorreu uma falha ao vincular o contador ao cliente na Cilos Contador: ' +
        E.Message + sLineBreak + sLineBreak +
        'Por favor, v� a Cilos Contador e vincule contador ao cliente manualmente.');
  end;

  pnContador.visible := False;
  pnContador.SendToBack;
  btnVisContador.Click;
end;

procedure TfrmMonitorClientes.btnResetarClick(Sender: TObject);
begin
  DeleteFile(pchar(ExtractFilePath(Application.ExeName) +
    '\frmMonitorClientes.cxGDRClientesSemAtualizacoa.ini'));

  { Carrega Grid Desenvolvimento }
  try
    cxGDRClientesArquivosGeradosDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName)
      + '/frmMonitorClientes.cxGDRClientesSemAtualizacoa.ini', true, False,
      [gsoUseFilter, gsoUseSummary]);
  except

  end;
end;

procedure TfrmMonitorClientes.btnSairSClick(Sender: TObject);
begin
  pnContatoCliente.visible := False;
  pnContatoCliente.SendToBack;
end;

procedure TfrmMonitorClientes.btnSalvaContataChamClick(Sender: TObject);
begin
  { Salva Dados }
  if trim(edtNomeContatoCham.Text) = '' then
  begin
    showmessage(dm.sNomeUsu + ', Informe o Nome do Contato');
    edtNomeContatoCham.setfocus;
    exit;
  end;

  if trim(edtNumeroContatoCham.Text) = '' then
  begin
    showmessage(dm.sNomeUsu + ', Informe o Telefone do Contato');
    edtNumeroContatoCham.setfocus;
    exit;
  end;

  { verifica se  ja existe a solicita��o }
  with dm.FDQContatoCli do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select c.CODIGO from CONTATOS c   ' + '  where c.COD_CLI = :COD_CLI    ' +
      ' and c.NUMERO = :NUMERO');
    parambyname('COD_CLI').asstring := trim(edtCodcli.Text);
    parambyname('NUMERO').asstring := trim(edtNumeroContatoCham.Text);
    open;
    last;
    first;
  end;

  if dm.FDQContatoCli.recordcount > 0 then
  begin
    showmessage(dm.sNomeUsu + ', Este contato ja est� cadastrado');
    edtNumeroContatoCham.setfocus;
    exit;
  end;

  if dm.FDTInsertFB.Active then
    dm.FDTInsertFB.Commit;
  dm.FDTInsertFB.StartTransaction;

  with dm.FDQInsertFB do
  begin
    Close;
    SQL.Clear;
    SQL.Add('INSERT INTO CONTATOS (COD_CLI, DESCRICAO, SETOR, NUMERO,EMAIL) ' +
      'VALUES (:COD_CLI, :DESCRICAO, :SETOR, :NUMERO,:EMAIL)');
    parambyname('COD_CLI').asinteger := strtoint(edtCodcli.Text);
    parambyname('DESCRICAO').asstring := trim(edtNomeContatoCham.Text);
    parambyname('SETOR').asstring := trim(edtSetorContatoCham.Text);
    parambyname('NUMERO').asstring := trim(edtNumeroContatoCham.Text);
    parambyname('EMAIL').asstring := trim(edtEmailContatoCham.Text);
    execsql;
  end;
  dm.FDTInsertFB.Commit;

  // showmessage(dm.sNomeUsu + ', Contato Salvo Com Sucesso');
  LimpaContato;

  if trim(edtCodcli.Text) <> '' then
    dm.BuscaContatoCli(strtoint(edtCodcli.Text));
end;

procedure TfrmMonitorClientes.btnSalvarClick(Sender: TObject);
begin

  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE grupo_clientes G   ' +
      ' SET G.valor_pago_nuvem = :valor_pago_nuvem, versao_fb = :versao_fb  ' +
      ' WHERE G.id_grupo = :id_grupo');
    parambyname('id_grupo').asinteger := QNuvemid_grupo.asinteger;
    parambyname('valor_pago_nuvem').ascurrency := edtValorNuvem.value;
    parambyname('versao_fb').asstring := edtVersaoFirebird.Text;
    execsql;
  end;

  PnAlteraValorNuvem.visible := False;
  BtnVisualizarNuvem.Click;
end;

procedure TfrmMonitorClientes.BtnSalvarDadosNuvemClick(Sender: TObject);
begin
  if trim(edtDescricaoDadosNuvem.Text).Isempty then
  begin
    showmessage('Informe a descri��o da nuvem!');
    edtDescricaoDadosNuvem.setfocus;
    exit;
  end;

  if trim(edtServidorDadosNuvem.Text).Isempty then
  begin
    showmessage('Informe o servidor da nuvem!');
    edtServidorDadosNuvem.setfocus;
    exit;
  end;

  if strtointdef(edtPortaPrincipalDadosNuvem.Text, 0) <= 0 then
  begin
    showmessage('Informe a porta principal da nuvem!');
    edtPortaPrincipalDadosNuvem.setfocus;
    exit;
  end;

  if strtointdef(edtPortaArquivosDadosNuvem.Text, 0) <= 0 then
  begin
    showmessage('Informe a porta de arquivos da nuvem!');
    edtPortaArquivosDadosNuvem.setfocus;
    exit;
  end;

  if strtointdef(edtPortaAplicativosDadosNuvem.Text, 0) <= 0 then
  begin
    showmessage('Informe a porta de aplicativos da nuvem!');
    edtPortaAplicativosDadosNuvem.setfocus;
    exit;
  end;

  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE grupo_clientes G   ' +
      ' SET G.descricao = :descricao, porta_principal = :porta_principal, ' +
      'porta_arquivos = :porta_arquivos, porta_aplicativos = :porta_aplicativos, ' +
      'servidor = :servidor WHERE G.id_grupo = :id_grupo');
    parambyname('id_grupo').asinteger := FIdNuvem;
    parambyname('descricao').asstring := trim(edtDescricaoDadosNuvem.Text);
    parambyname('porta_principal').asinteger := strtointdef(edtPortaPrincipalDadosNuvem.Text, 0);
    parambyname('porta_arquivos').asinteger := strtointdef(edtPortaArquivosDadosNuvem.Text, 0);
    parambyname('porta_aplicativos').asinteger :=
      strtointdef(edtPortaAplicativosDadosNuvem.Text, 0);
    parambyname('servidor').asstring := trim(edtServidorDadosNuvem.Text);
    execsql;
  end;

  PnAlterarDadosNuvem.visible := False;
  PnAlterarDadosNuvem.SendToBack;
  BtnVisualizarNuvem.Click;
end;

procedure TfrmMonitorClientes.btnSalvarNuvenClick(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE grupo_clientes G   ' +
      ' SET G.valor_pago_nuvem = :valor_pago_nuvem, versao_fb = :versao_fb ' +
      ' WHERE G.id_grupo = :id_grupo');
    parambyname('id_grupo').asinteger := QNuvemid_grupo.asinteger;
    parambyname('valor_pago_nuvem').ascurrency := edtValorNuvem.value;
    parambyname('versao_fb').asstring := edtVersaoFirebird.Text;
    execsql;
  end;

  PnAlteraValorNuvem.visible := False;
  BtnVisualizarNuvem.Click;
end;

procedure TfrmMonitorClientes.btnSalvarObsCliClick(Sender: TObject);
begin
  if dm.FDTAuxServer.Active then
    dm.FDTAuxServer.Commit;
  dm.FDTAuxServer.StartTransaction;

  with dm.FDQAuxServer do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  UPDATE CLIENTE C SET C.OBS_CLI = :OBS_CLI  ' + ' where c.COD_CLI  = :COD_CLI   ');
    parambyname('OBS_CLI').asstring := MDadosAtendimento.Text;
    parambyname('COD_CLI').asstring := EdtCodCliObs.Text;
    execsql;
  end;

  dm.FDTAuxServer.Commit;
  PnObsCliente.visible := False;
end;

procedure TfrmMonitorClientes.BtnVerAssinaturasClick(Sender: TObject);
begin
  Query.Close;
  Query.SQL.Text := 'select	ca.*, ca.id_cli cod_cli, c.NOME_CLI, c.NOME_FANTASIA, c.CNPJ_CLI, case '
    + 'ca.forma_pagamento when (0) then (' + quotedstr('BOLETO') + ')	when (1) then (' +
    quotedstr('CART�O DE CR�DITO') + ') end desc_forma_pagamento, case ca.periodicidade	' +
    'when (0) then (' + quotedstr('MENSAL') + ')	when (1) then (' + quotedstr('TRIMESTRAL') +
    ') when (2) then (' + quotedstr('SEMESTRAL') + ') when (3) then (' + quotedstr('ANUAL') +
    ') end desc_periodicidade, c.valor_mensalidade from cliente_assinaturas ca inner join cliente c on '
    + '(ca.id_cli = c.cod_cli)';
  Query.open;

  MTAssinaturas.open;
  MTAssinaturas.DisableControls;

  try
    MTAssinaturas.EmptyDataSet;

    while not Query.eof do
    begin
      MTAssinaturas.Append;
      MTAssinaturasid.asinteger := Query.fieldbyname('id').asinteger;
      MTAssinaturasdata_hora_criacao.asdatetime := Query.fieldbyname('data_hora_criacao')
        .asdatetime;
      MTAssinaturasid_cli.asinteger := Query.fieldbyname('id_cli').asinteger;
      MTAssinaturascod_cli.asinteger := Query.fieldbyname('cod_cli').asinteger;
      MTAssinaturasNOME_CLI.asstring := Query.fieldbyname('nome_cli').asstring;
      MTAssinaturasNOME_FANTASIA.asstring := Query.fieldbyname('NOME_FANTASIA').asstring;
      MTAssinaturasCNPJ_CLI.asstring := Query.fieldbyname('CNPJ_CLI').asstring;
      MTAssinaturasdia_vencimento.asinteger := Query.fieldbyname('dia_vencimento').asinteger;
      MTAssinaturasvalor.ascurrency := Query.fieldbyname('valor').ascurrency;
      MTAssinaturasvalor_mensalidade.ascurrency := Query.fieldbyname('valor_mensalidade')
        .ascurrency;
      MTAssinaturasdesc_forma_pagamento.asstring :=
        Query.fieldbyname('desc_forma_pagamento').asstring;
      MTAssinaturasdesc_periodicidade.asstring := Query.fieldbyname('desc_periodicidade').asstring;
      MTAssinaturasdescricao.asstring := Query.fieldbyname('descricao').asstring;
      MTAssinaturasid_api.asstring := Query.fieldbyname('id_api').asstring;
      MTAssinaturasforma_pagamento.asinteger := Query.fieldbyname('forma_pagamento').asinteger;
      MTAssinaturasperiodicidade.asinteger := Query.fieldbyname('periodicidade').asinteger;
      MTAssinaturasdata_primeiro_vencimento.asdatetime :=
        Query.fieldbyname('data_primeiro_vencimento').asdatetime;
      MTAssinaturasultimos_quatro_digitos_cartao.asinteger :=
        Query.fieldbyname('ultimos_quatro_digitos_cartao').asinteger;
      MTAssinaturasbandeira_cartao.asstring := Query.fieldbyname('bandeira_cartao').asstring;
      MTAssinaturastoken_cartao.asstring := Query.fieldbyname('token_cartao').asstring;

      if MTAssinaturasperiodicidade.asinteger <> 0 then
      begin
        FdQAux.Close;
        FdQAux.SQL.Clear;
        FdQAux.SQL.Text := 'select li.vencimento from licencas li where li.cnpj = :CNPJ and ' +
          'li.sistema_id = 1 limit 1';
        FdQAux.parambyname('cnpj').asstring := MTAssinaturasCNPJ_CLI.asstring;
        FdQAux.open;

        if not FdQAux.fieldbyname('vencimento').IsNull then
          MTAssinaturasvencimento_licenca.asdatetime := FdQAux.fieldbyname('vencimento').asdatetime;

        FdQAux.Close;
      end;

      MTAssinaturas.Post;

      Query.next;
    end;
  finally
    Query.Close;

    MTAssinaturas.first;
    MTAssinaturas.EnableControls;
  end;
end;

procedure TfrmMonitorClientes.btnVisGridClick(Sender: TObject);
var
  sMesAtual: string;
begin
  sMesAtual := INTTOSTR(strtoint(copy(datetostr(date), 4, 2)) - 1);
  { BUSCA CLIENTES SEM ATUALIZACAO }
  WITH FDQCliArquivosGerados do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  SELECT c.cod_cli,c.CNPJ_CLI,c.NOME_CLI,c.NOME_FANTASIA,   d.PASTA_BACKUP_FTP   ' +
      '  ,  c.enviado_pdc,c.data_hora_ultimo_mov_fiscal,    ' +
      '   c.mes_mov_fiscal,c.ano_mov_fiscal,              ' +
      '   c.inconsistencias_mov_fiscal,c.enviado_email_mov_fiscal,     ' +
      '   c.data_hora_email_mov_fiscal,c.data_hora_email_mov_fiscal,   ' +
      '   c.enviado_email_xml,c.data_hora_email_xml,d.cod_emp,d.versao_exe_retaguarda,d.versao_exe_pdv,d.versao_exe_connection, '
      + '    d.VERSAO,co.RAZAO_SOCIAL,co.NOME_COMERCIAL,co.DESCRICAO_ESCRITORIO  ,    ' +
      '   (SELECT p.descricao FROM ponto_revenda p WHERE p.cod_ponto = c.cod_con )   ' +
      '    as ponto_revenda FROM cliente c                  ' +
      '      LEFT JOIN dados_gerais_clientes d   ON d.COD_CLI = c.COD_CLI     ' +
      '      left join contador_cliente CC on  ' + '	CC.COD_CLIENTE = c.cod_cli   ' +
      ' left join contador co on       ' + '	co.ID_CONTADOR = CC.COD_CONTADOR   ' +
      '     WHERE (  (c.mes_mov_fiscal = :mes_mov_fiscal ) OR ' +
      ' (CAST(c.data_hora_email_xml as DATE)  between :dataini and :Datafin ) ) ');

    SQL.Add(' and (   c.nome_cli like ' + #39 + '%' + trim(EdtClientesArquivosFiscais.Text) + '%' +
      #39 + '  or  c.nome_fantasia like ' + #39 + '%' + trim(EdtClientesArquivosFiscais.Text) + '%'
      + #39 + ' )');

    SQL.Add('  GROUP BY c.cod_cli,c.CNPJ_CLI  ');
    parambyname('mes_mov_fiscal').asinteger := strtoint(sMesAtual);
    parambyname('dataini').asstring := FormatDateTime('yyyy-mm-dd', startofthemonth(date));
    parambyname('Datafin').asstring := FormatDateTime('yyyy-mm-dd', endofthemonth(date));
    open;
  end;

end;

procedure TfrmMonitorClientes.BtnVisualizarAgendaClick(Sender: TObject);
begin
  BuscaIndicacoes(0);
  GeraqtdImndicacoesContador;
  GeraComissaoAgente;
end;

procedure TfrmMonitorClientes.BtnVisualizarAgendamentoAtualizacaoClick(Sender: TObject);
var
  sVersaoAtualRetaguarda, sVersaoAtualPDV, sVersaoAtualConnection: String;
begin
  if not(EdtClientesAgendamento.focused) then
  begin

    // Buscar a ultima versao do retaguarda, pdv e connection
    with FdQAux do
    begin
      Close;
      SQL.Clear;
      SQL.Text :=
        'select versao from sistema_versoes where sistema_id = 1 order by id desc limit 1';
      open;

      sVersaoAtualRetaguarda := trim(fieldbyname('versao').asstring);

      Close;
      SQL.Clear;
      SQL.Text :=
        'select versao from sistema_versoes where sistema_id = 2 order by id desc limit 1';
      open;

      sVersaoAtualPDV := trim(fieldbyname('versao').asstring);

      Close;
      SQL.Clear;
      SQL.Text :=
        'select versao from sistema_versoes where sistema_id = 4 order by id desc limit 1';
      open;

      sVersaoAtualConnection := trim(fieldbyname('versao').asstring);
    end;

    with QAgendamentoAtualizacao do
    begin
      Close;
      SQL.Clear;

      SQL.Text := 'select X.*, ' + '  case ' + '    when (X.realizada_ult_agend is null) then ' +
        quotedstr('') + '    when coalesce(X.realizada_ult_agend, 0) <= 0 then ' + quotedstr('N�O')
        + '    else ' + quotedstr('SIM') + '  end as desc_realizada_ult_agend ' + 'from ( ' +
        '  select ' + '    0 as SELEC, ' +
        '    cliente.cod_cli, cliente.NOME_FANTASIA, cliente.NOME_CLI, ' +
        '    cliente.CNPJ_CLI, cliente.CIDRES_CLI, P.descricao, cliente.DATACADASTRO_CLI, ' +
        '    dgc.cod_emp, dgc.PASTA_BACKUP_FTP, dgc.DATA_SINCR_DADOS, dgc.versao_exe_retaguarda, ' +
        '    cast(' + quotedstr(sVersaoAtualRetaguarda) +
        ' as CHAR(50)) as ult_versao_exe_retaguarda, ' +
        '    dgc.versao_exe_retaguarda_download, dgc.data_hora_download_versao_exe_retaguarda, dgc.VERSAO, '
        + '    dgc.versao_exe_pdv, cast(' + quotedstr(sVersaoAtualPDV) +
        ' as CHAR(50)) as ult_versao_exe_pdv, ' +
        '    dgc.versao_exe_pdv_download, dgc.data_hora_download_versao_exe_pdv, dgc.versao_exe_connection, '
        + '    cast(' + quotedstr(sVersaoAtualConnection) +
        ' as CHAR(50)) as ult_versao_exe_connection, ' +
        '    dgc.versao_exe_connection_download, dgc.data_hora_download_versao_exe_connection, ' +

      // �ltimo agendamento (data_hora)
        '    (select aa.data_hora ' + '       from agendamento_atualizacao aa ' +
        '      where dgc.PASTA_BACKUP_FTP = aa.PASTA_BACKUP_FTP ' +
        '        and dgc.COD_CLI = aa.cod_cli ' + '        and dgc.cod_emp = aa.cod_emp ' +
        '      order by aa.id desc limit 1) as data_hora_ult_agend, ' +

      // �ltimo agendamento (realizada)
        '    (select aa.realizada ' + '       from agendamento_atualizacao aa ' +
        '      where dgc.PASTA_BACKUP_FTP = aa.PASTA_BACKUP_FTP ' +
        '        and dgc.COD_CLI = aa.cod_cli ' + '        and dgc.cod_emp = aa.cod_emp ' +
        '      order by aa.id desc limit 1) as realizada_ult_agend, ' +

      // Periodicidade
        '    (select case ca.periodicidade ' + '        when 0 then ''MENSAL'' ' +
        '        when 1 then ''TRIMESTRAL'' ' + '        when 2 then ''SEMESTRAL'' ' +
        '        when 3 then ''ANUAL'' ' + '      end ' + '      from cliente_assinaturas ca ' +
        '     where ca.id_cli = dgc.cod_cli ' +
        '     order by ca.id desc limit 1) as desc_periodicidade ' +

        '  from dados_gerais_clientes dgc ' +
        '  inner join cliente on dgc.COD_CLI = cliente.cod_cli ' +
        '  inner join ponto_revenda P on P.cod_ponto = cliente.COD_CON ' +
        '  where cliente.ATIVO = ' + quotedstr('S') + '    and cliente.CNPJ_CLI not like ' +
        quotedstr('% .   .   - %') + '    and cliente.COD_CON <> 13 ' +
        '    and cliente.cod_cli < 10000000 ' + '    and cliente.cod_cla <> 30 ';

      // filtro por nome/fantasia
      SQL.Add(' and ( cliente.nome_cli like ' + quotedstr('%' + trim(EdtClientesAgendamento.Text) +
        '%') + '    or cliente.nome_fantasia like ' +
        quotedstr('%' + trim(EdtClientesAgendamento.Text) + '%') + ' ) ');

      // fecha o derived table
      SQL.Add(') X ');

      if CBBuscarDataAgendamento.checked = true then
      begin
        // filtro pela data do �ltimo agendamento (aa.data_hora -> data_hora_ult_agend)
        SQL.Add('where DATE(X.data_hora_ult_agend) between :dataini and :datafin ');

        // par�metros (melhor como Date)
        parambyname('dataini').AsDate := etDataINIAtualizacao.date;
        parambyname('datafin').AsDate := etDataFinAtualizacao.date;

      end;

      // ordena��o final
      SQL.Add('order by X.NOME_FANTASIA ');

      open;
      last;
      first;
    end;

    MTAgendamentoAtualizacao.Close;
    MTAgendamentoAtualizacao.Data := QAgendamentoAtualizacao.Data;
    MTAgendamentoAtualizacao.open;
    MTAgendamentoAtualizacao.first;

    QAgendamentoAtualizacao.Close;
  end;

end;

procedure TfrmMonitorClientes.btnVisualizarClick(Sender: TObject);
begin
  with FDQBloqueioCli do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  SELECT c.cod_cli,c.CNPJ_CLI,c.NOME_CLI,c.NOME_FANTASIA,   ' +
      ' (SELECT p.descricao FROM ponto_revenda p WHERE p.cod_ponto = c.cod_con )  ' +
      ' as ponto_revenda,C.BLOQUEAR,C.MENSAGEM,C.bloquear_auto,C.BOL_FIN_IMP,     ' +
      ' C.CONF_BLOQUEIO,C.DATA_DE_BLOQUEIO,C.DATA_DO_BLOQUEIO,         ' +
      ' d.cod_emp,d.versao_exe_retaguarda,d.versao_exe_pdv,d.versao_exe_connection, ' +
      ' d.VERSAO,CIDRES_CLI        ' + ' FROM cliente C  ' + ' LEFT JOIN dados_gerais_clientes d ' +
      ' ON d.COD_CLI = c.COD_CLI     ' + ' WHERE C.BLOQUEAR = 1  ' + ' and c.ATIVO = ' + #39 + 'S' +
      #39 + ' ' + '  GROUP BY         ' + ' c.COD_CLI ');
    open;
  end;
end;

procedure TfrmMonitorClientes.BtnVisualizarTarefasClick(Sender: TObject);
begin
  with QAgendamentoTarefa do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select ' + '	at2.id, ' + '	at2.cod_cli, ' + '	at2.pasta_backup_ftp, ' +
      '	at2.cod_emp, ' + '	cliente.NOME_FANTASIA, ' + '	cliente.NOME_CLI, ' +
      '	cliente.CNPJ_CLI, ' + '	cliente.CIDRES_CLI, ' + '	P.descricao, ' + '	at2.data_hora, ' +
      '	at2.realizada, ' + '	if(coalesce(at2.realizada, 0) = 0, ' + '	' + quotedstr('N�O') + ', '
      + '	' + quotedstr('SIM') + ') desc_realizada, ' + '	at2.tipo_tarefa, ' + '	case ' +
      '		at2.tipo_tarefa ' + '       when (0) then (' + quotedstr('BACKUP') + ') ' +
      '		when (1) then (' + quotedstr('MOVIMENTO FISCAL') + ') ' + '		when (2) then (' +
      quotedstr('ENVIO XMLS E RELAT�RIOS EMAIL') + ') ' + '		when (3) then (' +
      quotedstr('RETORNO SQL') + ') ' + '		when (4) then (' + quotedstr('OPERA��O SQL') + ') ' +
      '	end desc_tipo_tarefa, ' + '	at2.sucesso, ' + '	if(coalesce(at2.sucesso, 0) = 0, ' + '	' +
      quotedstr('N�O') + ', ' + '	' + quotedstr('SIM') + ') desc_sucesso, ' +
      '        at2.retorno, ' + '        at2.instrucao ' + 'from ' + '	agendamento_tarefas at2 ' +
      'inner join cliente on ' + '	at2.COD_CLI = cliente.cod_cli ' +
      'inner join ponto_revenda P on ' + '	P.cod_ponto = cliente.COD_CON ' +
      'WHERE cliente.ATIVO = ' + quotedstr('S') + 'AND cliente.CNPJ_CLI   not LIKE  ' +
      quotedstr('% .   .   - %') +
      '  and ( cliente.cod_cli <> 1 and cliente.cod_cli <> 0 AND cliente.cod_cli <> 7    ' +
      '       AND  cliente.cod_cli <> 8 AND  cliente.cod_cli <> 6 ) ');
    if CbBuscarDataTarefa.checked = true then
    begin
      SQL.Add(' and cast(data_hora as date) between :dataini and :Datafin   ');
      parambyname('dataini').asstring := FormatDateTime('yyyy-mm-dd', edtiniAgendamentoTarefa.date);
      parambyname('Datafin').asstring := FormatDateTime('yyyy-mm-dd', edtFinAgendamentoTarefa.date);
    end;

    SQL.Add(' order by   ' + '	at2.id desc ');

    open;
    first;
  end;
end;

procedure TfrmMonitorClientes.btnVisualizaServidoresClick(Sender: TObject);
var
  I: Integer;

  LRequest: IRequest;
  LHost: String;
begin
  MTServidores.open;
  MTServidores.EmptyDataSet;

  with QServidores do
  begin
    Close;
    open;

    first;
    while not eof do
    begin

      LHost := 'http://' + QServidoresdns.asstring + ':' + QServidoresporta_api_servidor.asstring +
        '/api/ready/';

      MTServidores.Append;

      for I := 0 to FieldCount - 1 do
        MTServidores.Fields[I].value := Fields[I].value;

      if MTServidoresSTATUS.asstring = '' then
      begin

        LRequest := TRequest.New //
          .BaseURL(LHost) //
          .BasicAuthentication('<USUARIO_REMOVIDO>', '<SENHA_REMOVIDA>').Timeout(2000);

        try
          LRequest.get;

          MTServidoresSTATUS.asstring := 'ONLINE';
        except
          MTServidoresSTATUS.asstring := 'OFFLINE';
        end;
      end;

      MTServidores.Post;
      next;
    end;

    MTServidores.first;
  end;
end;

procedure TfrmMonitorClientes.BuscaCrescimentoEmpresa;
var
  cValorAcumulado: Currency;
begin
  cValorAcumulado := 0;
  { Busca dados crescimento cliente }

  with dm.FDQConsulta do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  SELECT MONTH(C.DATACADASTRO_CLI) AS MES,YEAR(C.DATACADASTRO_CLI) AS ANO ,   ' +
      ' COUNT(C.DATACADASTRO_CLI) AS QTD,SUM(C.valor_mensalidade)  AS TOTAL FROM  cliente C WHERE   '
      + ' C.valor_mensalidade >0 AND    ' +
      ' cod_cli <> 7  AND  c.cod_cli <> 8 AND  c.cod_cli <> 6  and c.cod_cla <>30  ' +
      ' and c.ATIVO =  ' + #39 + 'S' + #39 + ' ' + '      ');
    if CbCentral.itemindex > 0 then
    begin
      SQL.Add('  and  c.COD_CON = :COD_CON   ');
      parambyname('COD_CON').asinteger := CbCentral.itemindex;
    end;
    SQL.Add(' GROUP BY MONTH(C.DATACADASTRO_CLI),YEAR(C.DATACADASTRO_CLI)   ' +
      ' ORDER BY YEAR(C.DATACADASTRO_CLI),MONTH(C.DATACADASTRO_CLI)    ');
    open;
    last;
    first;
  end;

  FDMCrescimento.Close;
  FDMCrescimento.Isempty;
  FDMCrescimento.open;
  while not dm.FDQConsulta.eof do
  begin

    FDMCrescimento.Append;
    FDMCrescimentoMES.asstring := dm.FDQConsulta.fieldbyname('MES').asstring;
    FDMCrescimentoQTD.asstring := dm.FDQConsulta.fieldbyname('QTD').asstring;
    FDMCrescimentoANO.asstring := dm.FDQConsulta.fieldbyname('ANO').asstring;
    FDMCrescimentoTOTAL.ascurrency := dm.FDQConsulta.fieldbyname('TOTAL').ascurrency;
    FDMCrescimentoACUM_FATURAMENTO.ascurrency := cValorAcumulado + dm.FDQConsulta.fieldbyname
      ('TOTAL').ascurrency;
    FDMCrescimentoTICKET_MEDIO.ascurrency :=
      (dm.FDQConsulta.fieldbyname('TOTAL').ascurrency / dm.FDQConsulta.fieldbyname('QTD')
      .ascurrency);
    if cValorAcumulado = 0 then
    begin
      FDMCrescimentoPERC_CRESCIMENTO.ascurrency := 100;
    end
    else
    begin
      FDMCrescimentoPERC_CRESCIMENTO.ascurrency :=
        (dm.FDQConsulta.fieldbyname('TOTAL').ascurrency /
        FDMCrescimentoACUM_FATURAMENTO.ascurrency) * 100;
    end;
    cValorAcumulado := cValorAcumulado + dm.FDQConsulta.fieldbyname('TOTAL').ascurrency;
    FDMCrescimento.Post;
    dm.FDQConsulta.next;
  end;

end;

procedure TfrmMonitorClientes.BuscaIndicacoes(indice: Integer);
var
  cValorTotal, cComissao: Currency;
begin
  cValorTotal := 0;
  cComissao := 0;
  DBGContador.visible := False;
  QGerenciadorComissoes.DisableControls;
  with QGerenciadorComissoes do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT     ' + '    I.id, ' + '    I.data_hora_lanc, ' + '    I.data_indicacao, ' +
      '    I.id_contador, ' + '    CO.DESCRICAO_ESCRITORIO,    ' + '    CO.NOME_RESP, ' +
      '    CO.NOME_COMERCIAL, ' + '    I.id_cliente, ' + '    C.NOME_CLI, ' +
      '    C.NOME_FANTASIA, ' + '    I.tipo, ' + '    I.valor, ' + '    I.comissao_valor, ' +
      '    I.id_usu_lanc, ' + '    U.NOME_USU, ' + '    CO.CHAVE_PIX, ' + '    CO.EMAIL, ' +
      '    CO.TELEFONE, ' + '    ce.id_certificadora, ' + '    ce.descricao_certificadora ' +
      'FROM indicacao_contador I ' + 'LEFT JOIN contador CO  ' +
      '    ON CO.ID_CONTADOR = I.id_contador ' + 'INNER JOIN cliente C  ' +
      '    ON C.cod_cli = I.id_cliente ' + 'INNER JOIN usuario U  ' +
      '    ON U.COD_USU = I.id_usu_lanc ' + 'LEFT JOIN certificadora ce  ' +
      '    ON ce.id_certificadora = I.id_certificadora ');

    SQL.Add(' WHERE I.data_indicacao between :dataini and :Datafin ');
    parambyname('dataini').asstring := FormatDateTime('yyyy-mm-dd', EdtDatainiComissao.date);;
    parambyname('Datafin').asstring := FormatDateTime('yyyy-mm-dd', EdtDataFinComissao.date);

    if trim(EdtContador.Text) <> '' then
    begin
      SQL.Add(' and I.ID_CONTADOR = ' + trim(EdtContador.Text) + '');
    end;
    if indice = 0 then
    begin
      SQL.Add(' order by I.id  ');
    end
    else if indice = 1 then
    begin
      SQL.Add(' order by I.id_contador  ');
    end;

    open;

  end;
  QGerenciadorComissoes.EnableControls;

  while not QGerenciadorComissoes.eof do
  begin
    cValorTotal := cValorTotal + QGerenciadorComissoesvalor.ascurrency;
    cComissao := cComissao + QGerenciadorComissoescomissao_valor.ascurrency;

    QGerenciadorComissoes.next;
  end;

  EdtOperacao.caption :=
    currtostrf(StrToCurrDef(StringReplace(currtostrf((dm.ExatoCurrency(cValorTotal, 2)), ffnumber,
    2), '.', '', [rfReplaceAll]), 0), ffnumber, 2);

  EdtComissao.caption :=
    currtostrf(StrToCurrDef(StringReplace(currtostrf((dm.ExatoCurrency(cComissao, 2)), ffnumber, 2),
    '.', '', [rfReplaceAll]), 0), ffnumber, 2);

end;

procedure TfrmMonitorClientes.C1Click(Sender: TObject);
begin
  ClipBoard.AsText := QAgendamentoTarefaretorno.asstring;
end;

procedure TfrmMonitorClientes.C2Click(Sender: TObject);
begin
  ClipBoard.AsText := QAgendamentoTarefainstrucao.asstring;
end;

procedure TfrmMonitorClientes.C3Click(Sender: TObject);
begin
  CriarAlterarAssinatura(FDQClientesContador);
end;

procedure TfrmMonitorClientes.C4Click(Sender: TObject);
begin
  try
    ClipBoard.AsText := VarAsType(cxGridDBTableView3.DataController.Values
      [cxGridDBTableView3.DataController.FocusedRecordIndex,
      cxGridDBTableView3.Controller.FocusedColumn.Index], varString);
  except
  end;
end;

procedure TfrmMonitorClientes.c5Click(Sender: TObject);
var
  Codigo: Integer;
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Text := 'update CLIENTE set RECEBER_CARNE_IMPRESSO = :RECEBER_CARNE_IMPRESSO ' +
      'where COD_CLI = ' + FDQClientesContadorcod_cli.asstring;
    parambyname('RECEBER_CARNE_IMPRESSO').asstring := IfThen(c5.tag = 0, 'S', 'N');
    execsql;
  end;

  FDQClientesContador.DisableControls;

  try
    Codigo := FDQClientesContadorcod_cli.asinteger;
    btnVisContador.Click;

    FDQClientesContador.Locate('cod_cli', Codigo, []);
  finally
    FDQClientesContador.EnableControls;
  end;
end;

procedure TfrmMonitorClientes.C6Click(Sender: TObject);
var
  LToken: String;
  LActivationToken: String;
  LOcpApimSubscriptionKey: String;
  LCreateStoreResponse: TCreateStoreResponse;
  LEmail: String;
  LSenha: String;
begin
  if FDQClientesContador.Isempty then
    exit;

  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select token, activation_token, ocp_apim_subscription_key, senha from cliente_smarttef where id_cli = :cod_cli');
    parambyname('cod_cli').asinteger := FDQClientesContadorcod_cli.asinteger;
    open;

    LToken := fieldbyname('token').asstring;
    LActivationToken := fieldbyname('activation_token').asstring;
    LOcpApimSubscriptionKey := fieldbyname('ocp_apim_subscription_key').asstring;
    LSenha := fieldbyname('senha').asstring;
  end;

  LEmail := FDQClientesContadoremail_cli.asstring.trim;

  if LOcpApimSubscriptionKey.trim.Isempty then
  begin
    Randomize;
    LSenha := GerarSenha;

    if not(InputQuery('E-mail do cliente', 'Informe o e-mail do cliente', LEmail)) then
      exit;

    if LEmail.trim.Isempty then
    begin
      showmessage('O cliente est� sem e-mail! Coloque um e-mail no cliente para poder continuar.');
      exit;
    end;

    try
      LCreateStoreResponse := TSmartTefIntegrator.New.CreateStore( //
        dm.RemoveChar(FDQClientesContadorCNPJ_CLI.asstring), //
        LEmail.trim, //
        LSenha, //
        FDQClientesContadorNOME_CLI.asstring.trim, //
        FDQClientesContadorNOME_FANTASIA.asstring.trim);

      try
        LToken := LCreateStoreResponse.Token;
        LActivationToken := LCreateStoreResponse.ActivationToken;
        LOcpApimSubscriptionKey := LCreateStoreResponse.OcpApimSubscriptionKey;
      finally
        FreeAndNil(LCreateStoreResponse);
      end;

      with FdQAux do
      begin
        Close;
        SQL.Clear;
        SQL.Add('INSERT INTO cliente_smarttef (id_cli, email, token, activation_token, ' +
          'ocp_apim_subscription_key, senha) VALUES(:cod_cli, :email, :token, :activation_token, ' +
          ':ocp_apim_subscription_key, :senha)');
        parambyname('cod_cli').asinteger := FDQClientesContadorcod_cli.asinteger;
        parambyname('email').asstring := LEmail.trim;
        parambyname('senha').asstring := LSenha.trim;
        parambyname('token').asstring := LToken;
        parambyname('activation_token').asstring := LActivationToken;
        parambyname('ocp_apim_subscription_key').asstring := LOcpApimSubscriptionKey;
        execsql;
      end;
    except
      on E: Exception do
      begin
        showmessage('Falha ao criar a loja e gerar os tokens do cliente no SmartTEF: ' + E.Message);
        exit;
      end;
    end;
  end;

  ClipBoard.AsText := 'Painel de acesso: https://commandsystem.smarttef.mobi' + sLineBreak +
    'E-mail: ' + LEmail.trim + sLineBreak + 'Senha: ' + LSenha.trim + sLineBreak + sLineBreak +
    'GW Token (Ocp-Apim-Subscription-Key): ' + LOcpApimSubscriptionKey;
  showmessage('O token foi obtido com sucesso! Basta dar um Ctrl + V para colar!');
end;

procedure TfrmMonitorClientes.CBBuscarDataAgendamentoClick(Sender: TObject);
begin
  if CBBuscarDataAgendamento.checked = true then
  begin
    etDataINIAtualizacao.enabled := true;
    etDataFinAtualizacao.enabled := true;
  end
  else
  begin
    etDataINIAtualizacao.enabled := False;
    etDataFinAtualizacao.enabled := False;
  end;
end;

procedure TfrmMonitorClientes.CbBuscarDataTarefaClick(Sender: TObject);
begin
  if CbBuscarDataTarefa.checked = true then
  begin
    edtiniAgendamentoTarefa.enabled := true;
    edtFinAgendamentoTarefa.enabled := true;
  end
  else
  begin
    edtiniAgendamentoTarefa.enabled := False;
    edtFinAgendamentoTarefa.enabled := False;
  end;
end;

procedure TfrmMonitorClientes.CGFiltroStatusMensalidadePropertiesChange(Sender: TObject);
begin
  if (CGFiltroStatusMensalidade.States[0] = cbsUnChecked) or

    (CGFiltroStatusMensalidade.States[1] = cbsUnChecked) or

    (CGFiltroStatusMensalidade.States[2] = cbsUnChecked) then
    checkTodos.checked := False
  else
    checkTodos.checked := true;
end;

procedure TfrmMonitorClientes.checkTodosClick(Sender: TObject);
begin
  if checkTodos.checked then
  begin
    CGFiltroStatusMensalidade.States[0] := cbsChecked;
    CGFiltroStatusMensalidade.States[1] := cbsChecked;
    CGFiltroStatusMensalidade.States[2] := cbsChecked;
  end;
end;

procedure TfrmMonitorClientes.Concluido1Click(Sender: TObject);
begin

  { Acesso de usu�rio }
  if ((dm.icodusu = 10) or (dm.icodusu = 15) or (dm.icodusu = 18)) then
  begin
    with FdQAux do
    begin

      Close;
      SQL.Clear;
      SQL.Add(' UPDATE cliente C ' +
        '  SET C.STATUS_INSTAL = 7     , DT_Aguard_instalacao = :Dt_concluido     ' +
        ' WHERE C.cod_cli = :cod_cli ');
      parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
      parambyname('Dt_concluido').asdatetime := date;
      execsql;
    end;
    if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
    begin
      Application.CreateForm(TFrmObservacao, FrmObservacao);
      FrmObservacao.tag := 2;
      FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
      FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
        QInstalacaoNOME_FANTASIA.asstring;
      // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

      FrmObservacao.ShowModal;
    end;

    BtnInstalacoes.Click;

  end
  else
  begin
    showmessage('Somente o setor de CS pode concluir um cliente, FALE COM O CS!!');

  end;

end;

procedure TfrmMonitorClientes.ContatodoclienteContatodocliente1Click(Sender: TObject);
begin
  Application.CreateForm(TFrmContatoCliente, FrmContatoCliente);
  FrmContatoCliente.tag := 2;
  FrmContatoCliente.edtCodcliContato.Text := QInstalacaocod_cli.asstring;
  FrmContatoCliente.edtNomeCliContato.Text := QInstalacaoNOME_CLI.asstring;
  FrmContatoCliente.ShowModal;
end;

procedure TfrmMonitorClientes.Contatoscliente1Click(Sender: TObject);
begin
  Application.CreateForm(TFrmContatoCliente, FrmContatoCliente);
  FrmContatoCliente.tag := 2;
  FrmContatoCliente.edtCodcliContato.Text := FDqDadosGeraisClicod_cli.asstring;
  FrmContatoCliente.edtNomeCliContato.Text := FDqDadosGeraisCliNOME_CLI.asstring;
  FrmContatoCliente.ShowModal;
end;

procedure TfrmMonitorClientes.Contatosdocliente1Click(Sender: TObject);
begin
  Application.CreateForm(TFrmContatoCliente, FrmContatoCliente);
  FrmContatoCliente.tag := 2;
  FrmContatoCliente.edtCodcliContato.Text := FDQProblemasCOD_CLI.asstring;
  FrmContatoCliente.edtNomeCliContato.Text := FDQProblemasNOME_CLI.asstring;
  FrmContatoCliente.ShowModal;
end;

procedure TfrmMonitorClientes.Contatosdocliente2Click(Sender: TObject);
begin
  Application.CreateForm(TFrmContatoCliente, FrmContatoCliente);
  FrmContatoCliente.tag := 2;
  FrmContatoCliente.edtCodcliContato.Text := QGerenciadorComissoesid_cliente.asstring;
  FrmContatoCliente.edtNomeCliContato.Text := QGerenciadorComissoesNOME_CLI.asstring;
  FrmContatoCliente.ShowModal;
end;

procedure TfrmMonitorClientes.Contatosdocliente3Click(Sender: TObject);
begin
  Application.CreateForm(TFrmContatoCliente, FrmContatoCliente);
  FrmContatoCliente.tag := 2;
  FrmContatoCliente.edtCodcliContato.Text := FDQClientesContadorcod_cli.asstring;
  FrmContatoCliente.edtNomeCliContato.Text := FDQClientesContadorNOME_CLI.asstring;
  FrmContatoCliente.ShowModal;

end;

procedure TfrmMonitorClientes.CopiarCelula1Click(Sender: TObject);
begin
  try
    ClipBoard.AsText := VarAsType(cxGridDBTableView5.DataController.Values
      [cxGridDBTableView5.DataController.FocusedRecordIndex,
      cxGridDBTableView5.Controller.FocusedColumn.Index], varString);
  except
  end;
end;

procedure TfrmMonitorClientes.CopiarClula1Click(Sender: TObject);
begin
  if pgDados.activepage = tabDadosGerais then
  begin
    dm.CopiarValorCelulaGrid(cxGDRDadosGeraisDBTableView1);
  end
  else if pgDados.activepage = TabAgendamentoAtualizacao then
  begin
    dm.CopiarValorCelulaGrid(GAgendamentoAtualizacaoDBTableView);
  end
  else if pgDados.activepage = TabCliExternos then
  begin
    dm.CopiarValorCelulaGrid(cxGRelExternosTableView1);
  end
  else if pgDados.activepage = TabNuvem then
  begin
    dm.CopiarValorCelulaGrid(GNuvemDBTableView);
  end
  else if pgDados.activepage = TabCurvaABC then
  begin
    dm.CopiarValorCelulaGrid(cxGCurvaABCDBTableView4);
  end;

end;

procedure TfrmMonitorClientes.Copiarclula2Click(Sender: TObject);
begin
  dm.CopiarValorCelulaGrid(cxGridDBTableViewprob);
end;

procedure TfrmMonitorClientes.CopiarClula3Click(Sender: TObject);
begin
  dm.CopiarValorCelulaGrid(GRelComissaoIndicadorDBTableView);
end;

procedure TfrmMonitorClientes.CriarAlterarAssinatura(DataSet: TDataSet; const AAlteracao: Boolean);
var
  Codigo: Integer;
begin
  if DataSet.Isempty then
    exit;

  if DataSet.fieldbyname('cod_cli').asinteger <= 0 then
    exit;

  // Verifica se o cliente ja tem plano definido
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select ca.id from cliente_planos ca where ca.id_cli = :id_cli');
    parambyname('id_cli').asinteger := DataSet.fieldbyname('cod_cli').asinteger;
    open;
  end;

  if FdQAux.fieldbyname('id').asinteger <= 0 then
  begin
    showmessage('Este cliente ainda n�o possui nenhum plano vinculado! Por favor, primeiro ' +
      'informe o plano de assinatura do cliente para depois gerar a chave de licen�a.');
    exit;
  end;

  AbrirTelaAssinaturaCliente(DataSet.fieldbyname('cod_cli').asinteger);
  BtnVerAssinaturasClick(BtnVerAssinaturas);

  DataSet.DisableControls;

  try
    Codigo := DataSet.fieldbyname('cod_cli').asinteger;
    btnVisContador.Click;

    DataSet.Locate('cod_cli', Codigo, []);
  finally
    DataSet.EnableControls;
  end;
end;

procedure TfrmMonitorClientes.FDClientesSemAtualizacaoInicialCalcFields(DataSet: TDataSet);
begin
  FDClientesSemAtualizacaoInicialTEMPO_CADASTRO.asstring :=
    dm.RetornaMesMaisAnoPorNumeroDias
    (DaysBetween(NOW, FDClientesSemAtualizacaoInicialDATACADASTRO_CLI.asdatetime));

end;

procedure TfrmMonitorClientes.FDQClientesCaixaCalcFields(DataSet: TDataSet);
begin
  if FDQClientesCaixaDATA_ULT_ENVIO_ARQ.asstring <> '' then
  BEGIN
    FDQClientesCaixadias_Ult_Envio_xml_cont.asstring :=
      INTTOSTR(DaysBetween(date, FDQClientesCaixaDATA_ULT_ENVIO_ARQ.asdatetime));
  END;

  if FDQClientesCaixaDATA_HORA_ULT_ENVIO_SAT.asstring <> '' then
  BEGIN
    FDQClientesCaixaDIAS_DT_ULT_CUPOM.asstring :=
      INTTOSTR(DaysBetween(date, FDQClientesCaixaDATA_HORA_ULT_ENVIO_SAT.asdatetime));
  END;

  if FDQClientesCaixaDATA_HORA_ULT_SEFAZ_SAT.asstring <> '' then
  BEGIN
    FDQClientesCaixaDIAS_ULT_ENVIO_SEFAZ.asstring :=
      INTTOSTR(DaysBetween(date, FDQClientesCaixaDATA_HORA_ULT_SEFAZ_SAT.asdatetime));
  END;

  if FDQClientesCaixaDATA_HORA_ULT_VENDA.asstring <> '' then
  BEGIN
    FDQClientesCaixaDIAS_ULT_VENDA.asstring :=
      INTTOSTR(DaysBetween(date, FDQClientesCaixaDATA_HORA_ULT_VENDA.asdatetime));
  END;

end;

procedure TfrmMonitorClientes.FDQClientesContadorCalcFields(DataSet: TDataSet);
begin

  if FDQClientesContadordif_mensalidade.ascurrency < 0 then
    FDQClientesContadorSTATUS_MENSALIDADE.asstring := 'ACIMA DA TABELA'
  else if FDQClientesContadordif_mensalidade.ascurrency = 0 then
    FDQClientesContadorSTATUS_MENSALIDADE.asstring := 'NA TABELA'
  else if FDQClientesContadordif_mensalidade.ascurrency > 0 then
    FDQClientesContadorSTATUS_MENSALIDADE.asstring := 'ABAIXO DA TABELA';

end;

procedure TfrmMonitorClientes.FDqDadosGeraisCliCalcFields(DataSet: TDataSet);
begin
  if FDqDadosGeraisCliDATA_ULT_FTP.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_ULT_FTP.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_ULT_FTP.asdatetime));
  END;

  if FDqDadosGeraisCliDATA_ULT_BACKUP.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_ULT_BACKUP.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_ULT_BACKUP.asdatetime));
  END;

  if FDqDadosGeraisCliDATA_ULT_ENT_NOTA.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_ULT_ENTRADA.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_ULT_ENT_NOTA.asdatetime));
  END;

  if FDqDadosGeraisCliDATA_HORA_ULT_NFE.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_ULT_NFE.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_HORA_ULT_NFE.asdatetime));
  END;

  if FDqDadosGeraisCliDATA_HORA_ULT_VENDA.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_ULT_VENDA.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_HORA_ULT_VENDA.asdatetime));
  END;

  if FDqDadosGeraisCliDATA_ULT_CUPOM.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_ULT_CUPOM.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_ULT_CUPOM.asdatetime));
  END;

  if FDqDadosGeraisCliDATA_SINCR_DADOS.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_ULT_SICRONIZACAO.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_SINCR_DADOS.asdatetime));
  END;

  if FDqDadosGeraisCliDATA_VAL_CERT_DIG.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_VENC_CERTIFICADO.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATA_VAL_CERT_DIG.asdatetime));
  END;

  if FDqDadosGeraisCliDATACADASTRO_CLI.asstring <> '' then
  BEGIN
    FDqDadosGeraisCliDIAS_DATA_CADASTRO.asstring :=
      INTTOSTR(DaysBetween(date, FDqDadosGeraisCliDATACADASTRO_CLI.asdatetime));
  END;
end;

procedure TfrmMonitorClientes.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  { dm.GravaIni('command.ini', 'ConfiguracaoLocal', 'frmMonitorClientes.NClientesMeta',
    EdtQtdMeta.text);
    dm.GravaIni('command.ini', 'ConfiguracaoLocal', 'frmMonitorClientes.TClientesMeta',
    EdtFatMeta.text); }
  dm.GravaIni('command.ini', 'ConfiguracaoLocal', 'frmMonitorClientes.EdtDataMeta',
    EdtDataMeta.Text);
  dm.GravaIni('command.ini', 'ConfiguracaoLocal', 'frmMonitorClientes.edtDataIniMeta',
    edtDataIniMeta.Text);

  dm.GravaIni('command.ini', 'ConfiguracaoLocal', 'frmMonitorClientes.RGStatusOP',
    INTTOSTR(RGStatusOP.itemindex));

  frmMonitorClientes := nil;
  Action := caFree;
end;

procedure TfrmMonitorClientes.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if Key = vk_escape then
  begin
    Close;
  end;

end;

procedure TfrmMonitorClientes.FormKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    SelectNext(ActiveControl, true, true);
  end;
end;

procedure TfrmMonitorClientes.FormShow(Sender: TObject);
var
  sAuxCod, sAuxDescricao: string;
begin
  if frmMonitorClientes.tag = 0 then
  begin
    pgDados.activepageindex := 0;
    PCGerenciamentoClientes.activepageindex := 0;
    PCAgendamentos.activepageindex := 0;
  end;

  etDataINIAtualizacao.date := startofthemonth(date);
  etDataFinAtualizacao.date := endofthemonth(date);
  edtiniAgendamentoTarefa.date := startofthemonth(date);
  edtFinAgendamentoTarefa.date := endofthemonth(date);

  FIdNuvem := 0;
  EdtDataIni.date := startofthemonth(date);
  EdtDataFin.date := endofthemonth(date);
  EdtDatainiComissao.date := StrToDate(datetostr(startofthemonth(date)));
  EdtDataFinComissao.date := StrToDate(datetostr(endofthemonth(date)));

  if (dm.icodusu = 1) or (dm.icodusu = 2) or (dm.icodusu = 3) or (dm.icodusu = 4) or
    (dm.icodusu = 5) or (dm.icodusu = 6) or (dm.icodusu = 7) or (dm.icodusu = 10) or
    (dm.icodusu = 18) or (dm.icodusu = 24) or (dm.icodusu = 26) then
  begin
    TabClientesExternos.tabvisible := true;
    TabMetaCommand.tabvisible := true;
    TabCurvaABC.tabvisible := true;
    GBDadosNuvem.visible := true;
    TabListNuvemSimples.tabvisible := true;
    TabListResumidaNuvem.tabvisible := true;
    TabMensalidadeDifCadastro.tabvisible := true;
    TabListNuvemSimples.tabvisible := False;
    TabListResumidaNuvem.tabvisible := true;
    TabListNuvemCompleta.tabvisible := true;
    TabCurvaABC.tabvisible := true;
  end
  else
  begin
    TabClientesExternos.tabvisible := False;
    TabMetaCommand.tabvisible := False;
    TabListNuvemSimples.tabvisible := true;
    TabListResumidaNuvem.tabvisible := False;
    TabListNuvemCompleta.tabvisible := False;
    TabCurvaABC.tabvisible := true;
    GBDadosNuvem.visible := False;
    TabMensalidadeDifCadastro.tabvisible := true;
    TabCurvaABC.tabvisible := False;
  end;

  { Carrega Grid Desenvolvimento }
  try
    cxGDRClientesArquivosGeradosDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName)
      + '/frmMonitorClientes.cxGDRClientesSemAtualizacoa.ini', true, False,
      [gsoUseFilter, gsoUseSummary]);
  except

  end;

  try
    cxGDRDadosGeraisDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName) +
      '/frmMonitorClientes.cxGDRDadosGerais.ini', true, False, [gsoUseFilter, gsoUseSummary]);
  except

  end;

  try
    cxGDRPDadosCaixaDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName) +
      '/frmMonitorClientes.cxGDRPDadosCaixa.ini', true, False, [gsoUseFilter, gsoUseSummary]);
  except

  end;

  try
    cxGridDBTableView1.RestoreFromIniFile(ExtractFilePath(Application.ExeName) +
      '/frmMonitorClientes.cxGQuebraSequencia.ini', true, False, [gsoUseFilter, gsoUseSummary]);
  except

  end;

  try
    cxGerenciadoInstalacoesDBTableView.RestoreFromIniFile(ExtractFilePath(Application.ExeName) +
      '/frmMonitorClientes.cxGerenciadoInstalacoes.ini', true, False,
      [gsoUseFilter, gsoUseSummary]);
  except

  end;

  try
    RGStatusOP.itemindex := strtoint(dm.LeIni('command.ini', 'ConfiguracaoLocal',
      'frmMonitorClientes.RGStatusOP'));
  except
    RGStatusOP.itemindex := 0;
  end;

  { Carrega  numero de clientes }
  { try
    EdtQtdMeta.text := dm.LeIni('command.ini', 'ConfiguracaoLocal',
    'frmMonitorClientes.NClientesMeta');
    except
    EdtQtdMeta.text := '300';
    end; }
  { if EdtQtdMeta.text = '' then
    begin
    EdtQtdMeta.text := '300';
    end; }

  if trim(EdtDataMeta.Text) = '' then
  begin
    {
      try
      EdtDataMeta.text := (dm.LeIni('command.ini', 'ConfiguracaoLocal',
      'frmMonitorClientes.EdtDataMeta'));
      except
      EdtDataMeta.text := ('30/06/2021');
      end;
      if trim(EdtDataMeta.text) = '' then
      begin
      EdtDataMeta.text := ('30/06/2021');
      end; }

  end;

  if trim(edtDataIniMeta.Text) = '' then
  begin

    { try
      edtDataIniMeta.text := (dm.LeIni('command.ini', 'ConfiguracaoLocal',
      'frmMonitorClientes.edtDataIniMeta'));
      except
      edtDataIniMeta.text := ('26/03/2021');
      end;
      if trim(edtDataIniMeta.text) = '' then
      begin
      edtDataIniMeta.text := ('26/03/2021');
      end; }

  end;

  { Carrega  numero de clientes }
  try
    { EdtFatMeta.text := dm.LeIni('command.ini', 'ConfiguracaoLocal',
      'frmMonitorClientes.TClientesMeta'); }
  except
    EdtFatMeta.Text := FormatFloat('#,##0.00', 65000);
  end;

  if EdtFatMeta.Text = '' then
  begin
    EdtFatMeta.Text := FormatFloat('#,##0.00', 65000);
  end;

  trim(dm.LeIni('command.ini', 'ConfiguracaoLocal', 'Usuario'));

  { busca contador }

  pnContatoCliente.Left := (frmMonitorClientes.ClientWidth div 2) - (pnContatoCliente.Width div 2);
  pnContatoCliente.Top := (frmMonitorClientes.ClientHeight div 2) - (pnContatoCliente.Height div 2);

  pnContador.Top := (frmMonitorClientes.ClientHeight div 2) - (pnContador.Height div 2);

  { busca dados financeiro }
  if ((dm.icod_GrupoUsu = 1) or (dm.icodusu = 10) or (dm.icodusu = 18) or (dm.icodusu = 26) or
    (dm.icodusu = 12) or (dm.icodusu = 24)) then
  begin
    tabGerenciamentoCli.tabvisible := true;
    TabMetaCommand.tabvisible := true;
  end
  else
  begin
    tabGerenciamentoCli.tabvisible := False;
    TabMetaCommand.tabvisible := False;
  end;

  { Busca dados Configuracoes }
  with dm.FDQConsulta do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT VALOR_PAGO_NUVEM,C.QTD_CLIENTES_META,DATA_INI_FOR_META,DATA_FIN_FOR_META,VALOR_FIN_FOR_META FROM  configuracoes c');
    open;
  end;
  cTotalpagoNuvem := dm.FDQConsulta.fieldbyname('VALOR_PAGO_NUVEM').ascurrency;
  EdtQtdMeta.Text := dm.FDQConsulta.fieldbyname('QTD_CLIENTES_META').asstring;
  EdtFatMeta.value := dm.FDQConsulta.fieldbyname('VALOR_FIN_FOR_META').ascurrency;
  EdtDataMeta.date := dm.FDQConsulta.fieldbyname('DATA_FIN_FOR_META').asdatetime;
end;

procedure TfrmMonitorClientes.G1Click(Sender: TObject);
begin
  Application.CreateForm(TFrmGeraAtendimento, FrmGeraAtendimento);
  FrmGeraAtendimento.tag := 2;
  FrmGeraAtendimento.edtCodcli.Text := FDQProblemasCOD_CLI.asstring;
  FrmGeraAtendimento.MObsAtendimento.lines.Add(FDQProblemasDESCRICAO_PROBLEMA.asstring);
  FrmGeraAtendimento.ShowModal;
end;

procedure TfrmMonitorClientes.G2Click(Sender: TObject);
begin
  // Verifica se o cliente ja tem plano definido
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select ca.id from cliente_planos ca where ca.id_cli = :id_cli');
    parambyname('id_cli').asinteger := FDQClientesContadorcod_cli.asinteger;
    open;
  end;

  if FdQAux.fieldbyname('id').asinteger <= 0 then
  begin
    showmessage('Este cliente ainda n�o possui nenhum plano vinculado! Por favor, primeiro ' +
      'informe o plano de assinatura do cliente para depois gerar a chave de licen�a.');

    AbrirTelaPlanoCliente;
  end;

  // Verifica novamente se o cliente ja tem plano definido
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add('select ca.id from cliente_planos ca where ca.id_cli = :id_cli');
    parambyname('id_cli').asinteger := FDQClientesContadorcod_cli.asinteger;
    open;
  end;

  if FdQAux.fieldbyname('id').asinteger <= 0 then
  begin
    showmessage('Este cliente ainda n�o possui nenhum plano vinculado! Por favor, primeiro ' +
      'informe o plano de assinatura do cliente para depois gerar a chave de licen�a.');
    exit;
  end;

  Application.CreateForm(TFrmGerarLicenca, FrmGerarLicenca);
  FrmGerarLicenca.ShowModal;
end;

procedure TfrmMonitorClientes.G3Click(Sender: TObject);
var
  Response: IResponse;
  JsonObj: TJSONObject;
  LCodigoVinculacao: String;
begin
  if FDQClientesContador.Isempty then
    exit;

  try
    Response := dm.ExecutarRequestAPICommand
      (TRequest.New.BaseURL('/clientes/' + dm.RemoveChar(FDQClientesContadorCNPJ_CLI.asstring) +
      '/codigoVinculacaoSat'), rmGET);

    JsonObj := TJSONObject.ParseJSONValue(TEncoding.UTF8.GetBytes(Response.Content), 0)
      as TJSONObject;

    try
      if not JsonObj.TryGetValue<String>('codigoVinculacao', LCodigoVinculacao) then
        showmessage('Nenhum c�digo de vincula��o SAT/MFE gerado!')
      else
      begin
        ClipBoard.AsText := LCodigoVinculacao;
        showmessage('C�digo de vincula��o copiado para �rea de transfer�ncia! (Ctrl + V)');
      end;
    finally
      FreeAndNil(JsonObj);
    end;
  except
    on E: Exception do
    begin
      showmessage('Falha ao gerar o c�digo de vincula��o SAT/MFE: ' + E.Message);
      exit;
    end;
  end;
end;

procedure TfrmMonitorClientes.G4Click(Sender: TObject);
var
  LJson: TJsonZ;
  LResponse: IResponse;
  LLink: String;
begin
  if FDQClientesContador.Isempty then
    exit;

  if MessageDlg('tem certeza que deseja gerar um contrato de software para este cliente?',
    mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    LResponse := dm.ExecutarRequestAPICommand
      (TRequest.New.BaseURL('/clientes/' + dm.RemoveChar(FDQClientesContador.fieldbyname('CNPJ_CLI')
      .asstring) + '/contratos/software'), rmPOST);

    LJson := TJsonZ.Create;

    try
      LJson.Parse(LResponse.Content);
      LLink := LJson['link'].asstring.trim;

      if LLink.Isempty then
        showmessage('Ocorreu uma falha ao gerar o contrato do cliente!')
      else
      begin
        ClipBoard.AsText := LLink;
        showmessage
          ('Contrato gerado com sucesso! O link encontra-se em sua �rea de transfer�ncia (Ctrl + V)!');
      end;
    finally
      FreeAndNil(LJson);
    end;
  end;
end;

procedure TfrmMonitorClientes.GAgendamentoAtualizacaoDBTableViewCustomDrawCell
  (Sender: TcxCustomGridTableView; ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo;
  var ADone: Boolean);
var
  Agend: String;
  Data: String;
begin
  Agend := '';
  Data := '';

  if not AViewInfo.Selected then
  begin
    if trim(MTAgendamentoAtualizacaoNOME_CLI.asstring) <> '' then
    begin
      { verifica se o index da grid � maior que 0 }
      if (AViewInfo.Item.Index >= 0) then
      begin
        try
          Agend := VarAsType(GAgendamentoAtualizacaoDBTableView.ViewData.Records
            [AViewInfo.GridRecord.Index].Values
            [GAgendamentoAtualizacaoDBTableViewrealizada_ult_agend.Index], varString);
        except
          Agend := '';
        end;

        try
          Data := VarAsType(GAgendamentoAtualizacaoDBTableView.ViewData.Records
            [AViewInfo.GridRecord.Index].Values
            [GAgendamentoAtualizacaoDBTableViewdata_hora_ult_agend.Index], varString);
        except
          Data := '';
        end;

        if (trim(Agend) = '0') and (trim(Data) <> '') then
        begin
          ACanvas.Font.Color := clwhite;
          ACanvas.Brush.Color := clNavy;
          ACanvas.Font.Style := [fsBold];
        end;

        { Verifica se ja foi atualizado }
        try
          Data := VarAsType(GAgendamentoAtualizacaoDBTableView.ViewData.Records
            [AViewInfo.GridRecord.Index].Values
            [GAgendamentoAtualizacaoDBTableViewdesc_realizada_ult_agend.Index], varString);
        except
          Data := '';
        end;

        if (trim(Data) = 'SIM') then
        begin
          ACanvas.Font.Color := clwhite;
          ACanvas.Brush.Color := clgreen;
          ACanvas.Font.Style := [fsBold];
        end;
      end;
    end;
  end;

  Agend := '';
  Data := '';
end;

procedure TfrmMonitorClientes.GAgendamentoAtualizacaoDBTableViewDblClick(Sender: TObject);
begin
  if MTAgendamentoAtualizacao.Isempty then
    exit;

  with MTAgendamentoAtualizacao do
  begin
    Edit;

    if fieldbyname('selec').asinteger = 1 then
      fieldbyname('selec').asinteger := 0
    else
      fieldbyname('selec').asinteger := 1;

    Post;
  end;
end;

procedure TfrmMonitorClientes.GAgendamentoAtualizacaoDBTableViewSELECPropertiesValidate
  (Sender: TObject; var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
begin
  if MTAgendamentoAtualizacao.Isempty then
    exit;

  if DisplayValue = 1 then
  begin
    if strtointdef(trim(copy(MTAgendamentoAtualizacaoversao_exe_connection.asstring, 1, 1)), 0) < 2
    then
    begin
      showmessage
        ('S� � poss�vel agendar uma atualiza��o se a vers�o do Connection for acima da 2.0.0.0!');

      MTAgendamentoAtualizacao.Edit;
      MTAgendamentoAtualizacaoSELEC.asinteger := 0;
      MTAgendamentoAtualizacao.Post;
    end;
  end;
end;

procedure TfrmMonitorClientes.GAssinaturasDBTableViewDblClick(Sender: TObject);
begin
  if not MTAssinaturas.Isempty then
    BtnAlterarAssinatura.Click;
end;

procedure TfrmMonitorClientes.GeraComissaoAgente;
  procedure ConfiguraCampoFMTBCD(const ACampo: string; const APrecision, ASize: Integer;
    const ADisplayFormat: string);
  begin
    if QComissaoAgente.FindField(ACampo) = nil then
      with TFMTBCDField.Create(QComissaoAgente) do
      begin
        FieldName := ACampo;
        Name := '';
        DataSet := QComissaoAgente;
        Precision := APrecision;
        Size := ASize;
        DisplayFormat := ADisplayFormat;
        EditFormat := ADisplayFormat;
      end;
  end;

  procedure ConfiguraColuna(const AFieldName, ACaption: string; const AWidth: Integer);
  var
    AColuna: TcxGridDBColumn;
  begin
    AColuna := cxGridDBTableView9.GetColumnByFieldName(AFieldName);
    if AColuna = nil then
    begin
      AColuna := cxGridDBTableView9.CreateColumn;
      AColuna.DataBinding.FieldName := AFieldName;
    end;

    AColuna.caption := ACaption;
    if AWidth > 0 then
      AColuna.Width := AWidth;
  end;

  procedure AdicionaTotalizador(const AFieldName, AFormat: string);
  var
    AItem: TcxGridDBTableSummaryItem;
  begin
    AItem := cxGridDBTableView9.DataController.Summary.FooterSummaryItems.Add as
      TcxGridDBTableSummaryItem;
    AItem.Kind := skSum;
    AItem.FieldName := AFieldName;
    AItem.Column := cxGridDBTableView9.GetColumnByFieldName(AFieldName);
    AItem.Format := AFormat;
  end;

begin
  with QComissaoAgente do
  begin
    Close;
    SQL.Clear;

    SQL.Add('SELECT ' + '    c.id_usuario, ' + '    c.NOME_USU, ' + '    c.id_certificadora, ' +
      '    c.descricao_certificadora, ' + '    c.valor_total_emitido_certificadora, ' +
      '    c.percentual_aplicado, ' +
      '    CAST((c.participacao_inicial * 100) AS DECIMAL(18,2)) AS percentual_usuario, ' +
      '    CAST(( ' + '        CASE ' + '            WHEN c.qtd_certificados_equipe = 0 THEN 0 ' +
      '            WHEN IFNULL(e.total_excedente, 0) = 0 THEN c.participacao_inicial ' +
      '            WHEN c.participacao_inicial > 0.6 THEN 0.6 + (IFNULL(e.total_excedente, 0) / NULLIF(e.qtd_usuarios, 0)) '
      + '            ELSE c.participacao_inicial + (IFNULL(e.total_excedente, 0) / NULLIF(e.qtd_usuarios, 0)) '
      + '        END) * 100 AS DECIMAL(18,2)) AS percentual_comissao_usuario, ' +
      '    CAST((c.valor_total_equipe * ' + '        CASE ' +
      '            WHEN c.qtd_certificados_equipe = 0 THEN 0 ' +
      '            WHEN IFNULL(e.total_excedente, 0) = 0 THEN c.participacao_inicial ' +
      '            WHEN c.participacao_inicial > 0.6 THEN 0.6 + (IFNULL(e.total_excedente, 0) / NULLIF(e.qtd_usuarios, 0)) '
      + '            ELSE c.participacao_inicial + (IFNULL(e.total_excedente, 0) / NULLIF(e.qtd_usuarios, 0)) '
      + '        END) AS DECIMAL(18,2)) AS base_calculo_comissao, ' +
      '    CAST(((c.valor_total_equipe * c.percentual_aplicado) * ' + '        CASE ' +
      '            WHEN c.qtd_certificados_equipe = 0 THEN 0 ' +
      '            WHEN IFNULL(e.total_excedente, 0) = 0 THEN c.participacao_inicial ' +
      '            WHEN c.participacao_inicial > 0.6 THEN 0.6 + (IFNULL(e.total_excedente, 0) / NULLIF(e.qtd_usuarios, 0)) '
      + '            ELSE c.participacao_inicial + (IFNULL(e.total_excedente, 0) / NULLIF(e.qtd_usuarios, 0)) '
      + '        END) AS DECIMAL(18,2)) AS valor_total_comissao, ' +
      '    c.qtd_certificados_individual, ' + '    c.qtd_certificados_equipe ' + 'FROM ( ' +
      '    SELECT ' + '        b.id_usuario, ' + '        b.NOME_USU, ' +
      '        b.id_certificadora, ' + '        b.descricao_certificadora, ' +
      '        b.qtd_certificados_individual, ' + '        t.qtd_certificados_equipe, ' +
      '        b.valor_total_emitido_certificadora, ' + '        t.valor_total_equipe, ' +
      '        CASE ' + '            WHEN t.qtd_certificados_equipe BETWEEN 0 AND 10 THEN 0 ' +
      '            WHEN t.qtd_certificados_equipe BETWEEN 11 AND 20 THEN 0.01 ' +
      '            WHEN t.qtd_certificados_equipe BETWEEN 21 AND 30 THEN 0.02 ' +
      '            WHEN t.qtd_certificados_equipe BETWEEN 31 AND 40 THEN 0.03 ' +
      '            WHEN t.qtd_certificados_equipe BETWEEN 41 AND 50 THEN 0.04 ' +
      '            WHEN t.qtd_certificados_equipe >= 51 THEN 0.05 ' + '            ELSE 0 ' +
      '        END AS percentual_aplicado, ' +
      '        CAST(b.qtd_certificados_individual AS DECIMAL(18,6)) / NULLIF(t.qtd_certificados_equipe, 0) AS participacao_inicial '
      + '    FROM ( ' + '        SELECT ' + '            U.COD_USU AS id_usuario, ' +
      '            U.NOME_USU, ' + '            I.id_certificadora, ' +
      '            ce.descricao_certificadora, ' +
      '            COUNT(I.id) AS qtd_certificados_individual, ' +
      '            SUM(I.valor) AS valor_total_emitido_certificadora ' +
      '        FROM indicacao_contador I ' +
      '        INNER JOIN usuario U ON U.COD_USU = I.id_usu_lanc ' +
      '        LEFT JOIN certificadora ce ON ce.id_certificadora = I.id_certificadora ' +
      '        WHERE I.data_indicacao BETWEEN :dataini AND :datafin ' +
      '          AND I.id_certificadora > 0 ' +
      '        GROUP BY U.COD_USU, U.NOME_USU, I.id_certificadora, ce.descricao_certificadora ' +
      '    ) b ' + '    INNER JOIN ( ' + '        SELECT ' + '            I.id_certificadora, ' +
      '            COUNT(I.id) AS qtd_certificados_equipe, ' +
      '            SUM(I.valor) AS valor_total_equipe ' + '        FROM indicacao_contador I ' +
      '        WHERE I.data_indicacao BETWEEN :dataini AND :datafin ' +
      '          AND I.id_certificadora > 0 ' + '        GROUP BY I.id_certificadora ' +
      '    ) t ON t.id_certificadora = b.id_certificadora ' + ') c ' + 'LEFT JOIN ( ' +
      '    SELECT ' + '        z.id_certificadora, ' +
      '        SUM(CASE WHEN z.participacao_inicial > 0.6 THEN z.participacao_inicial - 0.6 ELSE 0 END) AS total_excedente, '
      + '        COUNT(*) AS qtd_usuarios ' + '    FROM ( ' + '        SELECT ' +
      '            b.id_certificadora, ' +
      '            CAST(b.qtd_certificados_individual AS DECIMAL(18,6)) / NULLIF(t.qtd_certificados_equipe, 0) AS participacao_inicial '
      + '        FROM ( ' + '            SELECT ' + '                U.COD_USU AS id_usuario, ' +
      '                I.id_certificadora, ' +
      '                COUNT(I.id) AS qtd_certificados_individual ' +
      '            FROM indicacao_contador I ' +
      '            INNER JOIN usuario U ON U.COD_USU = I.id_usu_lanc ' +
      '            WHERE I.data_indicacao BETWEEN :dataini AND :datafin ' +
      '              AND I.id_certificadora > 0 ' +
      '            GROUP BY U.COD_USU, I.id_certificadora ' + '        ) b ' +
      '        INNER JOIN ( ' + '            SELECT ' + '                I.id_certificadora, ' +
      '                COUNT(I.id) AS qtd_certificados_equipe ' +
      '            FROM indicacao_contador I ' +
      '            WHERE I.data_indicacao BETWEEN :dataini AND :datafin ' +
      '              AND I.id_certificadora > 0 ' + '            GROUP BY I.id_certificadora ' +
      '        ) t ON t.id_certificadora = b.id_certificadora ' + '    ) z ' +
      '    GROUP BY z.id_certificadora ' + ') e ON e.id_certificadora = c.id_certificadora ' +
      'ORDER BY c.id_certificadora, c.NOME_USU');

    parambyname('dataini').asdatetime := TRUNC(EdtDatainiComissao.date);
    parambyname('datafin').asdatetime := TRUNC(EdtDataFinComissao.date) + 1;

    ConfiguraCampoFMTBCD('percentual_usuario', 18, 2, ',0.00');
    ConfiguraCampoFMTBCD('percentual_comissao_usuario', 18, 2, ',0.00');
    ConfiguraCampoFMTBCD('base_calculo_comissao', 18, 2, ',#0.00');

    open;

    ConfiguraColuna('NOME_USU', 'Usuario', 150);
    ConfiguraColuna('descricao_certificadora', 'Certificadora', 130);
    ConfiguraColuna('valor_total_emitido_certificadora', 'Valor Emitido Usuario', 170);
    ConfiguraColuna('percentual_aplicado', '% Comissao Equipe', 120);
    ConfiguraColuna('qtd_certificados_individual', 'Qtd Certificados Usuario', 135);
    ConfiguraColuna('qtd_certificados_equipe', 'Qtd Certificados Equipe', 135);
    ConfiguraColuna('percentual_usuario', '% Certificados', 95);
    ConfiguraColuna('percentual_comissao_usuario', '% Comissionavel', 115);
    ConfiguraColuna('base_calculo_comissao', 'Base Calculo Comissao', 150);
    ConfiguraColuna('valor_total_comissao', 'Valor Comissao', 120);

    cxGridDBTableView9.DataController.Summary.FooterSummaryItems.Clear;
    AdicionaTotalizador('valor_total_emitido_certificadora', ',#0.00');
    AdicionaTotalizador('qtd_certificados_individual', '#,##0');
    AdicionaTotalizador('base_calculo_comissao', ',#0.00');
    AdicionaTotalizador('valor_total_comissao', ',#0.00');
  end;
end;

procedure TfrmMonitorClientes.GeraqtdImndicacoesContador;
begin
  with QtdIndContador do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT   ' + '    CO.ID_CONTADOR,  ' + '    CO.DESCRICAO_ESCRITORIO,  ' +
      '   CO.NOME_RESP,  ' + '   CO.NOME_COMERCIAL,  ' + 'CO.CIDADE,  ' +
      '    COUNT(*) AS qtd_indicacoes,  ' + '    SUM(I.valor) AS total_valor,  ' +
      '    SUM(I.comissao_valor) AS total_comissao,  ' +
      '   (SUM(I.comissao_valor) / NULLIF(SUM(I.valor),0)) * 100   ' +
      '        AS percentual_comissao ' + 'FROM indicacao_contador I  ' +
      'INNER JOIN contador CO ON CO.ID_CONTADOR = I.id_contador ');

    SQL.Add(' and I.data_indicacao between :dataini and :Datafin ');
    parambyname('dataini').asstring := FormatDateTime('yyyy-mm-dd', EdtDatainiComissao.date);;
    parambyname('Datafin').asstring := FormatDateTime('yyyy-mm-dd', EdtDataFinComissao.date);

    SQL.Add(' GROUP BY  ' + '    CO.ID_CONTADOR, ' + '    CO.DESCRICAO_ESCRITORIO, ' +
      '    CO.NOME_RESP, ' + '    CO.NOME_COMERCIAL ' + 'ORDER BY qtd_indicacoes DESC; ');
    open;

  end;
end;

function TfrmMonitorClientes.GerarNomeSubdominio(const NomeCliente: string): string;
var
  I: Integer;
  Subdominio: string;
begin
  // Remove espa�os em branco no in�cio e fim e converte para min�sculas
  Subdominio := NomeCliente.trim.ToLower;

  // Remove acentos e caracteres especiais
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'a');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'e');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'i');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'o');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'u');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'c');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'a');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'o');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'e');
  Subdominio := AnsiReplaceStr(Subdominio, '�', 'o');

  // Remove caracteres inv�lidos (n�o letras ou d�gitos)
  for I := Length(Subdominio) downto 1 do
    if not(Subdominio[I] in ['a' .. 'z', '0' .. '9']) then
      Delete(Subdominio, I, 1);

  // Retorna o subdom�nio gerado
  Result := Subdominio;
end;

function TfrmMonitorClientes.GerarSenha: string;
  function SorteiaChar(const ATexto: string): Char;
  begin
    Result := ATexto[Random(Length(ATexto)) + 1];
  end;

  procedure Embaralhar(var ATexto: string);
  var
    I, J: Integer;
    Temp: Char;
  begin
    for I := Length(ATexto) downto 2 do
    begin
      J := Random(I) + 1;

      Temp := ATexto[I];
      ATexto[I] := ATexto[J];
      ATexto[J] := Temp;
    end;
  end;

const
  LETRAS_MAIUSCULAS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  LETRAS_MINUSCULAS = 'abcdefghijklmnopqrstuvwxyz';
  NUMEROS = '0123456789';
  SIMBOLOS = '!@#$%&*?';

var
  I: Integer;
begin
  Result := '';

  // Garante pelo menos 1 letra mai�scula e 1 min�scula
  Result := Result + SorteiaChar(LETRAS_MAIUSCULAS);
  Result := Result + SorteiaChar(LETRAS_MINUSCULAS);

  // Completa as 8 letras restantes
  for I := 1 to 6 do
  begin
    if Random(2) = 0 then
      Result := Result + SorteiaChar(LETRAS_MAIUSCULAS)
    else
      Result := Result + SorteiaChar(LETRAS_MINUSCULAS);
  end;

  // Adiciona 1 s�mbolo
  Result := Result + SorteiaChar(SIMBOLOS);

  // Adiciona 3 n�meros
  for I := 1 to 3 do
    Result := Result + SorteiaChar(NUMEROS);

  // Embaralha para n�o ficar sempre no mesmo padr�o
  Embaralhar(Result);
end;

procedure TfrmMonitorClientes.GNuvemDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  sdados: string;
begin
  if not AViewInfo.Selected then
  begin
    ACanvas.Font.Style := [fsBold];
    ACanvas.Font.Color := $00502F12;
  end
  else
  begin
    ACanvas.Font.Color := clwhite;
    ACanvas.Brush.Color := $00C15B00;
    ACanvas.Font.Style := [fsBold];
  end;

  if (AViewInfo.Item.Index = GNuvemDBTableViewESTOUROU_PLANO.Index) then
  begin
    try
      sdados := (VarAsType(GNuvemDBTableView.ViewData.Records[AViewInfo.GridRecord.Index].Values
        [GNuvemDBTableViewESTOUROU_PLANO.Index], varString));
    except
    end;

    if sdados = 'SIM' then
    BEGIN
      ACanvas.Brush.Color := CLRED;
      ACanvas.Font.Color := clwhite;
    END;

    if sdados = 'N�O' then
    BEGIN
      ACanvas.Brush.Color := clgreen;
      ACanvas.Font.Color := clwhite;
    END;

  end;

end;

procedure TfrmMonitorClientes.GPlanoDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  bAtivo: Boolean;
begin
  if not AViewInfo.Selected then
  begin
    if MTPlanosidAPI.asstring <> '' then
    begin
      if (AViewInfo.Item.Index >= 0) then
      begin
        try
          bAtivo := VarAsType(GPlanoDBTableView.ViewData.Records[AViewInfo.GridRecord.Index].Values
            [GPlanoDBTableViewativo.Index], varBoolean);
        except
          bAtivo := False;
        end;

        if not bAtivo then
          ACanvas.Font.Color := CLRED;
      end;
    end;
  end;
end;

procedure TfrmMonitorClientes.GPlanoDBTableViewDblClick(Sender: TObject);
begin
  if not MTPlanos.Isempty then
    BtnAlterarPlano.Click;
end;

procedure TfrmMonitorClientes.GRelComissaoIndicadorDBTableViewCustomDrawCell
  (Sender: TcxCustomGridTableView; ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo;
  var ADone: Boolean);
begin
  try
    if QGerenciadorComissoesid.asstring <> '' then
    begin
      if not AViewInfo.Selected then
      begin
        if (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewCALC_TIPO_COMISSAO.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewdata_indicacao.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewNOME_COMERCIAL.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewvalor.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewcomissao_valor.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewCALC_PERC_COMISSAO.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewNOME_FANTASIA.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewNOME_USU.Index) then
          ACanvas.Font.Style := [fsBold];
      end
      else
      begin
        ACanvas.Font.Color := clwhite;
        ACanvas.Brush.Color := $00502F12;

        if (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewCALC_TIPO_COMISSAO.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewdata_indicacao.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewNOME_COMERCIAL.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewvalor.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewcomissao_valor.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewCALC_PERC_COMISSAO.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewNOME_FANTASIA.Index) OR
          (AViewInfo.Item.Index = GRelComissaoIndicadorDBTableViewNOME_USU.Index) then
          ACanvas.Font.Style := [fsBold];
      end;
    end;
  except
  end;
end;

procedure TfrmMonitorClientes.GroupBox2MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContatoCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.GroupBox3MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContatoCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.GServidoresDBTableViewCustomDrawCell(Sender: TcxCustomGridTableView;
  ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
begin
  ACanvas.Font.Style := [fsBold];
end;

procedure TfrmMonitorClientes.GServidoresDBTableViewDblClick(Sender: TObject);
begin

  if QServidores.Isempty then
    exit;

  if MTServidoresSTATUS.asstring = 'OFFLINE' then
  begin
    showmessage('Esse servidor est� com o sistema de gerenciador offline.');
    exit;
  end;

  Application.CreateForm(TFrmConnections, FrmConnections);
  FrmConnections.dns := MTServidoresdns.asstring;
  FrmConnections.porta := MTServidoresporta_api_servidor.asstring;
  FrmConnections.ShowModal;
end;

procedure TfrmMonitorClientes.guardandooclienteparainstalao1Click(Sender: TObject);
begin
  with FdQAux do
  begin

    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 11, DT_Aguard_instalacao = :DT_Aguardandocliente_p_instal     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('DT_Aguardandocliente_p_instal').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.I1Click(Sender: TObject);
begin
  pnContatoCliente.visible := true;
  pnContatoCliente.bringtofront;
  pnlTClienteContato.caption := FDQConsClicod_cli.asstring + '-' + FDQConsCliNOME_FANTASIA.Text;
  MedtTelefone.Text := FDQConsCliTELRES_CLI.asstring;
  MeditCelular.Text := FDQConsCliCELULAR_CLI.asstring;
  edtCodcli.Text := FDQConsClicod_cli.asstring;
  if trim(edtCodcli.Text) <> '' then
    dm.BuscaContatoCli(strtoint(edtCodcli.Text));
end;

procedure TfrmMonitorClientes.I2Click(Sender: TObject);
begin
  IcodClienteContador := FDQClientesContadorcod_cli.asinteger;
  EdtNomeContadorCliente.Text := FDQClientesContadorNOME_COMERCIAL.asstring;
  EdtContadorCliente.Text := FDQClientesContadorID_CONTADOR.asstring;
  pnContador.visible := true;
  pnContador.bringtofront;
  pnContador.Left := (Self.Width - pnContador.Width) div 2;
  pnContador.Top := (Self.Height - pnContador.Height) div 2;
  pnTitContadorCli.caption := FDQClientesContadorcod_cli.asstring + '-' +
    FDQClientesContadorNOME_FANTASIA.Text;
  EdtCodCliContador.Text := FDQClientesContadorcod_cli.asstring;
  EdtNomeContadorCliente.setfocus;
  EdtNomeContadorClienteChange(Sender);
  // FDQClientesContador.EnableControls;
end;

procedure TfrmMonitorClientes.ImprimirDados1Click(Sender: TObject);
begin
  if pgDados.activepage = tabDadosGerais then
  begin
    dm.ImprimirDadosGrid(cxGDRDadosGerais, cxGDRDadosGeraisDBTableView1,
      'Relat�rio de cadastro de clientes');
  end
  else if pgDados.activepage = TabAgendamentoAtualizacao then
  begin
    dm.ImprimirDadosGrid(GAgendamentoAtualizacao, GAgendamentoAtualizacaoDBTableView,
      'Relat�rio de agendamento de clientes');
  end
  else if pgDados.activepage = TabClientesExternos then
  begin
    dm.ImprimirDadosGrid(GRelExternos, cxGRelExternosTableView1, 'Relat�rio de clientes externos');
  end
  else if pgDados.activepage = TabNuvem then
  begin
    dm.ImprimirDadosGrid(GNuvem, GNuvemDBTableView, 'Relat�rio de clientes nuvem');
  end
  else if pgDados.activepage = TabCurvaABC then
  begin
    dm.ImprimirDadosGrid(cxGCurvaABC, cxGCurvaABCDBTableView4,
      'Relat�rio de curva ABC dos clientes');
  end;

end;

procedure TfrmMonitorClientes.Imprimirdados2Click(Sender: TObject);
begin
  dm.ImprimirDadosGrid(cxGridPainelProb, cxGridDBTableViewprob,
    'Relat�rio de problemas de clientes');
end;

procedure TfrmMonitorClientes.Imprimirtela1Click(Sender: TObject);
begin
  dm.ImprimirDadosGrid(GRelComissaoIndicador, GRelComissaoIndicadorDBTableView,
    'Relat�rio do gerenciador de comiss�es');
end;

procedure TfrmMonitorClientes.InformarAlterarPlanoeMdulos1Click(Sender: TObject);
var
  Codigo: Integer;
begin
  if MTAssinaturas.Isempty then
    exit;

  if MTAssinaturasid_cli.asinteger <= 0 then
    exit;

  Application.CreateForm(TFrmPlanosCliente, FrmPlanosCliente);
  FrmPlanosCliente.iCodigoCliente := MTAssinaturasid_cli.asinteger;
  FrmPlanosCliente.sNomeCliente := MTAssinaturasNOME_FANTASIA.asstring;
  FrmPlanosCliente.sCNPJCliente := MTAssinaturasCNPJ_CLI.asstring;
  FrmPlanosCliente.EdtValorAssinatura.value := MTAssinaturasvalor_mensalidade.ascurrency;
  FrmPlanosCliente.ShowModal;

  BtnVerAssinaturasClick(BtnVerAssinaturas);

  MTAssinaturas.DisableControls;

  try
    Codigo := MTAssinaturasid.asinteger;
    btnVisContador.Click;

    MTAssinaturas.Locate('id', Codigo, []);
  finally
    MTAssinaturas.EnableControls;
  end;
end;

procedure TfrmMonitorClientes.InserePainelProblemas(icod_cli: Integer;
  sDescricao, sPastaBackup, sErrosBackup, sTipoProb: string);
begin
  { Insere painel de problemas }
  with FDQAux2 do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' INSERT INTO painel_problemas  ' +
      ' (COD_CLI, DESCRICAO_PROBLEMA,PASTA_BACKUP_FTP,ERROS_BACKUP,TIPO_ERRO)  ' + ' VALUES  ' +
      ' (:COD_CLI, :DESCRICAO_PROBLEMA,:PASTA_BACKUP_FTP,:ERROS_BACKUP,:TIPO_ERRO)     ');
    parambyname('COD_CLI').asinteger := icod_cli;
    parambyname('DESCRICAO_PROBLEMA').asstring := UpperCase(sDescricao);
    parambyname('PASTA_BACKUP_FTP').asstring := UpperCase(sPastaBackup);
    parambyname('ERROS_BACKUP').asstring := UpperCase(sErrosBackup);
    parambyname('TIPO_ERRO').asstring := UpperCase(sTipoProb);
    execsql;
  end;

end;

procedure TfrmMonitorClientes.InserirAlterarClientenaAsaas1Click(Sender: TObject);
begin
  if FDQClientesContador.Isempty then
    exit;

  try
    dm.ExecutarRequestAPICommand
      (TRequest.New.BaseURL('/clientes/' + dm.RemoveChar(FDQClientesContadorCNPJ_CLI.asstring) +
      '/registrarPlataformaCobranca'), rmPOST);
    showmessage('Cliente inserido/atualizado com sucesso!');
  except
    on E: Exception do
    begin
      showmessage('Falha ao inserir/atualizar o cliente na Asaas: ' + E.Message);
      exit;
    end;
  end;
end;

procedure TfrmMonitorClientes.LimpaContato;
begin
  edtNomeContatoCham.Clear;
  edtNumeroContatoCham.Clear;
  edtSetorContatoCham.Clear;
  edtEmailContatoCham.Clear;
  MedtTelefone.Clear;
  MeditCelular.Clear;

end;

procedure TfrmMonitorClientes.M1Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM dados_gerais_clientes  ' + '  WHERE COD_CLI =:COD_CLI      ' +
      ' AND cod_emp = :cod_emp      ' + ' AND PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP  ');
    parambyname('COD_CLI').asstring := FDqDadosGeraisClicod_cli.asstring;
    parambyname('cod_emp').asstring := FDqDadosGeraisClicod_emp.asstring;
    parambyname('PASTA_BACKUP_FTP').asstring := FDqDadosGeraisCliPASTA_BACKUP_FTP.asstring;
    execsql;
  end;

end;

procedure TfrmMonitorClientes.MarcarComoInformadoFinanceiro1Click(Sender: TObject);
begin
  { with dm.fdqinsert do
    begin
    CLOSE;
    sql.clear;
    sql.Add(' UPDATE cliente c  ' + ' SET c.Informado_financeiro = ' + #39 + ''
    + #39 + ' ' + ' WHERE c.cod_cli = :cod_cli  ');
    parambyname('COD_CLI').asstring := FDQConsClicod_cli.asstring;
    execsql;
    end;
    btnVersaoMinima.Click; }
end;

procedure TfrmMonitorClientes.MDadosAtendimentoMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(PnObsCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.MenuItem11Click(Sender: TObject);
begin
  dm.CopiarValorCelulaGrid(cxGerenciadoInstalacoesDBTableView);
end;

procedure TfrmMonitorClientes.MenuItem12Click(Sender: TObject);
begin
  dm.ExportarDadosGrid(cxGerenciadoInstalacoes);
end;

procedure TfrmMonitorClientes.MenuItem13Click(Sender: TObject);
begin
  dm.ImprimirDadosGrid(cxGDRDadosGerais, cxGDRDadosGeraisDBTableView1,
    'Relat�rio de implanta��o dos clientes');
end;

procedure TfrmMonitorClientes.MenuItem15Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' INSERT INTO grupo_clientes ' + ' (descricao)    ' + ' VALUES ' + ' (:descricao)  ');
    parambyname('descricao').asstring := '';
    execsql;
  end;
  BtnVisualizarNuvem.Click;
end;

procedure TfrmMonitorClientes.MenuItem19Click(Sender: TObject);
begin
  PnObsCliente.Left := (frmMonitorClientes.ClientWidth div 2) - (PnObsCliente.Width div 2);
  PnObsCliente.Top := (frmMonitorClientes.ClientHeight div 2) - (PnObsCliente.Height div 2);

  EdtCodCliObs.Text := FDClientesSemAtualizacaoInicialcod_cli.asstring;

  if dm.FDTAuxServer.Active then
    dm.FDTAuxServer.Commit;
  dm.FDTAuxServer.StartTransaction;

  with dm.FDQAuxServer do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT  ' + ' C.obs_cli           ' + ' FROM CLIENTE C       ' +
      ' WHERE C.cod_cli = :cod_cli');
    parambyname('COD_CLI').asstring := EdtCodCliObs.Text;
    open;
  end;
  MDadosAtendimento.Text := dm.FDQAuxServer.fieldbyname('obs_cli').asstring;
  dm.FDTAuxServer.Commit;
  pnTituloObs.caption := FDClientesSemAtualizacaoInicialcod_cli.asstring + ' ' +
    FDClientesSemAtualizacaoInicialNOME_FANTASIA.asstring;
  PnObsCliente.visible := true;
  PnObsCliente.bringtofront;
end;

procedure TfrmMonitorClientes.MenuItem1Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM clientes_caixas  ' + '  WHERE COD_CLI =:COD_CLI      ' +
      ' AND cod_emp = :cod_emp      ' + ' AND PASTA_BACKUP_FTP =:PASTA_BACKUP_FTP  ');
    parambyname('COD_CLI').asstring := FDQClientesCaixa.fieldbyname('cod_cli').asstring;
    parambyname('cod_emp').asstring := FDQClientesCaixa.fieldbyname('cod_emp').asstring;
    parambyname('PASTA_BACKUP_FTP').asstring := FDQClientesCaixa.fieldbyname
      ('PASTA_BACKUP_FTP').asstring;
    execsql;
  end;
  btnDadosCaixa.Click;
end;

procedure TfrmMonitorClientes.MenuItem20Click(Sender: TObject);
begin
  Application.CreateForm(TFrmGeraAtendimento, FrmGeraAtendimento);
  FrmGeraAtendimento.tag := 2;
  FrmGeraAtendimento.edtCodcli.Text := FDClientesSemAtualizacaoInicialcod_cli.asstring;
  FrmGeraAtendimento.MObsAtendimento.lines.Add('');
  FrmGeraAtendimento.MObsAtendimento.lines.Add(FDClientesSemAtualizacaoInicialOBS_CLI.asstring);
  FrmGeraAtendimento.MObsAtendimento.lines.Add('');
  FrmGeraAtendimento.MObsAtendimento.lines.Add(FDClientesSemAtualizacaoInicialOBS_VENDA.asstring);
  FrmGeraAtendimento.ShowModal;
end;

procedure TfrmMonitorClientes.MenuItem21Click(Sender: TObject);
begin
  Application.CreateForm(Tfrmagenda, frmagenda);
  frmagenda.tag := 2;
  frmagenda.edtCodcli.Text := FDClientesSemAtualizacaoInicialcod_cli.asstring;
  frmagenda.edtNomeCli.Text := FDClientesSemAtualizacaoInicialNOME_CLI.asstring;
  frmagenda.ShowModal;
end;

procedure TfrmMonitorClientes.MenuItem22Click(Sender: TObject);
begin
  Application.CreateForm(TFrmContatoCliente, FrmContatoCliente);
  FrmContatoCliente.tag := 2;
  FrmContatoCliente.edtCodcliContato.Text := FDClientesSemAtualizacaoInicialcod_cli.asstring;
  FrmContatoCliente.edtNomeCliContato.Text := FDClientesSemAtualizacaoInicialNOME_CLI.asstring;
  FrmContatoCliente.ShowModal;
end;

procedure TfrmMonitorClientes.MenuItem23Click(Sender: TObject);
begin
  if pgDados.activepage = TabNuvem then
  begin
    dm.CopiarValorCelulaGrid(GNuvemDBTableView);
  end;

end;

procedure TfrmMonitorClientes.MenuItem24Click(Sender: TObject);
begin
  if pgDados.activepage = TabNuvem then
  begin
    dm.ExportarDadosGrid(GNuvem);
  end;
end;

procedure TfrmMonitorClientes.MenuItem25Click(Sender: TObject);
begin
  if pgDados.activepage = TabNuvem then
  begin
    dm.ImprimirDadosGrid(GNuvem, GNuvemDBTableView, 'Relat�rio de clientes nuvem');
  end;
end;

procedure TfrmMonitorClientes.MenuItem2Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM clientes_cupom_quebra_seq   ' + '  WHERE COD_CLI =:COD_CLI      ' +
      ' AND cod_emp = :cod_emp      ' + ' AND PASTA_BACKUP_FTP =:PASTA_BACKUP_FTP  ');
    parambyname('COD_CLI').asstring := FDQCliQuebraSeq.fieldbyname('cod_cli').asstring;
    parambyname('cod_emp').asstring := FDQCliQuebraSeq.fieldbyname('cod_emp').asstring;
    parambyname('PASTA_BACKUP_FTP').asstring :=
      FDQCliQuebraSeq.fieldbyname('PASTA_BACKUP_FTP').asstring;
    execsql;
  end;
  btnQuebraSeq.Click;
end;

procedure TfrmMonitorClientes.MenuItem4Click(Sender: TObject);
begin
  if dm.FDTInsertFB.Active then
    dm.FDTInsertFB.Commit;
  dm.FDTInsertFB.StartTransaction;

  with dm.FDQInsertFB do
  begin
    Close;
    SQL.Clear;
    SQL.Add('delete from contatos c ' + ' where c.codigo = :codigo');
    parambyname('codigo').asinteger := dm.FDQContatoCliCODIGO.asinteger;
    execsql;
  end;
  dm.FDTInsertFB.Commit;
  LimpaContato;

  if trim(edtCodcli.Text) <> '' then
    dm.BuscaContatoCli(strtoint(edtCodcli.Text));
end;

procedure TfrmMonitorClientes.MenuItem5Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM dados_gerais_clientes  ' + '  WHERE COD_CLI =:COD_CLI      ' +
      ' AND cod_emp = :cod_emp      ' + ' AND PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP  ');
    parambyname('COD_CLI').asstring := MTCliSemVersMincod_cli.asstring;
    parambyname('cod_emp').asstring := MTCliSemVersMincod_emp.asstring;
    parambyname('PASTA_BACKUP_FTP').asstring := MTCliSemVersMinpasta_backup_ftp.asstring;
    execsql;
  end;
  BtnVisualizarCliVersMin.Click;
end;

procedure TfrmMonitorClientes.MenuItem8Click(Sender: TObject);
var
  versao: Integer;
begin
  if FDQCliArquivosGerados.Isempty then
    exit;

  Application.CreateForm(TFrmAgendamentoTarefa, FrmAgendamentoTarefa);
  FrmAgendamentoTarefa.tag := 4;
  with FrmAgendamentoTarefa do
  begin
    CodigoCliente := FDQCliArquivosGeradoscod_cli.asinteger;
    NomeCliente := trim(FDQCliArquivosGeradosNOME_FANTASIA.asstring);
    CodigoEmpresa := FDQCliArquivosGeradoscod_emp.asinteger;
    PASTABACKUPFTP := trim(FDQCliArquivosGeradosPASTA_BACKUP_FTP.asstring);
  end;

  FrmAgendamentoTarefa.ShowModal;
end;

procedure TfrmMonitorClientes.Observaocliente1Click(Sender: TObject);
begin
  PnObsCliente.Left := (frmMonitorClientes.ClientWidth div 2) - (PnObsCliente.Width div 2);
  PnObsCliente.Top := (frmMonitorClientes.ClientHeight div 2) - (PnObsCliente.Height div 2);

  EdtCodCliObs.Text := FDQProblemasCOD_CLI.asstring;

  if dm.FDTAuxServer.Active then
    dm.FDTAuxServer.Commit;
  dm.FDTAuxServer.StartTransaction;

  with dm.FDQAuxServer do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT  ' + ' C.obs_cli           ' + ' FROM CLIENTE C       ' +
      ' WHERE C.cod_cli = :cod_cli');
    parambyname('COD_CLI').asstring := EdtCodCliObs.Text;
    open;
  end;
  MDadosAtendimento.Text := dm.FDQAuxServer.fieldbyname('obs_cli').asstring;
  dm.FDTAuxServer.Commit;
  pnTituloObs.caption := FDQProblemasCOD_CLI.asstring + ' ' + FDQProblemasNOME_FANTASIA.asstring;

  PnObsCliente.visible := true;
  PnObsCliente.bringtofront;
end;

procedure TfrmMonitorClientes.P1Click(Sender: TObject);
begin
  { P�s venda }
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL =  9    , DT_Aguard_instalacao = :Dt_pos_venda     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_pos_venda').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.P2Click(Sender: TObject);
var
  Codigo: Integer;
begin
  if FDQClientesContador.Isempty then
    exit;

  if FDQClientesContadorcod_cli.asinteger <= 0 then
    exit;

  AbrirTelaPlanoCliente;

  FDQClientesContador.DisableControls;

  try
    Codigo := FDQClientesContadorcod_cli.asinteger;
    btnVisContador.Click;

    FDQClientesContador.Locate('cod_cli', Codigo, []);
  finally
    FDQClientesContador.EnableControls;
    CriarAlterarAssinatura(FDQClientesContador);
  end;
end;

procedure TfrmMonitorClientes.paEnter(Sender: TObject);
begin
  btnListagemContadores.Click;
  BtnVisualizarAgenda.Click;
end;

procedure TfrmMonitorClientes.pnTitContadorCliMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContador.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.PopupPlanosPopup(Sender: TObject);
begin
  if MTPlanos.Isempty then
    exit;

  D1.caption := IfThen(MTPlanosativo.asboolean, 'Desativar este plano', 'Ativar este plano');
end;

procedure TfrmMonitorClientes.Primeirotreinamento1Click(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 13  , DT_Aguard_instalacao = :DT_prim_treinamento     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('DT_prim_treinamento').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.QGerenciadorComissoesCalcFields(DataSet: TDataSet);
begin
  if QGerenciadorComissoestipo.asstring = '0' then
    QGerenciadorComissoesCALC_TIPO_COMISSAO.asstring := 'CERTIFICADO'
  ELSE
    QGerenciadorComissoesCALC_TIPO_COMISSAO.asstring := 'SISTEMA';

  if (QGerenciadorComissoesvalor.ascurrency > 0) and
    (QGerenciadorComissoescomissao_valor.ascurrency > 0) then
  begin
    QGerenciadorComissoesCALC_PERC_COMISSAO.ascurrency :=
      (QGerenciadorComissoescomissao_valor.ascurrency /
      QGerenciadorComissoesvalor.ascurrency) * 100;
  end
  else
  begin
    QGerenciadorComissoesCALC_PERC_COMISSAO.ascurrency := 0;
  end;
end;

procedure TfrmMonitorClientes.QInstalacaoCalcFields(DataSet: TDataSet);
begin
  // ? C�lculo do tempo desde o cadastro
  if not QInstalacaoDATACADASTRO_CLI.IsNull then
    QInstalacaoTEMPO_CADASTRO.asstring := dm.RetornaMesMaisAnoPorNumeroDias
      (DaysBetween(NOW, QInstalacaoDATACADASTRO_CLI.asdatetime))
  else
    QInstalacaoTEMPO_CADASTRO.asstring := 'Data n�o informada';

  try
    // ? C�lculo do tempo desde a �ltima venda
    if (trim(QInstalacaoULTIMA_VENDA.asstring) <> '') and
      (not SameText(trim(QInstalacaoULTIMA_VENDA.asstring), '01/01/2000')) and
      (not SameText(trim(QInstalacaoULTIMA_VENDA.asstring), '2000-01-01 00:00:00')) and
      (not QInstalacaoULTIMA_VENDA.IsNull) then
    begin
      QInstalacaoTEMPO_ULT_VENDA.asstring := dm.RetornaMesMaisAnoPorNumeroDias
        (DaysBetween(NOW, QInstalacaoULTIMA_VENDA.asdatetime));
    end
    else
      QInstalacaoTEMPO_ULT_VENDA.asstring := 'Nunca vendeu';
  except
    QInstalacaoTEMPO_ULT_VENDA.asstring := 'Nunca vendeu';
  end;

  // ? Descri��o textual do status da instala��o
  case QInstalacaoSTATUS_INSTAL.asinteger of
    0, 1:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'AGUARDANDO INSTALA��O';
    2:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'EM INSTALA��O';
    3:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'AGENDAR TREINAMENTO';
    4:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'REAGENDAR TREINAMENTO';
    5:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'TREINAMENTO CONCLU�DO';
    6:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'RETORNO';
    7:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'CONCLU�DO';
    8:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'TESTE DEMONSTRA��O';
    9:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'P�S-VENDA';
    10:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'DESIST�NCIA';
    11:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'AGUARDANDO CLIENTE PARA INSTALA��O';
    12:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'AGUARDANDO MIGRA��O';
    13:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'PRIMEIRO TREINAMENTO';
    14:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'SEGUNDO TREINAMENTO';
    15:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'EM MIGRA��O';
    16:
      QInstalacaoCALC_STATUS_INSTAL.asstring := 'AGUARDANDO CONFER�NCIA MIGRA��O';
  else
    QInstalacaoCALC_STATUS_INSTAL.asstring := 'STATUS DESCONHECIDO';
  end;

end;

procedure TfrmMonitorClientes.QNuvemCalcFields(DataSet: TDataSet);

begin
  if (QNuvemid_plano_nuvem.asinteger <= 0) AND (QNuvemtamanho.asinteger > 0) then
    QNuvemESTOUROU_PLANO.asstring := 'SEM PLANO'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 7) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 300) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 36) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 400) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 37) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 500) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 9) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 600) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 38) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 700) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 39) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 800) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 40) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 900) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 41) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1000) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 42) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1100) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 43) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1200) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 44) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1300) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 45) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1400) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 46) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1500) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 47) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1600) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 48) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1700) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 49) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1800) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 50) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 1900) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 51) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2000) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 13) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2100) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 14) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2200) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 52) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2300) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 53) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2400) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 54) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2500) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 55) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2600) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 56) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2700) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 57) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2800) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 58) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 2900) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 59) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3000) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 60) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3100) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 61) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3200) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 62) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3300) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 63) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3400) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 64) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3500) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 65) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3600) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 66) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3700) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 67) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3800) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 68) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 3900) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 69) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4000) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 70) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4100) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 71) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4200) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 72) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4300) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 73) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4400) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 74) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4500) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 75) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4600) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 76) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4700) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 77) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4800) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 78) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 4900) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  ELSE if (QNuvemid_plano_nuvem.asinteger = 79) AND (QNuvemtamanho.asinteger > 0) AND
    (QNuvemtamanho.asinteger <= 5000) then
    QNuvemESTOUROU_PLANO.asstring := 'N�O'
  else
    QNuvemESTOUROU_PLANO.asstring := 'SIM';

  {

    IF (QNuvemvalor_pago_nuvem.ascurrency < 15) then
    QNuvemCALC_PLANO_ATUAL.asstring := 'SEM PLANO'
    ELSE IF (QNuvemvalor_pago_nuvem.ascurrency <= 30) and (QNuvemvalor_pago_nuvem.ascurrency >= 15) then
    QNuvemCALC_PLANO_ATUAL.asstring := '0MB A 300MB 29,90'
    else if (QNuvemvalor_pago_nuvem.ascurrency > 30) and (QNuvemvalor_pago_nuvem.ascurrency <= 60) then
    QNuvemCALC_PLANO_ATUAL.asstring := '300MB A 600MB 59,90'
    else if (QNuvemvalor_pago_nuvem.ascurrency > 60) and (QNuvemvalor_pago_nuvem.ascurrency <= 100) then
    QNuvemCALC_PLANO_ATUAL.asstring := '600MB A 1GB 99,90'
    else if (QNuvemvalor_pago_nuvem.ascurrency > 60) and (QNuvemvalor_pago_nuvem.ascurrency <= 100) then
    QNuvemCALC_PLANO_ATUAL.asstring := '1GB A 2GB 149,90'
    else if (QNuvemvalor_pago_nuvem.ascurrency > 60) and (QNuvemvalor_pago_nuvem.ascurrency <= 100) then
    QNuvemCALC_PLANO_ATUAL.asstring := '2GB A 3GB 199,90';

    if (QNuvemCALC_PLANO_ATUAL.asstring = 'SEM PLANO') AND (QNuvemtamanho.asinteger > 300) then
    QNuvemESTOUROU_PLANO.asstring := 'SIM'
    else if (QNuvemCALC_PLANO_ATUAL.asstring = '0MB A 300MB 29,90') AND (QNuvemtamanho.asinteger > 300) then
    QNuvemESTOUROU_PLANO.asstring := 'SIM'
    else if (QNuvemCALC_PLANO_ATUAL.asstring = '300MB A 600MB 59,90') AND (QNuvemtamanho.asinteger > 600) then
    QNuvemESTOUROU_PLANO.asstring := 'SIM'
    else if (QNuvemCALC_PLANO_ATUAL.asstring = '600MB A 1GB 99,90') AND (QNuvemtamanho.asinteger > 1000) then
    QNuvemESTOUROU_PLANO.asstring := 'SIM'
    else if (QNuvemCALC_PLANO_ATUAL.asstring = '1GB A 2GB 149,90') AND (QNuvemtamanho.asinteger > 2000) then
    QNuvemESTOUROU_PLANO.asstring := 'SIM'
    else if (QNuvemCALC_PLANO_ATUAL.asstring = '2GB A 3GB 199,90') AND (QNuvemtamanho.asinteger > 3000) then
    QNuvemESTOUROU_PLANO.asstring := 'SIM'
    else
    QNuvemESTOUROU_PLANO.asstring := 'N�O'; }
  // QNuvemESTOUROU_PLANO.ASSTRING :=
end;

procedure TfrmMonitorClientes.QrelABCCalcFields(DataSet: TDataSet);
begin
  if QrelABCmensalidade_venda.ascurrency > 1 then
  begin
    QrelABCCALC_PERC_LUCRO.ascurrency :=
      (QrelABCLucro.ascurrency / QrelABCmensalidade_venda.ascurrency) * 100;

  end
  else
  begin
    QrelABCCALC_PERC_LUCRO.ascurrency := 0;
  end;
  if QrelABCmensalidade_custo.ascurrency > 1 then
  begin
    QrelABCCALC_MENSALIDADE_IDEAL.ascurrency := QrelABCmensalidade_custo.ascurrency / 0.3;
    if QrelABCCALC_MENSALIDADE_IDEAL.ascurrency > QrelABCmensalidade_venda.ascurrency then
    begin
      QrelABCDEFICIT.ascurrency := QrelABCCALC_MENSALIDADE_IDEAL.ascurrency -
        QrelABCmensalidade_venda.ascurrency;
    end
    else
    begin
      QrelABCDEFICIT.ascurrency := 0;
    end;

  end
  else
  begin
    QrelABCCALC_MENSALIDADE_IDEAL.ascurrency := QrelABCmensalidade_venda.ascurrency;

  end;

end;

procedure TfrmMonitorClientes.pnTituloObsMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(PnObsCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.popInfContadorPopup(Sender: TObject);
begin
  mniAlternarVersaoBeta.Enabled := not FDQClientesContador.IsEmpty;

  if mniAlternarVersaoBeta.Enabled and
    (FDQClientesContadorUSAR_VERSAO_BETA.AsInteger = 1) then
    mniAlternarVersaoBeta.Caption := 'Retirar cliente do beta'
  else
    mniAlternarVersaoBeta.Caption := 'Colocar cliente em beta';

  if FDQClientesContadorreceber_carne_impresso.asstring.trim.Equals('S') then
  begin
    c5.caption := 'Cliente N�O DESEJA RECEBER o carn� da assinatura impresso';
    c5.tag := 1;
  end
  else
  begin
    c5.caption := 'Cliente DESEJA RECEBER o carn� da assinatura impresso';
    c5.tag := 0;
  end;
end;

procedure TfrmMonitorClientes.Panel32MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContatoCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.pnContadorMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContador.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.pnContatoClienteMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContatoCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.pnlTClienteContatoMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(pnContatoCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.PnObsClienteMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  PostMessage(PnObsCliente.Handle, WM_SYSCOMMAND, $F012, 0);
end;

procedure TfrmMonitorClientes.pgDadosChange(Sender: TObject);
begin
  { BUSCA CLIENTES SEM ATUALIZACAO }
  { WITH FDQCliArquivosGerados do
    begin
    CLOSE;
    sql.clear;
    sql.Add(' SELECT cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI,CIDRES_CLI,P.descricao FROM cliente c   '
    + '  INNER JOIN ponto_revenda P       ' +
    ' ON P.cod_ponto= c.cod_ponto_revenda   ' + ' WHERE c.ATIVO =  ' + #39 +
    'S' + #39 + ' ' + ' AND c.CNPJ_CLI   not LIKE ' + #39 + '% .   .   - %' +
    #39 + ' ' + '  ' + ' AND c.cod_cli NOT IN ' +
    ' (SELECT cod_cli  FROM dados_gerais_clientes d )  and ( c.cod_cli <> 1 and c.cod_cli <> 0 and c.cod_cli <> 7 '
    + ' AND  c.cod_cli <> 8 AND  c.cod_cli <> 6 )  ');
    open;
    end; }
end;

procedure TfrmMonitorClientes.R1Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM dados_gerais_clientes  ' + '  WHERE COD_CLI =:COD_CLI      ' +
      ' AND cod_emp = :cod_emp      ' + ' AND PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP  ');
    parambyname('COD_CLI').asstring := FDqDadosGeraisClicod_cli.asstring;
    parambyname('cod_emp').asstring := FDqDadosGeraisClicod_emp.asstring;
    parambyname('PASTA_BACKUP_FTP').asstring := FDqDadosGeraisCliPASTA_BACKUP_FTP.asstring;
    execsql;
  end;
  // btnDadosGerais.Click;
end;

procedure TfrmMonitorClientes.R2Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM contador_cliente      ' + ' WHERE COD_CONTADOR = :COD_CONTADOR  ' +
      ' AND COD_CLIENTE = :COD_CLIENTE   ');
    parambyname('COD_CONTADOR').asinteger := FDQClientesContadorID_CONTADOR.asinteger;
    parambyname('COD_CLIENTE').asinteger := FDQClientesContadorcod_cli.asinteger;
    execsql;
  end;
  // btnVisContador.Click;
end;

procedure TfrmMonitorClientes.R3Click(Sender: TObject);
begin
  with dm.fdqinsert do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' DELETE FROM dados_gerais_clientes  ' + '  WHERE COD_CLI =:COD_CLI      ' +
      ' AND cod_emp = :cod_emp      ' + ' AND PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP  ');
    parambyname('COD_CLI').asstring := FDQProblemasCOD_CLI.asstring;
    parambyname('cod_emp').asstring := FDQProblemascod_emp.asstring;
    parambyname('PASTA_BACKUP_FTP').asstring := FDQProblemasPASTA_BACKUP_FTP.asstring;
    execsql;
  end;
  // btnGeraProblemas.Click;
end;

procedure TfrmMonitorClientes.R4Click(Sender: TObject);
begin
  if MessageDlg('tem certeza que deseja remover as licen�as dos softwares deste cliente?',
    mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    with FdQAux do
    begin
      Close;
      SQL.Clear;
      SQL.Text := 'DELETE FROM licencas WHERE cnpj = :cnpj';
      parambyname('cnpj').asstring := trim(FDQClientesContadorCNPJ_CLI.asstring);
      execsql;
    end;
  end;
end;

procedure TfrmMonitorClientes.R5Click(Sender: TObject);
begin
  RemoverAssinatura(FDQClientesContador);
end;

procedure TfrmMonitorClientes.R7Click(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 4   , DT_Aguard_instalacao = :Dt_reagendar_Treinamento     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_reagendar_Treinamento').asdatetime := date;
    execsql;

  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

function TfrmMonitorClientes.RemoveChar(const Texto: string): string;
var
  I: Integer;
  S: string;
begin
  S := '';

  for I := 1 to Length(Texto) do
  begin
    if (CharInSet(Texto[I], ['0' .. '9'])) then
    begin
      S := S + copy(Texto, I);
    end;
  end;

  Result := S;
end;

procedure TfrmMonitorClientes.RemoverAssinatura(DataSet: TDataSet);
begin
  if DataSet.Isempty then
    exit;

  if MessageDlg('tem certeza que deseja remover a assinatura deste cliente?', mtConfirmation,
    [mbYes, mbNo], 0) = mrYes then
  begin
    dm.ExecutarRequestAPICommand(TRequest.New.BaseURL('/assinaturas/' +
      dm.RemoveChar(DataSet.fieldbyname('CNPJ_CLI').asstring)), rmDELETE);

    if not MTAssinaturas.Isempty then
      BtnVerAssinaturasClick(BtnVerAssinaturas);

    showmessage('Assinatura removida com sucesso!');
  end;
end;

procedure TfrmMonitorClientes.Retorno1Click(Sender: TObject);
begin
  with FdQAux do
  begin

    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 6   , DT_Aguard_instalacao = :Dt_retorno_cs     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_retorno_cs').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;

end;

procedure TfrmMonitorClientes.Segundotreinamento1Click(Sender: TObject);
begin
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 14   , DT_Aguard_instalacao = :Dt_Seg_treinamento     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_Seg_treinamento').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.T1Click(Sender: TObject);
begin
  with FdQAux do
  begin

    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 5   , DT_Aguard_instalacao = :Dt_treinamento_concluido     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('Dt_treinamento_concluido').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.T2Click(Sender: TObject);
begin
  { teste demostra��o }
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' UPDATE cliente C ' +
      '  SET C.STATUS_INSTAL = 8, DT_Aguard_instalacao = :DT_Teste_demo     ' +
      ' WHERE C.cod_cli = :cod_cli ');
    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
    parambyname('DT_Teste_demo').asdatetime := date;
    execsql;
  end;
  if ((QInstalacaocod_cli.asinteger > 0) and (QInstalacaocod_cli.asinteger <> 1)) then
  begin
    Application.CreateForm(TFrmObservacao, FrmObservacao);
    FrmObservacao.tag := 2;
    FrmObservacao.edtCodcli.Text := QInstalacaocod_cli.asstring;
    FrmObservacao.PnCliente.caption := QInstalacaocod_cli.asstring + ' - ' +
      QInstalacaoNOME_FANTASIA.asstring;
    // FrmObservacao.MemoObs.Text := QInstalacaoOBS_VENDA.asstring;

    FrmObservacao.ShowModal;
  end;

  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.TabAgendamentoEnter(Sender: TObject);
begin
  BtnVisualizarAgendamentoAtualizacao.Click;
end;

procedure TfrmMonitorClientes.TabAgendamentoTarefasEnter(Sender: TObject);
begin
  BtnVisualizarTarefas.Click;
end;

procedure TfrmMonitorClientes.TabClientesExternosEnter(Sender: TObject);
begin
  btnVisCertExterno.Click;
end;

procedure TfrmMonitorClientes.tabDadosGeraisEnter(Sender: TObject);
begin
  btnDadosGerais.Click;
end;

procedure TfrmMonitorClientes.TabSheet19Enter(Sender: TObject);
begin
  btnListagemContadores.Click;
end;

procedure TfrmMonitorClientes.TabSheet1Enter(Sender: TObject);
begin
  btnQuebraSeq.Click;
end;

procedure TfrmMonitorClientes.TabSheet20Enter(Sender: TObject);
begin
  btnClientesSemAtualizacao.Click;
end;

procedure TfrmMonitorClientes.tsClientesOnlineEnter(Sender: TObject);
begin
  btnVisualizar.Click;
end;

procedure TfrmMonitorClientes.tsDadosCaixasEnter(Sender: TObject);
begin
  btnDadosCaixa.Click;
end;

procedure TfrmMonitorClientes.tsTabClieSemAtualizacaoEnter(Sender: TObject);
begin
  btnVisGrid.Click;
end;

procedure TfrmMonitorClientes.VerificaoutrosDadosClienteAtendimento(icodclicons: Integer;
  PASTABACKUPFTP, SNaoGeraMovFiscal, SNaoVerificaBackup: string);
var
  iDiasBackup, iDiasFtp, iDiasVendas, iDiasSemComunicacao, iDiasCupom, iDiasNFE, iDiasPDC,
    iDiasUltSiocronizacao, iDiasCertificadoDigital: Integer;
  bModuloDesconectado, BPodeEscrever: Boolean;
  sMesAtual: string;
begin
  BPodeEscrever := true;
  iDiasBackup := 0;
  iDiasFtp := 0;
  iDiasVendas := 0;
  iDiasCupom := 0;
  iDiasNFE := 0;
  iDiasPDC := 0;
  iDiasCertificadoDigital := 0;
  iDiasUltSiocronizacao := 0;
  iDiasSemComunicacao := 0;

  { verifica se o cliente est� fazendo backup }
  PNStatus.visible := true;
  PNStatus.caption := ' Verifica se o cliente est� fazendo backup ';
  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add('  SELECT d.DATA_ULT_FTP,d.DATA_ULT_BACKUP,d.DATA_HORA_ULT_VENDA,d.VERSAO,DATA_SINCR_DADOS,  '
      + ' d.DATA_VAL_CERT_DIG,erro_backup,d.DATA_ULT_CUPOM,PASTA_BACKUP_FTP,DATA_HORA_ULT_NFE,DATA_ULT_SINC_PDC,  '
      + ' CC.COD_CONTADOR,d.dados_adm, TIPO_DOC_FISCAL_EMP,  mes_mov_fiscal,ano_mov_fiscal, ' +
      ' DIA_GERACAO_PROG,enviado_email_mov_fiscal,inconsistencias_mov_fiscal,data_hora_ultimo_mov_fiscal,enviado_email_mov_fiscal,Nao_gera_arquivos_fiscais  '
      + ' FROM dados_gerais_clientes d  ' + '   LEFT JOIN contador_cliente CC   ' +
      ' ON CC.COD_CLIENTE = D.cod_cli   ' + '  INNER JOIN cliente c  ' +
      '  ON c.cod_cli = d.COD_CLI   ' +
      '       WHERE d.COD_CLI =:COD_CLI and d.PASTA_BACKUP_FTP = :PASTA_BACKUP_FTP ');
    parambyname('COD_CLI').asinteger := icodclicons;
    parambyname('PASTA_BACKUP_FTP').asstring := PASTABACKUPFTP;
    open;
    last;
    first;
  end;
  while not FdQAux.eof do
  begin

    if FdQAux.fieldbyname('DATA_ULT_BACKUP').asstring <> '' then
    BEGIN
      iDiasBackup := (DaysBetween(FdQAux.fieldbyname('DATA_SINCR_DADOS').asdatetime,
        FdQAux.fieldbyname('DATA_ULT_BACKUP').asdatetime));
    END
    else
    begin
      iDiasBackup := 10000;
    end;

    if FdQAux.fieldbyname('DATA_ULT_FTP').asstring <> '' then
    BEGIN
      iDiasFtp := (DaysBetween(FdQAux.fieldbyname('DATA_SINCR_DADOS').asdatetime,
        FdQAux.fieldbyname('DATA_ULT_FTP').asdatetime));
    END
    else
    begin
      iDiasFtp := 10000;
    end;

    if (trim(FdQAux.fieldbyname('DATA_HORA_ULT_VENDA').asstring) <> '') then
    BEGIN
      iDiasVendas := (DaysBetween(date, FdQAux.fieldbyname('DATA_HORA_ULT_VENDA').asdatetime));
    END
    else
    begin
      iDiasVendas := 10000;
    end;

    if FdQAux.fieldbyname('DATA_ULT_CUPOM').asstring <> '' then
    BEGIN
      iDiasCupom := (DaysBetween(date, FdQAux.fieldbyname('DATA_ULT_CUPOM').asdatetime));
    END
    else
    begin
      iDiasCupom := 10000;
    end;

    if FdQAux.fieldbyname('DATA_VAL_CERT_DIG').asstring <> '' then
    BEGIN
      iDiasCertificadoDigital :=
        (DaysBetween(date, FdQAux.fieldbyname('DATA_VAL_CERT_DIG').asdatetime));
    END
    else
    begin
      iDiasCertificadoDigital := 10000;
    end;

    if FdQAux.fieldbyname('DATA_HORA_ULT_NFE').asstring <> '' then
    BEGIN
      iDiasNFE := (DaysBetween(date, FdQAux.fieldbyname('DATA_HORA_ULT_NFE').asdatetime));
    END
    else
    begin
      iDiasNFE := 10000;
    end;

    if FdQAux.fieldbyname('DATA_ULT_SINC_PDC').asstring <> '' then
    BEGIN
      iDiasPDC := (DaysBetween(date, FdQAux.fieldbyname('DATA_ULT_SINC_PDC').asdatetime));
    END
    else
    begin
      iDiasPDC := 10000;
    end;

    if FdQAux.fieldbyname('DATA_SINCR_DADOS').asstring <> '' then
    BEGIN
      iDiasUltSiocronizacao :=
        (DaysBetween(date, FdQAux.fieldbyname('DATA_SINCR_DADOS').asdatetime));
    END
    else
    begin
      iDiasUltSiocronizacao := 10000;
    end;

    { Verifica clientes sem comunica��o com a nossa rede }
    PNStatus.visible := true;
    PNStatus.caption := ' Verifica clientes sem comunica��o com a nossa rede ';
    with dm.FDQConsulta do
    begin
      Close;
      SQL.Clear;
      SQL.Add(' SELECT  C.cod_cli,C.NOME_CLI,C.NOME_FANTASIA,CAST(D.DATA_ULT_FTP AS DATE) ' +
        ' AS  DATA_ULT_BACKUP, CAST(D.DATA_SINCR_DADOS AS DATE) AS  DATA_SIC FROM cliente C ' +
        ' INNER JOIN dados_gerais_clientes D ' + ' ON D.COD_CLI = C.cod_cli           ' +
        ' WHERE CAST(D.DATA_ULT_FTP AS DATE) <= :DATACONS ' + ' AND C.cod_cli NOT IN (   ' +
        ' SELECT C.cod_cli  FROM cliente C  ' + ' INNER JOIN dados_gerais_clientes D   ' +
        ' ON D.COD_CLI = C.cod_cli     ' + ' WHERE CAST(D.DATA_ULT_FTP AS DATE) > :DATACONS ) ' +
        ' AND  C.ATIVO = ' + #39 + 'S' + #39 + ' and d.COD_CLI =:COD_CLI ');
      parambyname('DATACONS').asdatetime := date - 5;
      parambyname('cod_cli').asinteger := icodclicons;
      open;
      first;
      while not dm.FDQConsulta.eof do
      begin
        iDiasSemComunicacao :=
          (DaysBetween(date, dm.FDQConsulta.fieldbyname('DATA_SIC').asdatetime));
        if (SNaoVerificaBackup <> 'S') and (dm.FDQConsulta.fieldbyname('DATA_SIC').asdatetime <>
          dm.FDQConsulta.fieldbyname('DATA_ULT_BACKUP').asdatetime) then
        BEGIN
          InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
            'O CLIENTE EST� SEM COMUNICA��O COM NOSSA BASE E SEM BACKUP FTP ' +
            INTTOSTR(iDiasSemComunicacao) + ' DIAS', PASTABACKUPFTP,
            FdQAux.fieldbyname('erro_backup').asstring, 'GRAVE');
        END;

        dm.FDQConsulta.next;
      end;

    end;

    { Buscar o contador }
    PNStatus.visible := true;
    PNStatus.caption := ' Buscar o contador  ';
    with dm.FDQConsulta do
    begin
      Close;
      SQL.Clear;
      SQL.Add(' SELECT d.DATA_ULT_FTP,d.DATA_ULT_BACKUP,d.DATA_HORA_ULT_VENDA,d.VERSAO,DATA_SINCR_DADOS, '
        + '  d.DATA_VAL_CERT_DIG,d.DATA_ULT_CUPOM,PASTA_BACKUP_FTP,DATA_HORA_ULT_NFE,DATA_ULT_SINC_PDC,     '
        + ' CC.COD_CONTADOR FROM dados_gerais_clientes d   ' +
        '   LEFT JOIN contador_cliente CC    ' + ' ON CC.COD_CLIENTE = D.cod_cli  ' +
        '       WHERE d.COD_CLI =:COD_CLI ');
      parambyname('cod_cli').asinteger := icodclicons;
      open;
    end;

    { Verifica se o cliente est� com a plataforma configurada }
    { if ((dm.FDQConsulta.fieldbyname('COD_CONTADOR').asinteger) > 0) and
      (trim(dm.FDQConsulta.fieldbyname('DATA_ULT_SINC_PDC').asstring) <> '') and
      ((iDiasCupom <> 10000) or (iDiasNFE <> 10000)) and (iDiasPDC = 10000) and
      (trim(FdQAux.fieldbyname('dados_adm').asstring) = '') then
      begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
      'CONFIGURE ESTE CLIENTE PARA A PLATAFORMA DO CONTADOR');
      end; }

    { se o cliente est� subindo o cupom para a plataforma  do contador PDC }
    if (iDiasPDC - iDiasCupom >= 3) and (iDiasVendas - iDiasCupom >= 3) and
      (trim(dm.FDQConsulta.fieldbyname('COD_CONTADOR').asstring) <> '') AND (iDiasPDC <> 10000) and
      (iDiasCupom <> 10000) and (trim(FdQAux.fieldbyname('dados_adm').asstring) = '') then
    begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
        ' O SOFTWARE NAO ESTA ENVIANDO OS CUPONS PARA PLATAFORMA DO CONTADOR FAZ ' +
        INTTOSTR(iDiasCupom - iDiasPDC) + ' DIAS', PASTABACKUPFTP, '', 'BAIXO');

    end;

    { se o cliente est� subindo a NFE para a plataforma  do contador PDC }
    { if (iDiasPDC - iDiasNFE >= 3) and (trim(dm.FDQConsulta.fieldbyname('COD_CONTADOR').asstring) <>
      '') AND (iDiasPDC <> 10000) and (trim(FdQAux.fieldbyname('dados_adm').asstring) = '') then
      begin

      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
      ' O SOFTWARE NAO ESTA ENVIANDO AS NFES DE SA�DA PARA PLATAFORMA DO CONTADOR FAZ ' +
      INTTOSTR(iDiasNFE - iDiasPDC) + ' DIAS');

      end; }

    { verifica se o cliente est� se comunicando com o nosso servidor }
    { if (iDiasUltSiocronizacao >= 15) AND (iDiasUltSiocronizacao <> 10000) then
      begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
      ' O SISTEMA NAO EST� SE COMUNICANDO COM O NOSSO HOST FAZ ' + INTTOSTR(iDiasUltSiocronizacao)
      + ' DIAS');
      end; }

    { verififica se est� fazendo  backup }
    { if (iDiasBackup >= 2) and (iDiasBackup <> 10000) and
      ((iDiasBackup - iDiasVendas) >= 2) then
      begin
      VtProblemas.Append;
      VtProblemascod_cli.asstring := FDQConsCliProb.fieldbyname
      ('cod_cli').asstring;
      VtProblemasNOME_CLI.asstring := FDQConsCliProb.fieldbyname
      ('NOME_CLI').asstring;
      VtProblemasNOME_FANTASIA.asstring := FDQConsCliProb.fieldbyname
      ('NOME_FANTASIA').asstring;
      VtProblemasCIDRES_CLI.asstring := FDQConsCliProb.fieldbyname
      ('CIDRES_CLI').asstring;
      VtProblemasCNPJ_CLI.asstring := FDQConsCliProb.fieldbyname
      ('CNPJ_CLI').asstring;
      VtProblemasNOME_PONTO_REVENDA.asstring :=
      FDQConsCliProb.fieldbyname('NOME_PONTO_REVENDA').asstring;
      VtProblemasDESCRICAO_PROBLEMA.asstring :=
      ' O CLIENTE N�O EST� FAZENDO BACKUP FAZ ' + INTTOSTR(iDiasBackup)
      + ' DIAS';
      VtProblemas.post;

      end; }
    { verififica se o Backup est� configurado }

    if (iDiasBackup = 10000) and ((iDiasBackup - iDiasVendas) >= 2) then
    begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
        ' O BACKUP N�O EST� CONFIGURADO NESTE CLIENTE', PASTABACKUPFTP, '', 'GRAVE');
    end;

    if SNaoVerificaBackup <> 'S' then
    BEGIN
      { verifica se est� fazendo backup ftp }
      if (iDiasFtp >= 3) and (iDiasFtp <> 10000) then
      begin
        InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
          ' O CLIENTE N�O EST� ENVIANDO O BACKUP PARA O FTP FAZ ' + INTTOSTR(iDiasFtp) + ' DIAS',
          PASTABACKUPFTP, FdQAux.fieldbyname('erro_backup').asstring, 'GRAVE');
      end;
    END;

    { verifica se o backup ftp est� configurado }
    if (iDiasFtp = 10000) and ((iDiasFtp - iDiasVendas) >= 3) then
    begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
        ' O FTP N�O CONFIGURADO OU UTILIZADO NESTE CLIENTE ', PASTABACKUPFTP,
        FdQAux.fieldbyname('erro_backup').asstring, 'GRAVE');

    end;
    { verifica se o cliente est� fazendo backup mas nao est� enviando para o FTP }
    if (iDiasFtp <> iDiasBackup) and (iDiasFtp <> 10000) and (iDiasBackup <> 10000) and
      ((iDiasFtp - iDiasVendas) >= 3) then
    begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
        ' O CLIENTE EST� FAZENDO O BACKUP, POREM N�O EST� ENVIANDO VIA FTP FAZ ' +
        INTTOSTR(iDiasBackup - iDiasFtp) + ' DIAS', PASTABACKUPFTP,
        FdQAux.fieldbyname('erro_backup').asstring, 'GRAVE');
    end;

    { verifica se o o cliente est� enviando o cupom fiscal }
    { if (iDiasCupom >= 5) and (iDiasCupom <> 10000) and (iDiasCupom <= 365) and
      (trim(FdQAux.fieldbyname('dados_adm').asstring) = '') then
      begin
      VtProblemas.Append;
      VtProblemascod_cli.asstring := FDQConsCliProb.fieldbyname
      ('cod_cli').asstring;
      VtProblemasNOME_CLI.asstring := FDQConsCliProb.fieldbyname
      ('NOME_CLI').asstring;
      VtProblemasNOME_FANTASIA.asstring := FDQConsCliProb.fieldbyname
      ('NOME_FANTASIA').asstring;
      VtProblemasCIDRES_CLI.asstring := FDQConsCliProb.fieldbyname
      ('CIDRES_CLI').asstring;
      VtProblemasCNPJ_CLI.asstring := FDQConsCliProb.fieldbyname
      ('CNPJ_CLI').asstring;
      VtProblemasNOME_PONTO_REVENDA.asstring :=
      FDQConsCliProb.fieldbyname('NOME_PONTO_REVENDA').asstring;
      VtProblemasDESCRICAO_PROBLEMA.asstring :=
      ' O CLIENTE N�O EST� ENVIANDO O CUPOM FAZ ' + INTTOSTR(iDiasCupom)
      + ' DIAS';
      VtProblemas.post;

      end; }

    { verifica se o o cliente est� vendendo mas nao enviando o cupom fiscal }
    { if ((iDiasVendas - iDiasCupom) >= 5) and (iDiasCupom <> 10000) and
      (iDiasVendas <> 10000) and (iDiasCupom <= 365) and (iDiasCupom >= 5) and
      (trim(FdQAux.fieldbyname('dados_adm').asstring) = '') then
      begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
      ' O CLIENTE EST� FAZENDO VENDAS MAS N�O EST� ENVIANDO O CUPOM FAZ ' +
      INTTOSTR(iDiasVendas - iDiasCupom) + ' DIAS');
      end; }

    if SNaoGeraMovFiscal <> 'S' then
    BEGIN
      { Busca inconsistencias arquivos fiscais }
      PNStatus.visible := true;
      PNStatus.caption := ' Busca inconsistencias arquivos fiscais   ';
      with dm.FDQConsulta do
      begin
        Close;
        SQL.Clear;
        SQL.Add(' SELECT c.mes_mov_fiscal,c.ano_mov_fiscal,c.inconsistencias_mov_fiscal FROM cliente c  '
          + ' WHERE c.cod_cli = :cod_cli ');
        parambyname('cod_cli').asinteger := icodclicons;
        open;
      end;

      sMesAtual := FormatDateTime('mm', IncMonth(date, -1));

      if (trim(FdQAux.fieldbyname('TIPO_DOC_FISCAL_EMP').asstring) = 'F') or
        (trim(FdQAux.fieldbyname('TIPO_DOC_FISCAL_EMP').asstring) = 'S') AND
        (FdQAux.fieldbyname('Nao_gera_arquivos_fiscais').asstring <> 'S') THEN
      BEGIN

        if (trim(FdQAux.fieldbyname('inconsistencias_mov_fiscal').asstring) = 'S') and
          (strtoint(sMesAtual) = strtoint(FdQAux.fieldbyname('mes_mov_fiscal').asstring)) then
        begin

          InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
            ' ENCONTRAMOS INCONSISTENCIAS NA GERA��O DO ARQUIVO FISCAL REFERENTE AO M�S (' +
            FdQAux.fieldbyname('mes_mov_fiscal').asstring + ') DO ANO ' +
            FdQAux.fieldbyname('ano_mov_fiscal').asstring, PASTABACKUPFTP, '', 'MEDIO');
        end;

        { if (trim(FdQAux.fieldbyname('inconsistencias_mov_fiscal').asstring)
          = 'N') and
          (strtoint(sMesAtual) = strtoint(FdQAux.fieldbyname('mes_mov_fiscal')
          .asstring)) AND
          (trim(FdQAux.fieldbyname('enviado_email_mov_fiscal').asstring)
          = 'N') THEN
          BEGIN
          InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
          'ARQUIVO FISCAL GERADO MAS O EMAIL COM OS ARQUIVOS FISCAIS N�O FOI ENVIADO',
          PASTABACKUPFTP, '', 'MEDIO');
          END; }

      END;
    END;

    { Verifica se o cliente est� programado para subir o arquivo de movimento/Sped mas nao subiu }
    { if (trim(FdQAux.fieldbyname('TIPO_DOC_FISCAL_EMP').asstring) <> '') and
      (trim(FdQAux.fieldbyname('inconsistencias_mov_fiscal').asstring) <> 'S')
      and (trim(FdQAux.fieldbyname('inconsistencias_mov_fiscal').asstring) <>
      'N') then
      begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
      'O ARQUIVO FISCAL N�O FOI ENVIADO PARA A PLATAFORMA DO CONTADOR');
      end; }

    { Verifica se o cliente o cliente quando gerou o arquivo de movimento enviou o email }
    { if
      (trim(FdQAux.fieldbyname('inconsistencias_mov_fiscal').asstring) = 'N')
      and (trim(FdQAux.fieldbyname('enviado_email_mov_fiscal').asstring) =
      'N') then
      begin
      InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
      'O ARQUIVO FISCAL FOI GERADO MAS NAO FOI ENVIADO O EMAIL AUTOM�TICO PARA CONTABILIDADE');
      end; }

    { verifica se est� na vers�o minima Financeira }
    { if (StrToCurr(StringReplace(FdQAux.fieldbyname('versao').asstring, '.', ',',
      [rfReplaceAll]))) <= 21.2 then
      begin
      VtProblemas.Append;
      VtProblemascod_cli.asstring := FDQConsCliProb.fieldbyname
      ('cod_cli').asstring;
      VtProblemasNOME_CLI.asstring := FDQConsCliProb.fieldbyname
      ('NOME_CLI').asstring;
      VtProblemasNOME_FANTASIA.asstring := FDQConsCliProb.fieldbyname
      ('NOME_FANTASIA').asstring;
      VtProblemasCIDRES_CLI.asstring := FDQConsCliProb.fieldbyname
      ('CIDRES_CLI').asstring;
      VtProblemasCNPJ_CLI.asstring := FDQConsCliProb.fieldbyname
      ('CNPJ_CLI').asstring;
      VtProblemasNOME_PONTO_REVENDA.asstring :=
      FDQConsCliProb.fieldbyname('NOME_PONTO_REVENDA').asstring;
      VtProblemasDESCRICAO_PROBLEMA.asstring :=
      ' ATUALIZE ESTE CLIENTE PARA A VERS�O M�NIMA 21.3';
      VtProblemas.post;

      end; }

    Application.ProcessMessages;
    FdQAux.next;
  end;

  if (trim(FdQAux.fieldbyname('dados_adm').asstring) = '') then
  begin

    { verifica se o o modulo fiscal est� conectado na rede }
    PNStatus.visible := true;
    PNStatus.caption := ' verifica se o o modulo fiscal est� conectado na rede   ';
    with FdQAux do
    begin
      Close;
      SQL.Clear;
      SQL.Add('  SELECT  c.STATUS_REDE_SAT,c.DATA_HORA_ULT_SEFAZ_SAT,ESTADO_OPERACAO_SAT  from clientes_caixas c  '
        + '     INNER JOIN cliente cl    on cl.cod_cli = c.cod_cli ' +
        '   WHERE  c.cod_cli = :COD_CLI  and c.cod_cli <> 7     and cl.cod_cla <>30   ' +
        '   AND  c.cod_cli <> 8 AND  c.cod_cli <> 6 and cl.ATIVO = ' + #39 + 'S' + #39 + '    ');
      parambyname('COD_CLI').asinteger := icodclicons;
      open;
      last;
      first;
    end;

    while not FdQAux.eof do
    begin
      if (trim(FdQAux.fieldbyname('STATUS_REDE_SAT').asstring) = 'N�O CONECTADO') and
        ((DaysBetween(date, FdQAux.fieldbyname('DATA_HORA_ULT_SEFAZ_SAT').asdatetime)) > 0) then
      begin
        InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
          ' MFE SEM INTERNET FAZ ' + INTTOSTR(DaysBetween(date,
          FdQAux.fieldbyname('DATA_HORA_ULT_SEFAZ_SAT').asdatetime)) + ' DIAS', PASTABACKUPFTP,
          '', 'MEDIO');
      end;

      if trim(FdQAux.fieldbyname('ESTADO_OPERACAO_SAT').asstring) = 'BLOQUEIO AUT�NOMO' then
      begin
        InserePainelProblemas(FDQConsCliProb.fieldbyname('cod_cli').asinteger,
          ' MFE COM BLOQUEIO AUT�NOMO ', PASTABACKUPFTP, '', 'GRAVE');
      end;

      FdQAux.next;
    end;

  end;

end;

procedure TfrmMonitorClientes.VerificarStatuspagmento1Click(Sender: TObject);
begin

  with dm.FDQAuxServer do
  begin
    Close;
    SQL.Clear;
    SQL.Add('SELECT  ' + '   first 1 r.vlrpago_ctr AS VALOR, ' + '    ' +
      quotedstr('contas_receber') + ' AS ORIGEM ' + 'FROM contas_receber r ' +
      'WHERE COALESCE(r.vlrpago_ctr, 0) > 0 ' + '  AND r.cod_cli = :cod_cli ' + ' ' + 'UNION ALL ' +
      ' ' + 'SELECT ' + '   first 1  r.valor_pago AS VALOR, ' + '    ' +
      quotedstr('contas_receber_adm_cartao') + ' AS ORIGEM ' + 'FROM contas_receber_adm_cartao r ' +
      'WHERE COALESCE(r.valor_pago, 0) > 0 ' + '  AND r.cod_cli = :cod_cli ');

    parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;

    open;
  end;

  if dm.FDQAuxServer.fieldbyname('VALOR').ascurrency > 0 then
  begin
    with dm.fdqinsert do
    begin
      Close;
      SQL.Clear;
      SQL.Add('UPDATE cliente c SET  ' + 'c.STATUS_PRIM_PGTO  = ' + quotedstr('PAGOU') +
        'WHERE c.cod_cli = :cod_cli ');
      parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
      execsql;
    end;
  end
  else
  begin
    with dm.fdqinsert do
    begin
      Close;
      SQL.Clear;
      SQL.Add('UPDATE cliente c SET  ' + 'c.STATUS_PRIM_PGTO  = ' + quotedstr('') +
        'WHERE c.cod_cli = :cod_cli ');
      parambyname('cod_cli').asinteger := QInstalacaocod_cli.asinteger;
      execsql;
    end;
  end;
  BtnInstalacoes.Click;
end;

procedure TfrmMonitorClientes.VerretornodeSQL1Click(Sender: TObject);
begin
  if trim(QAgendamentoTarefaretorno.asstring) = '' then
    exit;

  if QAgendamentoTarefatipo_tarefa.asinteger <> 3 then
  begin
    showmessage('esta tarefa n�o � uma execu��o de um SQL de select!');
    exit;
  end;

  Application.CreateForm(tfrmRetornoSQLTarefa, frmRetornoSQLTarefa);
  frmRetornoSQLTarefa.sSQLRetorno := trim(QAgendamentoTarefaretorno.asstring);
  frmRetornoSQLTarefa.ShowModal;
end;

procedure TfrmMonitorClientes.VisualizarClientesComVersaoAbaixoDaMinima;
var
  versao: Integer;
begin
  { Busca clientes com a vers�o abaixo da vers�o minima }

  with FdQAux do
  begin
    Close;
    SQL.Clear;
    SQL.Add(' SELECT  ' + ' D.COD_CLI,       ' + ' C.NOME_CLI,    ' +
      ' C.NOME_FANTASIA,d.cod_emp,  ' + ' D.versao_exe_connection, ' + ' D.PASTA_BACKUP_FTP,      '
      + ' D.DATA_SINCR_DADOS, ' + ' C.CIDRES_CLI,D.DATA_SINCR_DADOS,   ' +
      ' c.CNPJ_CLI,PASTA_BACKUP_FTP,P.descricao ' + ' FROM dados_gerais_clientes D ' +
      ' INNER JOIN cliente C   ' + ' ON C.cod_cli = D.COD_CLI ' + ' inner join ponto_revenda P on '
      + '	P.cod_ponto = C.COD_CON  ' + ' WHERE C.ATIVO =' + quotedstr('S') + '  ' +
      ' AND c.CNPJ_CLI   not LIKE ' + quotedstr('% .   .   - %') + ' ' +
      ' and ( c.cod_cli <> 1 and c.cod_cli <> 0 AND c.cod_cli <> 7   ' +
      '      AND  c.cod_cli <> 8 AND  c.cod_cli <> 6  and c.cod_cla <>30 )   ' +
      '   AND D.PASTA_BACKUP_FTP NOT IN (SELECT PASTA_BACKUP_FTP FROM agendamento_atualizacao A  ' +
      ' WHERE A.PASTA_BACKUP_FTP = D.PASTA_BACKUP_FTP) ' + ' GROUP BY 1,2,3,4,5  ');
    open;

  end;

  MTCliSemVersMin.DisableControls;
  MTCliSemVersMin.Close;
  MTCliSemVersMin.Isempty;
  MTCliSemVersMin.open;
  FdQAux.first;
  while not FdQAux.eof do
  begin
    lbVersaoMinRecomendada.caption :=
      'Essa � uma listagem dos clientes abaixo da vers�o m�nima recomendada: ' + INTTOSTR(2400);
    versao := strtointdef(trim(RemoveChar(FdQAux.fieldbyname('versao_exe_connection')
      .asstring)), 0);

    if versao < 2400 then
    begin
      MTCliSemVersMin.Append;
      MTCliSemVersMincod_cli.asstring := FdQAux.fieldbyname('COD_CLI').asstring;
      MTCliSemVersMinpasta_backup_ftp.asstring := FdQAux.fieldbyname('PASTA_BACKUP_FTP').asstring;
      MTCliSemVersMinNOME_FANTASIA.asstring := FdQAux.fieldbyname('NOME_FANTASIA').asstring;
      MTCliSemVersMinNOME_CLI.asstring := FdQAux.fieldbyname('NOME_CLI').asstring;
      MTCliSemVersMinCNPJ_CLI.asstring := FdQAux.fieldbyname('CNPJ_CLI').asstring;
      MTCliSemVersMinCIDRES_CLI.asstring := FdQAux.fieldbyname('CIDRES_CLI').asstring;
      MTCliSemVersMindescricao.asstring := FdQAux.fieldbyname('descricao').asstring;
      MTCliSemVersMinversao_exe_connection.asstring :=
        FdQAux.fieldbyname('versao_exe_connection').asstring;
      MTCliSemVersMinDATA_SINCR_DADOS.asstring := FdQAux.fieldbyname('DATA_SINCR_DADOS').asstring;
      MTCliSemVersMincod_emp.asstring := FdQAux.fieldbyname('cod_emp').asstring;
      MTCliSemVersMin.Post;
    end;
    FdQAux.next;
  end;
  MTCliSemVersMin.EnableControls;
end;

end.
