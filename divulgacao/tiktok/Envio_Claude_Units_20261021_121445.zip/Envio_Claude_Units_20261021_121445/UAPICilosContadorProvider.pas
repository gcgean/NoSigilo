unit UAPICilosContadorProvider;

interface

uses
  System.Classes, System.SysUtils, System.JSON, RESTRequest4D, Rest.Client, Rest.Types, System.Math,
  Data.Bind.Components, Data.Bind.ObjectScope, IdHTTP, IdSSLOpenSSL, IdMultipartFormData, IdGlobal,
  System.DateUtils;

type
  TStatusDFeCilosContador = (sdccAutorizado, sdccCancelado, sdccEncerrado, sdccInutilizado,
    sdccDownload, sdccCartaCorrecao);

  TTipoDFeCilosContador = (tdccNFe, tdccNFCe, tdccCFe, tdccMDFe, tdccCTe);

  TTipoEnvioDFeCilosContador = (tedccEntrada, tedccSaida);

  RResultCilosContador = record
    Result: Boolean;
    StatusCode: Integer;
    ErrorMessage: String;
    Content: String;
  end;

  IAPICilosContadorConfig = interface
    ['{418DFE51-8ED2-4B31-9C77-626650A561A2}']

    function BaseURL: string; overload;
    function BaseURL(const AValue: String): IAPICilosContadorConfig; overload;

    function Token: string; overload;
    function Token(const AValue: String): IAPICilosContadorConfig; overload;
  end;

  IAPICilosContadorProvider = interface
    ['{2F3537F1-9153-4640-A39D-3FFB8A709C1C}']
    function Config(const AConfig: IAPICilosContadorConfig): IAPICilosContadorProvider;

    function ConsultarClientePorDocumento(const ADocumento: string): RResultCilosContador;
    function VincularClienteContador(const ACNPJCPFCliente: string;
      const ACNPJCPFContador: string): Boolean;
    function CriarContador(const ARazaoSocial: String; const ANomeFantasia: String;
      const ACNPJCPF: String; const AEmail: String): RResultCilosContador;

    function EnviarXMLString(const ACPFouCNPJ: string; const AModelo: TTipoDFeCilosContador;
      const AMes, AAno: Word; const ATipo: TTipoEnvioDFeCilosContador;
      const AEvento: TStatusDFeCilosContador; ASubstituir: Boolean; const AConteudoXML: string)
      : RResultCilosContador;

    function EnviarXMLArquivo(const ACPFouCNPJ: string; const AModelo: TTipoDFeCilosContador;
      const AMes, AAno: Word; const ATipo: TTipoEnvioDFeCilosContador;
      const AEvento: TStatusDFeCilosContador; ASubstituir: Boolean; const ACaminhoArquivo: string)
      : RResultCilosContador;

    function EnviarArquivoGeral(const ACPFouCNPJ: string; const AMes, AAno: Word;
      ASubstituir: Boolean; const ACaminhoArquivo: string; const ADescricaoArquivo: String)
      : RResultCilosContador;

    function EnviarProduto(const ABody: TJSONObject): RResultCilosContador;
    function ConsultarProdutosAtualizados(const ADesde: TDateTime; const APage: Integer;
      const ACNPJCPFCliente: string = ''): RResultCilosContador;

  end;

  TAPICilosContadorConfig = class(TInterfacedObject, IAPICilosContadorConfig)
  private
    FBaseURL: string;
    FToken: string;

    function BaseURL: string; overload;
    function BaseURL(const AValue: String): IAPICilosContadorConfig; overload;

    function Token: string; overload;
    function Token(const AValue: String): IAPICilosContadorConfig; overload;
  public
    constructor Create(const ABaseURL, AToken: string);
    class function New(const ABaseURL, AToken: string): IAPICilosContadorConfig;
  end;

  TAPICilosContadorProvider = class(TInterfacedObject, IAPICilosContadorProvider)
  private
    FConfig: IAPICilosContadorConfig;

    function Config(const AConfig: IAPICilosContadorConfig): IAPICilosContadorProvider;

    function BuildFullURL(const ARelativePath: string): string;
    function TratarRetorno(const ADescricaoRequisicao: String; const AResponse: IResponse)
      : RResultCilosContador;
    function ExecuteGET(const ARelativePath: string): RResultCilosContador;
    function ExecutePOSTJSON(const AURL: string; const ABody: TJSONObject): RResultCilosContador;
    function ExecutePUTJSON(const AURL: string; const ABody: TJSONObject): RResultCilosContador;
    function ExecutePOSTFile(const AURL, AFieldName, AFilePath, AFileDescription: string)
      : RResultCilosContador;
    function ModeloToStr(const AModelo: TTipoDFeCilosContador): string;
    function TipoToStr(const ATipo: TTipoEnvioDFeCilosContador): string;
    function EventoToStr(const AEvento: TStatusDFeCilosContador): string;
    function BoolToStrSN(ABool: Boolean): string;
    function RemoveAcento(Str: string): string;
    function SanitizeFileName(const AFileName: string): string;

    function ConsultarClientePorDocumento(const ADocumento: string): RResultCilosContador;
    function VincularClienteContador(const ACNPJCPFCliente: string;
      const ACNPJCPFContador: string): Boolean;
    function CriarContador(const ARazaoSocial: String; const ANomeFantasia: String;
      const ACNPJCPF: String; const AEmail: String): RResultCilosContador;

    function EnviarXMLString(const ACPFouCNPJ: string; const AModelo: TTipoDFeCilosContador;
      const AMes, AAno: Word; const ATipo: TTipoEnvioDFeCilosContador;
      const AEvento: TStatusDFeCilosContador; ASubstituir: Boolean; const AConteudoXML: string)
      : RResultCilosContador;

    function EnviarXMLArquivo(const ACPFouCNPJ: string; const AModelo: TTipoDFeCilosContador;
      const AMes, AAno: Word; const ATipo: TTipoEnvioDFeCilosContador;
      const AEvento: TStatusDFeCilosContador; ASubstituir: Boolean; const ACaminhoArquivo: string)
      : RResultCilosContador;

    function EnviarArquivoGeral(const ACPFouCNPJ: string; const AMes, AAno: Word;
      ASubstituir: Boolean; const ACaminhoArquivo: string; const ADescricaoArquivo: String)
      : RResultCilosContador;

    function EnviarProduto(const ABody: TJSONObject): RResultCilosContador;
    function ConsultarProdutosAtualizados(const ADesde: TDateTime; const APage: Integer;
      const ACNPJCPFCliente: string = ''): RResultCilosContador;

  public
    constructor Create(const AConfig: IAPICilosContadorConfig);
    class function New(const AConfig: IAPICilosContadorConfig): IAPICilosContadorProvider;
  end;

implementation

{ TAPICilosContadorConfig }

function TAPICilosContadorConfig.BaseURL: string;
begin
  Result := FBaseURL;
end;

function TAPICilosContadorConfig.BaseURL(const AValue: String): IAPICilosContadorConfig;
begin
  Result := Self;
  FBaseURL := AValue;
end;

constructor TAPICilosContadorConfig.Create(const ABaseURL, AToken: string);
begin
  FBaseURL := ABaseURL;
  FToken := AToken;
end;

class function TAPICilosContadorConfig.New(const ABaseURL, AToken: string): IAPICilosContadorConfig;
begin
  Result := Self.Create(ABaseURL, AToken);
end;

function TAPICilosContadorConfig.Token: string;
begin
  Result := FToken;
end;

function TAPICilosContadorConfig.Token(const AValue: String): IAPICilosContadorConfig;
begin
  Result := Self;
  FToken := AValue;
end;

{ TAPICilosContadorProvider }

constructor TAPICilosContadorProvider.Create(const AConfig: IAPICilosContadorConfig);
begin
  FConfig := AConfig;
end;

function TAPICilosContadorProvider.CriarContador(const ARazaoSocial, ANomeFantasia, ACNPJCPF,
  AEmail: String): RResultCilosContador;
var
  LJSON: TJSONObject;
begin
  LJSON := TJSONObject.Create.AddPair('razaoSocial', ARazaoSocial)
    .AddPair('nomeFantasia', ANomeFantasia).AddPair('cnpjCpf', ACNPJCPF).AddPair('email', AEmail);

  try
    Result := ExecutePOSTJSON(BuildFullURL('/v1/contadores'), LJSON);
  finally
    FreeAndNil(LJSON);
  end;
end;

class function TAPICilosContadorProvider.New(const AConfig: IAPICilosContadorConfig)
  : IAPICilosContadorProvider;
begin
  Result := Self.Create(AConfig);
end;

function TAPICilosContadorProvider.RemoveAcento(Str: string): string;
const
  ComAcento = '����������������������������';
  SemAcento = 'aaeouaoaeioucuAAEOUAOAEIOUCU';
var
  x: Integer;
begin;
  for x := 1 to Length(Str) do
    if Pos(Str[x], ComAcento) <> 0 then
      Str[x] := SemAcento[Pos(Str[x], ComAcento)];

  Result := Str;
end;

function TAPICilosContadorProvider.SanitizeFileName(const AFileName: string): string;
var
  I: Integer;
  LFileName: string;
begin
  LFileName := RemoveAcento(ExtractFileName(AFileName));
  Result := EmptyStr;

  for I := 1 to Length(LFileName) do
    if (Ord(LFileName[I]) >= 32) and (Ord(LFileName[I]) <= 126) and
      not CharInSet(LFileName[I], ['"', '\']) then
      Result := Result + LFileName[I]
    else
      Result := Result + '_';

  if Result.Trim.IsEmpty then
    Result := 'arquivo';
end;

function TAPICilosContadorProvider.BuildFullURL(const ARelativePath: string): string;
begin
  Result := FConfig.BaseURL.TrimRight(['/']) + '/' + ARelativePath.TrimLeft(['/']);
end;

function TAPICilosContadorProvider.ExecuteGET(const ARelativePath: string): RResultCilosContador;
begin
  Result := TratarRetorno('GET', TRequest.New.BaseURL(BuildFullURL(ARelativePath))
    .TokenBearer(FConfig.Token).Get);
end;

function TAPICilosContadorProvider.ExecutePOSTJSON(const AURL: string; const ABody: TJSONObject)
  : RResultCilosContador;
begin
  Result := TratarRetorno('POST com JSON', TRequest.New.BaseURL(AURL).TokenBearer(FConfig.Token)
    .AddBody(ABody, False).Post);
end;

function TAPICilosContadorProvider.ExecutePUTJSON(const AURL: string; const ABody: TJSONObject)
  : RResultCilosContador;
begin
  Result := TratarRetorno('PUT com JSON', TRequest.New.BaseURL(AURL).TokenBearer(FConfig.Token)
    .AddBody(ABody, False).Put);
end;

function TAPICilosContadorProvider.ExecutePOSTFile(const AURL, AFieldName, AFilePath,
  AFileDescription: string): RResultCilosContador;
var
  LStream: TMemoryStream;
  LBoundary, LFileName, LLine: string;
  LFileStream: TFileStream;
  LBuffer: TBytes;
  LReq: IRequest;
begin
  if not FileExists(AFilePath) then
    raise Exception.CreateFmt('Erro: O arquivo "%s" n�o foi encontrado.', [AFilePath]);

  LBoundary := '----CilosBoundary' + FormatDateTime('yyyymmddhhnnsszzz', Now);
  LStream := TMemoryStream.Create;
  try
    LFileName := SanitizeFileName(AFilePath);

    // --- Cabe�alho do arquivo ---
    LLine := '--' + LBoundary + sLineBreak +
      Format('Content-Disposition: form-data; name="%s"; filename="%s"' + sLineBreak,
      [AFieldName, LFileName]) + 'Content-Type: application/octet-stream' + sLineBreak + sLineBreak;
    LBuffer := TEncoding.ASCII.GetBytes(LLine);
    LStream.WriteBuffer(LBuffer, Length(LBuffer));

    // --- Conte�do do arquivo ---
    LFileStream := TFileStream.Create(AFilePath, fmOpenRead or fmShareDenyWrite);
    try
      LStream.CopyFrom(LFileStream, LFileStream.Size);
    finally
      LFileStream.Free;
    end;

    // quebra de linha ap�s o arquivo
    LLine := sLineBreak;
    LBuffer := TEncoding.ASCII.GetBytes(LLine);
    LStream.WriteBuffer(LBuffer, Length(LBuffer));

    // --- Campo opcional "descricao" ---
    if not AFileDescription.Trim.IsEmpty then
    begin
      LLine := '--' + LBoundary + sLineBreak + 'Content-Disposition: form-data; name="descricao"' +
        sLineBreak + sLineBreak + RemoveAcento(AFileDescription) + sLineBreak;
      LBuffer := TEncoding.UTF8.GetBytes(LLine);
      LStream.WriteBuffer(LBuffer, Length(LBuffer));
    end;

    // --- Encerramento do multipart ---
    LLine := '--' + LBoundary + '--' + sLineBreak;
    LBuffer := TEncoding.ASCII.GetBytes(LLine);
    LStream.WriteBuffer(LBuffer, Length(LBuffer));

    // --- Requisi��o ---
    LStream.Position := 0;

    LReq := TRequest.New.BaseURL(AURL).TokenBearer(FConfig.Token)
      .ContentType('multipart/form-data; boundary=' + LBoundary).Accept('*/*')
      .AcceptEncoding('gzip, deflate').FallbackCharsetEncoding('raw');

    LReq.AddBody(LStream, False); // N�O transfere posse do stream
    Result := TratarRetorno('POST com File', LReq.Post);
  finally
    FreeAndNil(LStream);
  end;
end;

function TAPICilosContadorProvider.Config(const AConfig: IAPICilosContadorConfig)
  : IAPICilosContadorProvider;
begin
  Result := Self;
  FConfig := AConfig;
end;

function TAPICilosContadorProvider.ConsultarClientePorDocumento(const ADocumento: string)
  : RResultCilosContador;
begin
  Result := ExecuteGET('v1/clientes/por-cnpjcpf/' + ADocumento);
end;

function TAPICilosContadorProvider.ConsultarProdutosAtualizados(const ADesde: TDateTime;
  const APage: Integer; const ACNPJCPFCliente: string): RResultCilosContador;
var
  LURL: string;
  LDataFormatada: string;
begin
  // Formato exigido: DD/MM/AAAA HH:mm:ss
  LDataFormatada := FormatDateTime('dd/mm/yyyy hh:nn:ss', ADesde);

  LURL := Format('v1/produtos/atualizados?dataHora=%s&page=%d', [LDataFormatada, APage]);
  if not ACNPJCPFCliente.Trim.IsEmpty then
    LURL := LURL + '&company_cnpj=' + ACNPJCPFCliente;

  Result := ExecuteGET(LURL);
end;

function TAPICilosContadorProvider.EnviarProduto(const ABody: TJSONObject): RResultCilosContador;
begin
  Result := ExecutePOSTJSON(BuildFullURL('/v1/produtos'), ABody);
end;

function TAPICilosContadorProvider.EnviarXMLString(const ACPFouCNPJ: string;
  const AModelo: TTipoDFeCilosContador; const AMes, AAno: Word;
  const ATipo: TTipoEnvioDFeCilosContador; const AEvento: TStatusDFeCilosContador;
  ASubstituir: Boolean; const AConteudoXML: string): RResultCilosContador;
var
  LURL: string;
  LJSON: TJSONObject;
begin
  LURL := Format('v1/dfe/%s/%s/%d/%d/string?tipo=%s&evento=%s&substituir=%s',
    [ACPFouCNPJ, ModeloToStr(AModelo), AMes, AAno, TipoToStr(ATipo), EventoToStr(AEvento),
    BoolToStrSN(ASubstituir)]);

  LJSON := TJSONObject.Create.AddPair('xml', AConteudoXML);

  try
    Result := ExecutePOSTJSON(BuildFullURL(LURL), LJSON);
  finally
    FreeAndNil(LJSON);
  end;
end;

function TAPICilosContadorProvider.EnviarXMLArquivo(const ACPFouCNPJ: string;
  const AModelo: TTipoDFeCilosContador; const AMes, AAno: Word;
  const ATipo: TTipoEnvioDFeCilosContador; const AEvento: TStatusDFeCilosContador;
  ASubstituir: Boolean; const ACaminhoArquivo: string): RResultCilosContador;
var
  LURL: string;
begin
  LURL := Format('v1/dfe/%s/%s/%d/%d/file?tipo=%s&evento=%s&substituir=%s',
    [ACPFouCNPJ, ModeloToStr(AModelo), AMes, AAno, TipoToStr(ATipo), EventoToStr(AEvento),
    BoolToStrSN(ASubstituir)]);

  Result := ExecutePOSTFile(BuildFullURL(LURL), 'file', ACaminhoArquivo, EmptyStr);
end;

function TAPICilosContadorProvider.EnviarArquivoGeral(const ACPFouCNPJ: string;
  const AMes, AAno: Word; ASubstituir: Boolean; const ACaminhoArquivo: string;
  const ADescricaoArquivo: String): RResultCilosContador;
var
  LURL: string;
begin
  LURL := Format('v1/file/%s/%d/%d?substituir=%s',
    [ACPFouCNPJ, AMes, AAno, BoolToStrSN(ASubstituir)]);

  Result := ExecutePOSTFile(BuildFullURL(LURL), 'file', ACaminhoArquivo, ADescricaoArquivo);
end;

function TAPICilosContadorProvider.ModeloToStr(const AModelo: TTipoDFeCilosContador): string;
begin
  case AModelo of
    tdccNFe:
      Result := '55';
    tdccCTe:
      Result := '57';
    tdccMDFe:
      Result := '58';
    tdccCFe:
      Result := '59';
    tdccNFCe:
      Result := '65';
  end;
end;

function TAPICilosContadorProvider.TipoToStr(const ATipo: TTipoEnvioDFeCilosContador): string;
begin
  case ATipo of
    tedccEntrada:
      Result := 'entrada';
    tedccSaida:
      Result := 'saida';
  end;
end;

function TAPICilosContadorProvider.TratarRetorno(const ADescricaoRequisicao: String;
  const AResponse: IResponse): RResultCilosContador;
var
  LJSON: TJSONValue;
  LMsg, LContentTrim: string;
  LIsJson, LIsServerError: Boolean;

  function IsLikelyJson(const S: string): Boolean;
  var
    T: string;
  begin
    T := S.Trim;
    Result := (T.StartsWith('{') and T.EndsWith('}')) or (T.StartsWith('[') and T.EndsWith(']'));
  end;

begin
  LContentTrim := AResponse.Content;
  LIsJson := IsLikelyJson(LContentTrim);
  LIsServerError := (AResponse.StatusCode >= 500) and (AResponse.StatusCode <= 599);

  Result.Result := InRange(AResponse.StatusCode, 200, 299);
  Result.StatusCode := AResponse.StatusCode;
  Result.ErrorMessage := '';
  Result.Content := '';

  // --- Sucesso ---
  if Result.Result then
  begin
    Result.Content := LContentTrim;
    Exit;
  end;

  // --- Erro ---
  if LIsJson then
  begin
    LJSON := nil;
    LJSON := TJSONObject.ParseJSONValue(LContentTrim);

    try
      if (LJSON is TJSONObject) and TJSONObject(LJSON).TryGetValue<string>('message', LMsg) then
        Result.ErrorMessage := Format('Erro %d na requisi��o %s: %s',
          [AResponse.StatusCode, ADescricaoRequisicao, LMsg])
      else
        Result.ErrorMessage := Format('Erro %d na requisi��o %s: %s',
          [AResponse.StatusCode, ADescricaoRequisicao, LContentTrim]);

      if not LIsServerError then
        Result.Content := LContentTrim;
    finally
      FreeAndNil(LJSON);
    end;
  end
  else
  begin
    if not LContentTrim.Trim.IsEmpty then
      Result.ErrorMessage := Format('Erro %d na requisi��o %s: %s',
        [AResponse.StatusCode, ADescricaoRequisicao, LContentTrim])
    else
      Result.ErrorMessage := Format('Erro %d: Falha ao efetuar a requisi��o %s',
        [AResponse.StatusCode, ADescricaoRequisicao]);
  end;
end;

function TAPICilosContadorProvider.VincularClienteContador(const ACNPJCPFCliente,
  ACNPJCPFContador: string): Boolean;
var
  LJSON: TJSONObject;
begin
  LJSON := TJSONObject.Create.AddPair('cnpjCliente', ACNPJCPFCliente)
    .AddPair('cnpjContador', ACNPJCPFContador);

  try
    Result := ExecutePUTJSON(BuildFullURL('/v1/clientes/vincular-contador'), LJSON).Result;
  finally
    FreeAndNil(LJSON);
  end;
end;

function TAPICilosContadorProvider.EventoToStr(const AEvento: TStatusDFeCilosContador): string;
begin
  case AEvento of
    sdccAutorizado, sdccDownload:
      Result := 'aut';
    sdccCancelado:
      Result := 'can';
    sdccInutilizado:
      Result := 'inu';
    sdccEncerrado:
      Result := 'enc';
    sdccCartaCorrecao:
      Result := 'cce';
  end;
end;

function TAPICilosContadorProvider.BoolToStrSN(ABool: Boolean): string;
begin
  if ABool then
    Result := 's'
  else
    Result := 'n';
end;

end.
