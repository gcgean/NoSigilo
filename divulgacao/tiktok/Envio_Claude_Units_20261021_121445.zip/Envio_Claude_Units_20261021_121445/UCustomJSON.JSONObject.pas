unit UCustomJSON.JSONObject;

interface

uses
  System.SysUtils, System.JSON, UCustomJSON.Contract;

type
  TCustomJSONJSONObject = class(TInterfacedObject, ICustomJSON)
  private
    FJSONObj: TJSONObject;

    function AddString(Name: String; Value: String; AddEmpty: Boolean = False): ICustomJSON;
    function AddInteger(Name: String; Value: Integer): ICustomJSON;
    function AddCurrency(Name: String; Value: Currency): ICustomJSON;
    function AddBoolean(Name: String; Value: Boolean): ICustomJSON;
    function AddJson(Name: String; Value: String): ICustomJSON;
    function ToJsonString: String;
  public
    constructor Create; virtual;
    destructor Destroy; override;
  end;

implementation

{ TCustomJSONJSONObject }

function TCustomJSONJSONObject.AddBoolean(Name: String; Value: Boolean): ICustomJSON;
begin
  FJSONObj.AddPair(Name, TJSONBool.Create(Value));
  Result := Self;
end;

function TCustomJSONJSONObject.AddCurrency(Name: String; Value: Currency): ICustomJSON;
begin
  FJSONObj.AddPair(Name, TJSONNumber.Create(Value));
  Result := Self;
end;

function TCustomJSONJSONObject.AddInteger(Name: String; Value: Integer): ICustomJSON;
begin
  FJSONObj.AddPair(Name, TJSONNumber.Create(Value));
  Result := Self;
end;

function TCustomJSONJSONObject.AddJson(Name, Value: String): ICustomJSON;
begin
  if Value.Trim <> '' then
    if Value.Trim = 'null' then
      FJSONObj.AddPair(Name, TJSONNull.Create)
    else
      FJSONObj.AddPair(Name, TJSONObject.ParseJSONValue(TEncoding.UTF8.GetBytes(Value), 0)
        as TJSONValue);

  Result := Self;
end;

function TCustomJSONJSONObject.AddString(Name: String; Value: String; AddEmpty: Boolean)
  : ICustomJSON;
begin
  if Value.Trim <> '' then
  begin
    if Value.Trim = 'null' then
      FJSONObj.AddPair(Name, TJSONNull.Create)
    else
      FJSONObj.AddPair(Name, TJSONString.Create(Value));
  end
  else if AddEmpty then
    FJSONObj.AddPair(Name, TJSONString.Create(Value));

  Result := Self;
end;

constructor TCustomJSONJSONObject.Create;
begin
  FJSONObj := TJSONObject.Create;
end;

destructor TCustomJSONJSONObject.Destroy;
begin
  if Assigned(FJSONObj) then
    FreeAndNil(FJSONObj);

  inherited;
end;

function TCustomJSONJSONObject.ToJsonString: String;
begin
  Result := FJSONObj.ToString;
end;

end.
