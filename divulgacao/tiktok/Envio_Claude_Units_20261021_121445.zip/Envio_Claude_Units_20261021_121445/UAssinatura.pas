unit UAssinatura;

interface

uses
  System.SysUtils;

type
  TFormaPagamentoAssinatura = (fpaBoleto, fpaCartao);
  TPeriodicidadeAssinatura = (paMensal, paTrimestral, paSemestral, paAnual);

  TDadosCartaoAssinatura = class
  private
    FAnoExpiracao: Integer;
    FNumero: String;
    FCodigoSeguranca: String;
    FNomeTitular: String;
    FMesExpiracao: Integer;

    procedure SetAnoExpiracao(const Value: Integer);
    procedure SetCodigoSeguranca(const Value: String);
    procedure SetMesExpiracao(const Value: Integer);
    procedure SetNomeTitular(const Value: String);
    procedure SetNumero(const Value: String);
  public
    property NomeTitular: String read FNomeTitular write SetNomeTitular;
    property Numero: String read FNumero write SetNumero;
    property MesExpiracao: Integer read FMesExpiracao write SetMesExpiracao;
    property AnoExpiracao: Integer read FAnoExpiracao write SetAnoExpiracao;
    property CodigoSeguranca: String read FCodigoSeguranca write SetCodigoSeguranca;

    constructor Create; virtual;
  end;

  TDadosTitularCartaoAssinatura = class
  private
    FBairro: String;
    FEmail: String;
    FCEP: String;
    FCPFCNPJ: String;
    FNumero: String;
    FComplemento: String;
    FNome: String;
    FEndereco: String;
    FTelefone: String;
    FCelular: String;

    procedure SetBairro(const Value: String);
    procedure SetCelular(const Value: String);
    procedure SetCEP(const Value: String);
    procedure SetComplemento(const Value: String);
    procedure SetCPFCNPJ(const Value: String);
    procedure SetEmail(const Value: String);
    procedure SetEndereco(const Value: String);
    procedure SetNome(const Value: String);
    procedure SetNumero(const Value: String);
    procedure SetTelefone(const Value: String);
  public
    property Nome: String read FNome write SetNome;
    property Email: String read FEmail write SetEmail;
    property CPFCNPJ: String read FCPFCNPJ write SetCPFCNPJ;
    property Endereco: String read FEndereco write SetEndereco;
    property Numero: String read FNumero write SetNumero;
    property Bairro: String read FBairro write SetBairro;
    property CEP: String read FCEP write SetCEP;
    property Complemento: String read FComplemento write SetComplemento;
    property Telefone: String read FTelefone write SetTelefone;
    property Celular: String read FCelular write SetCelular;
  end;

  TAssinatura = class
  private
    FValor: Currency;
    FDiaVencimento: Integer;
    FFormaPagamento: TFormaPagamentoAssinatura;
    FPeriodicidade: TPeriodicidadeAssinatura;
    FId: Integer;
    FIdAPI: String;
    FCodigoCliente: Integer;
    FDataHoraCriacao: TDateTime;
    FCodigoClienteAPI: String;
    FDescricao: String;
    FDataPrimeiroVencimento: TDate;
    FTokenCartao: String;
    FBandeiraCartao: String;
    FUltimosQuatroDigitosCartao: Integer;
    FControladaPorLicenca: Boolean;

    procedure SetCodigoCliente(const Value: Integer);
    procedure SetDataHoraCriacao(const Value: TDateTime);
    procedure SetDiaVencimento(const Value: Integer);
    procedure SetFormaPagamento(const Value: TFormaPagamentoAssinatura);
    procedure SetId(const Value: Integer);
    procedure SetIdAPI(const Value: String);
    procedure SetPeriodicidade(const Value: TPeriodicidadeAssinatura);
    procedure SetValor(const Value: Currency);
    procedure SetCodigoClienteAPI(const Value: String);
    procedure SetDescricao(const Value: String);
    procedure SetDataPrimeiroVencimento(const Value: TDate);
    procedure SetBandeiraCartao(const Value: String);
    procedure SetTokenCartao(const Value: String);
    procedure SetUltimosQuatroDigitosCartao(const Value: Integer);
  public
    property Id: Integer read FId write SetId;
    property IdAPI: String read FIdAPI write SetIdAPI;
    property DataHoraCriacao: TDateTime read FDataHoraCriacao write SetDataHoraCriacao;
    property CodigoCliente: Integer read FCodigoCliente write SetCodigoCliente;
    property CodigoClienteAPI: String read FCodigoClienteAPI write SetCodigoClienteAPI;
    property FormaPagamento: TFormaPagamentoAssinatura read FFormaPagamento write SetFormaPagamento;
    property Valor: Currency read FValor write SetValor;
    property DiaVencimento: Integer read FDiaVencimento write SetDiaVencimento;
    property DataPrimeiroVencimento: TDate read FDataPrimeiroVencimento
      write SetDataPrimeiroVencimento;
    property Periodicidade: TPeriodicidadeAssinatura read FPeriodicidade write SetPeriodicidade;
    property Descricao: String read FDescricao write SetDescricao;
    property UltimosQuatroDigitosCartao: Integer read FUltimosQuatroDigitosCartao
      write SetUltimosQuatroDigitosCartao;
    property BandeiraCartao: String read FBandeiraCartao write SetBandeiraCartao;
    property TokenCartao: String read FTokenCartao write SetTokenCartao;
    property ControladaPorLicenca: Boolean read FControladaPorLicenca write FControladaPorLicenca;

    constructor Create; virtual;
    function Clone: TAssinatura;

    procedure IntToFormaPagamento(Value: Integer);
    procedure IntToPeriodicidade(Value: Integer);
  end;

implementation

{ TAssinatura }

function TAssinatura.Clone: TAssinatura;
begin
  Result := TAssinatura.Create;

  Result.Id := FId;
  Result.IdAPI := FIdAPI;
  Result.DataHoraCriacao := FDataHoraCriacao;
  Result.CodigoCliente := FCodigoCliente;
  Result.CodigoClienteAPI := FCodigoClienteAPI;
  Result.FormaPagamento := FFormaPagamento;
  Result.Valor := FValor;
  Result.DiaVencimento := FDiaVencimento;
  Result.DataPrimeiroVencimento := FDataPrimeiroVencimento;
  Result.Periodicidade := FPeriodicidade;
  Result.Descricao := FDescricao;
  Result.UltimosQuatroDigitosCartao := FUltimosQuatroDigitosCartao;
  Result.BandeiraCartao := FBandeiraCartao;
  Result.TokenCartao := FTokenCartao;
  Result.ControladaPorLicenca := FControladaPorLicenca;
end;

constructor TAssinatura.Create;
begin
  FId := 0;
  FDataHoraCriacao := Now;
  FCodigoCliente := 0;
  FFormaPagamento := fpaBoleto;
  FValor := 0;
  FDiaVencimento := 0;
  FDataPrimeiroVencimento := 0;
  FPeriodicidade := paMensal;
  FUltimosQuatroDigitosCartao := 0;
  FControladaPorLicenca := False;
end;

procedure TAssinatura.IntToFormaPagamento(Value: Integer);
begin
  FFormaPagamento := fpaBoleto;

  if Value = 1 then
    FFormaPagamento := fpaCartao;
end;

procedure TAssinatura.IntToPeriodicidade(Value: Integer);
begin
  case Value of
    1:
      FPeriodicidade := paTrimestral;
    2:
      FPeriodicidade := paSemestral;
    3:
      FPeriodicidade := paAnual;
  else
    FPeriodicidade := paMensal;
  end;
end;

procedure TAssinatura.SetBandeiraCartao(const Value: String);
begin
  FBandeiraCartao := Value;
end;

procedure TAssinatura.SetCodigoCliente(const Value: Integer);
begin
  FCodigoCliente := Value;
end;

procedure TAssinatura.SetCodigoClienteAPI(const Value: String);
begin
  FCodigoClienteAPI := Value;
end;

procedure TAssinatura.SetDataHoraCriacao(const Value: TDateTime);
begin
  FDataHoraCriacao := Value;
end;

procedure TAssinatura.SetDataPrimeiroVencimento(const Value: TDate);
begin
  FDataPrimeiroVencimento := Value;
end;

procedure TAssinatura.SetDescricao(const Value: String);
begin
  FDescricao := Value;
end;

procedure TAssinatura.SetDiaVencimento(const Value: Integer);
begin
  FDiaVencimento := Value;
end;

procedure TAssinatura.SetFormaPagamento(const Value: TFormaPagamentoAssinatura);
begin
  FFormaPagamento := Value;
end;

procedure TAssinatura.SetId(const Value: Integer);
begin
  FId := Value;
end;

procedure TAssinatura.SetIdAPI(const Value: String);
begin
  FIdAPI := Value;
end;

procedure TAssinatura.SetPeriodicidade(const Value: TPeriodicidadeAssinatura);
begin
  FPeriodicidade := Value;
end;

procedure TAssinatura.SetTokenCartao(const Value: String);
begin
  FTokenCartao := Value;
end;

procedure TAssinatura.SetUltimosQuatroDigitosCartao(const Value: Integer);
begin
  FUltimosQuatroDigitosCartao := Value;
end;

procedure TAssinatura.SetValor(const Value: Currency);
begin
  FValor := Value;
end;

{ TDadosCartaoAssinatura }

constructor TDadosCartaoAssinatura.Create;
begin
  FMesExpiracao := 0;
  FAnoExpiracao := 0;
end;

procedure TDadosCartaoAssinatura.SetAnoExpiracao(const Value: Integer);
begin
  FAnoExpiracao := Value;
end;

procedure TDadosCartaoAssinatura.SetCodigoSeguranca(const Value: String);
begin
  FCodigoSeguranca := Value;
end;

procedure TDadosCartaoAssinatura.SetMesExpiracao(const Value: Integer);
begin
  FMesExpiracao := Value;
end;

procedure TDadosCartaoAssinatura.SetNomeTitular(const Value: String);
begin
  FNomeTitular := Value;
end;

procedure TDadosCartaoAssinatura.SetNumero(const Value: String);
begin
  FNumero := Value;
end;

{ TDadosTitularCartaoAssinatura }

procedure TDadosTitularCartaoAssinatura.SetBairro(const Value: String);
begin
  FBairro := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetCelular(const Value: String);
begin
  FCelular := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetCEP(const Value: String);
begin
  FCEP := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetComplemento(const Value: String);
begin
  FComplemento := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetCPFCNPJ(const Value: String);
begin
  FCPFCNPJ := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetEmail(const Value: String);
begin
  FEmail := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetEndereco(const Value: String);
begin
  FEndereco := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetNome(const Value: String);
begin
  FNome := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetNumero(const Value: String);
begin
  FNumero := Value;
end;

procedure TDadosTitularCartaoAssinatura.SetTelefone(const Value: String);
begin
  FTelefone := Value;
end;

end.
