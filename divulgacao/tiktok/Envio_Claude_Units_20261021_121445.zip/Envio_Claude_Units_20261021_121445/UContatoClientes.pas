unit UContatoClientes;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, AdvGlowButton, Vcl.ExtCtrls, Data.DB,
  Vcl.StdCtrls, Vcl.Grids, Vcl.DBGrids, AlignEdit, Vcl.ComCtrls,
  FireDAC.Stan.Intf, FireDAC.Stan.Option, FireDAC.Stan.Param,
  FireDAC.Stan.Error, FireDAC.DatS, FireDAC.Phys.Intf, FireDAC.DApt.Intf,
  FireDAC.Stan.Async, FireDAC.DApt, FireDAC.Comp.DataSet, FireDAC.Comp.Client,
  Vcl.Menus;

type
  TFrmContatoCliente = class(TForm)
    Panel9: TPanel;
    AdvGlowButton4: TAdvGlowButton;
    pgDadoscli: TPageControl;
    TabSheet2: TTabSheet;
    GroupBox22: TGroupBox;
    Telefone: TLabel;
    Label11: TLabel;
    Label14: TLabel;
    edtTelefonePrincip: TAlignEdit;
    EdtCelPrincip: TAlignEdit;
    edtemailPrincp: TAlignEdit;
    GroupBox2: TGroupBox;
    Label27: TLabel;
    edtnomecliContato: TAlignEdit;
    edtCodcliContato: TAlignEdit;
    DBGPesqClienteContato: TDBGrid;
    TabSheet5: TTabSheet;
    Panel12: TPanel;
    Label17: TLabel;
    Label18: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    edtNomeContato: TAlignEdit;
    edtTelefoneContato: TAlignEdit;
    btnSalvarContato: TAdvGlowButton;
    EdtEmailContato: TAlignEdit;
    edtSetor: TAlignEdit;
    DBGrid3: TDBGrid;
    TabSheet8: TTabSheet;
    MObsCliente: TMemo;
    FDQConsCli: TFDQuery;
    FDQConsClicod_cli: TIntegerField;
    FDQConsCliNOME_FANTASIA: TStringField;
    FDQConsCliNOME_CLI: TStringField;
    FDQConsCliCNPJ_CLI: TStringField;
    FDQConsCliCIDRES_CLI: TStringField;
    FDQConsCliATIVO: TStringField;
    FDQConsCliBLOQUEADO_CLI: TStringField;
    FDQConsCliEMAIL_CLI: TStringField;
    FDQConsCliCELULAR_CLI: TStringField;
    FDQConsCliTELRES_CLI: TStringField;
    FDQConsCliCATEGORIA_CLI: TStringField;
    dsConsCli: TDataSource;
    PopDeletaContato: TPopupMenu;
    MenuItem1: TMenuItem;
    dsContatoCli: TDataSource;
    TabSheet1: TTabSheet;
    MEndereco: TMemo;
    FDQConsCliENDRES_CLI: TStringField;
    FDQConsCliBAIRES_CLI: TStringField;
    FDQConsCliNUMERORES_CLI: TStringField;
    FDQConsCliESTRES_CLI: TStringField;
    FDQConsCliCEPRES_CLI: TStringField;
    FDQConsCliPONTO_REFERENCIA: TStringField;
    FDQConsCliOBS_VENDA: TMemoField;
    FDQConsCliOBS_CLI: TStringField;
    procedure edtnomecliContatoChange(Sender: TObject);
    procedure edtnomecliContatoEnter(Sender: TObject);
    procedure edtnomecliContatoExit(Sender: TObject);
    procedure DBGPesqClienteContatoDblClick(Sender: TObject);
    procedure DBGPesqClienteContatoDrawColumnCell(Sender: TObject;
      const Rect: TRect; DataCol: Integer; Column: TColumn;
      State: TGridDrawState);
    procedure DBGPesqClienteContatoExit(Sender: TObject);
    procedure DBGPesqClienteContatoKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure DBGPesqClienteContatoKeyPress(Sender: TObject; var Key: Char);
    procedure AdvGlowButton4Click(Sender: TObject);
    procedure BuscaClienteContato(istatus: Integer);
    procedure btnSalvarContatoClick(Sender: TObject);
    procedure DBGrid3DrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure MenuItem1Click(Sender: TObject);
    procedure LimpaContato;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure FormShow(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FrmContatoCliente: TFrmContatoCliente;

implementation

uses
  Udm;

{$R *.dfm}

procedure TFrmContatoCliente.AdvGlowButton4Click(Sender: TObject);
begin
  close;
end;

procedure TFrmContatoCliente.btnSalvarContatoClick(Sender: TObject);
begin
  { Salva Dados }
  if trim(edtNomeContato.text) = '' then
  begin
    showmessage(dm.sNomeUsu + ', Informe o Nome do Contato');
    edtNomeContato.setfocus;
    exit;
  end;

  if trim(edtTelefoneContato.text) = '' then
  begin
    showmessage(dm.sNomeUsu + ', Informe o Telefone do Contato');
    edtTelefoneContato.setfocus;
    exit;
  end;

  if dm.FDTInsertFB.Active then
    dm.FDTInsertFB.Commit;
  dm.FDTInsertFB.StartTransaction;

  with dm.FDQInsertFB do
  begin
    close;
    sql.clear;
    sql.add('INSERT INTO CONTATOS (COD_CLI, DESCRICAO, SETOR, NUMERO,EMAIL) ' +
      'VALUES (:COD_CLI, :DESCRICAO, :SETOR, :NUMERO,:EMAIL)');
    parambyname('COD_CLI').asinteger := strtoint(edtCodcliContato.text);
    parambyname('DESCRICAO').asstring := trim(edtNomeContato.text);
    parambyname('SETOR').asstring := trim(edtSetor.text);
    parambyname('NUMERO').asstring := trim(edtTelefoneContato.text);
    parambyname('EMAIL').asstring := trim(EdtEmailContato.text);
    execsql;
  end;
  dm.FDTInsertFB.Commit;

  showmessage(dm.sNomeUsu + ', Contato Salvo Com Sucesso');
  LimpaContato;

  if trim(edtCodcliContato.text) <> '' then
    dm.BuscaContatoCli(strtoint(edtCodcliContato.text));
end;

procedure TFrmContatoCliente.BuscaClienteContato(istatus: Integer);
var
  sCnpj: string;
begin
  sCnpj := dm.FormataCNPJ(trim(edtnomecliContato.text));
  if istatus = 0 then
  begin
    if (trim(edtnomecliContato.text) <> '') then
    begin
      with FDQConsCli do
      begin
        DisableControls;
        close;
        sql.clear;
        sql.text :=
          ' SELECT cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI,CIDRES_CLI,ATIVO,BLOQUEADO_CLI,EMAIL_CLI,CELULAR_CLI,TELRES_CLI,c.OBS_VENDA,c.OBS_CLI,CATEGORIA_CLI, '
          + '       c.ENDRES_CLI,c.BAIRES_CLI,c.NUMERORES_CLI,c.ESTRES_CLI,c.CEPRES_CLI,c.PONTO_REFERENCIA    '
          + '  FROM cliente c ';
        if dm.ipontoRevenda > 1 then
        begin
          sql.add(' where (c.cod_ponto_revenda = :COD_PONTO or  c.cod_cli = 1 or c.cod_cli = 0 )');
          parambyname('COD_PONTO').asstring := INTTOSTR(dm.ipontoRevenda);
          sql.add(' and (   nome_cli like ' + #39 + '%' +
            trim(edtnomecliContato.text) + '%' + #39 +
            '  or  nome_fantasia like ' + #39 + '%' +
            trim(edtnomecliContato.text) + '%' + #39 + ' ');
        end
        else
        begin
          sql.add(' where   nome_cli like ' + #39 + '%' +
            trim(edtnomecliContato.text) + '%' + #39 +
            '  or  nome_fantasia like ' + #39 + '%' +
            trim(edtnomecliContato.text) + '%' + #39 + ' ');
        end;

        if Length(sCnpj) >= 11 then
          sql.add(' or  CNPJ_CLI like ' + #39 + '%' + sCnpj + '%' + #39 + ' ');

        if dm.ipontoRevenda > 1 then
          sql.add(' )');
        sql.add('and c.ATIVO = ' + #39 + 'S' + #39 + '   ' + '  ');
        open;
        EnableControls;

        if FDQConsCli.recordcount <= 0 then
        begin

        end
        else
        begin
          DBGPesqClienteContato.enabled := true;
          DBGPesqClienteContato.BringToFront;
          edtTelefonePrincip.text := FDQConsCliTELRES_CLI.asstring;
          EdtCelPrincip.text := FDQConsCliCELULAR_CLI.asstring;
          edtemailPrincp.text := FDQConsCliEMAIL_CLI.asstring;
          dm.BuscaContatoCli(FDQConsClicod_cli.asinteger);
          MObsCliente.lines.add(FDQConsCliOBS_CLI.asstring);
          MObsCliente.lines.add(FDQConsCliOBS_VENDA.asstring);
          MEndereco.lines.add('ENDERE�O: ' + FDQConsCliENDRES_CLI.asstring +
            '  - N�: ' + FDQConsCliNUMERORES_CLI.asstring);
          MEndereco.lines.add('BAIRRO: ' + FDQConsCliBAIRES_CLI.asstring);
          MEndereco.lines.add('CIDADE: ' + FDQConsCliCIDRES_CLI.asstring);
          MEndereco.lines.add('ESTADO: ' + FDQConsCliESTRES_CLI.asstring);
          MEndereco.lines.add('PONTO DE REFER�NCIA: ' + FDQConsCliPONTO_REFERENCIA.asstring);
        end;
      end;

    end;

  end
  else
  begin

    if (trim(edtnomecliContato.text) <> '') then
    begin
      with FDQConsCli do
      begin
        DisableControls;
        close;
        sql.clear;
        sql.text := ' SELECT cod_cli,NOME_FANTASIA,NOME_CLI,CNPJ_CLI, ' +
          ' CIDRES_CLI,ATIVO,BLOQUEADO_CLI,EMAIL_CLI,CELULAR_CLI,TELRES_CLI,c.OBS_VENDA,c.OBS_CLI,CATEGORIA_CLI, '
          + ' c.ENDRES_CLI,c.BAIRES_CLI,c.NUMERORES_CLI,c.ESTRES_CLI,c.CEPRES_CLI,c.PONTO_REFERENCIA   '
          + ' FROM cliente c  ';
        if dm.ipontoRevenda > 1 then
        begin
          sql.add(' where (c.cod_ponto_revenda = :COD_PONTO or  c.cod_cli = 1 or c.cod_cli = 0 )');
          parambyname('COD_PONTO').asstring := INTTOSTR(dm.ipontoRevenda);
          sql.add(' and cod_cli = ' + trim(edtCodcliContato.text) + ' ');
        end
        else
        begin
          sql.add(' where cod_cli = ' + trim(edtCodcliContato.text) + ' ');
        end;
        sql.add('and c.ATIVO = ' + #39 + 'S' + #39 + '   ' + '  ');
        open;
        last;
        first;

        EnableControls;

        if FDQConsCli.recordcount <= 0 then
        begin

        end
        else
        begin
          DBGPesqClienteContato.enabled := true;
          DBGPesqClienteContato.BringToFront;
          edtTelefonePrincip.text := FDQConsCliTELRES_CLI.asstring;
          EdtCelPrincip.text := FDQConsCliCELULAR_CLI.asstring;
          edtemailPrincp.text := FDQConsCliEMAIL_CLI.asstring;
          dm.BuscaContatoCli(FDQConsClicod_cli.asinteger);
          MObsCliente.lines.add(FDQConsCliOBS_CLI.asstring);
          MObsCliente.lines.add(FDQConsCliOBS_VENDA.asstring);
        end;
      end;

    end;
  end;

end;

procedure TFrmContatoCliente.DBGPesqClienteContatoDblClick(Sender: TObject);
begin
  if FDQConsClicod_cli.asstring <> '' then
  begin
    edtCodcliContato.text := FDQConsClicod_cli.asstring;
    edtnomecliContato.text := FDQConsCliNOME_FANTASIA.asstring;
    DBGPesqClienteContato.enabled := false;
  end;
end;

procedure TFrmContatoCliente.DBGPesqClienteContatoDrawColumnCell
  (Sender: TObject; const Rect: TRect; DataCol: Integer; Column: TColumn;
  State: TGridDrawState);
begin
  { Muda a Cor da Linha Caso Esteja Selecionada e Deixa a Grid com Cor Zebrada }
  if Odd(FDQConsCli.RecNo) then
    TDBGrid(Sender).Canvas.Brush.Color :=
      clInactiveCaption { Primeira Cor da Linha }
  else
    TDBGrid(Sender).Canvas.Brush.Color := clBtnFace;
  { Segunda Cor da Linha }

  TDBGrid(Sender).Canvas.Font.Color := clblack; { Cor da Fonte }

  if gdSelected in State then
  begin
    with (Sender as TDBGrid).Canvas do
    begin
      Brush.Color := clScrollBar;
      { Aqui � Definido a Cor de Fundo }
      FillRect(Rect);
    end;
  end;

  TDBGrid(Sender).DefaultDrawDataCell(Rect, TDBGrid(Sender).columns[DataCol]
    .Field, State);

  { Verifica se o Cliente est� Bloqueado }
  if trim(FDQConsCliBLOQUEADO_CLI.asstring) = 'S' then
  begin
    DBGPesqClienteContato.Canvas.Brush.Color := clred;
  end;

  { Verifica se o Cliente est� Ativo }
  if trim(FDQConsCliATIVO.asstring) = 'N' then
  begin
    DBGPesqClienteContato.Canvas.Brush.Color := clred;
  end;
end;

procedure TFrmContatoCliente.DBGPesqClienteContatoExit(Sender: TObject);
begin
  DBGPesqClienteContato.enabled := false;
  edtCodcliContato.text := FDQConsClicod_cli.asstring;
  BuscaClienteContato(1);
end;

procedure TFrmContatoCliente.DBGPesqClienteContatoKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  if (Key = vk_escape) then
    DBGPesqClienteContato.enabled := false;
end;

procedure TFrmContatoCliente.DBGPesqClienteContatoKeyPress(Sender: TObject;
  var Key: Char);
begin
  if Key = #13 then
  begin
    if FDQConsClicod_cli.asstring <> '' then
    begin
      edtCodcliContato.text := FDQConsClicod_cli.asstring;
      edtnomecliContato.text := FDQConsCliNOME_FANTASIA.asstring;
      DBGPesqClienteContato.enabled := false;

    end;
  end;
end;

procedure TFrmContatoCliente.DBGrid3DrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn; State: TGridDrawState);
begin
  { Muda a Cor da Linha Caso Esteja Selecionada e Deixa a Grid com Cor Zebrada }
  if Odd(dm.FDQContatoCli.RecNo) then
    TDBGrid(Sender).Canvas.Brush.Color :=
      clInactiveCaption { Primeira Cor da Linha }
  else
    TDBGrid(Sender).Canvas.Brush.Color := clBtnFace;
  { Segunda Cor da Linha }

  TDBGrid(Sender).Canvas.Font.Color := clblack; { Cor da Fonte }

  if gdSelected in State then
  begin
    with (Sender as TDBGrid).Canvas do
    begin
      Brush.Color := clScrollBar;
      { Aqui � Definido a Cor de Fundo }
      FillRect(Rect);
    end;
  end;

  TDBGrid(Sender).DefaultDrawDataCell(Rect, TDBGrid(Sender).columns[DataCol]
    .Field, State);
end;

procedure TFrmContatoCliente.edtnomecliContatoChange(Sender: TObject);
begin
  if (edtnomecliContato.focused) then
    BuscaClienteContato(0);
end;

procedure TFrmContatoCliente.edtnomecliContatoEnter(Sender: TObject);
begin
  edtnomecliContato.selectall;
end;

procedure TFrmContatoCliente.edtnomecliContatoExit(Sender: TObject);
begin
  if trim(edtnomecliContato.text) = '' then
    edtCodcliContato.clear;

  if FDQConsCli.recordcount <= 0 then
  begin
    FDQConsCli.close;
    edtCodcliContato.clear;
    edtnomecliContato.clear;
  end;

  MObsCliente.lines.add(FDQConsCliOBS_VENDA.asstring);
  MObsCliente.lines.add('');
  MObsCliente.lines.add(FDQConsCliOBS_CLI.asstring);

  if DBGPesqClienteContato.enabled = true then
    DBGPesqClienteContato.setfocus;
end;

procedure TFrmContatoCliente.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  FrmContatoCliente := nil;
  Action := caFree;
end;

procedure TFrmContatoCliente.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if Key = vk_escape then
  begin
    close;
  end;

end;

procedure TFrmContatoCliente.FormKeyPress(Sender: TObject; var Key: Char);
begin
  if Key = #13 then
  begin
    Key := #0;
    SelectNext(ActiveControl, true, true);
  end;

end;

procedure TFrmContatoCliente.FormShow(Sender: TObject);
begin
  BuscaClienteContato(0);
end;

procedure TFrmContatoCliente.LimpaContato;
begin
  edtNomeContato.clear;
  edtTelefoneContato.clear;
  edtSetor.clear;
  EdtEmailContato.clear;
end;

procedure TFrmContatoCliente.MenuItem1Click(Sender: TObject);
begin
  if dm.FDTInsertFB.Active then
    dm.FDTInsertFB.Commit;
  dm.FDTInsertFB.StartTransaction;

  with dm.FDQInsertFB do
  begin
    close;
    sql.clear;
    sql.add('delete from contatos c ' + ' where c.codigo = :codigo');
    parambyname('codigo').asinteger := dm.FDQContatoCliCODIGO.asinteger;
    execsql;
  end;
  dm.FDTInsertFB.Commit;
  LimpaContato;

  if trim(edtCodcliContato.text) <> '' then
    dm.BuscaContatoCli(strtoint(edtCodcliContato.text));
end;

end.
