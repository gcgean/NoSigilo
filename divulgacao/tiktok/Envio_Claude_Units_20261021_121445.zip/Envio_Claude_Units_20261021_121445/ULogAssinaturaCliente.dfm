object FrmLogAssinaturaCliente: TFrmLogAssinaturaCliente
  Left = 0
  Top = 0
  BorderIcons = [biSystemMenu, biMaximize]
  Caption = 'Log de Assinatura do Cliente'
  ClientHeight = 496
  ClientWidth = 866
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  WindowState = wsMaximized
  OnClose = FormClose
  OnCreate = FormCreate
  OnKeyDown = FormKeyDown
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object GLog: TcxGrid
    Left = 0
    Top = 0
    Width = 866
    Height = 496
    Align = alClient
    BorderStyle = cxcbsNone
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    LockedStateImageOptions.Text = 'Por favor aguarde...'
    LookAndFeel.Kind = lfUltraFlat
    LookAndFeel.NativeStyle = True
    LookAndFeel.ScrollbarMode = sbmDefault
    LookAndFeel.SkinName = ''
    ExplicitLeft = -125
    ExplicitWidth = 991
    ExplicitHeight = 385
    object GLogDBTableView: TcxGridDBTableView
      Navigator.Buttons.CustomButtons = <>
      Navigator.Buttons.First.Visible = True
      Navigator.Buttons.PriorPage.Visible = False
      Navigator.Buttons.Prior.Visible = True
      Navigator.Buttons.Next.Visible = True
      Navigator.Buttons.NextPage.Visible = False
      Navigator.Buttons.Last.Visible = True
      Navigator.Buttons.Insert.Visible = False
      Navigator.Buttons.Append.Visible = False
      Navigator.Buttons.Delete.Visible = False
      Navigator.Buttons.Edit.Visible = False
      Navigator.Buttons.Post.Visible = False
      Navigator.Buttons.Cancel.Enabled = False
      Navigator.Buttons.Cancel.Visible = True
      Navigator.Buttons.Refresh.Visible = False
      Navigator.Buttons.SaveBookmark.Visible = False
      Navigator.Buttons.GotoBookmark.Visible = False
      Navigator.Buttons.Filter.Visible = True
      Navigator.InfoPanel.DisplayMask = '[RecordIndex] de [RecordCount]'
      FindPanel.InfoText = 'Digite um texto para pesquisar...'
      DataController.DataSource = DSLog
      DataController.DetailKeyFieldNames = 'None selected'
      DataController.Filter.AutoDataSetFilter = True
      DataController.KeyFieldNames = 'id'
      DataController.Summary.DefaultGroupSummaryItems = <>
      DataController.Summary.FooterSummaryItems = <
        item
          Format = 'Qtd. Registros: #'
          Kind = skCount
          FieldName = 'cod_cli'
          DisplayText = 'Qtd. Registros: '
        end>
      DataController.Summary.SummaryGroups = <>
      FilterRow.InfoText = 'Clique aqui para definir um filtro'
      FilterRow.Visible = True
      NewItemRow.InfoText = 'Clique aqui para adicionar uma nova linha'
      OptionsCustomize.ColumnsQuickCustomization = True
      OptionsData.Deleting = False
      OptionsData.Inserting = False
      OptionsView.NoDataToDisplayInfoText = '<Nenhum registro para exibir>'
      OptionsView.Footer = True
      OptionsView.FooterAutoHeight = True
      OptionsView.HeaderFilterButtonShowMode = fbmSmartTag
      OptionsView.Indicator = True
      OptionsView.ShowColumnFilterButtons = sfbWhenSelected
      object GLogDBTableVieworigem_log: TcxGridDBColumn
        DataBinding.FieldName = 'origem_log'
        Options.Editing = False
        Width = 120
      end
      object GLogDBTableViewdata_hora: TcxGridDBColumn
        DataBinding.FieldName = 'data_hora'
        Options.Editing = False
        Width = 180
      end
      object GLogDBTableViewdesc_tipo: TcxGridDBColumn
        DataBinding.FieldName = 'desc_tipo'
        Options.Editing = False
        Width = 120
      end
      object GLogDBTableViewnome_usuario: TcxGridDBColumn
        DataBinding.FieldName = 'nome_usuario'
        Options.Editing = False
        Width = 150
      end
      object GLogDBTableViewdesc_plano_anterior: TcxGridDBColumn
        DataBinding.FieldName = 'desc_plano_anterior'
        Options.Editing = False
        Width = 250
      end
      object GLogDBTableViewqtd_plano_anterior: TcxGridDBColumn
        DataBinding.FieldName = 'qtd_plano_anterior'
        Options.Editing = False
        Width = 165
      end
      object GLogDBTableViewvalor_plano_anterior: TcxGridDBColumn
        DataBinding.FieldName = 'valor_plano_anterior'
        Options.Editing = False
        Width = 173
      end
      object GLogDBTableViewvalor_total_plano_anterior: TcxGridDBColumn
        DataBinding.FieldName = 'valor_total_plano_anterior'
        Options.Editing = False
        Width = 201
      end
      object GLogDBTableViewvalor_assinatura_anterior: TcxGridDBColumn
        DataBinding.FieldName = 'valor_assinatura_anterior'
        Options.Editing = False
        Width = 156
      end
      object GLogDBTableViewdesc_plano_atual: TcxGridDBColumn
        DataBinding.FieldName = 'desc_plano_atual'
        Options.Editing = False
        Width = 250
      end
      object GLogDBTableViewqtd_plano_atual: TcxGridDBColumn
        DataBinding.FieldName = 'qtd_plano_atual'
        Options.Editing = False
        Width = 147
      end
      object GLogDBTableViewvalor_plano_atual: TcxGridDBColumn
        DataBinding.FieldName = 'valor_plano_atual'
        Options.Editing = False
        Width = 152
      end
      object GLogDBTableViewvalor_total_plano_atual: TcxGridDBColumn
        DataBinding.FieldName = 'valor_total_plano_atual'
        Options.Editing = False
        Width = 193
      end
      object GLogDBTableViewvalor_assinatura_atual: TcxGridDBColumn
        DataBinding.FieldName = 'valor_assinatura_atual'
        Options.Editing = False
        Width = 143
      end
    end
    object GLogLevel: TcxGridLevel
      GridView = GLogDBTableView
    end
  end
  object QLog: TFDQuery
    Connection = Dm.FDConexao
    SQL.Strings = (
      'select clp.id,'
      #9'case'
      #9#9'when (clp.id_usu is null) then ('#39'COMMAND SERVER'#39')'
      #9#9'else ('#39'ANALYTICS'#39')'
      #9'end origem_log,'
      #9'clp.data_hora,'
      #9'clp.tipo,'
      #9'case'
      #9#9'clp.tipo when (0) then ('#39'INCLUS'#195'O'#39')'
      #9#9'when (1) then ('#39'ALTERA'#199#195'O'#39')'
      #9#9'else ('#39'REMO'#199#195'O'#39')'
      #9'end desc_tipo,'
      #9'clp.nome_usuario,'
      #9'clp.id_plano_anterior,'
      #9'pa.descricao desc_plano_anterior,'
      #9'clp.qtd_plano_anterior ,'
      #9'clp.valor_plano_anterior ,'
      #9'clp.valor_total_plano_anterior ,'
      #9'clp.valor_assinatura_anterior ,'
      #9'clp.id_plano_atual ,'
      #9'pn.descricao desc_plano_atual,'
      #9'clp.qtd_plano_atual ,'
      #9'clp.valor_plano_atual ,'
      #9'clp.valor_total_plano_atual ,'
      #9'clp.valor_assinatura_atual'
      'from'
      #9'cliente_log_plano clp'
      'left join planos pa on'
      #9'(clp.id_plano_anterior = pa.id)'
      'left join planos pn on'
      #9'(clp.id_plano_atual = pn.id)'
      'where'
      #9'clp.id_cli = :id_cli'
      'order by'
      #9'clp.data_hora')
    Left = 64
    Top = 104
    ParamData = <
      item
        Name = 'ID_CLI'
        DataType = ftInteger
        FDDataType = dtInt32
        ParamType = ptInput
      end>
    object QLogid: TFDAutoIncField
      FieldName = 'id'
      Origin = 'id'
      ProviderFlags = [pfInWhere, pfInKey]
    end
    object QLogorigem_log: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Origem'
      FieldName = 'origem_log'
      Origin = 'origem_log'
      ProviderFlags = []
      ReadOnly = True
      Size = 14
    end
    object QLogdata_hora: TSQLTimeStampField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Data/Hora'
      FieldName = 'data_hora'
      Origin = 'data_hora'
    end
    object QLogtipo: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'tipo'
      Origin = 'tipo'
    end
    object QLogdesc_tipo: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Tipo do Log'
      FieldName = 'desc_tipo'
      Origin = 'desc_tipo'
      ProviderFlags = []
      ReadOnly = True
      Size = 9
    end
    object QLognome_usuario: TStringField
      DisplayLabel = 'Nome do Usu'#225'rio'
      FieldName = 'nome_usuario'
      Origin = 'nome_usuario'
      Required = True
      Size = 100
    end
    object QLogid_plano_anterior: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'id_plano_anterior'
      Origin = 'id_plano_anterior'
    end
    object QLogdesc_plano_anterior: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Plano/M'#243'dulo Anterior'
      FieldName = 'desc_plano_anterior'
      Origin = 'descricao'
      ProviderFlags = []
      ReadOnly = True
      Size = 255
    end
    object QLogqtd_plano_anterior: TIntegerField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Qtd. Plano/M'#243'dulo Anterior'
      FieldName = 'qtd_plano_anterior'
      Origin = 'qtd_plano_anterior'
    end
    object QLogvalor_plano_anterior: TFMTBCDField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Valor Plano/M'#243'dulo Anterior'
      FieldName = 'valor_plano_anterior'
      Origin = 'valor_plano_anterior'
      Precision = 18
      Size = 2
    end
    object QLogvalor_total_plano_anterior: TFMTBCDField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Valor Total Plano/M'#243'dulo Anterior'
      FieldName = 'valor_total_plano_anterior'
      Origin = 'valor_total_plano_anterior'
      Precision = 18
      Size = 2
    end
    object QLogvalor_assinatura_anterior: TFMTBCDField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Valor Assinatura Anterior'
      FieldName = 'valor_assinatura_anterior'
      Origin = 'valor_assinatura_anterior'
      Precision = 18
      Size = 2
    end
    object QLogid_plano_atual: TIntegerField
      AutoGenerateValue = arDefault
      FieldName = 'id_plano_atual'
      Origin = 'id_plano_atual'
    end
    object QLogdesc_plano_atual: TStringField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Plano/M'#243'dulo Atual'
      FieldName = 'desc_plano_atual'
      Origin = 'descricao'
      ProviderFlags = []
      ReadOnly = True
      Size = 255
    end
    object QLogqtd_plano_atual: TIntegerField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Qtd. Plano/M'#243'dulo Atual'
      FieldName = 'qtd_plano_atual'
      Origin = 'qtd_plano_atual'
    end
    object QLogvalor_plano_atual: TFMTBCDField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Valor Plano/M'#243'dulo Atual'
      FieldName = 'valor_plano_atual'
      Origin = 'valor_plano_atual'
      Precision = 18
      Size = 2
    end
    object QLogvalor_total_plano_atual: TFMTBCDField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Valor Total Plano/M'#243'dulo Atual'
      FieldName = 'valor_total_plano_atual'
      Origin = 'valor_total_plano_atual'
      Precision = 18
      Size = 2
    end
    object QLogvalor_assinatura_atual: TFMTBCDField
      AutoGenerateValue = arDefault
      DisplayLabel = 'Valor Assinatura Atual'
      FieldName = 'valor_assinatura_atual'
      Origin = 'valor_assinatura_atual'
      Precision = 18
      Size = 2
    end
  end
  object DSLog: TDataSource
    AutoEdit = False
    DataSet = QLog
    Left = 128
    Top = 104
  end
end
